'use strict';var mp = function(a, b) {
  this.data = a;
  this.bn = b;
};
mp.prototype.toString = function() {
  return "[op. result, version: " + this.bn + ", resource count: " + this.data.length + "]";
};
var np = function(a, b) {
  this.ci = a;
  this.ml = b;
};
np.prototype.MG = function() {
  return this.ml;
};
var op = {hga:0, Lea:1, Kea:2, Fga:3, yha:4, xha:5, wha:6, SUCCESS:7};
var pp = {dR:0, OP:1, TIMEOUT:2, ERROR:3, Ffa:4, $da:5, iD:6, Rea:7, mea:8, KP:9, rea:10, Wga:11, Cha:12, Hga:13, Bda:14, Pea:15, pfa:16, Qha:17, Hda:18, mfa:19, gha:20, Vfa:21, nea:22, Mea:23, kga:24, lha:25, iha:26, nQ:27, sfa:28, Nha:29, Vga:30, $fa:31, Xda:32, Rda:33, Oha:34, Ega:35, Yha:36, Sha:37, ifa:38, hfa:39, jfa:40, Vha:41, Iga:42, Fea:43, Nea:44, Tha:45, Oda:46, cga:47, Cga:48, aga:49, Dga:50, wga:51, yga:52, xga:53, Aga:54, zga:55, nha:56, Qea:57, $ha:58, Ifa:59, yfa:60, Pda:61, Gda:62, 
kea:63, Cfa:64, bfa:65, $ea:66, ufa:67, cfa:68, Qda:69, Sea:70, Vda:71, bga:72, uea:73, hha:74, Yda:102};
var qp = function(a, b, c) {
  this.Ej = l(a) ? a : -1;
  this.Eg = l(b) ? b : -1;
  this.qk = l(c) ? c : -1;
};
qp.prototype.toString = function() {
  return 0 >= this.Ej && 0 >= this.Eg && 0 >= this.qk ? "Unlimited" : "Bandwidth limited between " + this.Ej + " and " + this.Eg + " starting from " + this.qk;
};
var rp = function(a, b, c, e) {
  this.kr = a;
  this.Zr = b;
  this.Iu = c;
  this.Ys = e;
};
d = rp.prototype;
d.toString = function() {
  return "DataChannelDescriptor(label=" + this.Ys + " id=" + this.kr + ", SSRC=" + this.Iu + ", format=" + this.Zr + ")";
};
d.getChannelId = function() {
  return this.kr;
};
d.Mx = function() {
  return this.Zr;
};
d.zg = function() {
  return this.Iu;
};
d.vg = function() {
  return this.Ys;
};
d.equals = function(a) {
  return null == a ? !1 : this.kr == a.kr && this.Ys == a.Ys && this.Iu == a.Iu;
};
var sp = function(a, b) {
  return t(a) ? a : l(b) ? b : -1;
};
var tp = function() {
  this.BL = v();
};
new tp;
tp.prototype.set = function(a) {
  this.BL = a;
};
tp.prototype.reset = function() {
  this.set(v());
};
tp.prototype.get = function() {
  return this.BL;
};
var up = function() {
};
var vp = {SUCCESS:0, OP:100, uga:101, Xga:102, Yga:103, oda:200, Eda:221, KP:201, Tda:202, Zda:203, Vea:204, Yea:205, Rfa:206, Sfa:207, Ufa:208, fga:209, nQ:210, qga:211, dga:222, Pha:223, sga:212, Kga:213, Jga:214, Qga:215, aha:216, cha:217, Mha:218, USER_CANCELED:219, Wha:220, Cea:224, pga:225, nga:226, Kha:227, oea:228, efa:229, Gga:230, oga:231, vfa:232, Dfa:233, Efa:234, Nga:235, gga:236, Ada:237, zda:238, Bea:239, iga:240, Nda:300, Wda:301, lea:302, zfa:303, Bfa:304, Zfa:305, bha:306, jha:307, 
sea:308, pha:309, wfa:310, Eea:311, $ga:312, Zga:313, Afa:314, qfa:315, tea:316, afa:317, aea:318, Fda:319, mga:320, rga:321, Lha:322, tfa:323, Qfa:324, Pfa:325};
var wp = function() {
  this.E1 = 3;
  this.ep = this.cr = null;
  this.pA = this.Rt = this.jL = 0;
  this.lK = 1;
  this.iu = this.Ru = this.Qu = this.Pu = this.Su = this.FO = 0;
};
d = wp.prototype;
d.hT = function() {
  this.iu = this.Ru = this.Qu = this.Pu = this.Su = 0;
};
d.K6 = function(a) {
  null == this.cr && (this.cr = a);
  if (null == this.ep || a.getTime() > this.ep.getTime()) {
    this.ep = a;
  }
};
d.HU = function() {
  return null != this.ep && null != this.cr ? (this.ep.getTime() - this.cr.getTime()) / 1000 : -1;
};
d.BR = function(a) {
  this.Su += a.tabCpuUsage;
  this.Pu += a.browserCpuUsage;
  this.Qu += a.gpuCpuUsage;
  this.Ru += a.pluginCpuUsage;
  this.iu++;
};
d.FR = function(a) {
  var b = a && a.numOfProcessors;
  if (b) {
    var c = 0, e = 0;
    if (a = a.processors) {
      for (var f = 0;f < a.length;f++) {
        var g = a[f].usage, c = c + (g.user + g.kernel), e = e + g.total;
      }
    } else {
      c = this.pA, e = this.Rt;
    }
    a = e == this.Rt ? this.jL : 100 * b * (c - this.pA) / (e - this.Rt);
    this.pA = c;
    this.Rt = e;
    this.FO = this.jL = a;
    this.lK = b;
  }
};
d.toJson = function() {
  return {jmiVersion:this.E1, numOfProcessors:this.lK, totalCpuUsage:this.FO, tabCpuUsage:this.gs(this.Su), browserCpuUsage:this.gs(this.Pu), gpuCpuUsage:this.gs(this.Qu), pluginCpuUsage:this.gs(this.Ru)};
};
d.gs = function(a) {
  return this.iu ? a / this.iu : null;
};
var xp = function(a) {
  this.Zh = a;
};
xp.prototype.b_ = Bd;
var yp = function(a) {
  for (var b = "", c = 0, e = !1, f = null, g = 0;g < a.length;g++) {
    var k = a[g];
    if (e) {
      "\\" == f ? k = null : '"' == k && (e = !1);
    } else {
      if ('"' == k) {
        e = !0;
      } else {
        if ("," == f && "," == k | "]" == k || "[" == f && "," == k) {
          b = b + a.substring(c, g) + "null", c = g;
        }
      }
    }
    f = k;
  }
  b += a.substring(c);
  return JSON.parse(b);
};
var zp = function(a, b, c, e, f, g, k, q, r, A, E) {
  this.Kw = a;
  this.qA = b;
  this.Jd = c;
  this.vA = e;
  this.Hy = f;
  this.Ja = g;
  this.co = k;
  this.xx = q;
  this.Az = r;
  this.Fp = l(A) ? A : null;
  this.Gp = l(E) ? E : null;
}, Ap = {Jha:"UDP", Bha:"TCP", rha:"SSLTCP"};
d = zp.prototype;
d.Z = function() {
  return Qb(this);
};
d.Zi = function() {
  return this.Kw;
};
d.ej = function() {
  return this.qA;
};
d.N = function() {
  return this.Jd;
};
d.yg = function() {
  return this.vA;
};
d.xl = function() {
  return this.Hy;
};
d.Wa = function() {
  return this.Ja;
};
d.rv = function(a) {
  var b = this.Z();
  b.Ja = a;
  return b;
};
d.wl = function() {
  return this.xx;
};
d.xo = function() {
  return this.Az;
};
var Bp = function(a, b, c, e, f, g, k) {
  this.da = a;
  this.Ec = b;
  this.Ea = c;
  this.Nc = l(e) ? Qb(e) : null;
  this.nf = l(f) ? f : null;
  this.$b = l(g) ? g : !0;
  this.C = l(k) ? k : null;
  this.lD = 0;
  this.fc = [];
};
d = Bp.prototype;
d.toString = function() {
  return "{participantId: " + this.da + ", sourceId: " + this.Ec + ", mediaType: " + this.Ea + ", resolution: " + (null == this.Nc ? "" : this.Nc.width + "x" + this.Nc.height) + ", frameRate: " + this.nf + ", adaptationReason: " + this.lD + ", ssrcs: " + this.fc + "}";
};
d.A = function() {
  return this.da;
};
d.P = function() {
  return this.Ea;
};
d.$c = function() {
  return this.$b;
};
d.ya = function() {
  return this.Ec;
};
d.Ub = function() {
  return null != this.Nc ? Qb(this.Nc) : null;
};
d.es = function() {
  return this.lD;
};
d.wd = function() {
  return this.fc;
};
d.s = function() {
  return this.C;
};
d.Wf = function(a) {
  return new Bp(this.da, a, this.Ea, null != this.Nc ? this.Nc : void 0, null != this.nf ? this.nf : void 0, null != this.$b ? this.$b : void 0, null != this.C ? this.C : void 0);
};
d.jn = function(a) {
  return new Bp(this.da, this.Ec, this.Ea, null != this.Nc ? this.Nc : void 0, null != this.nf ? this.nf : void 0, a, null != this.C ? this.C : void 0);
};
d.Af = function() {
  return null != this.Nc ? this.Nc.width : null;
};
d.nda = function(a) {
  return new Bp(this.da, this.Ec, this.Ea, new Ji(a, this.tf() || 0), null != this.nf ? this.nf : void 0, null != this.$b ? this.$b : void 0, null != this.C ? this.C : void 0);
};
d.tf = function() {
  return null != this.Nc ? this.Nc.height : null;
};
d.ada = function(a) {
  return new Bp(this.da, this.Ec, this.Ea, new Ji(this.Af() || 0, a), null != this.nf ? this.nf : void 0, null != this.$b ? this.$b : void 0, null != this.C ? this.C : void 0);
};
d.rf = function() {
  return this.nf;
};
d.wP = function(a) {
  return new Bp(this.da, this.Ec, this.Ea, null != this.Nc ? this.Nc : void 0, a, null != this.$b ? this.$b : void 0, null != this.C ? this.C : void 0);
};
d.yP = function(a, b) {
  var c = this;
  if (null == this.Af() || this.Af() > a) {
    c = c.nda(a);
  }
  if (null == this.tf() || this.tf() > b) {
    c = c.ada(b);
  }
  return c;
};
d.xP = function(a) {
  return null == this.rf() || this.rf() > a ? this.wP(a) : this;
};
d.matches = function(a) {
  return this.A() == a.A() && this.LJ(a);
};
d.LJ = function(a) {
  return this.P() == a.P() && this.ya() == a.ya();
};
var Cp = function() {
  this.fL = null;
  this.vM = !1;
  this.LU = this.NU = this.JU = this.KU = this.lM = !0;
  this.PU = !1;
  this.sM = this.eP = this.fP = this.QU = !0;
};
Cp.prototype.na = function() {
  return {autoGainControl:this.JU, echoCancellation:this.KU, highPassFilter:this.LU, inbandFec:this.fP, dtx:this.eP, noiseSuppression:this.NU, preferredSendCodec:this.fL, sendComfortNoise:this.lM, sendOpus:this.sM, sendStereo:this.vM, stereoSwapping:this.PU, transientSuppression:this.QU};
};
Cp.prototype.Z = function() {
  return Qb(this);
};
var Dp = function() {
  this.pc = 64;
  this.fa = Array(4);
  this.UR = Array(this.pc);
  this.Yu = this.Cn = 0;
  this.reset();
};
w(Dp, yi);
Dp.prototype.reset = function() {
  this.fa[0] = 1732584193;
  this.fa[1] = 4023233417;
  this.fa[2] = 2562383102;
  this.fa[3] = 271733878;
  this.Yu = this.Cn = 0;
};
Dp.prototype.ph = function(a, b) {
  b || (b = 0);
  var c = Array(16);
  if (p(a)) {
    for (var e = 0;16 > e;++e) {
      c[e] = a.charCodeAt(b++) | a.charCodeAt(b++) << 8 | a.charCodeAt(b++) << 16 | a.charCodeAt(b++) << 24;
    }
  } else {
    for (e = 0;16 > e;++e) {
      c[e] = a[b++] | a[b++] << 8 | a[b++] << 16 | a[b++] << 24;
    }
  }
  a = this.fa[0];
  b = this.fa[1];
  var e = this.fa[2], f = this.fa[3], g;
  g = a + (f ^ b & (e ^ f)) + c[0] + 3614090360 & 4294967295;
  a = b + (g << 7 & 4294967295 | g >>> 25);
  g = f + (e ^ a & (b ^ e)) + c[1] + 3905402710 & 4294967295;
  f = a + (g << 12 & 4294967295 | g >>> 20);
  g = e + (b ^ f & (a ^ b)) + c[2] + 606105819 & 4294967295;
  e = f + (g << 17 & 4294967295 | g >>> 15);
  g = b + (a ^ e & (f ^ a)) + c[3] + 3250441966 & 4294967295;
  b = e + (g << 22 & 4294967295 | g >>> 10);
  g = a + (f ^ b & (e ^ f)) + c[4] + 4118548399 & 4294967295;
  a = b + (g << 7 & 4294967295 | g >>> 25);
  g = f + (e ^ a & (b ^ e)) + c[5] + 1200080426 & 4294967295;
  f = a + (g << 12 & 4294967295 | g >>> 20);
  g = e + (b ^ f & (a ^ b)) + c[6] + 2821735955 & 4294967295;
  e = f + (g << 17 & 4294967295 | g >>> 15);
  g = b + (a ^ e & (f ^ a)) + c[7] + 4249261313 & 4294967295;
  b = e + (g << 22 & 4294967295 | g >>> 10);
  g = a + (f ^ b & (e ^ f)) + c[8] + 1770035416 & 4294967295;
  a = b + (g << 7 & 4294967295 | g >>> 25);
  g = f + (e ^ a & (b ^ e)) + c[9] + 2336552879 & 4294967295;
  f = a + (g << 12 & 4294967295 | g >>> 20);
  g = e + (b ^ f & (a ^ b)) + c[10] + 4294925233 & 4294967295;
  e = f + (g << 17 & 4294967295 | g >>> 15);
  g = b + (a ^ e & (f ^ a)) + c[11] + 2304563134 & 4294967295;
  b = e + (g << 22 & 4294967295 | g >>> 10);
  g = a + (f ^ b & (e ^ f)) + c[12] + 1804603682 & 4294967295;
  a = b + (g << 7 & 4294967295 | g >>> 25);
  g = f + (e ^ a & (b ^ e)) + c[13] + 4254626195 & 4294967295;
  f = a + (g << 12 & 4294967295 | g >>> 20);
  g = e + (b ^ f & (a ^ b)) + c[14] + 2792965006 & 4294967295;
  e = f + (g << 17 & 4294967295 | g >>> 15);
  g = b + (a ^ e & (f ^ a)) + c[15] + 1236535329 & 4294967295;
  b = e + (g << 22 & 4294967295 | g >>> 10);
  g = a + (e ^ f & (b ^ e)) + c[1] + 4129170786 & 4294967295;
  a = b + (g << 5 & 4294967295 | g >>> 27);
  g = f + (b ^ e & (a ^ b)) + c[6] + 3225465664 & 4294967295;
  f = a + (g << 9 & 4294967295 | g >>> 23);
  g = e + (a ^ b & (f ^ a)) + c[11] + 643717713 & 4294967295;
  e = f + (g << 14 & 4294967295 | g >>> 18);
  g = b + (f ^ a & (e ^ f)) + c[0] + 3921069994 & 4294967295;
  b = e + (g << 20 & 4294967295 | g >>> 12);
  g = a + (e ^ f & (b ^ e)) + c[5] + 3593408605 & 4294967295;
  a = b + (g << 5 & 4294967295 | g >>> 27);
  g = f + (b ^ e & (a ^ b)) + c[10] + 38016083 & 4294967295;
  f = a + (g << 9 & 4294967295 | g >>> 23);
  g = e + (a ^ b & (f ^ a)) + c[15] + 3634488961 & 4294967295;
  e = f + (g << 14 & 4294967295 | g >>> 18);
  g = b + (f ^ a & (e ^ f)) + c[4] + 3889429448 & 4294967295;
  b = e + (g << 20 & 4294967295 | g >>> 12);
  g = a + (e ^ f & (b ^ e)) + c[9] + 568446438 & 4294967295;
  a = b + (g << 5 & 4294967295 | g >>> 27);
  g = f + (b ^ e & (a ^ b)) + c[14] + 3275163606 & 4294967295;
  f = a + (g << 9 & 4294967295 | g >>> 23);
  g = e + (a ^ b & (f ^ a)) + c[3] + 4107603335 & 4294967295;
  e = f + (g << 14 & 4294967295 | g >>> 18);
  g = b + (f ^ a & (e ^ f)) + c[8] + 1163531501 & 4294967295;
  b = e + (g << 20 & 4294967295 | g >>> 12);
  g = a + (e ^ f & (b ^ e)) + c[13] + 2850285829 & 4294967295;
  a = b + (g << 5 & 4294967295 | g >>> 27);
  g = f + (b ^ e & (a ^ b)) + c[2] + 4243563512 & 4294967295;
  f = a + (g << 9 & 4294967295 | g >>> 23);
  g = e + (a ^ b & (f ^ a)) + c[7] + 1735328473 & 4294967295;
  e = f + (g << 14 & 4294967295 | g >>> 18);
  g = b + (f ^ a & (e ^ f)) + c[12] + 2368359562 & 4294967295;
  b = e + (g << 20 & 4294967295 | g >>> 12);
  g = a + (b ^ e ^ f) + c[5] + 4294588738 & 4294967295;
  a = b + (g << 4 & 4294967295 | g >>> 28);
  g = f + (a ^ b ^ e) + c[8] + 2272392833 & 4294967295;
  f = a + (g << 11 & 4294967295 | g >>> 21);
  g = e + (f ^ a ^ b) + c[11] + 1839030562 & 4294967295;
  e = f + (g << 16 & 4294967295 | g >>> 16);
  g = b + (e ^ f ^ a) + c[14] + 4259657740 & 4294967295;
  b = e + (g << 23 & 4294967295 | g >>> 9);
  g = a + (b ^ e ^ f) + c[1] + 2763975236 & 4294967295;
  a = b + (g << 4 & 4294967295 | g >>> 28);
  g = f + (a ^ b ^ e) + c[4] + 1272893353 & 4294967295;
  f = a + (g << 11 & 4294967295 | g >>> 21);
  g = e + (f ^ a ^ b) + c[7] + 4139469664 & 4294967295;
  e = f + (g << 16 & 4294967295 | g >>> 16);
  g = b + (e ^ f ^ a) + c[10] + 3200236656 & 4294967295;
  b = e + (g << 23 & 4294967295 | g >>> 9);
  g = a + (b ^ e ^ f) + c[13] + 681279174 & 4294967295;
  a = b + (g << 4 & 4294967295 | g >>> 28);
  g = f + (a ^ b ^ e) + c[0] + 3936430074 & 4294967295;
  f = a + (g << 11 & 4294967295 | g >>> 21);
  g = e + (f ^ a ^ b) + c[3] + 3572445317 & 4294967295;
  e = f + (g << 16 & 4294967295 | g >>> 16);
  g = b + (e ^ f ^ a) + c[6] + 76029189 & 4294967295;
  b = e + (g << 23 & 4294967295 | g >>> 9);
  g = a + (b ^ e ^ f) + c[9] + 3654602809 & 4294967295;
  a = b + (g << 4 & 4294967295 | g >>> 28);
  g = f + (a ^ b ^ e) + c[12] + 3873151461 & 4294967295;
  f = a + (g << 11 & 4294967295 | g >>> 21);
  g = e + (f ^ a ^ b) + c[15] + 530742520 & 4294967295;
  e = f + (g << 16 & 4294967295 | g >>> 16);
  g = b + (e ^ f ^ a) + c[2] + 3299628645 & 4294967295;
  b = e + (g << 23 & 4294967295 | g >>> 9);
  g = a + (e ^ (b | ~f)) + c[0] + 4096336452 & 4294967295;
  a = b + (g << 6 & 4294967295 | g >>> 26);
  g = f + (b ^ (a | ~e)) + c[7] + 1126891415 & 4294967295;
  f = a + (g << 10 & 4294967295 | g >>> 22);
  g = e + (a ^ (f | ~b)) + c[14] + 2878612391 & 4294967295;
  e = f + (g << 15 & 4294967295 | g >>> 17);
  g = b + (f ^ (e | ~a)) + c[5] + 4237533241 & 4294967295;
  b = e + (g << 21 & 4294967295 | g >>> 11);
  g = a + (e ^ (b | ~f)) + c[12] + 1700485571 & 4294967295;
  a = b + (g << 6 & 4294967295 | g >>> 26);
  g = f + (b ^ (a | ~e)) + c[3] + 2399980690 & 4294967295;
  f = a + (g << 10 & 4294967295 | g >>> 22);
  g = e + (a ^ (f | ~b)) + c[10] + 4293915773 & 4294967295;
  e = f + (g << 15 & 4294967295 | g >>> 17);
  g = b + (f ^ (e | ~a)) + c[1] + 2240044497 & 4294967295;
  b = e + (g << 21 & 4294967295 | g >>> 11);
  g = a + (e ^ (b | ~f)) + c[8] + 1873313359 & 4294967295;
  a = b + (g << 6 & 4294967295 | g >>> 26);
  g = f + (b ^ (a | ~e)) + c[15] + 4264355552 & 4294967295;
  f = a + (g << 10 & 4294967295 | g >>> 22);
  g = e + (a ^ (f | ~b)) + c[6] + 2734768916 & 4294967295;
  e = f + (g << 15 & 4294967295 | g >>> 17);
  g = b + (f ^ (e | ~a)) + c[13] + 1309151649 & 4294967295;
  b = e + (g << 21 & 4294967295 | g >>> 11);
  g = a + (e ^ (b | ~f)) + c[4] + 4149444226 & 4294967295;
  a = b + (g << 6 & 4294967295 | g >>> 26);
  g = f + (b ^ (a | ~e)) + c[11] + 3174756917 & 4294967295;
  f = a + (g << 10 & 4294967295 | g >>> 22);
  g = e + (a ^ (f | ~b)) + c[2] + 718787259 & 4294967295;
  e = f + (g << 15 & 4294967295 | g >>> 17);
  g = b + (f ^ (e | ~a)) + c[9] + 3951481745 & 4294967295;
  this.fa[0] = this.fa[0] + a & 4294967295;
  this.fa[1] = this.fa[1] + (e + (g << 21 & 4294967295 | g >>> 11)) & 4294967295;
  this.fa[2] = this.fa[2] + e & 4294967295;
  this.fa[3] = this.fa[3] + f & 4294967295;
};
Dp.prototype.update = function(a, b) {
  l(b) || (b = a.length);
  for (var c = b - this.pc, e = this.UR, f = this.Cn, g = 0;g < b;) {
    if (0 == f) {
      for (;g <= c;) {
        this.ph(a, g), g += this.pc;
      }
    }
    if (p(a)) {
      for (;g < b;) {
        if (e[f++] = a.charCodeAt(g++), f == this.pc) {
          this.ph(e);
          f = 0;
          break;
        }
      }
    } else {
      for (;g < b;) {
        if (e[f++] = a[g++], f == this.pc) {
          this.ph(e);
          f = 0;
          break;
        }
      }
    }
  }
  this.Cn = f;
  this.Yu += b;
};
Dp.prototype.digest = function() {
  var a = Array((56 > this.Cn ? this.pc : 2 * this.pc) - this.Cn);
  a[0] = 128;
  for (var b = 1;b < a.length - 8;++b) {
    a[b] = 0;
  }
  for (var c = 8 * this.Yu, b = a.length - 8;b < a.length;++b) {
    a[b] = c & 255, c /= 256;
  }
  this.update(a);
  a = Array(16);
  for (b = c = 0;4 > b;++b) {
    for (var e = 0;32 > e;e += 8) {
      a[c++] = this.fa[b] >>> e & 255;
    }
  }
  return a;
};
var Fp = function(a) {
  x(!Ep.hasOwnProperty(a), "Attempt to create a second Namespace with name: " + a);
  x(!/[^0-9a-zA-Z._]/.test(a), "Attempt to create a Namespace with invalid characters: " + a);
  this.ua = a;
  Ep[a] = this;
}, Ep;
Ep = {};
new Fp("lib");
var Gp = function(a, b) {
  p(b) ? (x(b, "NamespacedType does not allow empty type string"), x(!/[:]/.test(b), 'NamespacedType does not allow ":" in type string: ' + b)) : x(0 <= b, "NamespacedType does not allow negative type number");
  x(a, "NamespacedType does not accept undefined or null namespace");
  this.namespace_ = a;
  this.Jd = b;
  this.constructor.Wv || (this.constructor.Wv = {});
  a = this.toString();
  x(!this.constructor.Wv[a], "Registering duplicate namespaced type " + a);
  this.constructor.Wv[a] = this;
};
Gp.prototype.cb = function() {
  return this.toString();
};
Gp.prototype.toString = function() {
  this.DO || (this.DO = this.namespace_.ua + ":" + this.Jd);
  return this.DO;
};
Gp.prototype.N = function() {
  return this.Jd;
};
var M = function(a, b, c) {
  x(a, "Invalid service id + " + a);
  if (c) {
    for (var e = 0;e < c.length;e++) {
      x(c[e], "Invalid dependency " + c[e] + " (index in dependency array: " + e + ") for service " + a);
    }
  }
  this.B8 = a;
  this.bm = b || null;
  this.cK = !1;
  this.lU = c || [];
};
M.prototype.toString = function() {
  return this.B8;
};
M.prototype.AY = function() {
  this.cK = !0;
  return this.bm;
};
M.prototype.I0 = function() {
  return !!this.bm;
};
M.prototype.o$ = function(a) {
  x(!this.cK || a == this.bm, "The module id cannot be changed after it was read.");
  this.bm = a;
};
var Hp = function(a) {
  this.Zh = a;
};
w(Hp, xp);
var Ip = function(a, b, c, e) {
  this.zb = a;
  this.key = b;
  this.Wb = l(c) ? c : null;
  this.params = e || [];
}, Jp = {MEDIA:"m", Lda:"a", VERSION:"v", ORIGIN:"o", mha:"s", Dha:"t", nfa:"i", qea:"c", Sda:"b", Gea:"k"}, Kp = {kha:"session", AUDIO:"audio", VIDEO:"video", Kda:"application", vea:"data"}, Lp = {HOST:"host", qha:"srflx", Uga:"relay", Oga:"prflx"}, Mp = {host:"LOCAL", srflx:"STUN", relay:"RELAY", prflx:"PEER_REFLEX"}, Np = {audio:"a", video:"v", data:"d", application:"d"};
var Op = function(a) {
  this.Df = x(a.Df);
  this.Kd = x(a.Kd);
};
Op.prototype.toString = function() {
  return "CodecParam(key=" + this.Df + ", value=" + this.Kd + ")";
};
Op.prototype.getKey = function() {
  return this.Df;
};
Op.prototype.vc = function() {
  return this.Kd;
};
var Pp = function(a) {
  this.Df = a ? a.Df : null;
  this.Kd = a ? a.Kd : null;
};
Pp.prototype.S = function() {
  x(this.Uc());
  return new Op(this);
};
Pp.prototype.Uc = function() {
  return null != this.Df && null != this.Kd;
};
Pp.prototype.bda = function(a) {
  this.Df = a;
  return this;
};
Pp.prototype.mda = function(a) {
  this.Kd = a;
  return this;
};
var Qp = function(a) {
  this.uk = x(a.uk);
  this.tj = Za(a.tj);
  this.xm = a.xm;
  this.vk = Ya(a.vk);
}, Rp = {Cda:"AES_CM_128_HMAC_SHA1_32", Dda:"AES_CM_128_HMAC_SHA1_80"};
d = Qp.prototype;
d.toString = function() {
  return "Crypto(suite=" + this.uk + ", keyParams=<redacted>, sessionParams_=" + (null != this.xm ? "<redacted>" : null) + ", tag=" + this.vk + ")";
};
d.Lh = function() {
  return this.uk;
};
d.zl = function() {
  return this.tj;
};
d.Fo = function() {
  return this.xm;
};
d.Ho = function() {
  return this.vk;
};
var Sp = function(a) {
  this.uk = a ? a.uk : null;
  this.tj = a ? a.tj : null;
  this.xm = a ? a.xm : null;
  this.vk = a ? a.vk : null;
};
d = Sp.prototype;
d.S = function() {
  x(this.Uc());
  return new Qp(this);
};
d.Uc = function() {
  return null != this.uk && null != this.tj && null != this.vk && -1 != this.tj.indexOf(":");
};
d.JC = function(a) {
  this.uk = a;
  return this;
};
d.FC = function(a) {
  this.tj = a;
  return this;
};
d.EP = function(a) {
  this.xm = a;
  return this;
};
d.KC = function(a) {
  this.vk = a;
  return this;
};
var Tp = function(a) {
  this.xk = Za(a.xk);
  this.vb = Ya(a.vb);
  this.Ea = a.Ea;
};
Tp.prototype.toString = function() {
  return "RtpHeaderExtension(uri=" + this.xk + ", id=" + this.vb + ", mediaType=" + this.Ea + ")";
};
Tp.prototype.Fl = function() {
  return this.xk;
};
Tp.prototype.getId = function() {
  return this.vb;
};
Tp.prototype.P = function() {
  return this.Ea;
};
var Up = function(a) {
  this.xk = a ? a.xk : null;
  this.vb = a ? a.vb : null;
  this.Ea = a ? a.Ea : null;
};
d = Up.prototype;
d.S = function() {
  x(this.Uc());
  return new Tp(this);
};
d.Uc = function() {
  return !Ga(Pa(this.xk)) && null != this.vb && 0 < this.vb && 255 > this.vb;
};
d.kn = function(a) {
  this.xk = a;
  return this;
};
d.en = function(a) {
  this.vb = a;
  return this;
};
d.La = function(a) {
  this.Ea = a;
  return this;
};
var Vp = function(a) {
  this.Ja = Ya(a.Ja);
  this.ua = Za(a.ua);
  this.mp = a.mp;
  this.Bj = Ya(a.Bj);
};
Vp.prototype.na = function() {
  return {port:this.Wa(), name:this.getName(), messagesize:this.mp, numstreams:this.Bj};
};
Vp.prototype.Wa = function() {
  return this.Ja;
};
Vp.prototype.getName = function() {
  return this.ua;
};
var Wp = function(a) {
  this.Ja = a ? a.Ja : null;
  this.ua = a ? a.ua : null;
  this.mp = a ? a.mp : null;
  this.Bj = a ? a.Bj : null;
};
d = Wp.prototype;
d.S = function() {
  x(this.Uc());
  return new Vp(this);
};
d.Uc = function() {
  return null != this.Ja && null != this.ua && null != this.Bj;
};
d.rv = function(a) {
  this.Ja = a;
  return this;
};
d.hc = function(a) {
  this.ua = a;
  return this;
};
d.cda = function(a) {
  this.mp = a;
  return this;
};
d.GC = function(a) {
  this.Bj = a;
  return this;
};
var Xp = function() {
  this.iP = this.wC = this.$m = this.Cq = !0;
  this.ex = !1;
  this.DD = !0;
  this.Ud = null;
  this.el = [];
  this.Pca = !0;
  this.Ri = this.Qi = !1;
  this.Fw = null;
  this.xC = !0;
  this.fU = this.Aa = !1;
  this.iO = !0;
  this.Xq = new Cp;
  this.Zm = !1;
  this.vC = this.zp = !0;
  this.FD = this.ED = this.dP = !1;
  this.RS = void 0;
  this.gP = this.cP = !1;
  this.jP = !0;
  this.ef = null;
};
d = Xp.prototype;
d.na = function() {
  return {useAudio:this.Cq, useVideo:this.$m, useData:this.wC, useVideoRtx:this.iP, dumpRtpHeaders:this.ex, allowEarlyMedia:this.DD, earlyMediaHangoutId:this.Ud, defaultRequests:this.el, useStandardIce:this.Pca, debugLogUploadAllowed:this.Qi, debugLogUploadForced:this.Ri, clientResource:this.Fw, useSimulcast:this.xC, useP2P:this.Aa, startMuted:this.iO, useDtls:this.Zm, playAudio:this.zp, useConferenceMode:this.vC, useDetours:this.dP, allowH264:this.ED, allowVP9:this.FD, useAdaptiveLayering_:this.cP, 
  useMsodc:this.gP, useWebrtcCpuAdaptation:this.jP};
};
d.Z = function() {
  return Qb(this);
};
d.lda = function(a) {
  var b = this.Z();
  b.$m = a;
  return b;
};
d.ms = function() {
  return this.ex;
};
d.$ca = function(a) {
  var b = this.Z();
  b.ex = a;
  return b;
};
d.rP = function(a) {
  if (this.Qi && this.Ri) {
    return this;
  }
  var b = this.Z();
  b.Qi = a;
  return b;
};
d.sP = function() {
  var a = this.Z();
  a.Ri = !0;
  return a;
};
d.uP = function(a) {
  var b = this.Z();
  b.Ud = a;
  return b;
};
d.ze = function() {
  return this.el;
};
d.Ck = function(a) {
  var b = this.Z();
  b.el = a;
  return b;
};
d.Ic = function() {
  return this.Fw;
};
d.Yca = function(a) {
  var b = this.Z();
  b.Fw = a;
  return b;
};
d.kda = function(a) {
  var b = this.Z();
  b.xC = a;
  return b;
};
d.jda = function(a) {
  var b = this.Z();
  b.Aa = a;
  return b;
};
d.Xca = function(a) {
  var b = this.Z();
  b.Xq = a;
  return b;
};
d.gda = function(a) {
  var b = this.Z();
  b.iO = a;
  return b;
};
d.ida = function(a) {
  var b = this.Z();
  b.Zm = a;
  return b;
};
d.fda = function(a) {
  var b = this.Z();
  b.zp = a;
  return b;
};
d.hda = function(a) {
  var b = this.Z();
  b.vC = a;
  return b;
};
d.$F = function() {
  return this.ED;
};
d.ov = function(a) {
  var b = this.Z();
  b.ef = a;
  return b;
};
d.Hc = function() {
  return this.ef;
};
var N = function(a) {
  return N.QI(a);
};
N.QI = function(a) {
  return a + "_";
};
N.Qna = function() {
  throw Error("xid.literal must not be used in COMPILED mode.");
};
N.object = function(a) {
  if (a && a.constructor && a.constructor.toString() === Object.toString()) {
    var b = {}, c;
    for (c in a) {
      a.hasOwnProperty(c) && (b[N.QI(c)] = a[c]);
    }
    return b;
  }
  throw Error("xid.object must be called with an object literal.");
};
N.Hea = !0;
N.Bia = function(a) {
  return a;
};
N.vna = function() {
  return !0;
};
var Yp = function(a, b, c, e, f) {
  x(0 < a, "Initial value must be greater than zero.");
  x(b >= a, "Max value should be at least as large as initial value.");
  l(c) && x(0 <= c && 1 >= c, "Randomness factor should be between 0 and 1.");
  l(e) && x(1 < e, "Backoff factor should be greater than 1");
  l(f) && x(1 <= f, "Decay factor should be greater than 1");
  this.II = a;
  this.NJ = b;
  this.Pn = this.Rw = a;
  this.rL = c || 0;
  this.br = e || 2;
};
Yp.prototype.On = 0;
Yp.prototype.reset = function() {
  this.Pn = this.Rw = this.II;
  this.On = 0;
};
Yp.prototype.vc = function() {
  return this.Rw;
};
Yp.prototype.ar = function() {
  this.Pn = Math.min(this.NJ, this.Pn * this.br);
  this.Rw = Math.min(this.NJ, this.Pn + (this.rL ? Math.round(this.rL * (Math.random() - 0.5) * 2 * this.Pn) : 0));
  this.On++;
};
var Zp = function(a, b) {
  Rc.call(this);
  this.nF = this.XE = null;
  this.Aj = b;
  this.ic = [];
  this.MT(a);
};
w(Zp, Rc);
d = Zp.prototype;
d.getObject = function() {
  return this.ic.length ? this.ic.pop() : this.jg();
};
d.Xj = function(a) {
  this.ic.length < this.Aj ? this.ic.push(a) : this.Si(a);
};
d.MT = function(a) {
  if (a > this.Aj) {
    throw Error("[goog.structs.SimplePool] Initial cannot be greater than max");
  }
  for (var b = 0;b < a;b++) {
    this.ic.push(this.jg());
  }
};
d.jg = function() {
  return this.XE ? this.XE() : {};
};
d.Si = function(a) {
  if (this.nF) {
    this.nF(a);
  } else {
    if (va(a)) {
      if (ua(a.Qa)) {
        a.Qa();
      } else {
        for (var b in a) {
          delete a[b];
        }
      }
    }
  }
};
d.U = function() {
  Zp.T.U.call(this);
  for (var a = this.ic;a.length;) {
    this.Si(a.pop());
  }
  delete this.ic;
};
var $p = {TAB:0, WC:1}, aq = function(a) {
  ah("MediaRouter.Hangouts.Start.Success", a, $p);
};
var bq = function() {
}, cq = function(a, b) {
  a.T ? x(a.prototype instanceof bq, "delegate base class is not a subclass of fava.delegate.Delegate") : w(a, bq);
  x(!b.kg, "delegator already has a delegate base set");
  b.kg = a;
  do {
    b = b.T && b.T.constructor;
  } while (b && !b.kg);
  if (b && b.kg !== a.T.constructor) {
    throw Error("delegate base must derive from superclass delegate base");
  }
}, dq = function(a, b, c) {
  if (a.T) {
    x(a.prototype instanceof b, "delegate is not a subclass of the delegate base");
  } else {
    for (var e in a.prototype) {
      if (a.prototype.hasOwnProperty(e)) {
        throw Error("delegate registered after defining methods. you should extend your delegate base explicitly immediately after defining your delegate class");
      }
    }
    w(a, b);
  }
  x(!b.Zw, "delegate registered after first delegator instantiation");
  c = c || 0;
  a.hF = c;
  if (b.sd) {
    b = b.sd;
    e = 0;
    for (var f = b.length - 1;e <= f;) {
      var g = e + f >> 1;
      c > b[g].hF ? f = g - 1 : e = g + 1;
    }
    e < b.length && b[e].hF == c && ++e;
    b.splice(e, 0, a);
  } else {
    b.sd = [a];
  }
}, gq = function(a) {
  var b = a.kg, c = function(a) {
    c.T.constructor.call(this, a);
    var b = this.sd.length;
    this.ue = [];
    for (var e = 0;e < b;++e) {
      this.sd[e].Mka || (this.ue[e] = new this.sd[e](a));
    }
  };
  w(c, b);
  for (var e = [];a;) {
    if (b = a.kg) {
      b.sd && yb(e, b.sd);
      var f = b.prototype, g;
      for (g in f) {
        if (f.hasOwnProperty(g) && ua(f[g]) && f[g] !== b) {
          var k = !!f[g].kja, q = eq(g, f, e, k);
          (k = fq(g, f, q, k)) && (c.prototype[g] = k);
        }
      }
    }
    a = a.T && a.T.constructor;
  }
  c.prototype.sd = e;
  return c;
}, eq = function(a, b, c, e) {
  for (var f = [], g = 0;g < c.length && (c[g].prototype[a] === b[a] || (f.push(g), !e));++g) {
  }
  return f;
}, fq = function(a, b, c, e) {
  return c.length ? e ? function(b) {
    var e = this.ue[c[0]];
    return e ? e[a].apply(this.ue[c[0]], arguments) : this.sd[c[0]].prototype[a].apply(this, arguments);
  } : b[a].GS ? function(b) {
    return this.kU(a, c, Array.prototype.slice.call(arguments, 0));
  } : b[a].hE ? function(b) {
    return this.jU(a, c, Array.prototype.slice.call(arguments, 0));
  } : b[a].hK ? function(b) {
    return this.iU(a, c, Array.prototype.slice.call(arguments, 0));
  } : function(b) {
    return this.hU(a, c, Array.prototype.slice.call(arguments, 0));
  } : e || b[a].GS || b[a].hE || b[a].hK ? null : hq;
}, hq = function() {
  return [];
};
d = bq.prototype;
d.hU = function(a, b, c) {
  for (var e = [], f = 0;f < b.length;++f) {
    var g = this.ue[b[f]];
    e.push(g ? g[a].apply(g, c) : this.sd[b[f]].prototype[a].apply(this, c));
  }
  return e;
};
d.iU = function(a, b, c) {
  for (var e = 0;e < b.length;++e) {
    var f = this.ue[b[e]];
    f ? f[a].apply(f, c) : this.sd[b[e]].prototype[a].apply(this, c);
  }
};
d.kU = function(a, b, c) {
  for (var e = 0;e < b.length;++e) {
    var f = this.ue[b[e]];
    if (f = f ? f[a].apply(f, c) : this.sd[b[e]].prototype[a].apply(this, c)) {
      return f;
    }
  }
  return !1;
};
d.jU = function(a, b, c) {
  for (var e = 0;e < b.length;++e) {
    var f = this.ue[b[e]], f = f ? f[a].apply(f, c) : this.sd[b[e]].prototype[a].apply(this, c);
    if (null != f) {
      return f;
    }
  }
};
d.Ur = function(a) {
  if (this.ue) {
    for (var b = 0;b < this.ue.length;++b) {
      if (this.ue[b] instanceof a) {
        return this.ue[b];
      }
    }
  }
  return null;
};
var iq = function(a) {
  a = a ? a : function() {
  };
  a.hE = !0;
  return a;
};
var jq = function(a, b) {
  Gp.call(this, a, b);
};
w(jq, Gp);
var kq = function(a) {
  var b = {}, c = {}, e = [], f = [], g = function(a) {
    if (!c[a]) {
      var f = a instanceof M ? a.lU : [];
      c[a] = B(f);
      y(f, function(c) {
        b[c] = b[c] || [];
        b[c].push(a);
      });
      f.length || e.push(a);
      y(f, g);
    }
  };
  for (y(a, g);e.length;) {
    var k = e.shift();
    f.push(k);
    b[k] && y(b[k], function(a) {
      ub(c[a], k);
      c[a].length || e.push(a);
    });
  }
  x(!Ib(c, function(a) {
    return 0 < a.length;
  }), "Some dependencies were not resolved properly.This can be caused by a dependency cycle.");
  var q = {}, r = [];
  y(f, function(a) {
    a instanceof M && (a = a.AY(), null == a || q[a] || (q[a] = !0, r.push(a)));
  });
  return {services:f, M2:r};
};
var lq = function(a, b, c, e, f, g, k, q, r, A, E) {
  x(b.length == c.length);
  x(k.length == q.length);
  x(b.length == k.length);
  x(e.length == f.length);
  x(r.length == A.length);
  x(e.length == r.length);
  this.bk = a;
  this.VA = B(b);
  this.H7 = B(c);
  B(e);
  this.fu = xb(b, e);
  this.M7 = xb(c, f);
  this.eu = g;
  this.I7 = B(k);
  this.J7 = B(q);
  B(r);
  this.UL = xb(k, r);
  this.L7 = xb(q, A);
  this.K7 = E || Cd;
};
d = lq.prototype;
d.ur = function(a) {
  var b;
  if (a instanceof this.bk) {
    b = this.VA;
  } else {
    if (a instanceof this.eu) {
      b = this.I7;
    } else {
      return Xa("Passed in object did not match resource or identifier type"), [];
    }
  }
  return z(b, function(b) {
    return b.call(a);
  });
};
d.bl = function(a) {
  var b;
  if (a instanceof this.bk) {
    b = this.fu;
  } else {
    if (a instanceof this.eu) {
      b = this.UL;
    } else {
      return Xa("Passed in object did not match resource or identifier type"), [];
    }
  }
  return z(b, function(b) {
    return b.call(a);
  });
};
d.x1 = function(a) {
  return a instanceof this.bk;
};
d.Mn = function(a, b) {
  var c = this.M7;
  a.length == c.length ? x(!b, "Cannot specify resourceKey and itemKey") : b ? a = xb(a, b) : c = this.H7;
  x(c.length == a.length);
  var e = new this.bk;
  y(a, function(a, b) {
    c[b].call(e, a);
  }, this);
  return e;
};
d.$E = function(a, b) {
  var c = this.L7;
  a.length == c.length ? x(!b, "Cannot specify resourceKey and itemKey") : b ? a = xb(a, b) : c = this.J7;
  x(c.length == a.length);
  var e = new this.eu;
  y(a, function(a, b) {
    c[b].call(e, a);
  }, this);
  return e;
};
d.Oy = function(a) {
  var b;
  if (a instanceof this.bk) {
    b = this.fu;
  } else {
    if (a instanceof this.eu) {
      b = this.UL;
    } else {
      return Xa("Passed in object did not match resource or identifier type"), !1;
    }
  }
  return !jb(b, function(b) {
    return null == b.call(a);
  });
};
d.cJ = function(a, b) {
  a = this.wr(a, this.ur);
  b = this.wr(b, this.ur);
  x(a.length == this.VA.length);
  x(b.length == this.VA.length);
  return Fb(a, b);
};
d.dJ = function(a, b) {
  a = this.wr(a, this.bl);
  b = this.wr(b, this.bl);
  x(a.length == this.fu.length);
  x(b.length == this.fu.length);
  return Fb(a, b);
};
d.Ow = function(a) {
  if (a instanceof this.bk) {
    return a;
  }
  var b = new this.bk(JSON.parse(a.cb()));
  x(a.tt == b.tt);
  return b;
};
d.sr = function(a) {
  return this.K7(a);
};
d.wr = function(a, b) {
  return a instanceof Array ? a : b.call(this, a);
};
var mq = function(a, b, c) {
  this.CS = a;
  this.W5 = b;
  this.Z7 = c;
};
mq.prototype.kG = function() {
  return B(this.CS);
};
mq.prototype.dj = function() {
  return this.W5;
};
mq.prototype.El = function() {
  return this.Z7;
};
var nq = function(a) {
  this.Ea = x(a.Ea);
  this.yc = Ya(a.yc);
  this.ua = Za(a.ua);
  this.gh = a.gh;
  this.fg = a.fg;
  this.ff = a.ff;
  this.Hf = a.Hf;
};
d = nq.prototype;
d.toString = function() {
  return "Codec(name=" + this.ua + ", mediaType=" + this.Ea + ", payloadType=" + this.yc + ", bitrate=" + this.gh + ", clockrate=" + this.fg + ", channels=" + this.ff + ", params=" + this.Hf + ")";
};
d.P = function() {
  return this.Ea;
};
d.getName = function() {
  return this.ua;
};
d.Xx = function() {
  return B(this.Hf);
};
d.getParam = function(a) {
  var b = mb(this.Hf, function(b) {
    return b.getKey() == a;
  });
  return b ? b.vc() : null;
};
d.lt = function(a) {
  var b = this.getName(), b = String(b).toLowerCase();
  a = String(a).toLowerCase();
  return 0 == (b < a ? -1 : b == a ? 0 : 1);
};
var oq = function(a) {
  this.Ea = a ? a.Ea : null;
  this.yc = a ? a.yc : null;
  this.ua = a ? a.ua : null;
  this.gh = a ? a.gh : null;
  this.fg = a ? a.fg : null;
  this.ff = a ? a.ff : null;
  this.Hf = a ? B(a.Hf) : [];
};
d = oq.prototype;
d.S = function() {
  x(this.Uc());
  return new nq(this);
};
d.Uc = function() {
  return null != this.Ea && null != this.yc && null != this.ua && 0 <= this.yc && 127 >= this.yc;
};
d.La = function(a) {
  this.Ea = a;
  return this;
};
d.hd = function(a) {
  this.yc = a;
  return this;
};
d.hc = function(a) {
  this.ua = a;
  return this;
};
d.Xe = function(a) {
  this.gh = a;
  return this;
};
d.Md = function(a) {
  this.fg = a;
  return this;
};
d.Ld = function(a) {
  this.ff = a;
  return this;
};
d.eda = function(a) {
  this.Hf = B(a);
  return this;
};
d.Fq = function(a, b) {
  b = (new Pp).bda(a).mda(b).S();
  var c = lb(this.Hf, function(b) {
    return b.getKey() == a;
  });
  -1 == c ? this.Hf.push(b) : this.Hf[c] = b;
  return this;
};
var pq = function(a) {
  this.ki = Za(a.ki);
  x(!Ga(this.ki));
  this.fc = B(a.fc);
};
pq.prototype.toString = function() {
  return "SsrcGroup(semantics=" + this.ki + ", ssrcs=" + this.fc + ")";
};
pq.prototype.Eo = function() {
  return this.ki;
};
pq.prototype.wd = function() {
  return B(this.fc);
};
var qq = function(a) {
  this.ki = a ? a.ki : null;
  this.fc = a ? B(a.fc) : [];
};
qq.prototype.S = function() {
  x(this.Uc());
  return new pq(this);
};
qq.prototype.Uc = function() {
  return null != this.ki && 0 != this.fc.length;
};
qq.prototype.sv = function(a) {
  this.ki = a;
  return this;
};
qq.prototype.Ze = function(a) {
  this.fc = B(a);
  return this;
};
var rq = function(a, b, c, e, f, g) {
  this.zk = a;
  this.wi = b;
  this.di = c;
  this.nl = e || null;
  this.wF = null;
  this.PS = f || [];
  this.K2 = g || "full";
};
d = rq.prototype;
d.Z = function() {
  return Qb(this);
};
d.zf = function() {
  return this.zk;
};
d.FP = function(a) {
  var b = this.Z();
  b.wi = a;
  return b;
};
d.CP = function(a) {
  var b = this.Z();
  b.di = a;
  return b;
};
d.ud = function() {
  return this.nl;
};
d.vP = function(a) {
  var b = this.Z();
  b.nl = a;
  return b;
};
d.tP = function(a) {
  var b = this.Z();
  b.wF = a;
  return b;
};
d.jo = function() {
  return B(this.PS);
};
new M("iHLLuf");
new M("FwiOSb");
N.wb = {};
N.wb.Gv = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
N.wb.xv = N.wb.Gv + "0123456789";
N.wb.Hv = N.wb.Gv.length;
N.wb.Dv = N.wb.xv.length;
N.wb.ZC = -2147483648;
N.wb.ata = function(a) {
  x(6 >= a.length, "Xids should not be longer than 6 characters");
  for (var b = 0, c = a.length - 1;0 <= c;c--) {
    b = b * (0 == c ? N.wb.Hv : N.wb.Dv) + N.wb.xv.indexOf(a.charAt(c));
  }
  return b + N.wb.ZC;
};
N.wb.toString = function(a) {
  var b = [], c = 0;
  a -= N.wb.ZC;
  b[c++] = N.wb.Gv.charAt(a % N.wb.Hv);
  for (a = Math.floor(a / N.wb.Hv);0 < a;) {
    b[c++] = N.wb.xv.charAt(a % N.wb.Dv), a = Math.floor(a / N.wb.Dv);
  }
  return b.join("");
};
var tq = function(a) {
  if (!a.Lb) {
    var b;
    for (b = a.constructor;b && !b.kg;) {
      b = b.T && b.T.constructor;
    }
    x(b, "trying to create delegate for non-delegating class: did you forget to use fava.delegate.Delegate.setBase?");
    b.kg.Zw || (b.kg.Zw = gq(b));
    b = new b.kg.Zw(a);
    a.Lb = b;
    a.Ur ? x(a.Ur == sq, "conflicting definitions of findDelegate") : a.Ur = sq;
  }
}, sq = function(a) {
  return this.Lb.Ur(a);
};
var uq = function(a, b) {
  this.cm = a;
  this.deviceId = null != b ? b : null;
};
d = uq.prototype;
d.equals = function(a) {
  return a === this ? !0 : a ? this.cm === a.cm && this.deviceId === a.deviceId : !1;
};
d.Z = function() {
  return Qb(this);
};
d.dda = function(a) {
  var b = this.Z();
  b.cm = a;
  return b;
};
d.ys = function() {
  var a = {optional:[]};
  a.optional.push({sourceId:this.deviceId});
  return a;
};
d.toString = function() {
  return h.JSON.stringify(this);
};
var vq = function(a, b, c, e, f, g, k, q) {
  uq.call(this, a, q);
  this.wt = b;
  this.minWidth = c;
  this.minHeight = e;
  this.mt = f;
  this.maxWidth = g;
  this.maxHeight = k;
};
w(vq, uq);
vq.prototype.equals = function(a) {
  return this === a ? !0 : a instanceof vq ? vq.T.equals.call(this, a) && this.wt === a.wt && this.minWidth === a.minWidth && this.minHeight === a.minHeight && this.mt === a.mt && this.maxWidth === a.maxWidth && this.maxHeight === a.maxHeight : !1;
};
vq.prototype.ys = function() {
  var a = vq.T.ys.call(this);
  a.optional.push({minRefreshRate:this.wt});
  a.optional.push({minHeight:this.minHeight});
  a.optional.push({minWidth:this.minWidth});
  a.optional.push({maxRefreshRate:this.mt});
  a.optional.push({maxWidth:this.maxWidth});
  a.optional.push({maxHeight:this.maxHeight});
  return a;
};
var wq = function(a, b, c, e) {
  this.Jd = a;
  this.rd = b;
  this.Bc = null;
  this.um = c;
  this.rO = [];
  this.uz = "";
  this.el = [];
  this.Ut = this.$b = !0;
  this.ef = e || null;
};
d = wq.prototype;
d.na = function() {
  var a = this.Bc ? this.Bc.na() : {};
  return {type:this.N(), mediaId:this.Ae(), bandwidthConstraints:this.Hc() && this.Hc().toString(), codecs:this.sc(), streams:this.lb(), sctpSettings:a, defaultRequests:z(this.ze(), function(a) {
    return a.toString();
  }), send:this.$c(), receive:this.Ut};
};
d.Z = function() {
  return Qb(this);
};
d.N = function() {
  return this.Jd;
};
d.sc = function() {
  return B(this.rd);
};
d.zi = function(a) {
  var b = this.Z();
  b.rd = a;
  return b;
};
d.hn = function(a) {
  var b = this.Z();
  b.Bc = a;
  return b;
};
d.fj = function() {
  return B(this.um);
};
d.DP = function(a) {
  var b = this.Z();
  b.um = a;
  return b;
};
d.lb = function() {
  return B(this.rO);
};
d.Qc = function(a) {
  var b = this.Z();
  b.rO = a;
  return b;
};
d.Ae = function() {
  if (this.uz) {
    return this.uz;
  }
  switch(this.Jd) {
    case "a":
      return "audio";
    case "v":
      return "video";
    case "d":
      return "data";
    default:
      return Xa("No default media ID for unknown type: " + this.Jd), "";
  }
};
d.pv = function(a) {
  var b = this.Z();
  b.uz = a;
  return b;
};
d.ze = function() {
  return B(this.el);
};
d.Ck = function(a) {
  var b = this.Z();
  b.el = a;
  return b;
};
d.pP = function(a) {
  null == a && (a = -1);
  var b = this.Z();
  null == b.ef && (b.ef = new qp(-1, -1, -1));
  b.ef.Eg = a;
  return b;
};
d.Bx = function() {
  return this.ef ? this.ef.Eg : null;
};
d.ov = function(a) {
  var b = this.Z();
  b.ef = a;
  return b;
};
d.Hc = function() {
  return this.ef;
};
d.jn = function(a) {
  var b = this.Z();
  b.$b = a;
  return b;
};
d.$c = function() {
  return this.$b;
};
d.HC = function(a) {
  var b = this.Z();
  b.Ut = a;
  return b;
};
d.dv = function(a, b) {
  var c = this.lb(), e = Gb(b, function(a) {
    return a.Vb();
  });
  wb(c, function(a) {
    return a.Vb() in e;
  });
  c = xb(c, a);
  return this.Qc(c);
};
d.k7 = function(a) {
  return this.j7(function(b) {
    return b.lt(a);
  });
};
d.j7 = function(a) {
  return this.zi(ib(this.sc(), Dd(a)));
};
d.kL = function(a, b) {
  return this.c6(function(b) {
    return b.lt(a);
  }, b);
};
d.c6 = function(a, b) {
  a = lb(this.rd, a);
  if (-1 == a) {
    return this;
  }
  var c = this.sc(), e = c[a];
  null != b && (e = b(e));
  tb(c, a);
  rb(c, 0, 0, e);
  return this.zi(c);
};
d.GE = function(a) {
  if (null == a) {
    return this;
  }
  var b = this.Z(), c = a.Bx();
  c && (b = b.pP(c));
  c = a.sc();
  0 == c.length || (b = b.zi(c));
  (c = a.Bc) && (b = b.hn(c));
  c = a.fj();
  0 == c.length || (b = b.DP(c));
  c = a.ze();
  0 == c.length || (b = b.Ck(c));
  a = xq(this.lb(), a.lb(), function(a) {
    return a.Vb();
  });
  return b.Qc(a);
};
var xq = function(a, b, c) {
  a = Gb(a, c);
  Ub(a, Gb(b, c));
  return Jb(a);
};
var yq = function(a) {
  this.Ea = x(a.Ea);
  this.da = a.da;
  this.Ec = Za(a.Ec);
  this.rk = Za(a.rk);
  this.bd = a.bd;
  this.sh = a.sh;
  this.He = a.He;
  this.Dj = a.Dj;
  this.fc = B(a.fc);
  this.Nm = B(a.Nm);
};
d = yq.prototype;
d.toString = function() {
  return "Stream(participantId=" + this.da + ", mediaType=" + this.Ea + ", sourceId=" + this.Ec + ", streamId=" + this.rk + ", muted=" + this.bd + ", croppable=" + this.sh + ", mediaStreamId=" + this.He + ", mediaStreamTrackId=" + this.Dj + ", ssrcs=" + this.fc + ", ssrcGroups=" + this.Nm + ")";
};
d.P = function() {
  return this.Ea;
};
d.A = function() {
  return this.da;
};
d.ya = function() {
  return this.Ec;
};
d.Vb = function() {
  return this.rk;
};
d.wo = function() {
  return this.bd;
};
d.wd = function() {
  return B(this.fc);
};
d.TH = function() {
  return B(this.Nm);
};
d.matches = function(a) {
  return this.A() == a.A() && this.P() == a.P() && this.ya() == a.ya() && this.Vb() == a.Vb();
};
d.j2 = function(a) {
  return this.A() == a.A() && this.P() == a.N() && this.ya() == a.getId();
};
var zq = function(a) {
  this.Ea = a ? a.Ea : null;
  this.da = a ? a.da : "";
  this.Ec = a ? a.Ec : null;
  this.rk = a ? a.rk : null;
  this.bd = a ? a.bd : !1;
  this.sh = a ? a.sh : !0;
  this.He = a ? a.He : null;
  this.Dj = a ? a.Dj : null;
  this.fc = a ? B(a.fc) : [];
  this.Nm = a ? B(a.Nm) : [];
};
d = zq.prototype;
d.S = function() {
  x(this.Uc());
  return new yq(this);
};
d.Uc = function() {
  return null != this.Ea && null != this.Ec && null != this.rk;
};
d.La = function(a) {
  this.Ea = a;
  return this;
};
d.qv = function(a) {
  this.da = a;
  return this;
};
d.Wf = function(a) {
  this.Ec = a;
  return this;
};
d.Dk = function(a) {
  this.rk = a;
  return this;
};
d.AP = function(a) {
  this.bd = a;
  return this;
};
d.Zca = function(a) {
  this.sh = a;
  return this;
};
d.gn = function(a) {
  this.He = a;
  return this;
};
d.zP = function(a) {
  this.Dj = a;
  return this;
};
d.Ze = function(a) {
  this.fc = B(a);
  return this;
};
d.tn = function(a) {
  this.fc.push(a);
  return this;
};
d.IC = function(a) {
  this.Nm = B(a);
  return this;
};
var Aq = function(a, b, c, e) {
  this.status = a;
  this.lx = b;
  this.Kl = c;
  this.response = e;
};
Aq.prototype.toString = function() {
  var a = "[" + this.status + "/" + this.lx;
  null != this.Kl && (a += "/" + this.Kl);
  null != this.response && (a += ": ", a = ta(this.response) ? a + ye(this.response, this.Zn, this).join("; ") : a + this.Zn(this.response));
  return a + "]";
};
Aq.prototype.Zn = function(a) {
  if (null != a.error) {
    var b = a.error;
    a = b.message + " " + b.code;
    b = b.data || b.errors;
    null != b && (b = ye(b, function(a) {
      var b = a.domain + " - " + a.reason;
      null != a.debugInfo && (b += " = " + Ua(a.debugInfo, "\n", 4).slice(0, 3).join(" - "));
      return b;
    }), we(b) || (a += ": " + b.join(", ")));
    return a;
  }
  return "Unknown";
};
var Bq = function(a, b, c, e) {
  this.status = a;
  this.lx = b;
  this.Kl = c;
  this.response = e;
};
Bq.prototype.toString = function() {
  var a = "[" + this.status + "/" + this.lx;
  null != this.Kl && (a += "/" + this.Kl);
  null != this.response && null != this.response.Fr && (a += ": ", a = ta(this.response.Fr) ? a + ye(this.response.Fr, this.Zn, this).join("; ") : a + this.Zn(this.response.Fr));
  return a + "]";
};
Bq.prototype.Zn = function(a) {
  if (null != a.error) {
    var b = a.error;
    a = b.message + " " + b.code;
    b = b.data || b.errors;
    null != b && (b = ye(b, function(a) {
      var b = a.domain + " - " + a.reason;
      null != a.debugInfo && (b += " = " + Ua(a.debugInfo, "\n", 4).slice(0, 3).join(" - "));
      return b;
    }), we(b) || (a += ": " + b.join(", ")));
    return a;
  }
  return "Unknown";
};
var Dq = function() {
  this.Op = new Cq;
  this.Bn = new Yp(1E3, 36E4);
  this.Pq = 0;
  this.Rn = 60000;
  this.hr = !1;
  this.BD = [];
};
d = Dq.prototype;
d.Bm = function(a) {
  this.Ry = a;
  return this;
};
d.qo = function() {
  return this.Ry || "en";
};
d.FB = function(a) {
  this.Sg = a;
  return this;
};
d.ws = function() {
  return this.Sg || "";
};
d.ni = function(a) {
  this.Jg = a;
  return this;
};
d.vd = function() {
  x(null != this.Jg);
  return this.Jg;
};
d.cG = function() {
  return this.NR || this.vd();
};
d.vB = function(a) {
  this.Oo = a;
  return this;
};
d.Qx = function() {
  x(null != this.Oo);
  return this.Oo;
};
d.NB = function(a) {
  this.Bq = a;
  return this;
};
d.dI = function() {
  return null != this.Bq ? this.Bq : {};
};
d.ps = function() {
  return null != this.oj ? this.oj : {};
};
d.AG = function() {
  return null != this.Nw ? this.Nw : "application/json";
};
d.qu = function(a) {
  this.jw = a;
  return this;
};
d.Hm = function(a) {
  this.ck = a;
  return this;
};
d.hs = function() {
  return this.jw;
};
d.OB = function(a) {
  this.Dq = a;
  return this;
};
d.ry = function() {
  return null != this.Dq ? this.Dq : !0;
};
d.HN = function(a) {
  this.ji = a;
  return this;
};
d.FN = function(a) {
  this.ii = a;
  return this;
};
d.EH = function() {
  return null != this.ii ? this.ii : 0;
};
d.MM = function(a) {
  this.Rn = a;
  return this;
};
d.VD = function() {
  var a = this.Bn.vc(), a = Math.min(a, (36E4 - this.Pq) / 1.5), a = Math.round(0.5 * a) + Math.floor(Math.random() * a);
  this.Bn.ar();
  x(0 < this.ii);
  this.ii--;
  return a + this.Pq;
};
d.cancel = function() {
  this.hr = !0;
  this.Hm("c");
};
d.Ny = function() {
  return "p" == this.ck;
};
d.toString = function() {
  return "<Request to " + this.cG() + " with payload " + this.hs() + ">";
};
var Cq = function() {
};
Cq.prototype.mB = function(a) {
  this.Hi = a;
  return this;
};
Cq.prototype.sB = function(a) {
  this.jx = a;
  return this;
};
Cq.prototype.callback = function(a) {
  this.Hi(a);
};
Cq.prototype.Yc = function(a) {
  this.jx(a);
};
N.hash = {};
N.hash.TC = 2654435769;
N.hash.NQ = 314159265;
N.hash.$sa = function(a) {
  a = N.hash.Jba(a);
  for (var b = N.hash.TC, c = N.hash.TC, e = N.hash.NQ, f = a.length, g = f, k = 0, q = function() {
    b -= c;
    b -= e;
    b ^= e >>> 13;
    c -= e;
    c -= b;
    c ^= b << 8;
    e -= b;
    e -= c;
    e ^= c >>> 13;
    b -= c;
    b -= e;
    b ^= e >>> 12;
    c -= e;
    c -= b;
    c ^= b << 16;
    e -= b;
    e -= c;
    e ^= c >>> 5;
    b -= c;
    b -= e;
    b ^= e >>> 3;
    c -= e;
    c -= b;
    c ^= b << 10;
    e -= b;
    e -= c;
    e ^= c >>> 15;
  };12 <= g;g -= 12, k += 12) {
    b += N.hash.nl(a, k), c += N.hash.nl(a, k + 4), e += N.hash.nl(a, k + 8), q();
  }
  e += f;
  switch(g) {
    case 11:
      e += a[k + 10] << 24;
    case 10:
      e += a[k + 9] << 16;
    case 9:
      e += a[k + 8] << 8;
    case 8:
      c += a[k + 7] << 24;
    case 7:
      c += a[k + 6] << 16;
    case 6:
      c += a[k + 5] << 8;
    case 5:
      c += a[k + 4];
    case 4:
      b += a[k + 3] << 24;
    case 3:
      b += a[k + 2] << 16;
    case 2:
      b += a[k + 1] << 8;
    case 1:
      b += a[k + 0];
  }
  q();
  return N.wb.toString(e);
};
N.hash.aca = function(a) {
  return a;
};
N.hash.Jba = function(a) {
  for (var b = [], c = 0;c < a.length;c++) {
    b.push(a.charCodeAt(c));
  }
  return b;
};
N.hash.nl = function(a, b) {
  return a[b + 0] + (a[b + 1] << 8) + (a[b + 2] << 16) + (a[b + 3] << 24);
};
new M("tdUkaf");
new M("fJuxOc");
new M("ZtVrH");
new M("WSziFf");
new M("ZmXAm");
new M("BWETze");
new M("UBSgGf");
new M("zZa4xc");
new M("o1bZcd");
new M("yRRtR");
new M("WwG67d");
var Eq = new M("pVbxBc"), Fq = new M("n73qwf");
new M("z72MOc");
new M("JccZRe");
new M("amY3Td");
new M("ABma3e");
new M("GHAeAc", N.hash.aca("GHAeAc"));
new M("gSshPb");
new M("klpyYe");
new M("OPbIxb");
new M("pg9hFd");
new M("Wt6vjf");
new M("CV7dle");
new M("yu4DA");
new M("vk3Wc");
new M("IykvEf");
new M("J5K1Ad");
new M("IW8Usd");
new M("IaqD3e");
new M("byfTOb");
new M("jbDgG");
new M("b8xKu");
new M("d0RAGb");
new M("AzG0ke");
new M("J4QWB");
new M("LEikZe");
new M("rJmJrc");
new M("TuDsZ");
new M("MpJwZc");
new M("UUJqVe");
new M("hdXIif");
new M("mITR5c");
new M("VYNvce");
new M("NGntwf");
new M("Bgf0ib");
new M("Xpw1of");
new M("v5BQle");
new M("ofuapc");
new M("FENZqe");
new M("tLnxq");
new M("lsjVmc");
var Gq = function() {
  tq(this);
};
pa(Gq);
d = Gq.prototype;
d.lo = function(a) {
  return this.Lb.lo(a);
};
d.mo = function() {
  return this.Lb.mo();
};
d.pi = function(a) {
  return this.Lb.pi(a);
};
d.si = function(a, b) {
  return this.Lb.si(a, b);
};
d.Vd = function(a) {
  return this.Lb.Vd(a);
};
d.ev = function() {
  return this.Lb.ev();
};
var Hq = function() {
};
w(Hq, bq);
cq(Hq, Gq);
d = Hq.prototype;
d.lo = iq();
d.mo = iq();
d.pi = iq();
d.si = iq();
d.Vd = iq();
d.ev = iq();
var Iq = function(a) {
  this.Ba = a;
  tq(this);
};
Iq.prototype.Hc = function() {
  var a = new qp;
  this.Lb.Hc(a);
  return a;
};
var Jq = function() {
};
w(Jq, bq);
cq(Jq, Iq);
Jq.prototype.Hc = function(a) {
  a = a ? a : function() {
  };
  a.hK = !0;
  return a;
}();
var Lq = function() {
  this.Op = new Kq;
  this.Bn = new Yp(1E3, 36E4);
  this.Pq = 0;
  this.Rn = 60000;
  this.hr = !1;
  this.BD = [];
};
d = Lq.prototype;
d.toString = function() {
  return "<# " + this.ji + " to " + this.ws() + " for " + this.vd() + ">";
};
d.Bm = function(a) {
  this.Ry = a;
  return this;
};
d.qo = function() {
  return this.Ry || "en";
};
d.FB = function(a) {
  this.Sg = a;
  return this;
};
d.ws = function() {
  return this.Sg || "";
};
d.ni = function(a) {
  this.Jg = a;
  return this;
};
d.vd = function() {
  x(null != this.Jg);
  return this.Jg;
};
d.cG = function() {
  return this.NR || this.vd();
};
d.vB = function(a) {
  this.Oo = a;
  return this;
};
d.Qx = function() {
  x(null != this.Oo);
  return this.Oo;
};
d.NB = function(a) {
  this.Bq = a;
  return this;
};
d.dI = function() {
  return null != this.Bq ? this.Bq : {};
};
d.ps = function() {
  return null != this.oj ? this.oj : {};
};
d.AG = function() {
  return null != this.Nw ? this.Nw : "application/json";
};
d.qu = function(a) {
  this.jw = a;
  return this;
};
d.Hm = function(a) {
  this.ck = a;
  return this;
};
d.hs = function() {
  return this.jw;
};
d.OB = function(a) {
  this.Dq = a;
  return this;
};
d.ry = function() {
  return null != this.Dq ? this.Dq : !0;
};
d.HN = function(a) {
  this.ji = a;
  return this;
};
d.FN = function(a) {
  this.ii = a;
  return this;
};
d.EH = function() {
  return null != this.ii ? this.ii : 0;
};
d.MM = function(a) {
  this.Rn = a;
  return this;
};
d.VD = function() {
  var a = this.Bn.vc(), a = Math.round(0.5 * a) + Math.floor(Math.random() * a);
  this.Bn.ar();
  x(0 < this.ii--);
  return Math.min(a + this.Pq, 36E4);
};
d.cancel = function() {
  this.hr = !0;
  this.Hm("c");
};
d.Ny = function() {
  return "p" == this.ck;
};
var Kq = function() {
};
Kq.prototype.mB = function(a) {
  this.Hi = a;
  return this;
};
Kq.prototype.sB = function(a) {
  this.jx = a;
  return this;
};
Kq.prototype.callback = function(a) {
  this.Hi(a);
};
Kq.prototype.Yc = function(a) {
  this.jx(a);
};
var Mq = function() {
};
w(Mq, up);
Mq.prototype.V = function() {
  var a = 0;
  oe(this.$e(!0), function(b) {
    Za(b);
    a++;
  });
  return a;
};
Mq.prototype.clear = function() {
  var a = qe(this.$e(!0)), b = this;
  y(a, function(a) {
    b.remove(a);
  });
};
var Nq = function() {
  var a;
  return lc ? (a = /Windows NT ([0-9.]+)/, (a = a.exec(Vb)) ? a[1] : "0") : kc ? (a = /10[_.][0-9_.]+/, (a = a.exec(Vb)) ? a[0].replace(/_/g, ".") : "10") : nc ? (a = /Android\s+([^\);]+)(\)|;)/, (a = a.exec(Vb)) ? a[1] : "") : oc || pc || qc ? (a = /(?:iPhone|CPU)\s+OS\s+(\S+)/, (a = a.exec(Vb)) ? a[1].replace(/_/g, ".") : "") : "";
}();
new I({neon:1, sse2:2, ssse3:4, sse4_1:8, sse4_2:16, avx:32});
new M("bBNFlf", "bm");
var Oq = new M("FolmWb", "dlh"), Pq = new M("Mv4R6b", "dds"), Qq = new M("EitxU", "hl", [Pq]), Rq = new M("T3bcCc", void 0, [Qq]), Sq = new M("TjR1Nb", "ma", [Fq]);
var Tq = function(a) {
  this.Rc = a.Rc;
  this.Tq = a;
};
w(Tq, bq);
d = Tq.prototype;
d.uu = function(a) {
  this.Tq.uu(a);
};
d.mc = iq();
d.So = iq();
d.Go = iq();
d.zr = iq();
d.xr = iq();
d.Mf = iq();
d.al = iq();
var Uq = function(a, b, c, e, f, g, k) {
  this.ma = a || null;
  this.ha = b || null;
  this.Cr = c || null;
  this.C = l(e) ? e : null;
  this.nm = new I;
  this.nm.addAll(Gb(f || [], function(a) {
    return a.vg();
  }, this));
  this.ui = g || null;
  this.Nn = k || [];
}, Vq = function(a, b) {
  var c = a.ha;
  if (!c) {
    return a;
  }
  b = ib(c.sc(), b);
  var e = z(b, function(a) {
    return a.yc.toString();
  });
  b = ib(b, function(a) {
    return !a.lt("rtx") || pb(e, a.getParam("apt"));
  });
  return a.qe(c.zi(b));
};
d = Uq.prototype;
d.na = function() {
  return {sessionId:this.s(), audio:this.ma && this.ma.na(), video:this.ha && this.ha.na(), data:this.getData() && this.getData().na(), pushChannels:this.fs() && this.fs().toString(), cryptos:this.Ah()};
};
d.Z = function() {
  var a = Qb(this);
  a.nm = this.nm.clone();
  return a;
};
d.We = function(a) {
  var b = this.Z();
  b.ma = a;
  return b;
};
d.qe = function(a) {
  var b = this.Z();
  b.ha = a;
  return b;
};
d.getData = function() {
  return this.Cr;
};
d.Ye = function(a) {
  var b = this.Z();
  b.Cr = a;
  return b;
};
d.s = function() {
  return this.C;
};
d.kc = function() {
  return this.ui;
};
d.Gq = function(a) {
  var b = this.Z();
  b.ui = a;
  return b;
};
d.xH = function(a) {
  return this.nm.get(a || "collections");
};
d.fs = function() {
  return this.nm.H();
};
d.BP = function(a) {
  x(!Ga(a.vg()));
  var b = this.Z();
  b.nm.set(a.vg(), a);
  return b;
};
d.Ah = function() {
  return B(this.Nn);
};
d.qP = function(a) {
  var b = this.Z();
  b.Nn = a;
  return b;
};
d.dv = function(a, b) {
  var c = this.Z();
  c.ma = c.sC(c.ma, a, b);
  c.ha = c.sC(c.ha, a, b);
  c.Cr = c.sC(c.Cr, a, b);
  return c;
};
d.sC = function(a, b, c) {
  if (null == a) {
    return null;
  }
  b = ib(b, function(b) {
    return b.P() == a.N();
  });
  c = ib(c, function(b) {
    return b.P() == a.N();
  });
  return a.dv(b, c);
};
d.z2 = function(a) {
  var b = this.ma, b = null != b ? b.GE(a.ma) : a.ma, c = this.ha, c = null != c ? c.GE(a.ha) : a.ha;
  return this.We(b).qe(c);
};
d.M0 = function() {
  var a = 0 != this.Ah().length, b = !1, c = this.kc();
  c && null != c.ud() && (b = 2 == c.ud().split(" ").length);
  return a != b;
};
var Wq = function() {
  this.YJ = new I;
  this.XJ = new I;
  this.QE = new I;
};
d = Wq.prototype;
d.clear = function() {
  this.YJ.clear();
  this.XJ.clear();
  this.QE.clear();
};
d.zca = function(a, b, c) {
  var e = a.ssrc;
  if (null == e) {
    return null;
  }
  if (c) {
    return c = this.LB(this.YJ, e, u(this.fK, this, c)), c.update(b, a.bytesSent, a.packetsSent, a.packetsLost);
  }
  c = this.LB(this.XJ, e, u(this.fK, this, c));
  return c.update(b, a.bytesReceived, a.packetsReceived, a.packetsLost);
};
d.rca = function(a, b) {
  if ("false" == a.googActiveConnection) {
    return null;
  }
  var c = a.googLocalAddress + a.googRemoteAddress;
  return null != c ? this.LB(this.QE, c, u(this.S2, this)).update(b, a.bytesSent, a.bytesReceived) : null;
};
d.LB = function(a, b, c) {
  var e = a.get(b);
  null == e && (e = c(), a.set(b, e));
  return e;
};
d.fK = function(a) {
  return new Xq(a);
};
d.S2 = function() {
  return new Yq;
};
var Xq = function(a) {
  this.Bg = -1;
  this.xJ = this.yJ = this.wJ = 0;
  this.B1 = a;
};
Xq.prototype.update = function(a, b, c, e) {
  var f = null;
  if (t(a) && t(b) && t(c) && t(e)) {
    if (a > this.Bg) {
      var g = c - this.yJ, f = e - this.xJ, g = this.B1 ? g : g + f, f = 0 < g ? Math.round(100 * f / g) : -1, g = -1;
      if (0 <= this.Bg) {
        var g = a - this.Bg, k = b - this.wJ, g = 0 < k ? Math.round(8 * k / g) : 0;
      }
      f = {XD:g, i2:f};
    }
    this.Bg = a;
    this.wJ = b;
    this.yJ = c;
    this.xJ = e;
  }
  return f;
};
var Yq = function() {
  this.Bg = -1;
  this.uJ = this.vJ = 0;
};
Yq.prototype.update = function(a, b, c) {
  var e = null;
  if (t(a) && t(b) && t(c)) {
    if (0 <= this.Bg && a > this.Bg) {
      var e = a - this.Bg, f = b - this.vJ, g = c - this.uJ, e = {z8:0 < f ? Math.round(f / e) : 0, M6:0 < g ? Math.round(g / e) : 0};
    }
    this.Bg = a;
    this.vJ = b;
    this.uJ = c;
  }
  return e;
};
var Zq = function(a, b, c, e) {
  this.left = a;
  this.top = b;
  this.width = c;
  this.height = e;
};
Zq.prototype.clone = function() {
  return new Zq(this.left, this.top, this.width, this.height);
};
Zq.prototype.toString = function() {
  return "(" + this.left + ", " + this.top + " - " + this.width + "w x " + this.height + "h)";
};
var $q = function(a, b) {
  return a == b ? !0 : a && b ? a.left == b.left && a.width == b.width && a.top == b.top && a.height == b.height : !1;
};
d = Zq.prototype;
d.contains = function(a) {
  return this.left <= a.left && this.left + this.width >= a.left + a.width && this.top <= a.top && this.top + this.height >= a.top + a.height;
};
d.getSize = function() {
  return new Ji(this.width, this.height);
};
d.ceil = function() {
  this.left = Math.ceil(this.left);
  this.top = Math.ceil(this.top);
  this.width = Math.ceil(this.width);
  this.height = Math.ceil(this.height);
  return this;
};
d.floor = function() {
  this.left = Math.floor(this.left);
  this.top = Math.floor(this.top);
  this.width = Math.floor(this.width);
  this.height = Math.floor(this.height);
  return this;
};
d.round = function() {
  this.left = Math.round(this.left);
  this.top = Math.round(this.top);
  this.width = Math.round(this.width);
  this.height = Math.round(this.height);
  return this;
};
d.translate = function(a, b) {
  this.left += Ya(a);
  t(b) && (this.top += b);
  return this;
};
d.scale = function(a, b) {
  b = t(b) ? b : a;
  this.left *= a;
  this.width *= a;
  this.top *= b;
  this.height *= b;
  return this;
};
var ar = function(a) {
  this.Ta = a;
};
w(ar, Mq);
d = ar.prototype;
d.isAvailable = function() {
  if (!this.Ta) {
    return !1;
  }
  try {
    return this.Ta.setItem("__sak", "1"), this.Ta.removeItem("__sak"), !0;
  } catch (a) {
    return !1;
  }
};
d.set = function(a, b) {
  try {
    this.Ta.setItem(a, b);
  } catch (c) {
    if (0 == this.Ta.length) {
      throw "Storage mechanism: Storage disabled";
    }
    throw "Storage mechanism: Quota exceeded";
  }
};
d.get = function(a) {
  a = this.Ta.getItem(a);
  if (!p(a) && null !== a) {
    throw "Storage mechanism: Invalid value was encountered";
  }
  return a;
};
d.remove = function(a) {
  this.Ta.removeItem(a);
};
d.V = function() {
  return this.Ta.length;
};
d.$e = function(a) {
  var b = 0, c = this.Ta, e = new me;
  e.next = function() {
    if (b >= c.length) {
      throw le;
    }
    var e = Za(c.key(b++));
    if (a) {
      return e;
    }
    e = c.getItem(e);
    if (!p(e)) {
      throw "Storage mechanism: Invalid value was encountered";
    }
    return e;
  };
  return e;
};
d.clear = function() {
  this.Ta.clear();
};
d.key = function(a) {
  return this.Ta.key(a);
};
var br = function(a, b) {
  this.WF = new Ae;
  this.Sj = a || 2;
  this.om = b || 4294967295;
  this.Sj = Math.max(this.Sj, 2);
  this.om = Math.min(this.om, 4294967295);
  this.Sj > this.om && (this.Sj = 2, this.om = 4294967295);
};
br.prototype.XT = function() {
  for (var a = this.om - this.Sj + 1, b = Math.floor(this.Sj + a * Math.random()), c = 0;this.WF.contains(b);) {
    if (b < this.om ? ++b : b = this.Sj, ++c >= a) {
      return null;
    }
  }
  this.WF.add(b);
  return b;
};
var O = function() {
}, cr = "function" == typeof Uint8Array;
O.prototype.PX = function() {
  return this.tt;
};
var P = function(a, b, c, e, f, g) {
  a.Ga = null;
  b || (b = c ? [c] : []);
  a.tt = c ? String(c) : void 0;
  a.Wq = 0 === c ? -1 : 0;
  a.cf = b;
  a: {
    if (a.cf.length && (b = a.cf.length - 1, (c = a.cf[b]) && "object" == typeof c && !sa(c) && !(cr && c instanceof Uint8Array))) {
      a.yp = b - a.Wq;
      a.we = c;
      break a;
    }
    -1 < e ? (a.yp = e, a.we = null) : a.yp = Number.MAX_VALUE;
  }
  a.lka = {};
  if (f) {
    for (e = 0;e < f.length;e++) {
      b = f[e], b < a.yp ? (b += a.Wq, a.cf[b] = a.cf[b] || dr) : a.we[b] = a.we[b] || dr;
    }
  }
  g && g.length && y(g, Aa(er, a));
}, dr = Object.freeze ? Object.freeze([]) : [], Q = function(a, b, c) {
  for (var e = [], f = 0;f < a.length;f++) {
    e[f] = b.call(a[f], c, a[f]);
  }
  return e;
}, R = function(a, b) {
  if (b < a.yp) {
    b += a.Wq;
    var c = a.cf[b];
    return c === dr ? a.cf[b] = [] : c;
  }
  c = a.we[b];
  return c === dr ? a.we[b] = [] : c;
}, fr = function(a, b) {
  a = R(a, b);
  return null == a ? a : +a;
}, gr = function(a) {
  if (null == a || p(a)) {
    return a;
  }
  if (cr && a instanceof Uint8Array) {
    return Fj(a);
  }
  Xa("Cannot coerce to b64 string: " + qa(a));
  return null;
}, S = function(a, b, c) {
  a = R(a, b);
  return null == a ? c : a;
}, T = function(a, b, c) {
  b < a.yp ? a.cf[b + a.Wq] = c : a.we[b] = c;
}, hr = function(a, b, c, e) {
  a = R(a, b);
  void 0 != e ? a.splice(e, 0, c) : a.push(c);
}, er = function(a, b) {
  var c, e;
  y(b, function(b) {
    var f = R(a, b);
    null != f && (c = b, e = f, T(a, b, void 0));
  });
  return c ? (T(a, c, e), c) : 0;
}, U = function(a, b, c, e) {
  a.Ga || (a.Ga = {});
  if (!a.Ga[c]) {
    var f = R(a, c);
    if (e || f) {
      a.Ga[c] = new b(f);
    }
  }
  return a.Ga[c];
}, V = function(a, b, c) {
  ir(a, b, c);
  b = a.Ga[c];
  b == dr && (b = a.Ga[c] = []);
  return b;
}, ir = function(a, b, c) {
  a.Ga || (a.Ga = {});
  if (!a.Ga[c]) {
    for (var e = R(a, c), f = [], g = 0;g < e.length;g++) {
      f[g] = new b(e[g]);
    }
    a.Ga[c] = f;
  }
}, W = function(a, b, c) {
  a.Ga || (a.Ga = {});
  var e = c ? c.pe() : c;
  a.Ga[b] = c;
  T(a, b, e);
}, X = function(a, b, c) {
  a.Ga || (a.Ga = {});
  c = c || [];
  for (var e = [], f = 0;f < c.length;f++) {
    e[f] = c[f].pe();
  }
  a.Ga[b] = c;
  T(a, b, e);
};
O.prototype.vO = function() {
  if (this.Ga) {
    for (var a in this.Ga) {
      var b = this.Ga[a];
      if (sa(b)) {
        for (var c = 0;c < b.length;c++) {
          b[c] && b[c].pe();
        }
      } else {
        b && b.pe();
      }
    }
  }
};
O.prototype.pe = function() {
  this.vO();
  return this.cf;
};
var jr = h.JSON && h.JSON.stringify || "object" === typeof JSON && JSON.stringify;
O.prototype.cb = cr ? function() {
  x(jr);
  var a = Uint8Array.prototype.toJSON;
  Uint8Array.prototype.toJSON = function() {
    return Fj(this);
  };
  try {
    var b = jr.call(null, this.pe(), kr);
  } finally {
    Uint8Array.prototype.toJSON = a;
  }
  return b;
} : jr ? function() {
  return jr.call(null, this.pe(), kr);
} : function() {
  return ef(this.pe(), kr);
};
var kr = function(a, b) {
  if (t(b)) {
    if (isNaN(b)) {
      return "NaN";
    }
    if (Infinity === b) {
      return "Infinity";
    }
    if (-Infinity === b) {
      return "-Infinity";
    }
  }
  return b;
};
O.prototype.toString = function() {
  this.vO();
  return this.cf.toString();
};
O.prototype.getExtension = function(a) {
  if (this.we) {
    this.Ga || (this.Ga = {});
    var b = a.Sla;
    if (a.w1) {
      if (a.q1()) {
        return this.Ga[b] || (this.Ga[b] = z(this.we[b] || [], function(b) {
          return new a.bU(b);
        })), this.Ga[b];
      }
    } else {
      if (a.q1()) {
        return !this.Ga[b] && this.we[b] && (this.Ga[b] = new a.bU(this.we[b])), this.Ga[b];
      }
    }
    return this.we[b];
  }
};
var nr = function(a, b) {
  return a == b || !(!a || !b) && a instanceof b.constructor && lr(a.pe(), b.pe());
}, or = function(a, b) {
  a = a || {};
  b = b || {};
  var c = {}, e;
  for (e in a) {
    c[e] = 0;
  }
  for (e in b) {
    c[e] = 0;
  }
  for (e in c) {
    if (!lr(a[e], b[e])) {
      return !1;
    }
  }
  return !0;
}, lr = function(a, b) {
  if (a == b) {
    return !0;
  }
  if (!va(a) || !va(b) || a.constructor != b.constructor) {
    return !1;
  }
  if (cr && a.constructor === Uint8Array) {
    if (a.length != b.length) {
      return !1;
    }
    for (var c = 0;c < a.length;c++) {
      if (a[c] != b[c]) {
        return !1;
      }
    }
    return !0;
  }
  if (a.constructor === Array) {
    for (var e = void 0, f = void 0, g = Math.max(a.length, b.length), c = 0;c < g;c++) {
      var k = a[c], q = b[c];
      k && k.constructor == Object && (x(void 0 === e), x(c === a.length - 1), e = k, k = void 0);
      q && q.constructor == Object && (x(void 0 === f), x(c === b.length - 1), f = q, q = void 0);
      if (!lr(k, q)) {
        return !1;
      }
    }
    return e || f ? (e = e || {}, f = f || {}, or(e, f)) : !0;
  }
  if (a.constructor === Object) {
    return or(a, b);
  }
  throw Error("Invalid type in JSPB array");
};
O.prototype.Uk = function() {
  return pr(this);
};
O.prototype.clone = function() {
  return pr(this);
};
var pr = function(a) {
  return new a.constructor(qr(a.pe()));
}, qr = function(a) {
  var b;
  if (sa(a)) {
    for (var c = Array(a.length), e = 0;e < a.length;e++) {
      null != (b = a[e]) && (c[e] = "object" == typeof b ? qr(b) : b);
    }
    return c;
  }
  if (cr && a instanceof Uint8Array) {
    return new Uint8Array(a);
  }
  c = {};
  for (e in a) {
    null != (b = a[e]) && (c[e] = "object" == typeof b ? qr(b) : b);
  }
  return c;
}, sr = function(a, b) {
  rr[a] = b;
  b.messageId = a;
}, rr = {};
var tr = function(a) {
  var b = h.navigator || null;
  if (ci && null != b.webkitGetUserMedia) {
    var c = H();
    b.webkitGetUserMedia(a, c.resolve, c.reject);
    return c.promise;
  }
  return Zh && b.mediaDevices && b.mediaDevices.getUserMedia ? Xd(b.mediaDevices.getUserMedia(a)) : Yd("Missing getUserMedia API.");
};
var ur = function() {
  this.qc = !1;
  this.Zb = H();
  this.Kd = null;
};
ur.prototype.then = function(a, b, c) {
  return this.Zb.promise.then(a, b, c);
};
Qd(ur);
ur.prototype.get = function() {
  return this.Kd;
};
var vr = function() {
  this.provider = new ur;
};
vr.prototype.resolve = function(a) {
  this.provider.qc || (this.provider.qc = !0, this.provider.Kd = a, this.provider.Zb.resolve(a));
};
vr.prototype.reject = function(a) {
  this.provider.qc || (this.provider.qc = !0, this.provider.Zb.reject(a));
};
var wr = function() {
  var a = null;
  try {
    a = window.localStorage || null;
  } catch (b) {
  }
  this.Ta = a;
};
w(wr, ar);
/*
 Portions of this code are from MochiKit, received by
 The Closure Authors under the MIT license. All other code is Copyright
 2005-2009 The Closure Authors. All Rights Reserved.
*/
var xr = function(a, b) {
  this.mu = [];
  this.qK = a;
  this.fF = b || null;
  this.Jo = this.qc = !1;
  this.Qg = void 0;
  this.VB = this.YD = this.iw = !1;
  this.bv = 0;
  this.Ob = null;
  this.er = 0;
};
d = xr.prototype;
d.cancel = function(a) {
  if (this.qc) {
    this.Qg instanceof xr && this.Qg.cancel();
  } else {
    if (this.Ob) {
      var b = this.Ob;
      delete this.Ob;
      a ? b.cancel(a) : b.VR();
    }
    this.qK ? this.qK.call(this.fF, this) : this.VB = !0;
    this.qc || this.Yc(new yr(this));
  }
};
d.VR = function() {
  this.er--;
  0 >= this.er && this.cancel();
};
d.SE = function(a, b) {
  this.iw = !1;
  this.tC(a, b);
};
d.tC = function(a, b) {
  this.qc = !0;
  this.Qg = b;
  this.Jo = !a;
  this.OF();
};
d.tE = function() {
  if (this.qc) {
    if (!this.VB) {
      throw new zr(this);
    }
    this.VB = !1;
  }
};
d.callback = function(a) {
  this.tE();
  this.OD(a);
  this.tC(!0, a);
};
d.Yc = function(a) {
  this.tE();
  this.OD(a);
  this.tC(!1, a);
};
d.OD = function(a) {
  x(!(a instanceof xr), "An execution sequence may not be initiated with a blocking Deferred.");
};
d.eb = function(a, b) {
  return this.Bi(a, null, b);
};
d.Mq = function(a, b) {
  return this.Bi(null, a, b);
};
d.nR = function(a, b) {
  return this.Bi(a, a, b);
};
d.Bi = function(a, b, c) {
  x(!this.YD, "Blocking Deferreds can not be re-used");
  this.mu.push([a, b, c]);
  this.qc && this.OF();
  return this;
};
d.then = function(a, b, c) {
  var e, f, g = new Td(function(a, b) {
    e = a;
    f = b;
  });
  this.Bi(e, function(a) {
    a instanceof yr ? g.cancel() : f(a);
  });
  return g.then(a, b, c);
};
Qd(xr);
d = xr.prototype;
d.nE = function(a) {
  this.Bi(a.callback, a.Yc, a);
  return this;
};
d.UD = function(a) {
  return a instanceof xr ? this.eb(u(a.lw, a)) : this.eb(function() {
    return a;
  });
};
d.lw = function(a) {
  var b = new xr;
  this.nE(b);
  a && (b.Ob = this, this.er++);
  return b;
};
d.k1 = function(a) {
  return a instanceof Error;
};
d.xI = function() {
  return jb(this.mu, function(a) {
    return ua(a[1]);
  });
};
d.OF = function() {
  if (this.bv && this.qc && this.xI()) {
    var a = this.bv, b = Ar[a];
    b && (b.E7(), delete Ar[a]);
    this.bv = 0;
  }
  this.Ob && (this.Ob.er--, delete this.Ob);
  for (var a = this.Qg, c = b = !1;this.mu.length && !this.iw;) {
    var e = this.mu.shift(), f = e[0], g = e[1], e = e[2];
    if (f = this.Jo ? g : f) {
      try {
        var k = f.call(e || this.fF, a);
        l(k) && (this.Jo = this.Jo && (k == a || this.k1(k)), this.Qg = a = k);
        if (Rd(a) || "function" === typeof h.Promise && a instanceof h.Promise) {
          this.iw = c = !0;
        }
      } catch (q) {
        a = q, this.Jo = !0, this.xI() || (b = !0);
      }
    }
  }
  this.Qg = a;
  c && (k = u(this.SE, this, !0), c = u(this.SE, this, !1), a instanceof xr ? (a.Bi(k, c), a.YD = !0) : a.then(k, c));
  b && (a = new Br(a), Ar[a.vb] = a, this.bv = a.vb);
};
var Cr = function(a) {
  var b = new xr;
  b.callback(a);
  return b;
}, Dr = function(a) {
  var b = new xr;
  b.Yc(a);
  return b;
}, zr = function() {
  Ba.call(this);
};
w(zr, Ba);
zr.prototype.message = "Deferred has already fired";
zr.prototype.name = "AlreadyCalledError";
var yr = function() {
  Ba.call(this);
};
w(yr, Ba);
yr.prototype.message = "Deferred was canceled";
yr.prototype.name = "CanceledError";
var Br = function(a) {
  this.vb = h.setTimeout(u(this.Wba, this), 0);
  this.Nr = a;
};
Br.prototype.Wba = function() {
  x(Ar[this.vb], "Cannot throw an error that is not scheduled.");
  delete Ar[this.vb];
  throw this.Nr;
};
Br.prototype.E7 = function() {
  h.clearTimeout(this.vb);
};
var Ar = {};
var Er = function() {
};
Er.prototype.load = function(a) {
  this.a.w("Loading gapi for realtime client");
  var b = window.gapi;
  b ? a(b) : (new ik("notneeded", void 0, void 0, !0, !1, void 0)).init().then(function(b) {
    a(b);
  });
};
Er.prototype.a = D("mr.mirror.hangouts.ClientLoader");
var Fr = function() {
};
la(Fr, Hq);
Fr.prototype.lo = function(a) {
  var b = new xr;
  chrome.system.cpu.getInfo(function(a) {
    b.callback(a);
  });
  return b.eb(function(b) {
    a(b);
  });
};
Fr.prototype.mo = function() {
  function a(a) {
    hh(10);
    if (void 0 == c) {
      uh("mr.mirror.hangouts.HangoutsService").then(function(a) {
        if (a = a.Ha) {
          a = a.$a.mediaSource, -1 != a.indexOf(":tab:") && (a = a.split(":"), chrome.processes.getProcessIdForTab(parseInt(a[a.length - 1], 10), function(a) {
            chrome.runtime.lastError || (c = a);
          }));
        }
      });
    } else {
      var e = a[c];
      if (e) {
        var g = 0, k = 0, q = 0, r;
        for (r in a) {
          var A = a[r];
          "browser" == A.type ? k = A.cpu : "gpu" == A.type ? q = A.cpu : "extension" == A.type && A.title == chrome.runtime.getManifest().name && (g = A.cpu);
        }
        b({tabCpuUsage:e.cpu, browserCpuUsage:k, gpuCpuUsage:q, pluginCpuUsage:g});
      }
    }
  }
  if (!chrome.processes) {
    return null;
  }
  var b = n, c;
  return {onMessage:{addListener:function(c) {
    x(b == n);
    b = c;
    chrome.processes.onUpdated.addListener(a);
  }}, disconnect:function() {
    chrome.processes.onUpdated.removeListener(a);
    b = n;
  }};
};
dq(Fr, Hq, 2);
var Gr = function(a) {
  this.Rp = a;
};
Gr.prototype.onError = function(a, b) {
  401 == b.Kl && this.Rp(new Gh("REFRESH_AUTH"));
};
Gr.prototype.onRequest = n;
Gr.prototype.s4 = n;
var Hr = function(a, b, c) {
  F.call(this, "r");
  this.sessionId = a;
  c.clone();
};
w(Hr, F);
var Ir = function(a, b) {
  F.call(this, "u");
  this.za = a;
  this.data = b;
};
w(Ir, F);
var Jr = function(a) {
  F.call(this, "v");
  this.data = a;
};
w(Jr, F);
var Kr = function(a, b) {
  var c = window.crypto || window.msCrypto;
  c && c.getRandomValues && !b && (this.Eq = !0, this.Vi = Infinity, this.Wr = !0);
  a && this.l$(a);
};
d = Kr.prototype;
d.tT = function(a) {
  var b = {}, c = window.localStorage || {}, e = window.sessionStorage || {}, f = this;
  a && this.T6(a);
  if (!this.Eq) {
    b.pna = this.yf();
    b.Xna = (new Date).toLocaleString();
    b.local = {};
    for (a = 0;a < c.length;a++) {
      var g = c.key(a);
      b.local[g] = c[g];
    }
    b.session = {};
    for (a = 0;a < e.length;a++) {
      g = e.key(a), b.session[g] = e[g];
    }
    b.noa = Math.random();
    b.ooa = Math.random();
    a = 1E4 * Math.random() + 10e3;
    for (c = {};e = Math.floor(Math.random() * a), !c[e];) {
      c[e] = 1;
    }
    b.poa = Math.random();
    b.ET = 0;
    for (b.FT = this.yf();75 > this.yf() - b.FT;) {
      b.ET++;
    }
    try {
      b.N0 = window.history.length;
    } catch (r) {
      b.N0 = r.message;
    }
    b.window = this.Uf(window);
    b.document = this.Uf(document);
    b.screen = this.Uf(window.screen);
    try {
      b.documentElement = this.Uf(document.documentElement);
    } catch (r) {
      b.documentElement = r.message;
    }
    b.navigator = this.Uf(window.navigator);
    try {
      b.performance = Lr(window.performance);
    } catch (r) {
      b.performance = r.message;
    }
    b.EV = [];
    a = u(function(a) {
      b.EV.push(this.Uf(a));
    }, this);
    this.EC(window, a, 0);
    b.plugins = [];
    if (navigator.plugins) {
      for (a = 0;a < navigator.plugins.length;a++) {
        c = navigator.plugins[a];
        e = this.Uf(c);
        e.media = [];
        for (g = 0;g < c.length;g++) {
          e.media.push(this.Uf(c[g]));
        }
        b.plugins.push(e);
      }
    }
    this.b8();
    this.a8();
    var k = function(a) {
      setTimeout(function() {
        f.TO();
        k(a);
      }, a);
    };
    k(this.cQ);
    var q = function(a) {
      setTimeout(function() {
        f.TO();
        q(a);
      }, a);
    };
    q(1);
    b.Wla = this.yf();
    this.Lq(Lr(b), 0);
  }
};
d.yf = function() {
  return window.performance && window.performance.now && window.performance.timing && window.performance.timing.navigationStart ? window.performance.now() + window.performance.timing.navigationStart : (new Date).getTime();
};
d.Eq = !1;
d.Ag = "";
d.mA = "";
d.Ot = 0;
var Mr = ["click", "mousedown", "mouseup", "mouseover", "mouseout", "mousemove", "mouseenter", "mouseleave", "selectstart", "keypress", "keydown", "keyup", "blur", "focus", "change", "select", "submit", "input", "touchstart", "touchmove", "touchend", "touchcancel", "beforeunload", "DOMContentLoaded", "load", "orientationchange", "readystatechange", "resize", "scroll", "unload", "hashchange", "pagehide", "pageshow", "popstate", Wc, Xc, Yc, Zc, "pointerdown", "pointerup", "pointermove", "pointerenter", 
"pointerleave", "visibilitychange"];
d = Kr.prototype;
d.Cv = 100;
d.LP = 1;
d.ZP = 10;
d.fQ = 160;
d.gQ = 10;
d.CQ = "RANDOM_SALT:";
d.cD = "SEED_SALT:";
d.bQ = "/google/crypt/Random/seed.key";
d.cQ = 60e3;
d.eQ = 2;
d.UP = 500;
d.Vi = -1;
d.l$ = function(a) {
  if (a < this.fQ && a > this.Vi) {
    var b = this.Ag, c = this.Vi;
    this.Ag = "";
    this.Vi = a;
    this.Lq(b, Math.max(0, c));
    this.Wr = !1;
  }
  return this.Vi;
};
d.T6 = function(a) {
  var b = this;
  if (ua(a) && a) {
    if (b.Wr) {
      a();
    } else {
      var c = function(e) {
        setTimeout(function() {
          b.Wr ? a() : c(e);
        }, e);
      };
      c(this.UP);
    }
  }
};
d.TO = function() {
  if (!this.Eq) {
    try {
      var a = new Li;
      a.update(this.Ag);
      a.update(String(this.yf()));
      window.localStorage.setItem(this.bQ, String.fromCharCode.apply(String, a.digest()));
    } catch (b) {
    }
  }
};
d.Uf = function(a, b) {
  var c = {}, e = {};
  b = b || {};
  if (null == a) {
    return {type:typeof a};
  }
  try {
    a.constructor && (e = a.constructor.prototype);
    a.__proto__ && (e = a.__proto__);
    for (var f in a) {
      if (a[f] != e[f] && a[f] != b[f] && "function" != typeof a[f]) {
        try {
          c[f] = String(a[f]), c[f].length > this.Cv && (c[f] = c[f].substr(0, this.Cv / 2) + c[f].substr(c[f].length - this.Cv / 2) + "," + c[f].length);
        } catch (g) {
          c[f] = String(g + ": " + g.message);
        }
      }
    }
  } catch (g) {
    c = {message:String(g.message)};
  }
  return c;
};
d.EC = function(a, b, c) {
  if (a && !(c > this.gQ)) {
    try {
      for (var e = 0;e < a.frames.length;e++) {
        a.frames[e].parent == a && a.frames[e] != a && this.EC(a.frames[e], b, c + 1);
      }
      a.top == a && a.opener && a.opener != a && this.EC(a.opener.top, b, c + 1);
      b(a);
    } catch (f) {
    }
  }
};
d.Or = 0;
d.tJ = 0;
d.mx = 0;
d.Wy = null;
d.Uy = null;
d.Vy = "";
d.VU = function(a, b, c) {
  var e = {}, f = Math.floor(this.yf() / 1e3);
  f == this.tJ ? this.mx++ : (this.mx = 1, this.tJ = f);
  if (!(10 < this.mx)) {
    f = {beforepaste:1, beforecopy:1, beforecut:1, keydown:1, mousemove:1, mousedown:1, touchstart:1};
    if (c) {
      for (var g = 0;g < c.length;g++) {
        var k = c[g], q = this.Wy || {};
        k in a && q[k] != a[k] && ("object" == typeof a[k] ? e[k] = this.Uf(a[k], q[k]) : a[k] == q[k] || "function" == typeof a[k] || a.constructor && a.constructor.prototype == a[k] || (e[k] = String(a[k])));
      }
    } else {
      for (k in a) {
        q = this.Wy || {}, q[k] != a[k] && ("object" == typeof a[k] ? e[k] = this.Uf(a[k], q[k]) : a[k] == q[k] || "function" == typeof a[k] || a.constructor && a.constructor.prototype == a[k] || (e[k] = String(a[k])));
      }
    }
    e.time = this.yf();
    this.Pr.push(e);
    if (a.target != this.Uy || a.type != this.Vy) {
      this.Or += f[a.type] || 0;
    }
    this.Wy = a;
    this.Uy = a.target || null;
    this.Vy = a.type;
    b == window && (this.Uy = null, this.Vy = "");
    if (10 <= this.Pr.length) {
      var r = this.Pr, A = this.Or, g = 0, E = new Li, aa = this, ba = function(a) {
        setTimeout(function() {
          g >= r.length ? aa.Lq(String.fromCharCode.apply(String, E.digest()), A) : (E.update(Lr(r[g++])), ba(a));
        }, a);
      };
      ba(this.ZP);
      this.Pr = [];
      this.Or = 0;
    }
  }
};
d.a8 = function() {
  var a = this, b = function(b) {
    a.VU(b, this, void 0);
  };
  this.Pr = [];
  jd(window, "devicemotion", b);
  jd(window, "deviceorientation", b);
  for (var c = 0;c < Mr.length;c++) {
    var e = Mr[c];
    p(e) && (jd(window, e, b), jd(document, e, b), document.documentElement && jd(document.documentElement, e, b));
  }
  jd(window, "error", b);
};
d.Zy = 0;
d.e1 = function() {
  var a = this.yf(), b = Math.abs(a - 100 - this.Zy) % 100;
  this.Zy = a;
  b > this.LP && (this.Yy.push([b, this.yf(), Math.random()]), 10 < this.Yy.length && (this.Lq(Lr(b), 5), this.Yy = []));
};
d.b8 = function() {
  this.Zy = this.yf();
  this.Yy = [];
  var a = this, b = function(c) {
    setTimeout(function() {
      a.e1();
      b(c);
    }, c);
  };
  b(100);
};
d.Lq = function(a, b) {
  if (!this.Eq) {
    a = this.mA + a;
    var c = new Li;
    c.update(a);
    a = String.fromCharCode.apply(String, c.digest());
    this.Ot += b;
    this.Ot >= this.Vi ? (c.reset(), c.update(this.cD + a + this.Ag), this.Ag = String.fromCharCode.apply(String, c.digest()), this.mA = "", this.Ot = 0, this.Wr = !0) : this.mA = a;
  }
};
d.EY = function(a) {
  a = new window.Uint8Array(Math.min(65536, a));
  (window.crypto || window.msCrypto).getRandomValues(a);
  return [].slice.call(a);
};
d.fZ = function(a) {
  var b = [];
  if (this.Eq) {
    b = this.EY(a || 1);
  } else {
    if (0 > this.Vi || 0 == this.Ag.length) {
      throw new Nr;
    }
    var c = new Li;
    c.update(this.CQ + this.Ag);
    var e = c.digest();
    null !== e && (c.reset(), c.update(this.cD + this.Ag), this.Ag = String.fromCharCode.apply(String, c.digest()), b = e.slice(0, a || e.length));
  }
  return b;
};
d.AH = function(a) {
  for (var b = [], c = 0;b.length < a && c < a * this.eQ;) {
    b.push.apply(b, this.fZ(a - b.length)), c++;
  }
  if (b.length < a) {
    throw new Nr;
  }
  return b.slice(0, a);
};
var Nr = function() {
};
w(Nr, Error);
Nr.prototype.name = "Insufficient Entropy";
var Lr = function(a) {
  if (window.JSON) {
    try {
      return window.JSON.stringify(a);
    } catch (e) {
    }
  }
  var b = [], c;
  for (c in a) {
    try {
      "object" == typeof a[c] ? b.push(c, Lr(a[c])) : b.push(c, a[c]);
    } catch (e) {
      b.push(c, e.message);
    }
  }
  return b.join(",");
};
var Or = function(a, b, c, e, f, g) {
  xr.call(this, f, g);
  this.hz = a;
  this.Ww = [];
  this.NF = !!b;
  this.wV = !!c;
  this.CT = !!e;
  for (b = this.kK = 0;b < a.length;b++) {
    a[b].Bi(u(this.jI, this, b, !0), u(this.jI, this, b, !1));
  }
  0 != a.length || this.NF || this.callback(this.Ww);
};
w(Or, xr);
Or.prototype.jI = function(a, b, c) {
  this.kK++;
  this.Ww[a] = [b, c];
  this.qc || (this.NF && b ? this.callback([a, c]) : this.wV && !b ? this.Yc(c) : this.kK == this.hz.length && this.callback(this.Ww));
  this.CT && !b && (c = null);
  return c;
};
Or.prototype.Yc = function(a) {
  Or.T.Yc.call(this, a);
  for (a = 0;a < this.hz.length;a++) {
    this.hz[a].cancel();
  }
};
var Pr = function(a, b) {
  G.call(this);
  this.ll = a;
  x(0 < b.getAudioTracks().length);
  this.gv = window.URL.createObjectURL(b);
  this.Ia = new tk(this);
  this.la(this.Ia);
  this.wh = [];
  this.Im(1.0);
};
w(Pr, G);
d = Pr.prototype;
d.Im = function(a) {
  var b = Math.ceil(a) - this.wh.length;
  0 < b ? this.qR(b) : 0 > b && this.f7(-b);
  0.0 < a ? this.wh[0].volume = a - (this.wh.length - 1) : x(0 == this.wh.length);
};
d.qR = function(a) {
  x(0 < a);
  for (var b = [], c = 0;c < a;++c) {
    var e = this.ll.createElement("AUDIO"), f = new xr;
    e.autoplay = !0;
    e.src = this.gv;
    this.Ia.hp(e, "playing", u(f.callback, f));
    this.wh.push(e);
    b.push(f);
    this.ll.appendChild(this.ll.Un.body, e);
  }
  (new Or(b)).eb(u(this.dispatchEvent, this, "playing"));
};
d.f7 = function(a) {
  x(0 < a);
  for (var b = 0;b < a;++b) {
    var c = this.wh.pop();
    c.src = "";
    this.ll.removeNode(c);
  }
};
d.U = function() {
  this.Im(0.0);
  window.URL.revokeObjectURL(this.gv);
  Pr.T.U.call(this);
};
d.no = function() {
  return 0 == this.wh.length ? null : this.wh[0].currentTime;
};
var Qr = function(a, b) {
  G.call(this);
  a = a || 4194304;
  this.ao = this.Lz = null;
  this.rg = new Uint8Array(a + (b || 10485760));
  this.nj = this.rg.subarray(0, a);
  this.gd = this.rg.subarray(a);
  this.od = this.Sm = 0;
  this.$h = [];
};
w(Qr, G);
Qr.prototype.open = function(a, b, c) {
  if (!this.Lz) {
    var e = H();
    this.Lz = e.promise;
    a = this.iX(a, b, !!c);
    b = this.kX(a);
    b = this.W1(b);
    this.jX(b, a).then(function(a) {
      this.ao = a;
      this.dx();
      e.resolve();
    }, u(e.reject, e), this);
  }
  return this.Lz;
};
var Rr = function(a) {
  if (Uint8Array.__proto__.from) {
    return Uint8Array.from(a);
  }
  a = Object(a);
  if (!a.length) {
    return new Uint8Array(0);
  }
  for (var b = new Uint8Array(a.length), c = 0;c < b.length;c++) {
    b[c] = a[c];
  }
  return b;
};
d = Qr.prototype;
d.write = function(a) {
  y(a, function(a) {
    this.$h.push(Rr(gi(a)));
  }, this);
  this.dx();
};
d.Bb = function() {
  return 0 == this.od && 0 == this.$h.length;
};
d.gG = function() {
  var a = 0, b = [];
  if (this.od > this.rg.length) {
    for (var c = this.nj.length;c && 127 < this.nj[c - 1];) {
      c--;
    }
    for (var e = this.gd.length, f = this.Sm;e && 127 < this.gd[f];) {
      f++, e--, f == this.gd.length && (f = 0);
    }
    b.push(this.nj.subarray(0, c));
    a += c;
    c = this.h_(this.od - c - e);
    b.push(c);
    a += c.length;
    f + e <= this.gd.length ? b.push(this.gd.subarray(f, f + e)) : (b.push(this.gd.subarray(f)), b.push(this.gd.subarray(0, e - (this.gd.length - f))));
    a += e;
  } else {
    this.od && (a += this.od, b.push(this.rg.subarray(0, this.od)));
  }
  this.$h.length && y(this.$h, function(c) {
    b.push(c);
    a += c.length;
  });
  var g = new Uint8Array(a), k = 0;
  y(b, function(a) {
    g.set(a, k);
    k += a.length;
  });
  return g;
};
d.iX = function(a, b, c) {
  var e = H();
  a.then(function(a) {
    a.getFile(b, c ? {} : {create:!0}, u(e.resolve, e), u(e.reject, e));
  }, u(e.reject, e));
  return e.promise;
};
d.kX = function(a) {
  var b = H();
  a.then(function(a) {
    a.file(u(b.resolve, b), u(b.reject, b));
  }, u(b.reject, b));
  return b.promise;
};
d.W1 = function(a) {
  var b = H();
  a.then(function(a) {
    this.od = a.size;
    if (this.od > this.rg.length) {
      var c = H(), f = new FileReader;
      f.onload = u(function() {
        this.nj.set(new Uint8Array(f.result));
        c.resolve();
      }, this);
      f.readAsArrayBuffer(a.slice(0, this.nj.length));
      var g = H(), k = new FileReader;
      k.onload = u(function() {
        this.gd.set(new Uint8Array(k.result));
        g.resolve();
      }, this);
      k.readAsArrayBuffer(a.slice(a.size - this.gd.length, a.size));
      b.resolve(be([c.promise, g.promise]));
    } else {
      var q = new FileReader;
      q.onload = u(function() {
        var a = new Uint8Array(q.result);
        this.rg.set(a);
        this.od > this.nj.length && (this.Sm = (this.od - this.nj.length) % this.gd.length);
        b.resolve();
      }, this);
      q.readAsArrayBuffer(a);
    }
  }, u(b.reject, b), this);
  return b.promise;
};
d.jX = function(a, b) {
  var c = H();
  ae([a, b]).then(function(a) {
    a[1].createWriter(u(function(a) {
      a.seek(a.length);
      a.onwriteend = u(this.dx, this);
      c.resolve(a);
    }, this), u(c.reject, c));
  }, u(c.reject, c), this);
  return c.promise;
};
d.dx = function() {
  this.ao && this.ao.readyState != this.ao.WRITING && 0 < this.$h.length && (this.ao.write(new Blob(this.$h)), y(this.$h, function(a) {
    var b = this.od;
    this.od += a.length;
    if (b < this.rg.length) {
      var c = a.subarray(0, Math.min(this.rg.length - b, a.length));
      this.rg.set(c, b);
      a = a.subarray(c.length);
    }
    for (b = this.gd.length - this.Sm;a.length;) {
      c = a.subarray(0, Math.min(b, a.length)), this.gd.set(c, this.Sm), a = a.subarray(c.length), this.Sm = c.length == b ? 0 : this.Sm + c.length, b = this.gd.length;
    }
  }, this), this.$h.length = 0);
};
d.h_ = function(a) {
  return Rr(gi("...\r\n\r\n##### LOG TRUNCATED - REMOVED " + a + " BYTES#####\r\n\r\n..."));
};
var Sr = new I("wduck", "googDucking", "audio_echo_cancellation", "googEchoCancellation", "audio_echo_cancellation_delay_correction", "googEchoCancellation2", "audio_auto_gain_control", "googAutoGainControl", "internal_audio_auto_gain_control", "googAutoGainControl2", "audio_noise_suppression", "googNoiseSuppression", "audio_highpass_filter", "googHighpassFilter", "audio_stereo_swapping", "googAudioMirroring", "audio_transient_suppression", "googNoiseSuppression2");
new Ae(Sr.ub());
var Tr = new I("vnr", "googNoiseReduction");
new Ae(["vnr"]);
new Ae(Tr.ub());
var Ur = function() {
  G.call(this);
};
w(Ur, G);
Ur.prototype.r7 = function() {
  this.dispatchEvent("w");
};
var Vr = function(a, b, c) {
  F.call(this, "s");
  this.state = b;
  this.sessionId = c;
};
w(Vr, F);
var Wr = function(a, b, c, e, f, g, k) {
  G.call(this);
  this.da = a;
  this.vb = b;
  this.Jd = c;
  this.Kb = l(e) ? e : "ya";
  this.F = l(f) ? f : "Aa";
  this.sh = !1;
  this.dn = null;
  this.QJ(k || null);
  this.Mp = l(g) ? g : null;
  this.WU = !1;
};
w(Wr, G);
d = Wr.prototype;
d.toString = function() {
  return "Source(id=" + this.vb + " type=" + this.Jd + " content=" + this.Kb + " state=" + this.F + " participantId=" + this.da + ")";
};
d.A = function() {
  return this.da;
};
d.Sa = function(a) {
  this.da = a;
};
d.getId = function() {
  return this.vb;
};
d.N = function() {
  return this.Jd;
};
d.j9 = function(a) {
  this.Kb != a && (this.Kb = a, this.dispatchEvent("x"));
};
d.eaa = function(a) {
  this.Mp != a && (this.Mp = a, this.dispatchEvent("y"));
};
d.getState = function() {
  return this.F;
};
d.ec = function(a) {
  this.F != a && (this.F = a, this.dispatchEvent("z"));
};
d.bO = function(a) {
  this.QJ(a) && this.dispatchEvent("A");
};
d.QJ = function(a) {
  var b = null != this.dn && 0 != this.dn.length, c = null != a && 0 != a.length;
  c ? (a = B(a), Bb(a, function(a, b) {
    return a.left - b.left || a.top - b.top || a.width - b.width || a.height - b.height;
  })) : a = null;
  if (b = c != b || c && !Fb(this.dn, a, $q)) {
    this.dn = a;
  }
  return b;
};
d.gI = function() {
  return null != this.dn ? B(this.dn) : null;
};
d.dispatchEvent = function(a) {
  return this.WU ? !1 : Wr.T.dispatchEvent.call(this, a);
};
var Xr = function() {
  G.call(this);
  this.pk = [];
};
w(Xr, G);
Xr.prototype.add = function(a, b) {
  if (null != this.Vr(a.N(), a.getId(), a.A())) {
    return !1;
  }
  this.pk.push(a);
  l(b) && !b || a.xu(this);
  this.dispatchEvent(new Yr("B", a));
  return !0;
};
Xr.prototype.remove = function(a) {
  return ub(this.pk, a) ? (a.vp == this && a.xu(null), this.dispatchEvent(new Yr("C", a)), !0) : !1;
};
Xr.prototype.getSources = function() {
  return B(this.pk);
};
Xr.prototype.Vr = function(a, b, c) {
  return mb(this.pk, function(e) {
    var f = e.N() == a, g = null == b || e.getId() == b;
    e = null == c || e.A() == c;
    return f && g && e;
  });
};
var Yr = function(a, b) {
  F.call(this, a);
  this.source = b;
};
w(Yr, F);
var Zr = function() {
  G.call(this);
};
w(Zr, G);
var $r = function(a, b, c) {
  F.call(this, a);
  this.da = b;
  this.nba = c;
};
w($r, F);
$r.prototype.A = function() {
  return this.da;
};
$r.prototype.oy = function() {
  return this.nba;
};
var as = function(a, b, c, e) {
  G.call(this);
  this.da = a;
  this.Ec = b;
  this.GI = c;
  this.F = l(e) ? e : "Na";
};
w(as, G);
d = as.prototype;
d.A = function() {
  return this.da;
};
d.ya = function() {
  return this.Ec;
};
d.getState = function() {
  return this.F;
};
d.ec = function(a) {
  a != this.F && (this.F = a, this.dispatchEvent("F"));
};
d.getInfo = function() {
  return this.GI;
};
d.P9 = function(a) {
  this.GI = a;
};
var bs = function() {
  G.call(this);
};
w(bs, G);
var cs = function(a) {
  F.call(this, "G");
  this.QA = B(a);
};
w(cs, F);
var ds = function() {
  G.call(this);
  this.mj = !1;
};
w(ds, G);
pa(ds);
var es = function(a) {
  G.call(this);
  this.yi = a || window;
  this.iz = jd(this.yi, "resize", this.i0, !1, this);
  this.iq = Jj(this.yi || window);
};
w(es, G);
es.prototype.getSize = function() {
  return this.iq ? this.iq.clone() : null;
};
es.prototype.U = function() {
  es.T.U.call(this);
  this.iz && (td(this.iz), this.iz = null);
  this.iq = this.yi = null;
};
es.prototype.i0 = function() {
  var a = Jj(this.yi || window), b = this.iq;
  a == b || a && b && a.width == b.width && a.height == b.height || (this.iq = a, this.dispatchEvent("resize"));
};
var fs = function(a) {
  G.call(this);
  this.yi = a ? a.getWindow() : window;
  this.kJ = this.HG();
  this.Cg = u(this.Y_, this);
  this.st = this.yi.matchMedia ? this.yi.matchMedia("(min-resolution: 1.5dppx), (-webkit-min-device-pixel-ratio: 1.5)") : null;
};
w(fs, G);
fs.prototype.start = function() {
  this.st && this.st.addListener(this.Cg);
};
fs.prototype.HG = function() {
  return 1.5 <= this.yi.devicePixelRatio ? 2 : 1;
};
fs.prototype.Y_ = function() {
  var a = this.HG();
  this.kJ != a && (this.kJ = a, this.dispatchEvent("K"));
};
fs.prototype.U = function() {
  this.st && this.st.removeListener(this.Cg);
  fs.T.U.call(this);
};
var gs = function(a) {
  P(this, a, 0, -1, null, null);
};
w(gs, O);
gs.prototype.b = function(a) {
  return hs(a, this);
};
var hs = function(a, b) {
  var c, e = {ypa:(c = b.FY()) && is(a, c), Wka:(c = b.TW()) && js(a, c), sla:(c = b.dX()) && js(a, c), Jna:(c = b.RX()) && ks(a, c)};
  a && (e.f = b);
  return e;
};
gs.prototype.FY = function() {
  return U(this, ls, 1);
};
gs.prototype.TW = function() {
  return U(this, ms, 2);
};
gs.prototype.dX = function() {
  return U(this, ms, 3);
};
gs.prototype.RX = function() {
  return U(this, ns, 4);
};
var ls = function(a) {
  P(this, a, 0, -1, null, null);
};
w(ls, O);
ls.prototype.b = function(a) {
  return is(a, this);
};
var is = function(a, b) {
  var c = {Xia:R(b, 1), networkType:R(b, 2)};
  a && (c.f = b);
  return c;
}, ms = function(a) {
  P(this, a, 0, -1, null, null);
};
w(ms, O);
ms.prototype.b = function(a) {
  return js(a, this);
};
var js = function(a, b) {
  var c = {Mna:R(b, 1), foa:R(b, 2), accuracy:fr(b, 3)};
  a && (c.f = b);
  return c;
}, ns = function(a) {
  P(this, a, 0, -1, null, null);
};
w(ns, O);
ns.prototype.b = function(a) {
  return ks(a, this);
};
var ks = function(a, b) {
  var c = {gia:R(b, 1), fia:R(b, 2), dqa:R(b, 3), jra:R(b, 4)};
  a && (c.f = b);
  return c;
};
var os = function(a) {
  P(this, a, 0, -1, null, null);
};
w(os, O);
os.prototype.b = function(a) {
  return ps(a, this);
};
var ps = function(a, b) {
  var c, e = {hla:R(b, 1), ena:(c = b.JX()) && qs(a, c)};
  a && (e.f = b);
  return e;
};
os.prototype.JX = function() {
  return U(this, rs, 2);
};
var rs = function(a) {
  P(this, a, 0, -1, null, null);
};
w(rs, O);
rs.prototype.b = function(a) {
  return qs(a, this);
};
var qs = function(a, b) {
  var c = {rpa:R(b, 1), mna:R(b, 2), mka:R(b, 3), P6:R(b, 4), yna:R(b, 5), Bta:S(b, 6, 99)};
  a && (c.f = b);
  return c;
};
var ss = function(a) {
  P(this, a, 0, -1, null, null);
};
w(ss, O);
ss.prototype.b = function(a) {
  return ts(a, this);
};
var ts = function(a, b) {
  var c = {$:R(b, 1), WR:R(b, 2)};
  a && (c.f = b);
  return c;
};
ss.prototype.O = function() {
  return R(this, 1);
};
ss.prototype.L = function(a) {
  T(this, 1, a);
};
var us = function(a) {
  P(this, a, 0, 1, null, null);
};
w(us, O);
us.prototype.b = function(a) {
  return vs(a, this);
};
var vs = function(a, b) {
  var c = {}, e = ws, f = us.prototype.getExtension, g;
  for (g in e) {
    var k = e[g], q = f.call(b, k);
    if (q) {
      for (var r in k.kV) {
        if (k.kV.hasOwnProperty(r)) {
          break;
        }
      }
      c[r] = k.CO ? k.w1 ? Q(q, k.CO, a) : k.CO(a, q) : q;
    }
  }
  a && (c.f = b);
  return c;
}, ws = {};
var ys = function(a) {
  P(this, a, 0, -1, xs, null);
};
w(ys, O);
var xs = [10];
ys.prototype.b = function(a) {
  return zs(a, this);
};
var zs = function(a, b) {
  var c = {$:R(b, 1), QS:R(b, 2), type:R(b, 4), jO:R(b, 5), Bla:R(b, 6), ola:R(b, 7), ksa:R(b, 8), Hia:R(b, 9), pqa:Q(b.XY(), As, a), language:R(b, 11)};
  a && (c.f = b);
  return c;
};
d = ys.prototype;
d.O = function() {
  return R(this, 1);
};
d.L = function(a) {
  T(this, 1, a);
};
d.N = function() {
  return R(this, 4);
};
d.Rf = function(a) {
  T(this, 4, a);
};
d.XY = function() {
  return V(this, Bs, 10);
};
var Bs = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Bs, O);
Bs.prototype.b = function(a) {
  return As(a, this);
};
var As = function(a, b) {
  var c = {text:R(b, 1), confidence:fr(b, 2)};
  a && (c.f = b);
  return c;
};
var Cs = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Cs, O);
Cs.prototype.b = function(a) {
  return Ds(a, this);
};
var Ds = function(a, b) {
  var c = {$:R(b, 1), QS:R(b, 2)};
  a && (c.f = b);
  return c;
};
Cs.prototype.O = function() {
  return R(this, 1);
};
Cs.prototype.L = function(a) {
  T(this, 1, a);
};
var Es = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Es, O);
Es.prototype.b = function(a) {
  return Fs(a, this);
};
var Fs = function(a, b) {
  var c = {jta:S(b, 1, !1), language:S(b, 2, "en-US")};
  a && (c.f = b);
  return c;
};
var Gs = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Gs, O);
Gs.prototype.b = function(a) {
  return Hs(a, this);
};
var Hs = function(a, b) {
  var c = {rna:R(b, 1), zia:R(b, 2)};
  a && (c.f = b);
  return c;
};
var Is = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Is, O);
Is.prototype.b = function(a) {
  return Js(a, this);
};
var Js = function(a, b) {
  var c = {ota:R(b, 1), Xma:R(b, 2), Yma:R(b, 3), version:R(b, 4)};
  a && (c.f = b);
  return c;
};
Is.prototype.zf = function() {
  return R(this, 4);
};
Is.prototype.setVersion = function(a) {
  T(this, 4, a);
};
var Ks = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Ks, O);
Ks.prototype.b = function(a) {
  return Ls(a, this);
};
var Ls = function(a, b) {
  var c = {Pg:R(b, 1), clientId:R(b, 2), i8:R(b, 3), Oj:R(b, 4)};
  a && (c.f = b);
  return c;
};
d = Ks.prototype;
d.DB = function(a) {
  T(this, 1, a);
};
d.rc = function() {
  return R(this, 2);
};
d.Pe = function(a) {
  T(this, 2, a);
};
d.Gh = function() {
  return R(this, 4);
};
d.Ug = function(a) {
  T(this, 4, a);
};
var Ms = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Ms, O);
Ms.prototype.b = function(a) {
  return Ns(a, this);
};
var Ns = function(a, b) {
  var c = {Mja:R(b, 1)};
  a && (c.f = b);
  return c;
};
var Os = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Os, O);
Os.prototype.b = function(a) {
  return Ps(a, this);
};
var Ps = function(a, b) {
  var c = {clientId:R(b, 1), Zia:R(b, 2), loa:R(b, 3), version:R(b, 4), Xka:R(b, 5), Vka:R(b, 6), tia:R(b, 7)};
  a && (c.f = b);
  return c;
};
Os.prototype.rc = function() {
  return R(this, 1);
};
Os.prototype.Pe = function(a) {
  T(this, 1, a);
};
Os.prototype.zf = function() {
  return R(this, 4);
};
Os.prototype.setVersion = function(a) {
  T(this, 4, a);
};
var Qs = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Qs, O);
Qs.prototype.b = function(a) {
  return Rs(a, this);
};
var Rs = function(a, b) {
  var c = {id:R(b, 1)};
  a && (c.f = b);
  return c;
};
Qs.prototype.getId = function() {
  return R(this, 1);
};
Qs.prototype.tu = function(a) {
  T(this, 1, a);
};
var Ss = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Ss, O);
Ss.prototype.b = function(a) {
  return Ts(a, this);
};
var Ts = function(a, b) {
  var c = {bla:R(b, 1), Kla:R(b, 2)};
  a && (c.f = b);
  return c;
};
var Us = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Us, O);
Us.prototype.b = function(a) {
  return Vs(a, this);
};
var Vs = function(a, b) {
  var c = {Nsa:R(b, 1), Ila:R(b, 2)};
  a && (c.f = b);
  return c;
};
var Xs = function(a) {
  P(this, a, 0, -1, Ws, null);
};
w(Xs, O);
var Ws = [6];
Xs.prototype.b = function(a) {
  return Ys(a, this);
};
var Ys = function(a, b) {
  var c = {$:R(b, 1), KR:R(b, 2), uia:R(b, 3), wM:R(b, 4), Fsa:R(b, 5), Zqa:R(b, 6), locale:R(b, 7), action:R(b, 8), title:R(b, 9), body:R(b, 10), Pna:S(b, 11, 1)};
  a && (c.f = b);
  return c;
};
d = Xs.prototype;
d.O = function() {
  return R(this, 1);
};
d.L = function(a) {
  T(this, 1, a);
};
d.KH = function() {
  return R(this, 4);
};
d.getTitle = function() {
  return R(this, 9);
};
d.setTitle = function(a) {
  T(this, 9, a);
};
d.hs = function() {
  return R(this, 10);
};
d.qu = function(a) {
  T(this, 10, a);
};
var Zs = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Zs, O);
Zs.prototype.b = function(a) {
  return $s(a, this);
};
var $s = function(a, b) {
  var c = {$:R(b, 1), KR:R(b, 2)};
  a && (c.f = b);
  return c;
};
Zs.prototype.O = function() {
  return R(this, 1);
};
Zs.prototype.L = function(a) {
  T(this, 1, a);
};
var bt = function(a) {
  P(this, a, 0, -1, at, null);
};
w(bt, O);
var at = [1];
bt.prototype.b = function(a) {
  return ct(a, this);
};
var ct = function(a, b) {
  var c = {fla:Q(b.$W(), dt, a)};
  a && (c.f = b);
  return c;
};
bt.prototype.$W = function() {
  return V(this, et, 1);
};
var et = function(a) {
  P(this, a, 0, -1, null, null);
};
w(et, O);
et.prototype.b = function(a) {
  return dt(a, this);
};
var dt = function(a, b) {
  var c = {code:R(b, 1)};
  a && (c.f = b);
  return c;
};
var ft = function(a) {
  P(this, a, 0, -1, null, null);
};
w(ft, O);
ft.prototype.b = function(a) {
  return gt(a, this);
};
var gt = function(a, b) {
  var c = {service:R(b, 1), value:R(b, 2)};
  a && (c.f = b);
  return c;
};
ft.prototype.getService = function() {
  return R(this, 1);
};
ft.prototype.saa = function(a) {
  T(this, 1, a);
};
ft.prototype.vc = function() {
  return R(this, 2);
};
ft.prototype.QB = function(a) {
  T(this, 2, a);
};
var ht = function(a) {
  P(this, a, 0, -1, null, null);
};
w(ht, O);
ht.prototype.b = function(a) {
  return it(a, this);
};
var it = function(a, b) {
  var c = {$:R(b, 1)};
  a && (c.f = b);
  return c;
};
ht.prototype.O = function() {
  return R(this, 1);
};
ht.prototype.L = function(a) {
  T(this, 1, a);
};
var jt = function(a) {
  P(this, a, 0, -1, null, null);
};
w(jt, O);
jt.prototype.b = function(a) {
  return kt(a, this);
};
var kt = function(a, b) {
  var c = {Wqa:R(b, 1), Era:R(b, 2), dla:S(b, 3, 0)};
  a && (c.f = b);
  return c;
};
var lt = function(a) {
  P(this, a, 0, -1, null, null);
};
w(lt, O);
lt.prototype.b = function(a) {
  return mt(a, this);
};
var mt = function(a, b) {
  var c = {$ma:S(b, 3, !1), Cka:S(b, 4, !1)};
  a && (c.f = b);
  return c;
};
var nt = function(a) {
  P(this, a, 0, -1, null, null);
};
w(nt, O);
nt.prototype.b = function(a) {
  return ot(a, this);
};
var ot = function(a, b) {
  var c = {$:R(b, 1), za:R(b, 2)};
  a && (c.f = b);
  return c;
};
nt.prototype.O = function() {
  return R(this, 1);
};
nt.prototype.L = function(a) {
  T(this, 1, a);
};
nt.prototype.A = function() {
  return R(this, 2);
};
nt.prototype.Sa = function(a) {
  T(this, 2, a);
};
var qt = function(a) {
  P(this, a, 0, -1, pt, null);
};
w(qt, O);
var pt = [1];
qt.prototype.b = function(a) {
  return rt(a, this);
};
var rt = function(a, b) {
  var c = {cka:R(b, 1)};
  a && (c.f = b);
  return c;
};
var st = function(a) {
  P(this, a, 0, -1, null, null);
};
w(st, O);
st.prototype.b = function(a) {
  return tt(a, this);
};
var tt = function(a, b) {
  var c = {$oa:R(b, 1), qoa:R(b, 2), ssa:R(b, 3)};
  a && (c.f = b);
  return c;
};
st.prototype.mN = function(a) {
  T(this, 1, a);
};
st.prototype.fN = function(a) {
  T(this, 2, a);
};
st.prototype.RN = function(a) {
  T(this, 3, a);
};
var vt = function(a) {
  P(this, a, 0, -1, ut, null);
};
w(vt, O);
var ut = [8];
vt.prototype.b = function(a) {
  return wt(a, this);
};
var wt = function(a, b) {
  var c = {jqa:R(b, 1), name:R(b, 2), mediaType:R(b, 3), Aqa:R(b, 4), bitRate:R(b, 5), sampleRate:R(b, 6), channelCount:R(b, 7), gqa:Q(b.rH(), xt, a)};
  a && (c.f = b);
  return c;
};
d = vt.prototype;
d.RY = function() {
  return R(this, 1);
};
d.M$ = function(a) {
  T(this, 1, a);
};
d.getName = function() {
  return R(this, 2);
};
d.Dm = function(a) {
  T(this, 2, a);
};
d.P = function() {
  return R(this, 3);
};
d.oc = function(a) {
  T(this, 3, a);
};
d.dg = function() {
  T(this, 3, void 0);
};
d.ZV = function() {
  return R(this, 5);
};
d.R8 = function(a) {
  T(this, 5, a);
};
d.HZ = function() {
  return R(this, 6);
};
d.kaa = function(a) {
  T(this, 6, a);
};
d.rW = function() {
  return R(this, 7);
};
d.Z8 = function(a) {
  T(this, 7, a);
};
d.rH = function() {
  return V(this, yt, 8);
};
d.K$ = function(a) {
  X(this, 8, a);
};
var yt = function(a) {
  P(this, a, 0, -1, null, null);
};
w(yt, O);
yt.prototype.b = function(a) {
  return xt(a, this);
};
var xt = function(a, b) {
  var c = {key:R(b, 1), value:R(b, 2)};
  a && (c.f = b);
  return c;
};
yt.prototype.getKey = function() {
  return R(this, 1);
};
yt.prototype.V9 = function(a) {
  T(this, 1, a);
};
yt.prototype.vc = function() {
  return R(this, 2);
};
yt.prototype.QB = function(a) {
  T(this, 2, a);
};
var zt = function(a) {
  P(this, a, 0, -1, null, null);
};
w(zt, O);
zt.prototype.b = function(a) {
  return At(a, this);
};
var At = function(a, b) {
  var c = {Gsa:R(b, 1), Fna:R(b, 2), asa:R(b, 3), tag:R(b, 4)};
  a && (c.f = b);
  return c;
};
d = zt.prototype;
d.Lh = function() {
  return R(this, 1);
};
d.Faa = function(a) {
  T(this, 1, a);
};
d.zl = function() {
  return R(this, 2);
};
d.W9 = function(a) {
  T(this, 2, a);
};
d.Fo = function() {
  return R(this, 3);
};
d.vaa = function(a) {
  T(this, 3, a);
};
d.Ho = function() {
  return R(this, 4);
};
d.Haa = function(a) {
  T(this, 4, a);
};
var Bt = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Bt, O);
Bt.prototype.b = function(a) {
  return Ct(a, this);
};
var Ct = function(a, b) {
  var c = {component:R(b, 1), protocol:R(b, 2), ip:R(b, 3), port:R(b, 4), type:R(b, 5), priority:R(b, 6), network:R(b, 7), rma:R(b, 8), mediaType:R(b, 9)};
  a && (c.f = b);
  return c;
};
d = Bt.prototype;
d.Zi = function() {
  return R(this, 1);
};
d.h9 = function(a) {
  T(this, 1, a);
};
d.yg = function() {
  return R(this, 2);
};
d.Yp = function(a) {
  T(this, 2, a);
};
d.xl = function() {
  return R(this, 3);
};
d.R9 = function(a) {
  T(this, 3, a);
};
d.Wa = function() {
  return R(this, 4);
};
d.Fm = function(a) {
  T(this, 4, a);
};
d.CI = function() {
  return null != R(this, 4);
};
d.N = function() {
  return R(this, 5);
};
d.Rf = function(a) {
  T(this, 5, a);
};
d.ej = function() {
  return R(this, 6);
};
d.BN = function(a) {
  T(this, 6, a);
};
d.xo = function() {
  return R(this, 7);
};
d.y$ = function(a) {
  T(this, 7, a);
};
d.wl = function() {
  return R(this, 8);
};
d.I9 = function(a) {
  T(this, 8, a);
};
d.P = function() {
  return R(this, 9);
};
d.oc = function(a) {
  T(this, 9, a);
};
d.dg = function() {
  T(this, 9, void 0);
};
var Dt = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Dt, O);
Dt.prototype.b = function(a) {
  return Et(a, this);
};
var Et = function(a, b) {
  var c = {id:R(b, 1), uri:R(b, 2), mediaType:R(b, 3)};
  a && (c.f = b);
  return c;
};
d = Dt.prototype;
d.getId = function() {
  return R(this, 1);
};
d.tu = function(a) {
  T(this, 1, a);
};
d.Fl = function() {
  return R(this, 2);
};
d.Qaa = function(a) {
  T(this, 2, a);
};
d.P = function() {
  return R(this, 3);
};
d.oc = function(a) {
  T(this, 3, a);
};
d.dg = function() {
  T(this, 3, void 0);
};
var Ft = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Ft, O);
Ft.prototype.b = function(a) {
  return Gt(a, this);
};
var Gt = function(a, b) {
  var c = {sessionId:R(b, 1)};
  a && (c.f = b);
  return c;
};
Ft.prototype.s = function() {
  return R(this, 1);
};
Ft.prototype.Ca = function(a) {
  T(this, 1, a);
};
var Ht = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Ht, O);
Ht.prototype.b = function(a) {
  return It(a, this);
};
var It = function(a, b) {
  var c = {$:R(b, 1), za:R(b, 2), sourceId:R(b, 3)};
  a && (c.f = b);
  return c;
};
d = Ht.prototype;
d.O = function() {
  return R(this, 1);
};
d.L = function(a) {
  T(this, 1, a);
};
d.A = function() {
  return R(this, 2);
};
d.Sa = function(a) {
  T(this, 2, a);
};
d.ya = function() {
  return R(this, 3);
};
d.Qf = function(a) {
  T(this, 3, a);
};
var Jt = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Jt, O);
Jt.prototype.b = function(a) {
  return Kt(a, this);
};
var Kt = function(a, b) {
  var c = {$:R(b, 1), sessionId:R(b, 2), pO:R(b, 3), direction:R(b, 4)};
  a && (c.f = b);
  return c;
};
d = Jt.prototype;
d.O = function() {
  return R(this, 1);
};
d.L = function(a) {
  T(this, 1, a);
};
d.s = function() {
  return R(this, 2);
};
d.Ca = function(a) {
  T(this, 2, a);
};
d.Vb = function() {
  return R(this, 3);
};
d.lk = function(a) {
  T(this, 3, a);
};
d.jc = function() {
  return R(this, 4);
};
d.oe = function(a) {
  T(this, 4, a);
};
var Lt = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Lt, O);
Lt.prototype.b = function(a) {
  return Mt(a, this);
};
var Mt = function(a, b) {
  var c = {reason:R(b, 1)};
  a && (c.f = b);
  return c;
};
var Nt = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Nt, O);
Nt.prototype.b = function(a) {
  return Ot(a, this);
};
var Ot = function(a, b) {
  var c = {name:R(b, 1), domain:R(b, 2), jja:R(b, 3), Gla:R(b, 4)};
  a && (c.f = b);
  return c;
};
d = Nt.prototype;
d.getName = function() {
  return R(this, 1);
};
d.Dm = function(a) {
  T(this, 1, a);
};
d.Ch = function() {
  return R(this, 2);
};
d.Am = function(a) {
  T(this, 2, a);
};
d.Js = function() {
  return null != R(this, 2);
};
var Pt = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Pt, O);
Pt.prototype.b = function(a) {
  return Qt(a, this);
};
var Qt = function(a, b) {
  var c = {Eqa:R(b, 1), rw:R(b, 2)};
  a && (c.f = b);
  return c;
};
Pt.prototype.bZ = function() {
  return R(this, 1);
};
Pt.prototype.S$ = function(a) {
  T(this, 1, a);
};
Pt.prototype.sl = function() {
  return R(this, 2);
};
Pt.prototype.ym = function(a) {
  T(this, 2, a);
};
var Rt = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Rt, O);
Rt.prototype.b = function(a) {
  return St(a, this);
};
var St = function(a, b) {
  var c = {channelId:R(b, 1), format:R(b, 2), ssrc:R(b, 3), label:R(b, 4), type:R(b, 5)};
  a && (c.f = b);
  return c;
};
d = Rt.prototype;
d.getChannelId = function() {
  return R(this, 1);
};
d.a9 = function(a) {
  T(this, 1, a);
};
d.Mx = function() {
  return R(this, 2);
};
d.E9 = function(a) {
  T(this, 2, a);
};
d.zg = function() {
  return R(this, 3);
};
d.GB = function(a) {
  T(this, 3, a);
};
d.vg = function() {
  return R(this, 4);
};
d.X9 = function(a) {
  T(this, 4, a);
};
d.N = function() {
  return R(this, 5);
};
d.Rf = function(a) {
  T(this, 5, a);
};
var Tt = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Tt, O);
Tt.prototype.b = function(a) {
  return Ut(a, this);
};
var Ut = function(a, b) {
  var c = {action:R(b, 1), lsa:R(b, 2)};
  a && (c.f = b);
  return c;
};
var Vt = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Vt, O);
Vt.prototype.b = function(a) {
  return Wt(a, this);
};
var Wt = function(a, b) {
  var c = {za:R(b, 1), DL:S(b, 2, 0)};
  a && (c.f = b);
  return c;
};
Vt.prototype.A = function() {
  return R(this, 1);
};
Vt.prototype.Sa = function(a) {
  T(this, 1, a);
};
var Y = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Y, O);
Y.prototype.b = function(a) {
  return Z(a, this);
};
var Z = function(a, b) {
  var c, e = {version:R(b, 1), Jja:R(b, 2), Hma:(c = b.os()) && Xt(a, c)};
  a && (e.f = b);
  return e;
};
d = Y.prototype;
d.zf = function() {
  return R(this, 1);
};
d.setVersion = function(a) {
  T(this, 1, a);
};
d.os = function() {
  return U(this, Yt, 3);
};
d.uB = function(a) {
  W(this, 3, a);
};
d.yE = function() {
  this.uB(void 0);
};
var Yt = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Yt, O);
Yt.prototype.b = function(a) {
  return Xt(a, this);
};
var Xt = function(a, b) {
  var c = {cookie:R(b, 1), timestamp:R(b, 2)};
  a && (c.f = b);
  return c;
};
Yt.prototype.xE = function() {
  T(this, 1, void 0);
};
Yt.prototype.wI = function() {
  return null != R(this, 1);
};
Yt.prototype.jj = function() {
  return R(this, 2);
};
Yt.prototype.KB = function(a) {
  T(this, 2, a);
};
var Zt = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Zt, O);
Zt.prototype.b = function(a) {
  return $t(a, this);
};
var $t = function(a, b) {
  var c = {height:R(b, 1), width:R(b, 2), kma:R(b, 3)};
  a && (c.f = b);
  return c;
};
d = Zt.prototype;
d.tf = function() {
  return R(this, 1);
};
d.ik = function(a) {
  T(this, 1, a);
};
d.Af = function() {
  return R(this, 2);
};
d.mk = function(a) {
  T(this, 2, a);
};
d.oX = function() {
  return R(this, 3);
};
d.YM = function(a) {
  T(this, 3, a);
};
var bu = function(a) {
  P(this, a, "cl:plu", -1, au, null);
};
w(bu, O);
var au = [1];
bu.prototype.b = function(a) {
  var b = {eoa:Q(this.Tx(), cu, a)};
  a && (b.f = this);
  return b;
};
sr("cl:plu", bu);
bu.prototype.Tx = function() {
  return V(this, du, 1);
};
bu.prototype.eN = function(a) {
  X(this, 1, a);
};
var du = function(a) {
  P(this, a, 0, -1, null, null);
};
w(du, O);
du.prototype.b = function(a) {
  return cu(a, this);
};
var cu = function(a, b) {
  var c = {Dia:R(b, 1), sessionId:R(b, 2), timestamp:R(b, 3)};
  a && (c.f = b);
  return c;
};
d = du.prototype;
d.hG = function() {
  return R(this, 1);
};
d.N8 = function(a) {
  T(this, 1, a);
};
d.s = function() {
  return R(this, 2);
};
d.Ca = function(a) {
  T(this, 2, a);
};
d.jj = function() {
  return R(this, 3);
};
d.KB = function(a) {
  T(this, 3, a);
};
var eu = function(a) {
  P(this, a, 0, -1, null, null);
};
w(eu, O);
eu.prototype.b = function(a) {
  return fu(a, this);
};
var fu = function(a, b) {
  var c = {$:S(b, 1, ""), sessionId:S(b, 2, "")};
  a && (c.f = b);
  return c;
};
eu.prototype.O = function() {
  return S(this, 1, "");
};
eu.prototype.L = function(a) {
  T(this, 1, a);
};
eu.prototype.s = function() {
  return S(this, 2, "");
};
eu.prototype.Ca = function(a) {
  T(this, 2, a);
};
var gu = function(a) {
  P(this, a, 0, -1, null, null);
};
w(gu, O);
gu.prototype.b = function(a) {
  return hu(a, this);
};
var hu = function(a, b) {
  var c = {koa:S(b, 1, "")};
  a && (c.f = b);
  return c;
};
var iu = function(a) {
  P(this, a, 0, -1, null, null);
};
w(iu, O);
iu.prototype.b = function(a) {
  return ju(a, this);
};
var ju = function(a, b) {
  var c = {Rra:S(b, 1, 0), qpa:S(b, 2, 0)};
  a && (c.f = b);
  return c;
};
iu.prototype.getSeconds = function() {
  return S(this, 1, 0);
};
iu.prototype.setSeconds = function(a) {
  T(this, 1, a);
};
var lu = function(a) {
  P(this, a, 0, -1, ku, null);
};
w(lu, O);
var ku = [7, 13, 16, 17];
lu.prototype.b = function(a) {
  return mu(a, this);
};
var mu = function(a, b) {
  var c, e = {Roa:S(b, 1, ""), displayName:S(b, 2, ""), TD:S(b, 3, ""), Dna:S(b, 4, 0), joined:S(b, 5, !1), IU:S(b, 6, ""), x2:R(b, 7), Bma:S(b, 8, !1), Nka:S(b, 9, !1), Oka:S(b, 10, ""), oT:S(b, 11, 0), Eia:(c = b.SV()) && nu(a, c), Jqa:R(b, 13), Fia:(c = b.TV()) && ou(a, c), via:S(b, 15, !1), bra:Q(b.iZ(), pu, a), gra:Q(b.lZ(), qu, a)};
  a && (e.f = b);
  return e;
};
d = lu.prototype;
d.Bh = function() {
  return S(this, 2, "");
};
d.ZG = function() {
  return S(this, 5, !1);
};
d.SV = function() {
  return U(this, ru, 12);
};
d.TV = function() {
  return U(this, su, 14);
};
d.iZ = function() {
  return V(this, tu, 16);
};
d.lZ = function() {
  return V(this, uu, 17);
};
var ru = function(a) {
  P(this, a, 0, -1, null, null);
};
w(ru, O);
ru.prototype.b = function(a) {
  return nu(a, this);
};
var nu = function(a, b) {
  var c = {dja:S(b, 1, "")};
  a && (c.f = b);
  return c;
}, su = function(a) {
  P(this, a, 0, -1, null, null);
};
w(su, O);
su.prototype.b = function(a) {
  return ou(a, this);
};
var ou = function(a, b) {
  var c = {kpa:S(b, 1, "")};
  a && (c.f = b);
  return c;
}, tu = function(a) {
  P(this, a, 0, -1, null, null);
};
w(tu, O);
tu.prototype.b = function(a) {
  return pu(a, this);
};
var pu = function(a, b) {
  var c = {AA:S(b, 1, ""), hia:S(b, 2, 0)};
  a && (c.f = b);
  return c;
}, uu = function(a) {
  P(this, a, 0, -1, null, null);
};
w(uu, O);
uu.prototype.b = function(a) {
  return qu(a, this);
};
var qu = function(a, b) {
  var c = {AA:S(b, 1, ""), kka:S(b, 2, 0)};
  a && (c.f = b);
  return c;
};
var wu = function(a) {
  P(this, a, 0, -1, vu, null);
};
w(wu, O);
var vu = [5];
wu.prototype.b = function(a) {
  return xu(a, this);
};
var xu = function(a, b) {
  var c, e = {vz:S(b, 1, ""), ZJ:S(b, 2, ""), Voa:S(b, 3, ""), iia:S(b, 4, 0), lqa:Q(b.VY(), yu, a), lja:(c = b.hW()) && zu(a, c), y2:S(b, 7, "")};
  a && (e.f = b);
  return e;
};
d = wu.prototype;
d.Al = function() {
  return S(this, 1, "");
};
d.jk = function(a) {
  T(this, 1, a);
};
d.uo = function() {
  return S(this, 2, "");
};
d.Cm = function(a) {
  T(this, 2, a);
};
d.VY = function() {
  return V(this, Au, 5);
};
d.hW = function() {
  return U(this, Bu, 6);
};
var Au = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Au, O);
Au.prototype.b = function(a) {
  return yu(a, this);
};
var yu = function(a, b) {
  var c = {R5:S(b, 1, ""), pin:S(b, 2, ""), P6:S(b, 3, ""), J1:S(b, 4, "")};
  a && (c.f = b);
  return c;
};
Au.prototype.sH = function() {
  return S(this, 1, "");
};
Au.prototype.qo = function() {
  return S(this, 4, "");
};
Au.prototype.Bm = function(a) {
  T(this, 4, a);
};
var Cu = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Cu, O);
Cu.prototype.b = function(a) {
  return Du(a, this);
};
var Du = function(a, b) {
  var c = {Dqa:S(b, 1, ""), bja:S(b, 2, "")};
  a && (c.f = b);
  return c;
}, Eu = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Eu, O);
Eu.prototype.b = function(a) {
  return Fu(a, this);
};
var Fu = function(a, b) {
  var c = {L6:S(b, 1, 0), AA:S(b, 2, "")};
  a && (c.f = b);
  return c;
};
Eu.prototype.CH = function() {
  return S(this, 1, 0);
};
var Bu = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Bu, O);
Bu.prototype.b = function(a) {
  return zu(a, this);
};
var zu = function(a, b) {
  var c, e = {a6:(c = b.zo()) && Du(a, c), dra:(c = b.kZ()) && Fu(a, c), ija:S(b, 3, ""), Vpa:S(b, 4, ""), y2:S(b, 5, "")};
  a && (e.f = b);
  return e;
};
Bu.prototype.zo = function() {
  return U(this, Cu, 1);
};
Bu.prototype.AN = function(a) {
  W(this, 1, a);
};
Bu.prototype.kZ = function() {
  return U(this, Eu, 2);
};
var Gu = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Gu, O);
Gu.prototype.b = function(a) {
  return Hu(a, this);
};
var Hu = function(a, b) {
  var c = {version:S(b, 1, 0)};
  a && (c.f = b);
  return c;
};
Gu.prototype.zf = function() {
  return S(this, 1, 0);
};
Gu.prototype.setVersion = function(a) {
  T(this, 1, a);
};
var Iu = function(a, b) {
  Rc.call(this);
  this.Ba = a;
  b && this.J$(b);
};
w(Iu, Rc);
Iu.prototype.J$ = function(a) {
  if (this.YK) {
    throw Error("[fava.component.DomServices] Owner document already initialized");
  }
  this.Lr = (this.YK = a) ? new Pj(Nj(a)) : Ca || (Ca = new Pj);
  this.nv = new es(Kj(a));
  this.nv.xu(this.Ba.Vn);
  this.nA = new fs(this.Lr);
  this.nA.start();
};
Iu.prototype.U = function() {
  this.Lr = this.YK = null;
  this.nv && (this.nv.Qa(), this.nv = null);
  Sc(this.nA);
  this.nA = null;
};
var Ju = function() {
  Rc.call(this);
};
w(Ju, Rc);
Ju.prototype.a = zf("fava.debug.ErrorReporter");
Ju.prototype.init = function() {
};
new Ju;
var Lu = function() {
  this.Zh = new Ku;
  this.qr = null;
  this.version = 0;
};
w(Lu, Hp);
d = Lu.prototype;
d.e9 = function(a) {
  this.qr = a;
};
d.ZU = function(a) {
  Od(u(a.Mba, a));
};
d.hg = function(a) {
  return this.Ln(0, a);
};
d.ig = function(a) {
  return this.Ln(1, a);
};
d.gf = function(a, b) {
  return this.Ln(2, a, b);
};
d.qh = function(a) {
  return this.Ln(3, [a]);
};
d.rh = function() {
  return this.Ln(4, []);
};
d.Ln = function(a, b, c) {
  return new Mu(this, a, b, c);
};
var Ku = function() {
  G.call(this);
};
w(Ku, Ur);
Ku.prototype.execute = function(a) {
  a.execute();
};
var Mu = function(a, b, c) {
  this.Sh = a;
  this.Wz = b;
  this.Np = c;
  this.version = null;
  this.Zb = H();
  this.EF = !1;
};
d = Mu.prototype;
d.execute = function() {
  this.EF = !0;
  this.Sh.ZU(this);
};
d.KW = function() {
  if (!this.Sh.qr) {
    return null;
  }
  switch(this.Wz) {
    case 0:
      return this.Np;
    case 1:
      var a = [];
      y(this.JF(this.Np), function(b, e) {
        null === b || a.push(this.Np[e]);
      }, this);
      return a;
    case 2:
    case 3:
      var b = this.JF(this.Np);
      vb(b, ra);
      return b;
    case 4:
      return this.Sh.qr.get();
    default:
      return null;
  }
};
d.JF = function(a) {
  return z(a, this.tV, this);
};
d.tV = function(a) {
  var b = this.Sh.qr;
  if (!b) {
    return null;
  }
  var c = b.tc(a);
  return mb(b.get(), function(a) {
    return c.equals(b.tc(a));
  });
};
d.Mba = function(a, b) {
  if (a = a || this.KW()) {
    if (l(b)) {
      b > this.Sh.version && (this.Sh.version = b);
    } else {
      switch(this.Wz) {
        case 0:
        case 1:
        case 2:
          this.Sh.version++;
      }
    }
    this.Zb.resolve(new mp(a, l(b) ? b : this.Sh.version));
  } else {
    this.Zb.reject("Could not perform operation");
  }
};
d.rx = function(a) {
  this.Zb.reject(a);
};
d.$N = function(a) {
  this.version = a;
};
d.getPromise = function() {
  return this.Zb.promise;
};
d.ss = Ad(0);
d.yB = n;
d.Ds = Ad(0);
d.JB = n;
d.yI = function() {
  return this.EF;
};
d.$H = function() {
  return this.Wz.toString();
};
d.FH = function() {
  return this.Np.toString();
};
var Nu = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Nu, O);
Nu.prototype.b = function(a) {
  return Ou(a, this);
};
var Ou = function(a, b) {
  var c = {Psa:S(b, 1, 30000), Bra:S(b, 2, 1000), Osa:S(b, 3, 60000), pta:S(b, 4, 64), Ara:S(b, 5, 4), Lsa:S(b, 6, 300000), roa:S(b, 7, 0), ura:S(b, 8, 60000), dma:S(b, 9, 90000), Hsa:S(b, 11, !1), $ia:S(b, 12, 10000)};
  a && (c.f = b);
  return c;
};
d = Nu.prototype;
d.YH = function() {
  return S(this, 1, 30000);
};
d.CZ = function() {
  return S(this, 2, 1000);
};
d.d_ = function() {
  return S(this, 3, 60000);
};
d.cI = function() {
  return S(this, 4, 64);
};
d.BZ = function() {
  return S(this, 5, 4);
};
d.qy = function() {
  return S(this, 6, 300000);
};
d.fH = function() {
  return S(this, 7, 0);
};
d.gN = function(a) {
  T(this, 7, a);
};
d.GH = function() {
  return S(this, 8, 60000);
};
d.IN = function(a) {
  T(this, 8, a);
};
d.mX = function() {
  return S(this, 9, 90000);
};
d.$Z = function() {
  return S(this, 11, !1);
};
var Pu = function() {
  Rc.call(this);
  this.a = zf("realtime.diagnostics.DiagnosticDataService");
  this.cz = 0;
  this.gr = new I;
};
w(Pu, Rc);
var Qu = function(a) {
  a.rj(Pq) || a.hi(Pq, new Pu);
};
Pu.prototype.U = function() {
  var a = [];
  this.gr.forEach(function(b) {
    a.push(b.key);
  }, this);
  a.length && J(this.a, "Leftover callbacks for diagnostic data collection: " + a.join(", "));
  Pu.T.U.call(this);
};
Pu.prototype.eb = function(a, b) {
  this.cz++;
  this.gr.set(this.cz, {key:a, jr:b});
  return this.cz;
};
Pu.prototype.GA = function(a) {
  null != a && this.gr.remove(a);
};
Pu.prototype.na = function() {
  var a = {};
  this.isDisposed() || this.gr.forEach(function(b, c) {
    var e = b.jr.call();
    a[null !== a && b.key in a ? b.key + c : b.key] = e;
  }, this);
  return a;
};
var Ru = function() {
  this.a = zf("realtime.media.api.webrtc.sdp.Parser");
  this.Xc = "session";
  this.zq = new I;
  this.oC = new I;
  this.pC = new I;
  this.ut = "";
  this.oh = new rq("ICE", "", "");
  this.rd = [];
  this.Bc = null;
  this.pr = new I;
  this.Nn = [];
  this.um = [];
  this.Gu = new I;
  this.Hu = new I;
};
d = Ru.prototype;
d.C7 = function() {
  this.Gb = null;
  this.oh = new rq("ICE", "", "");
  this.TL();
  this.Xc = "session";
  this.zq.clear();
  this.oC.clear();
  this.pC.clear();
};
d.TL = function() {
  this.ut = "";
  this.rd = [];
  this.Bc = null;
  this.pr.clear();
  this.um = [];
  this.Gu.clear();
  this.Hu.clear();
};
d.parse = function(a) {
  this.Gb && this.C7();
  this.Gb = new Uq;
  y(a.split(/\r?\n/), function(a) {
    Ga(a) || this.y5(a);
  }, this);
  this.VE();
  this.Gb = this.Gb.Gq(this.oh).qP(this.Nn);
  K(this.a, "Parsed session data: " + this.Gb.na());
  return this.Gb;
};
d.y5 = function(a) {
  var b = Ua(a, "=", 1), c = b[0];
  2 == b.length && 1 == c.length || this.Mb("Invalid SDP line: " + a);
  var e = b[1].split(" "), f = e.shift().split(":");
  2 < f.length && this.Mb("Invalid key parts: " + f);
  b = f[0];
  e = new Ip(a, b, f[1], e);
  switch(this.An(c, Jp)) {
    case "m":
      this.VE();
      this.TL();
      this.Xc = this.An(b, Kp);
      break;
    case "a":
      this.M4(e);
      break;
    default:
      this.un(this.zq, this.Xc, a);
  }
  return e;
};
d.M4 = function(a) {
  switch(a.key) {
    case "group":
      this.i5(a);
      break;
    case "mid":
      this.q5(a);
      break;
    case "ice-ufrag":
      this.n5(a);
      break;
    case "ice-pwd":
      this.m5(a);
      break;
    case "ice-options":
      this.l5(a);
      break;
    case "fingerprint":
      this.g5(a);
      break;
    case "setup":
      this.A5(a);
      break;
    case "extmap":
      this.k5(a);
      break;
    case "crypto":
      this.aA(a);
      break;
    case "rtpmap":
      this.$z(a);
      break;
    case "sctpmap":
      this.x5(a);
      break;
    case "fmtp":
      this.Z4(a);
      break;
    case "rtcp-fb":
      this.a5(a);
      break;
    case "ssrc-group":
      this.cA(a);
      break;
    case "ssrc":
      this.km(a);
      break;
    default:
      this.un(this.zq, this.Xc, a.zb);
  }
};
d.i5 = function(a) {
  a.Wb || this.Mb("Invalid group line: " + a.zb);
  "BUNDLE" != a.Wb && this.un(this.zq, this.Xc, a.zb);
};
d.q5 = function(a) {
  this.ut = x(a.Wb, "Invalid mid line: " + a.zb);
};
d.n5 = function(a) {
  var b = x(a.Wb, "Empty ice ufrag line: " + a.zb);
  /^[0-9a-zA-Z\+\/]{4,256}$/.test(b) || this.Mb("Invalid ice ufrag line: " + a.zb);
  this.oh = this.oh.FP(b);
};
d.m5 = function(a) {
  var b = x(a.Wb, "Empty ice pwd line: " + a.zb);
  /^[0-9a-zA-Z\+\/]{22,256}$/.test(b) || this.Mb("Invalid ice pwd line: " + a.zb);
  this.oh = this.oh.CP(b);
};
d.l5 = function(a) {
  var b = a.Wb;
  b || this.Mb("Empty ice options line: " + a.zb);
  K(this.a, "Ignoring unrecognized ice option: " + b);
};
d.g5 = function(a) {
  var b = a.Wb;
  b || this.Mb("Empty fingerprint hash type: " + a.zb);
  1 != a.params.length && this.Mb("Malformed fingerprint hash value: " + a.zb);
  this.oh = this.oh.vP(b + " " + a.params[0]);
};
d.A5 = function(a) {
  "actpass" != a.Wb && this.Mb("Setup attribute was '" + a.Wb + "' instead of expected 'actpass'");
};
d.k5 = function(a) {
  var b = parseInt(a.Wb, 10), c = a.params[0];
  (isNaN(b) || !c || 1 > a.params.length) && this.Mb("Invalid extmap line: " + a.zb);
  a = (new Up).kn(c).en(b);
  (b = Np[this.Xc]) && a.La(b);
  this.um.push(a.S());
};
d.aA = function(a) {
  var b = parseInt(a.Wb, 10);
  (isNaN(b) || 2 > a.params.length) && this.Mb("Invalid crypto line: " + a.zb);
  a = (new Sp).JC(this.An(a.params.shift(), Rp)).FC(a.params.shift()).EP(a.params.join(" ")).KC(b).S();
  this.Nn.push(a);
};
d.$z = function(a) {
  var b = a.params[0].split("/"), c = b[0];
  (!a.Wb || 1 != a.params.length || 2 > b.length) && this.Mb("Invalid rtpmap line: " + a.zb);
  a = (new oq).La(Np[this.Xc]).hc(c).hd(parseInt(a.Wb, 10)).Ld(b[2] ? parseInt(b[2], 10) : 1).Md(parseInt(b[1], 10));
  this.rd.push(a.S());
};
d.x5 = function(a) {
  "application" != this.Xc && "data" != this.Xc && this.Mb("Sctpmap lines with incompatible media type: " + this.Xc);
  var b = parseInt(a.Wb, 10);
  (!b || 2 > a.params.length) && this.Mb("Invalid sctpmap line: " + a.zb);
  var c = a.params[0];
  a = parseInt(a.params[1], 10);
  this.Bc = (new Wp).rv(b).hc(c).GC(a).S();
};
d.Z4 = function(a) {
  var b = a.Wb;
  a = a.params.join(" ").split(";");
  this.pr.Ma(b) && this.Mb("Duplicated fmtp line for payload " + b);
  this.pr.set(b, a);
};
d.a5 = function(a) {
  this.un(this.oC, parseInt(a.Wb, 10), a.zb);
};
d.cA = function(a) {
  var b = x(a.Wb, "ssrc-group missing semantics: " + a.zb);
  1 > a.params.length && this.Mb("Invalid ssrc-group line: " + a.zb);
  a = a.params.map(Number);
  var c = (new qq).sv(b).Ze(a).S();
  y(a, function(a) {
    var b = this.Gu.get(a);
    b ? b.push(c) : b = [c];
    this.Gu.set(a, b);
  }, this);
};
d.km = function(a) {
  (!a.Wb || 1 > a.params.length) && this.Mb("Invalid ssrc line: " + a.zb);
  var b = parseInt(a.Wb, 10), c = this.XZ(b), e = a.params[0].split(":");
  switch(e[0]) {
    case "cname":
      x(e[1], "Invalid ssrc cname line: " + a.zb);
      c.Wf(e[1]);
      break;
    case "msid":
      x(e[1] && a.params[1], "Invalid ssrc msid line: " + a.zb);
      c.Dk(a.params[1]).gn(e[1]).zP(a.params[1]);
      break;
    default:
      this.un(this.pC, b, a.zb);
  }
};
d.XZ = function(a) {
  var b = this.Hu.get(a);
  if (b) {
    return b;
  }
  var b = this.Gu.get(a), c = [];
  b ? y(b, function(a) {
    c = c.concat(a.wd());
  }, this) : (c.push(a), b = []);
  b = (new zq).La(Np[this.Xc]).Ze(c).IC(b);
  this.ER(b, c);
  return b;
};
d.ER = function(a, b) {
  y(b, function(b) {
    this.Hu.set(b, a);
  }, this);
};
d.r1 = function(a) {
  if (!Ea(a.getName(), "H264")) {
    return !1;
  }
  var b = !1;
  a.Xx().forEach(function(a) {
    Ea(a.getKey(), "packetization-mode") && 1 == a.vc() && (b = !0);
  });
  return b;
};
d.VE = function() {
  if ("session" != this.Xc) {
    var a = z(ib(this.Hu.H(), function(a, c, e) {
      return c == e.indexOf(a) && a.Uc();
    }), function(a) {
      return a.S();
    });
    this.pr.forEach(function(a, c) {
      var b = lb(this.rd, function(a) {
        return c == a.yc;
      });
      -1 == b && this.Mb("fmtp line has no corresponding codec line, pt=" + c);
      a = a.reduce(function(a, b) {
        b = b.trim().split("=");
        return 2 != b.length ? a : (new oq(a)).Fq(b[0], b[1]).S();
      }, this.rd[b]);
      this.rd[b] = a;
    }, this);
    this.rd = ib(this.rd, function(a, c, e) {
      var b = !0;
      e.forEach(function(e, f) {
        f != c && e.getName() == a.getName() && "v" == a.P() && (b = b && this.r1(a));
      }, this);
      return b;
    }, this);
    0 < this.rd.length && this.Bc && this.Mb("Media " + this.ut + " contained both RTP and SCTP Settings.");
    a = (new wq(Np[this.Xc], this.rd, this.um)).Qc(a).pv(this.ut).hn(this.Bc);
    switch(this.Xc) {
      case "audio":
        this.Gb = this.Gb.We(a);
        break;
      case "video":
        this.Gb = this.Gb.qe(a);
        break;
      case "application":
      case "data":
        this.Gb = this.Gb.Ye(a);
    }
  }
};
d.An = function(a, b) {
  x(Lb(b, a), "Value '" + a + "' not found in enum type.");
  return x(a);
};
d.Mb = function(a) {
  a = Error(a);
  Bf(this.a, "Parsing failed.", a);
  throw a;
};
d.Q4 = function(a) {
  a = a.candidate.trim().split(" ");
  var b = a[0].split(":")[1], c = Number(a[1]), e = this.An(a[2].toUpperCase(), Ap), f = Number(a[3]), g = a[4], k = Number(a[5]);
  x("typ" == a[6]);
  var q = Mp[this.An(a[7], Lp)], r;
  y(a, function(a, b) {
    "generation" == a && (r = b + 1);
  });
  switch(q) {
    case "LOCAL":
      break;
    case "STUN":
    case "RELAY":
    case "PEER_REFLEX":
      x("raddr" == a[8]);
      var A = a[9];
      x("rport" == a[10]);
      var E = Number(a[11]);
      break;
    default:
      this.Mb("Unknown candidate type: " + q);
  }
  var aa = 0;
  r && (aa = Number(a[r]));
  return new zp(c, f, q, e, g, k, b, aa, "", A, E);
};
d.un = function(a, b, c) {
  var e = a.get(b);
  e || (e = [], a.set(b, e));
  e.push(c);
};
d.bI = function(a) {
  return this.zq.get(a);
};
d.m_ = function(a) {
  return this.oC.get(a);
};
d.o_ = function(a) {
  return this.pC.get(a);
};
var Tu = function(a) {
  P(this, a, "hc:rc", -1, Su, null);
};
w(Tu, O);
var Su = [7];
Tu.prototype.b = function(a) {
  var b = {time:R(this, 1), Kra:R(this, 2), $:R(this, 3), j6:R(this, 4), X7:R(this, 5), Oj:R(this, 6), $ra:Q(this.gj(), Uu, a), hb:R(this, 8), clientId:R(this, 9), Rba:R(this, 10), nT:R(this, 11), ZJ:R(this, 12), vz:R(this, 13)};
  a && (b.f = this);
  return b;
};
sr("hc:rc", Tu);
d = Tu.prototype;
d.getTime = function() {
  return R(this, 1);
};
d.setTime = function(a) {
  T(this, 1, a);
};
d.GZ = function() {
  return R(this, 2);
};
d.jaa = function(a) {
  T(this, 2, a);
};
d.O = function() {
  return R(this, 3);
};
d.L = function(a) {
  T(this, 3, a);
};
d.xg = function() {
  return R(this, 4);
};
d.setProperty = function(a) {
  T(this, 4, a);
};
d.wf = function() {
  return R(this, 5);
};
d.yu = function(a) {
  T(this, 5, a);
};
d.Gh = function() {
  return R(this, 6);
};
d.Ug = function(a) {
  T(this, 6, a);
};
d.gj = function() {
  return V(this, Vu, 7);
};
d.taa = function(a) {
  X(this, 7, a);
};
d.AD = function(a, b) {
  var c = Vu;
  ir(this, c, 7);
  var e = this.Ga[7];
  e || (e = this.Ga[7] = []);
  a = a ? a : new c;
  c = R(this, 7);
  void 0 != b ? (e.splice(b, 0, a), c.splice(b, 0, a.pe())) : (e.push(a), c.push(a.pe()));
  return a;
};
d.tl = function() {
  return R(this, 8);
};
d.Wp = function(a) {
  T(this, 8, a);
};
d.rc = function() {
  return R(this, 9);
};
d.Pe = function(a) {
  T(this, 9, a);
};
d.Cs = function() {
  return R(this, 10);
};
d.bq = function(a) {
  T(this, 10, a);
};
d.Ic = function() {
  return R(this, 11);
};
d.zm = function(a) {
  T(this, 11, a);
};
d.uo = function() {
  return R(this, 12);
};
d.Cm = function(a) {
  T(this, 12, a);
};
d.Al = function() {
  return R(this, 13);
};
d.jk = function(a) {
  T(this, 13, a);
};
var Vu = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Vu, O);
Vu.prototype.b = function(a) {
  return Uu(a, this);
};
var Uu = function(a, b) {
  var c = {lra:R(b, 1), localId:R(b, 2)};
  a && (c.f = b);
  return c;
};
Vu.prototype.ey = function() {
  return R(this, 1);
};
Vu.prototype.$$ = function(a) {
  T(this, 1, a);
};
Vu.prototype.bH = function() {
  return R(this, 2);
};
Vu.prototype.c$ = function(a) {
  T(this, 2, a);
};
var Wu = function() {
  G.call(this);
};
w(Wu, Zr);
var Yu = function() {
  Rc.call(this);
  this.lV = [];
  this.Ou = new Xu(u(this.c8, this));
  this.la(this.Ou);
};
w(Yu, Rc);
Yu.prototype.refresh = function() {
  this.Ou.xL();
};
Yu.prototype.c8 = function(a) {
  y(this.lV, function(b) {
    a = b.filter(a);
  });
  return a;
};
var Xu = function(a) {
  G.call(this);
  this.oV = a;
  this.ei = [];
  this.px = !1;
};
w(Xu, bs);
Xu.prototype.hM = function(a) {
  this.ei = B(a);
  this.xL();
};
Xu.prototype.xL = function() {
  this.px || (this.px = !0, Od(this.tU, this));
};
Xu.prototype.tU = function() {
  this.px = !1;
  this.dispatchEvent(new cs(this.oV(this.ei)));
};
var Zu = {ofa:"INITIAL", tha:"STARTING", sha:"STARTED", rfa:"INPROGRESS", PAUSED:"PAUSED", STOPPED:"STOPPED", FINISHED:"FINISHED"}, $u = function(a, b, c) {
  F.call(this, "L");
  this.state = a;
  this.hb = b;
  this.th = c;
};
w($u, F);
var av = function(a, b, c) {
  var e = a.K();
  as.call(this, e.A(), e.getId(), b, c);
  this.ir = a;
};
w(av, as);
var bv = function(a, b, c) {
  as.call(this, b.A(), b.ya(), b, c);
  this.C = a;
  this.SL = !1;
};
w(bv, as);
bv.prototype.s = function() {
  return this.C;
};
bv.prototype.daa = function(a) {
  a != this.SL && (this.SL = a, this.dispatchEvent("N"));
};
var cv = function(a, b) {
  G.call(this);
  this.am = b;
  this.a = zf("realtime.network.ApiaryClient");
  a.load(u(this.a3, this), u(this.b3, this));
  this.s7 = 0;
  this.cu = new I;
  this.bu = new I;
  K(this.a, "Created apiary client");
};
w(cv, G);
var dv = function(a, b, c, e) {
  var f = "\r\n\r\n--" + e + "\r\n";
  e = "\r\n\r\n--" + e + "--\r\n";
  var g = f + "Content-Type: " + a + "\r\n\r\n" + (b && !p(b) ? b.cb() : b);
  y(c, function(a) {
    g += f + "Content-Type: " + a.type + "\r\nContent-transfer-encoding: " + a.encoding + "\r\n\r\n" + a.data + "\r\n\r\n";
  });
  return g += e;
};
d = cv.prototype;
d.Yi = null;
d.UI = function() {
  return null != this.Yi;
};
d.a3 = function(a) {
  this.Yi = a;
  this.dispatchEvent("O");
  K(this.a, "Apiary client loaded");
};
d.b3 = function() {
  this.isDisposed() || (this.Yi = null, K(this.a, "Apiary client unloaded"));
};
d.U = function() {
  var a = this.cu.ub();
  y(a, je);
  a = this.bu.ub();
  y(a, je);
};
d.request = function(a) {
  this.w7(a);
};
d.w7 = function(a) {
  if (!this.isDisposed() && !a.hr) {
    if (this.UI()) {
      a.HN(this.s7++);
      this.am && this.am.onRequest(a);
      var b = a.hs(), c = a.ps(), e = a.dI(), f = a.AG();
      a.ry() && (e.alt = "protojson", f = "application/json+protobuf", null != b && (b = JSON.parse(b.cb())));
      var g = a.BD;
      if (0 < g.length) {
        x("POST" == a.Qx(), "Media upload requires the POST method");
        x(null != b, "Media upload requires a request body");
        c["MIME-Version"] = "1.0";
        var k = "END_OF_PART_" + Ra();
        c["Content-Type"] = 'multipart/related; boundary="' + k + '"';
        b = dv(f, b, g, k);
      } else {
        null != b && (c["Content-Type"] = f);
      }
      c["Accept-Language"] = a.qo();
      b = {method:a.Qx(), path:a.vd(), params:e, headers:c, body:b};
      Ga(Pa(a.ws())) || (b.root = a.ws());
      K(this.a, "Sending request " + a);
      try {
        var q = this.Yi.client.request(b);
        a.Hm("p");
        null != a.Rn && this.bu.set(a.ji, ie(u(this.v7, this, a), a.Rn || void 0));
        q.execute(u(this.k0, this, a));
      } catch (r) {
        Bf(this.a, "Failed to enqueue request " + ef(b), r), this.Ko(a, new Aq("fatal", "request_queuing", null, null), null, 0);
      }
    } else {
      J(this.a, "Request when client is not ready!");
    }
  }
};
d.v7 = function(a) {
  J(this.a, "Request timed out: " + a);
  this.Ko(a, new Aq("retry", "deadline_exceeded", null, null), null, 0);
};
d.k0 = function(a, b, c) {
  if (this.isDisposed() || !a.Ny()) {
    this.HL(a);
  } else {
    var e = null, f = "ok", g;
    this.HL(a);
    var k = null, q = null;
    try {
      var r = df(c), A = r.gapiRequest.data.body, k = r.gapiRequest.data.headers, e = yp(A);
    } catch (E) {
      J(this.a, "Failed to parse the response for request " + a + ": " + c, E), g = "response_decoding", f = "retry";
    }
    null != b && null != b.error && (q = b.error.code, J(this.a, "Request failed: " + a + ": " + b.error.code + " - " + b.error.message), g = "network_or_frontend", f = "retry", 400 == b.error.code ? (g = "bad_request", f = "fatal") : 401 == b.error.code ? (g = "unauthorized", f = "fatal") : 402 == b.error.code ? (g = "payment_required", f = "fatal") : 403 == b.error.code && (g = "forbidden", f = "fatal"));
    "ok" == f && null != e.error && (J(this.a, "Server returned an error for request " + a + ": " + e.error.code + ' "' + e.error.message + '": ' + e.error.errors[0].th), g = "backend", f = "retry");
    "ok" == f && ((b = a.ry()) && !ta(e) || !b && !va(e)) && (J(this.a, "Apiary returned bad response type for request " + a + ": expected " + (b ? "Array" : "Object") + ", received " + qa(e)), g = "response_format", f = "retry");
    if ("ok" == f && (a.Hm("o"), a.Op.callback(e), "o" != a.ck)) {
      switch(g = "response_callback", a.ck) {
        case "r":
          J(this.a, "Error processing response for request " + a + ": should retry.");
          f = "retry";
          break;
        case "d":
          J(this.a, "Fatal error processing response for request " + a);
          f = "fatal";
          break;
        default:
          Bf(this.a, "Unexpected response state from processing the response for " + a + ": " + a.ck);
      }
    }
    if ("ok" == f) {
      K(this.a, "Response processed successfully for request " + a), this.am && this.am.s4(a, x(e));
    } else {
      b = 0;
      if (null != k && null != k["Retry-After"]) {
        try {
          b = 1000 * parseInt(k["Retry-After"], 10), b = Math.min(Math.max(b, 0), 72E5);
        } catch (E) {
        }
      }
      this.Ko(a, new Aq(f, x(g), q, e), c, b);
    }
  }
  this.e7(a);
};
d.HL = function(a) {
  var b = this.cu.get(a.ji);
  null != b && (this.cu.remove(a.ji), je(b));
};
d.e7 = function(a) {
  var b = this.bu.get(a.ji);
  null != b && (this.bu.remove(a.ji), je(b));
};
d.Ko = function(a, b, c, e) {
  this.isDisposed() || !a.Ny() && "r" != a.ck || (this.am && this.am.onError(a, b, c), c = a.EH(), "retry" == b.status && 0 < c ? (K(this.a, "Scheduling retry for request " + a), this.cu.set(a.ji, ie(u(this.request, this, a), Math.max(a.VD(), e)))) : (a.cancel(), a.Op.Yc(b)));
};
var fv = function(a, b, c) {
  L(ev, "Asynchronously loading appContext service (" + b + ")");
  var e = H();
  try {
    null != c && ua(c) ? (c(a), x(a.rj(b))) : x(a.p1(b)), a.ho(b).then(function(a) {
      e.resolve(a);
    }, function(a) {
      Bf(ev, "Error getting service (" + b + "): " + a);
      e.reject(a);
    });
  } catch (f) {
    Bf(ev, "Exception thrown getting service (" + b + ")", f), e.reject(f);
  }
  return e.promise;
}, ev = zf("realtime.util.AsyncServiceResolver");
var gv = function(a, b, c) {
  Rc.call(this);
  this.Cg = null != c ? u(a, c) : a;
  this.yd = b;
  this.Hi = u(this.Uz, this);
  this.Re = !1;
  this.Me = 0;
  this.ab = null;
  this.Di = [];
};
w(gv, Rc);
d = gv.prototype;
d.bo = function(a) {
  this.stop();
  this.Di = arguments;
  this.ab = ie(this.Hi, this.yd);
};
d.stop = function() {
  this.ab && (je(this.ab), this.ab = null);
  this.Re = !1;
  this.Di = [];
};
d.pause = function() {
  ++this.Me;
};
d.resume = function() {
  this.Me && (--this.Me, !this.Me && this.Re && this.kl());
};
d.U = function() {
  this.stop();
  gv.T.U.call(this);
};
d.Uz = function() {
  this.ab = null;
  this.Me ? this.Re = !0 : this.kl();
};
d.kl = function() {
  this.Re = !1;
  this.Cg.apply(null, this.Di);
};
var jv = function() {
  this.Xn = [];
  this.Zz = new I;
  this.HO = this.IO = this.JO = this.ri = 0;
  this.nq = new I;
  this.HE = this.GO = 0;
  this.em = 1;
  this.yF = new Zp(0, 4000);
  this.yF.jg = function() {
    return new hv;
  };
  this.lO = new Zp(0, 50);
  this.lO.jg = function() {
    return new iv;
  };
  var a = this;
  this.Cy = new Zp(0, 2000);
  this.Cy.jg = function() {
    return String(a.em++);
  };
  this.Cy.Si = function() {
  };
};
jv.prototype.a = zf("goog.debug.Trace");
var iv = function() {
  this.AC = this.time = this.count = 0;
};
iv.prototype.toString = function() {
  var a = [];
  a.push(this.type, " ", this.count, " (", Math.round(10 * this.time) / 10, " ms)");
  this.AC && a.push(" [VarAlloc = ", this.AC, "]");
  return a.join("");
};
var hv = function() {
};
hv.prototype.cca = function(a, b, c) {
  var e = [];
  -1 == b ? e.push("    ") : e.push(kv(this.eventTime - b));
  e.push(" ", lv(this.eventTime - a));
  0 == this.eventType ? e.push(" Start        ") : 1 == this.eventType ? (e.push(" Done "), e.push(kv(this.Gba - this.startTime), " ms ")) : e.push(" Comment      ");
  e.push(c, this);
  0 < this.eca && e.push("[VarAlloc ", this.eca, "] ");
  return e.join("");
};
hv.prototype.toString = function() {
  return null == this.type ? this.comment : "[" + this.type + "] " + this.comment;
};
jv.prototype.reset = function() {
  this.a7();
  this.Zz.clear();
  this.ri = v();
  this.HE = this.GO = this.HO = this.IO = this.JO = 0;
  for (var a = this.nq.ub(), b = 0;b < a.length;b++) {
    var c = this.nq.get(a[b]);
    c.count = 0;
    c.time = 0;
    c.AC = 0;
    this.lO.Xj(c);
  }
  this.nq.clear();
};
jv.prototype.a7 = function() {
  for (var a = 0;a < this.Xn.length;a++) {
    var b = this.Xn[a];
    b.id && this.Cy.Xj(b.id);
    this.yF.Xj(b);
  }
  this.Xn.length = 0;
};
jv.prototype.toString = function() {
  for (var a = [], b = -1, c = [], e = 0;e < this.Xn.length;e++) {
    var f = this.Xn[e];
    1 == f.eventType && c.pop();
    a.push(" ", f.cca(this.ri, b, c.join("")));
    b = f.eventTime;
    a.push("\n");
    0 == f.eventType && c.push("|  ");
  }
  if (0 != this.Zz.V()) {
    var g = v();
    a.push(" Unstopped timers:\n");
    oe(this.Zz, function(b) {
      a.push("  ", b, " (", g - b.startTime, " ms, started at ", lv(b.startTime), ")\n");
    });
  }
  b = this.nq.ub();
  for (e = 0;e < b.length;e++) {
    c = this.nq.get(b[e]), 1 < c.count && a.push(" TOTAL ", c, "\n");
  }
  a.push("Total tracers created ", this.GO, "\n", "Total comments created ", this.HE, "\n", "Overhead start: ", this.JO, " ms\n", "Overhead end: ", this.IO, " ms\n", "Overhead comment: ", this.HO, " ms\n");
  return a.join("");
};
var kv = function(a) {
  a = Math.round(a);
  var b = "";
  1000 > a && (b = " ");
  100 > a && (b = "  ");
  10 > a && (b = "   ");
  return b + a;
}, lv = function(a) {
  a = Math.round(a);
  return String(100 + a / 1000 % 60).substring(1, 3) + "." + String(1000 + a % 1000).substring(1, 4);
};
new jv;
var mv = function(a) {
  P(this, a, 0, -1, null, null);
};
w(mv, O);
mv.prototype.b = function(a) {
  return nv(a, this);
};
var nv = function(a, b) {
  var c = {qna:R(b, 1), stream:R(b, 2), BT:R(b, 3), protocol:R(b, 4)};
  a && (c.f = b);
  return c;
};
d = mv.prototype;
d.$M = function(a) {
  T(this, 1, a);
};
d.ib = function() {
  return R(this, 2);
};
d.kk = function(a) {
  T(this, 2, a);
};
d.ru = function(a) {
  T(this, 3, a);
};
d.yg = function() {
  return R(this, 4);
};
d.Yp = function(a) {
  T(this, 4, a);
};
var pv = function(a) {
  P(this, a, 0, -1, ov, null);
};
w(pv, O);
var ov = [5];
pv.prototype.b = function(a) {
  return qv(a, this);
};
var qv = function(a, b) {
  var c = {csa:R(b, 1), hna:R(b, 2), Vqa:R(b, 3), qta:R(b, 4), xta:Q(b.r_(), rv, a)};
  a && (c.f = b);
  return c;
};
pv.prototype.r_ = function() {
  return V(this, sv, 5);
};
var sv = function(a) {
  P(this, a, 0, -1, null, null);
};
w(sv, O);
sv.prototype.b = function(a) {
  return rv(a, this);
};
var rv = function(a, b) {
  var c = {Uqa:R(b, 1), response:R(b, 2)};
  a && (c.f = b);
  return c;
};
var tv = function(a) {
  P(this, a, 0, -1, null, null);
};
w(tv, O);
tv.prototype.b = function(a) {
  return uv(a, this);
};
var uv = function(a, b) {
  var c, e = {cma:R(b, 1), Jpa:R(b, 2), $la:R(b, 3), sra:R(b, 4), pla:R(b, 5), Hta:(c = b.y_()) && vv(a, c)};
  a && (e.f = b);
  return e;
};
tv.prototype.y_ = function() {
  return U(this, wv, 6);
};
var wv = function(a) {
  P(this, a, 0, -1, null, null);
};
w(wv, O);
wv.prototype.b = function(a) {
  return vv(a, this);
};
var vv = function(a, b) {
  var c = {uta:S(b, 1, !1), yla:S(b, 4, !1), ria:S(b, 7, !1), xla:S(b, 14, !1), Nra:S(b, 15, 4000), Mra:S(b, 16, 5000), apa:S(b, 31, 0), ula:S(b, 33, !1), wla:S(b, 35, !1), tla:S(b, 36, !1), Zka:S(b, 37, !1), tta:S(b, 38, !1)};
  a && (c.f = b);
  return c;
};
wv.prototype.$F = function() {
  return S(this, 7, !1);
};
var xv = function(a) {
  P(this, a, 0, -1, null, null);
};
w(xv, O);
xv.prototype.b = function(a) {
  return yv(a, this);
};
var yv = function(a, b) {
  var c = {type:R(b, 1), Fla:R(b, 2), Gqa:R(b, 3), Apa:R(b, 4), Qja:R(b, 5)};
  a && (c.f = b);
  return c;
};
d = xv.prototype;
d.N = function() {
  return R(this, 1);
};
d.Rf = function(a) {
  T(this, 1, a);
};
d.z9 = function(a) {
  T(this, 2, a);
};
d.T$ = function(a) {
  T(this, 3, a);
};
d.z$ = function(a) {
  T(this, 4, a);
};
d.c9 = function(a) {
  T(this, 5, a);
};
var zv = function(a) {
  P(this, a, 0, -1, null, null);
};
w(zv, O);
zv.prototype.b = function(a) {
  return Av(a, this);
};
var Av = function(a, b) {
  var c = {bpa:R(b, 1), toa:R(b, 2), xoa:R(b, 3), ysa:R(b, 4), count:R(b, 5)};
  a && (c.f = b);
  return c;
};
zv.prototype.V = function() {
  return R(this, 5);
};
var Bv = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Bv, O);
Bv.prototype.b = function(a) {
  return Cv(a, this);
};
var Cv = function(a, b) {
  var c = {networkType:R(b, 1), wqa:R(b, 2), vqa:R(b, 3), yqa:R(b, 4)};
  a && (c.f = b);
  return c;
};
var Dv = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Dv, O);
Dv.prototype.b = function(a) {
  return Ev(a, this);
};
var Ev = function(a, b) {
  var c, e = {local:(c = b.YX()) && Fv(a, c), remote:(c = b.oZ()) && Fv(a, c), Fja:R(b, 3)};
  a && (e.f = b);
  return e;
};
Dv.prototype.YX = function() {
  return U(this, Gv, 1);
};
Dv.prototype.oZ = function() {
  return U(this, Gv, 2);
};
var Gv = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Gv, O);
Gv.prototype.b = function(a) {
  return Fv(a, this);
};
var Fv = function(a, b) {
  var c = {nqa:R(b, 1), IU:R(b, 2), moa:R(b, 3)};
  a && (c.f = b);
  return c;
};
var Hv = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Hv, O);
Hv.prototype.b = function(a) {
  return Iv(a, this);
};
var Iv = function(a, b) {
  var c = {Mla:R(b, 1), Nla:R(b, 2), zpa:R(b, 3), opa:R(b, 4), ppa:R(b, 5), $:R(b, 6), sja:R(b, 7)};
  a && (c.f = b);
  return c;
};
Hv.prototype.O = function() {
  return R(this, 6);
};
Hv.prototype.L = function(a) {
  T(this, 6, a);
};
var Jv = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Jv, O);
Jv.prototype.b = function(a) {
  return Kv(a, this);
};
var Kv = function(a, b) {
  var c, e = {Xpa:R(b, 1), oka:R(b, 2), qka:R(b, 3), ska:R(b, 4), tka:R(b, 5), GT:R(b, 6), rka:R(b, 7), wma:R(b, 8), Ama:R(b, 9), xma:R(b, 10), yma:R(b, 11), zma:R(b, 12), ika:R(b, 13), Ypa:R(b, 14), browser:R(b, 15), Wia:R(b, 16), nka:R(b, 17), pka:R(b, 18), joa:R(b, 19), wja:R(b, 20), dpa:(c = b.yY()) && Lv(a, c), yia:R(b, 22), Jta:(c = b.z_()) && Mv(a, c)};
  a && (e.f = b);
  return e;
};
d = Jv.prototype;
d.G$ = function(a) {
  T(this, 1, a);
};
d.k9 = function(a) {
  T(this, 2, a);
};
d.m9 = function(a) {
  T(this, 3, a);
};
d.JM = function(a) {
  T(this, 5, a);
};
d.qB = function(a) {
  T(this, 6, a);
};
d.H$ = function(a) {
  T(this, 14, a);
};
d.S8 = function(a) {
  T(this, 15, a);
};
d.U8 = function(a) {
  T(this, 16, a);
};
d.l9 = function(a) {
  T(this, 18, a);
};
d.yY = function() {
  return U(this, Nv, 21);
};
d.z_ = function() {
  return U(this, Ov, 23);
};
var Nv = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Nv, O);
Nv.prototype.b = function(a) {
  return Lv(a, this);
};
var Lv = function(a, b) {
  var c = {Zma:R(b, 1), Ora:R(b, 2), Lra:R(b, 3), nma:R(b, 4), Mia:R(b, 5)};
  a && (c.f = b);
  return c;
}, Ov = function(a) {
  P(this, a, 0, -1, Pv, null);
};
w(Ov, O);
var Pv = [3];
Ov.prototype.b = function(a) {
  return Mv(a, this);
};
var Mv = function(a, b) {
  var c = {Isa:R(b, 1), Jsa:R(b, 2), Ksa:Q(b.a_(), Qv, a)};
  a && (c.f = b);
  return c;
};
Ov.prototype.a_ = function() {
  return V(this, Rv, 3);
};
var Rv = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Rv, O);
Rv.prototype.b = function(a) {
  return Qv(a, this);
};
var Qv = function(a, b) {
  var c = {$ja:R(b, 1), uoa:R(b, 2), soa:R(b, 4), woa:R(b, 3)};
  a && (c.f = b);
  return c;
};
var Sv = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Sv, O);
Sv.prototype.b = function(a) {
  return Tv(a, this);
};
var Tv = function(a, b) {
  var c = {device:R(b, 1), xia:R(b, 2), platform:R(b, 3)};
  a && (c.f = b);
  return c;
};
Sv.prototype.getDevice = function() {
  return R(this, 1);
};
Sv.prototype.p9 = function(a) {
  T(this, 1, a);
};
Sv.prototype.M8 = function(a) {
  T(this, 2, a);
};
Sv.prototype.N$ = function(a) {
  T(this, 3, a);
};
var Uv = function() {
  this.Ta = new wr;
  this.R7 = new Ae;
};
pa(Uv);
var Vv = [31, 37, 41, 43, 47, 53, 61, 67, 71, 73];
d = Uv.prototype;
d.a = zf("talk.media.webrtc.PendingLogUploadManager");
d.Zx = function(a) {
  for (var b = [], c = 0, e = 0;e < a.length;e++) {
    for (var f = a.charCodeAt(e);255 < f;) {
      b[c++] = f & 255, f >>= 8;
    }
    b[c++] = f;
  }
  for (a = 0;a < b.length;a++) {
    b[a] ^= Vv[a % Vv.length];
  }
  return "wrplumplu-" + Fj(b);
};
d.NG = function(a, b) {
  var c = v() - 432E6;
  a = this.Ta.get(this.Zx(a));
  if (null != a) {
    try {
      var e = bb(df(a));
      if ("cl:plu" == e[0]) {
        var f = new bu(e), g = ib(f.Tx(), function(a) {
          return null != a.hG() && null != a.s() && null != a.jj() && 0 < a.hG() && a.jj() > c && a.s() != b;
        });
        f.eN(g);
        return f;
      }
    } catch (k) {
      J(this.a, "Invalid pending JS log upload storage: " + a, k);
    }
  }
  return new bu;
};
d.add = function(a, b) {
  K(this.a, "Recording pending upload for session " + b + " for " + a);
  this.R7.add(b);
  var c = this.NG(a, b), e = c.Tx(), f = new du;
  f.N8(5);
  f.Ca(b);
  f.KB(v());
  rb(e, void 0, 0, f);
  c.eN(e);
  this.Ta.set(this.Zx(a), c.cb());
};
d.remove = function(a, b) {
  K(this.a, "Removing record for session " + b + " for " + a);
  b = this.NG(a, b);
  this.Ta.set(this.Zx(a), b.cb());
};
var Xv = function(a) {
  P(this, a, 0, -1, Wv, null);
};
w(Xv, O);
var Wv = [14];
Xv.prototype.b = function(a) {
  return Yv(a, this);
};
var Yv = function(a, b) {
  var c, e = {$:R(b, 1), WR:R(b, 2), projectId:R(b, 3), resolution:R(b, 4), cqa:R(b, 10), Lqa:R(b, 5), mta:(c = b.k_()) && Zv(a, c), vra:R(b, 7), cra:(c = b.jZ()) && $v(a, c), Sna:(c = b.WX()) && aw(a, c), Tna:(c = b.XX()) && bw(a, c), L6:(c = b.CH()) && cw(a, c), sta:R(b, 13), Mta:R(b, 14)};
  a && (e.f = b);
  return e;
};
d = Xv.prototype;
d.O = function() {
  return R(this, 1);
};
d.L = function(a) {
  T(this, 1, a);
};
d.Ub = function() {
  return R(this, 4);
};
d.Zp = function(a) {
  T(this, 4, a);
};
d.k_ = function() {
  return U(this, dw, 6);
};
d.jZ = function() {
  return U(this, ew, 8);
};
d.WX = function() {
  return U(this, fw, 9);
};
d.XX = function() {
  return U(this, gw, 11);
};
d.CH = function() {
  return U(this, hw, 12);
};
var ew = function(a) {
  P(this, a, 0, -1, null, null);
};
w(ew, O);
ew.prototype.b = function(a) {
  return $v(a, this);
};
var $v = function(a, b) {
  var c, e = {jO:R(b, 1), Gba:(c = b.VZ()) && iw(a, c), Yla:R(b, 3), Vsa:(c = b.g_()) && jw(a, c), uma:(c = b.qX()) && kw(a, c), bia:(c = b.JV()) && lw(a, c), Tka:(c = b.RW()) && vs(a, c)};
  a && (e.f = b);
  return e;
};
d = ew.prototype;
d.VZ = function() {
  return U(this, mw, 2);
};
d.g_ = function() {
  return U(this, nw, 4);
};
d.qX = function() {
  return U(this, ow, 5);
};
d.JV = function() {
  return U(this, pw, 6);
};
d.RW = function() {
  return U(this, us, 7);
};
var mw = function(a) {
  P(this, a, 0, -1, null, null);
};
w(mw, O);
mw.prototype.b = function(a) {
  return iw(a, this);
};
var iw = function(a, b) {
  var c = {Nta:R(b, 1), Npa:R(b, 2)};
  a && (c.f = b);
  return c;
}, dw = function(a) {
  P(this, a, 0, -1, null, null);
};
w(dw, O);
dw.prototype.b = function(a) {
  return Zv(a, this);
};
var Zv = function(a, b) {
  var c = {yka:R(b, 1), oma:R(b, 2)};
  a && (c.f = b);
  return c;
}, nw = function(a) {
  P(this, a, 0, -1, null, null);
};
w(nw, O);
nw.prototype.b = function(a) {
  return jw(a, this);
};
var jw = function(a, b) {
  var c = {roomName:R(b, 1)};
  a && (c.f = b);
  return c;
}, ow = function(a) {
  P(this, a, 0, -1, null, null);
};
w(ow, O);
ow.prototype.b = function(a) {
  return kw(a, this);
};
var kw = function(a, b) {
  var c = {bqa:R(b, 1), qia:R(b, 2), title:R(b, 3), oqa:R(b, 4)};
  a && (c.f = b);
  return c;
};
ow.prototype.getTitle = function() {
  return R(this, 3);
};
ow.prototype.setTitle = function(a) {
  T(this, 3, a);
};
var fw = function(a) {
  P(this, a, 0, -1, qw, null);
};
w(fw, O);
var qw = [5];
fw.prototype.b = function(a) {
  return aw(a, this);
};
var aw = function(a, b) {
  var c = {Pta:R(b, 1), topic:R(b, 2), vla:S(b, 3, !0), Hqa:R(b, 4), Sba:R(b, 5)};
  a && (c.f = b);
  return c;
}, pw = function(a) {
  P(this, a, 0, -1, null, null);
};
w(pw, O);
pw.prototype.b = function(a) {
  return lw(a, this);
};
var lw = function(a, b) {
  var c = {status:S(b, 1, 0), Lka:R(b, 2), vta:R(b, 3)};
  a && (c.f = b);
  return c;
};
pw.prototype.Ra = function() {
  return S(this, 1, 0);
};
var gw = function(a) {
  P(this, a, 0, -1, null, null);
};
w(gw, O);
gw.prototype.b = function(a) {
  return bw(a, this);
};
var bw = function(a, b) {
  var c = {zka:R(b, 3), Rna:R(b, 4), esa:S(b, 5, !1)};
  a && (c.f = b);
  return c;
}, hw = function(a) {
  P(this, a, 0, -1, null, null);
};
w(hw, O);
hw.prototype.b = function(a) {
  return cw(a, this);
};
var cw = function(a, b) {
  var c = {Aka:R(b, 1), Ssa:R(b, 2)};
  a && (c.f = b);
  return c;
};
var sw = function(a) {
  P(this, a, 0, -1, rw, null);
};
w(sw, O);
var rw = [2, 3];
sw.prototype.b = function(a) {
  return tw(a, this);
};
var tw = function(a, b) {
  var c = {zd:Q(b.Na(), zs, a), jf:Q(b.Ab(), Ds, a)};
  a && (c.f = b);
  return c;
};
sw.prototype.Na = function() {
  return V(this, ys, 2);
};
sw.prototype.Ab = function() {
  return V(this, Cs, 3);
};
var vw = function(a) {
  P(this, a, 0, -1, uw, null);
};
w(vw, O);
var uw = [6];
vw.prototype.b = function(a) {
  return ww(a, this);
};
var ww = function(a, b) {
  var c, e = {pma:R(b, 1), Nja:R(b, 2), Lja:R(b, 3), Q5:(c = b.$x()) && ps(a, c), Pla:R(b, 4), goa:Q(b.cY(), xw, a), Rka:b.QW()};
  a && (e.f = b);
  return e;
};
vw.prototype.$x = function() {
  return U(this, os, 7);
};
vw.prototype.cY = function() {
  return V(this, yw, 6);
};
vw.prototype.PW = function() {
  return R(this, 5);
};
vw.prototype.QW = function() {
  return gr(this.PW());
};
var yw = function(a) {
  P(this, a, 0, -1, null, null);
};
w(yw, O);
yw.prototype.b = function(a) {
  return xw(a, this);
};
var xw = function(a, b) {
  var c, e = {mqa:(c = b.WY()) && zw(a, c), rla:(c = b.cX()) && Aw(a, c), mpa:(c = b.CY()) && Bw(a, c)};
  a && (e.f = b);
  return e;
};
yw.prototype.WY = function() {
  return U(this, Cw, 1);
};
yw.prototype.cX = function() {
  return U(this, Dw, 2);
};
yw.prototype.CY = function() {
  return U(this, Ew, 3);
};
var Cw = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Cw, O);
Cw.prototype.b = function(a) {
  return zw(a, this);
};
var zw = function(a, b) {
  var c, e = {R5:(c = b.sH()) && ps(a, c)};
  a && (e.f = b);
  return e;
};
Cw.prototype.sH = function() {
  return U(this, os, 1);
};
var Dw = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Dw, O);
Dw.prototype.b = function(a) {
  return Aw(a, this);
};
var Aw = function(a, b) {
  var c = {email:R(b, 1)};
  a && (c.f = b);
  return c;
};
Dw.prototype.getEmail = function() {
  return R(this, 1);
};
var Ew = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Ew, O);
Ew.prototype.b = function(a) {
  return Bw(a, this);
};
var Bw = function(a, b) {
  var c = {hqa:R(b, 1)};
  a && (c.f = b);
  return c;
};
var Fw = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Fw, O);
Fw.prototype.b = function(a) {
  return Gw(a, this);
};
var Gw = function(a, b) {
  var c, e = {ala:(c = b.XW()) && Ts(a, c)};
  a && (e.f = b);
  return e;
};
Fw.prototype.XW = function() {
  return U(this, Ss, 1);
};
var Hw = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Hw, O);
Hw.prototype.b = function(a) {
  return Iw(a, this);
};
var Iw = function(a, b) {
  var c, e = {Wja:(c = b.Dx()) && Ps(a, c), Rja:(c = b.tG()) && Ls(a, c), Tja:(c = b.tW()) && Ns(a, c), J1:R(b, 4), jna:S(b, 5, !1), Dra:S(b, 6, 0), Hra:(c = b.FZ()) && Tv(a, c), zE:R(b, 8), Wna:(c = b.ZX()) && Js(a, c)};
  a && (e.f = b);
  return e;
};
d = Hw.prototype;
d.Dx = function() {
  return U(this, Os, 1);
};
d.pB = function(a) {
  W(this, 1, a);
};
d.tG = function() {
  return U(this, Ks, 2);
};
d.oB = function(a) {
  W(this, 2, a);
};
d.tW = function() {
  return U(this, Ms, 3);
};
d.qo = function() {
  return R(this, 4);
};
d.Bm = function(a) {
  T(this, 4, a);
};
d.FZ = function() {
  return U(this, Sv, 7);
};
d.EB = function(a) {
  W(this, 7, a);
};
d.ZX = function() {
  return U(this, Is, 9);
};
var Jw = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Jw, O);
Jw.prototype.b = function(a) {
  return Kw(a, this);
};
var Kw = function(a, b) {
  var c, e = {status:R(b, 1), Dla:R(b, 2), Hka:R(b, 3), z7:R(b, 4), Yia:R(b, 10), Kja:R(b, 11), dU:R(b, 5), Nia:R(b, 6), zE:R(b, 7), Zna:R(b, 8), Msa:(c = b.c_()) && Vs(a, c)};
  a && (e.f = b);
  return e;
};
d = Jw.prototype;
d.Ra = function() {
  return R(this, 1);
};
d.gX = function() {
  return R(this, 2);
};
d.HH = function() {
  return R(this, 4);
};
d.$X = function() {
  return R(this, 8);
};
d.c_ = function() {
  return U(this, Us, 9);
};
var Mw = function(a) {
  P(this, a, 0, -1, Lw, null);
};
w(Mw, O);
var Lw = [2, 3];
Mw.prototype.b = function(a) {
  return Nw(a, this);
};
var Nw = function(a, b) {
  var c, e = {J:(c = b.h()) && Z(a, c), zd:Q(b.Na(), Ys, a), jf:Q(b.Ab(), $s, a), Ne:(c = b.Nb()) && $s(a, c)};
  a && (e.f = b);
  return e;
};
d = Mw.prototype;
d.h = function() {
  return U(this, Y, 1);
};
d.j = function(a) {
  W(this, 1, a);
};
d.G = function() {
  this.j(void 0);
};
d.Na = function() {
  return V(this, Xs, 2);
};
d.Ab = function() {
  return V(this, Zs, 3);
};
d.Nb = function() {
  return U(this, Zs, 4);
};
var Pw = function(a) {
  P(this, a, 0, -1, Ow, null);
};
w(Pw, O);
var Ow = [15, 26];
Pw.prototype.b = function(a) {
  return Qw(a, this);
};
var Qw = function(a, b) {
  var c, e = {$:R(b, 1), type:R(b, 2), fV:(c = b.Lx()) && gt(a, c), active:R(b, 4), vka:R(b, 6), Ina:R(b, 7), topic:R(b, 8), DT:(c = b.Fx()) && Rs(a, c), cja:R(b, 10), jO:R(b, 11), GU:R(b, 12), Wpa:R(b, 13), mediaType:R(b, 14), Sba:R(b, 15), sia:R(b, 16), oia:R(b, 24), a6:(c = b.zo()) && Qt(a, c), Gna:R(b, 18), Hna:R(b, 25), caption:(c = b.nW()) && Fs(a, c), Lla:R(b, 21), Opa:R(b, 22), Jka:R(b, 23), kia:R(b, 26), eka:R(b, 27), Uoa:R(b, 28), Soa:R(b, 29), TB:R(b, 30)};
  a && (e.f = b);
  return e;
};
d = Pw.prototype;
d.O = function() {
  return R(this, 1);
};
d.L = function(a) {
  T(this, 1, a);
};
d.N = function() {
  return R(this, 2);
};
d.Rf = function(a) {
  T(this, 2, a);
};
d.Lx = function() {
  return U(this, ft, 3);
};
d.TM = function(a) {
  W(this, 3, a);
};
d.setActive = function(a) {
  T(this, 4, a);
};
d.Fx = function() {
  return U(this, Qs, 9);
};
d.P = function() {
  return R(this, 14);
};
d.oc = function(a) {
  T(this, 14, a);
};
d.dg = function() {
  T(this, 14, void 0);
};
d.zo = function() {
  return U(this, Pt, 17);
};
d.AN = function(a) {
  W(this, 17, a);
};
d.nW = function() {
  return U(this, Es, 19);
};
var Rw = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Rw, O);
Rw.prototype.b = function(a) {
  return Sw(a, this);
};
var Sw = function(a, b) {
  var c, e = {J:(c = b.h()) && Z(a, c), appId:R(b, 2), data:R(b, 3)};
  a && (e.f = b);
  return e;
};
d = Rw.prototype;
d.h = function() {
  return U(this, Y, 1);
};
d.j = function(a) {
  W(this, 1, a);
};
d.G = function() {
  this.j(void 0);
};
d.getData = function() {
  return R(this, 3);
};
d.setData = function(a) {
  T(this, 3, a);
};
d.clearData = function() {
  T(this, 3, void 0);
};
var Uw = function(a) {
  P(this, a, 0, -1, Tw, null);
};
w(Uw, O);
var Tw = [2];
Uw.prototype.b = function(a) {
  return Vw(a, this);
};
var Vw = function(a, b) {
  var c, e = {f1:(c = b.Sx()) && Ww(a, c), Hpa:R(b, 2), displayName:R(b, 3), TD:R(b, 4)};
  a && (e.f = b);
  return e;
};
Uw.prototype.Sx = function() {
  return U(this, Xw, 1);
};
Uw.prototype.Bh = function() {
  return R(this, 3);
};
var Xw = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Xw, O);
Xw.prototype.b = function(a) {
  return Ww(a, this);
};
var Ww = function(a, b) {
  var c, e = {kqa:(c = b.UY()) && Yw(a, c), DT:(c = b.Fx()) && Rs(a, c)};
  a && (e.f = b);
  return e;
};
Xw.prototype.UY = function() {
  return U(this, Zw, 1);
};
Xw.prototype.Fx = function() {
  return U(this, Qs, 4);
};
var Zw = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Zw, O);
Zw.prototype.b = function(a) {
  return Yw(a, this);
};
var Yw = function(a, b) {
  var c = {email:R(b, 1), lP:R(b, 2)};
  a && (c.f = b);
  return c;
};
Zw.prototype.getEmail = function() {
  return R(this, 1);
};
var ax = function(a) {
  P(this, a, 0, -1, $w, null);
};
w(ax, O);
var $w = [20, 8, 19, 26];
ax.prototype.b = function(a) {
  return bx(a, this);
};
var bx = function(a, b) {
  var c, e = {$:R(b, 1), za:R(b, 2), lP:R(b, 3), displayName:R(b, 4), TD:R(b, 5), ara:R(b, 6), Fqa:R(b, 7), Sia:Q(b.$V(), cx, a), Ria:R(b, 8), gna:R(b, 9), tma:R(b, 10), Qla:R(b, 11), role:R(b, 12), oT:S(b, 13, 1), epa:S(b, 14, 1), iqa:S(b, 17, 0), joined:S(b, 18, !1), Iqa:R(b, 19), eia:S(b, 21, !1), ila:(c = b.aX()) && hs(a, c), RI:R(b, 23), fra:S(b, 24, 0), yta:R(b, 25), x2:R(b, 26)};
  a && (e.f = b);
  return e;
};
d = ax.prototype;
d.O = function() {
  return R(this, 1);
};
d.L = function(a) {
  T(this, 1, a);
};
d.A = function() {
  return R(this, 2);
};
d.Sa = function(a) {
  T(this, 2, a);
};
d.Bh = function() {
  return R(this, 4);
};
d.$V = function() {
  return V(this, dx, 20);
};
d.getGivenName = function() {
  return R(this, 10);
};
d.getFamilyName = function() {
  return R(this, 11);
};
d.PY = function() {
  return S(this, 17, 0);
};
d.ZG = function() {
  return S(this, 18, !1);
};
d.aX = function() {
  return U(this, gs, 22);
};
var dx = function(a) {
  P(this, a, 0, -1, null, null);
};
w(dx, O);
dx.prototype.b = function(a) {
  return cx(a, this);
};
var cx = function(a, b) {
  var c = {lP:R(b, 1), Qia:S(b, 2, 1)};
  a && (c.f = b);
  return c;
};
var fx = function(a) {
  P(this, a, 0, -1, ex, null);
};
w(fx, O);
var ex = [3];
fx.prototype.b = function(a) {
  return gx(a, this);
};
var gx = function(a, b) {
  var c, e = {$:R(b, 1), Xra:R(b, 2), Yqa:R(b, 3), Zsa:R(b, 9), eventType:R(b, 4), ela:(c = b.ZW()) && ct(a, c), kra:(c = b.qZ()) && Ut(a, c), gpa:(c = b.BY()) && Mt(a, c), dsa:R(b, 6)};
  a && (e.f = b);
  return e;
};
d = fx.prototype;
d.O = function() {
  return R(this, 1);
};
d.L = function(a) {
  T(this, 1, a);
};
d.MG = function() {
  return R(this, 4);
};
d.ZW = function() {
  return U(this, bt, 5);
};
d.qZ = function() {
  return U(this, Tt, 7);
};
d.BY = function() {
  return U(this, Lt, 8);
};
var hx = function(a) {
  P(this, a, 0, -1, null, null);
};
w(hx, O);
hx.prototype.b = function(a) {
  return ix(a, this);
};
var ix = function(a, b) {
  var c, e = {ana:(c = b.VG()) && rt(a, c)};
  a && (e.f = b);
  return e;
};
hx.prototype.VG = function() {
  return U(this, qt, 1);
};
var jx = function(a) {
  P(this, a, 0, -1, null, null);
};
w(jx, O);
jx.prototype.b = function(a) {
  return kx(a, this);
};
var kx = function(a, b) {
  var c, e = {$:R(b, 1), za:R(b, 2), sourceId:R(b, 3), mediaType:R(b, 4), R2:(c = b.Be()) && lx(a, c), hpa:(c = b.Bl()) && mx(a, c), Cta:(c = b.Gl()) && nx(a, c), sqa:(c = b.ay()) && ox(a, c)};
  a && (e.f = b);
  return e;
};
d = jx.prototype;
d.O = function() {
  return R(this, 1);
};
d.L = function(a) {
  T(this, 1, a);
};
d.A = function() {
  return R(this, 2);
};
d.Sa = function(a) {
  T(this, 2, a);
};
d.ya = function() {
  return R(this, 3);
};
d.Qf = function(a) {
  T(this, 3, a);
};
d.P = function() {
  return R(this, 4);
};
d.oc = function(a) {
  T(this, 4, a);
};
d.dg = function() {
  T(this, 4, void 0);
};
d.Be = function() {
  return U(this, px, 5);
};
d.AB = function(a) {
  W(this, 5, a);
};
d.Bl = function() {
  return U(this, qx, 6);
};
d.q$ = function(a) {
  W(this, 6, a);
};
d.Gl = function() {
  return U(this, rx, 7);
};
d.Saa = function(a) {
  W(this, 7, a);
};
d.ay = function() {
  return U(this, sx, 8);
};
d.O$ = function(a) {
  W(this, 8, a);
};
var px = function(a) {
  P(this, a, 0, -1, null, null);
};
w(px, O);
px.prototype.b = function(a) {
  return lx(a, this);
};
var lx = function(a, b) {
  var c = {muted:R(b, 1), rw:R(b, 2), T5:fr(b, 3)};
  a && (c.f = b);
  return c;
};
d = px.prototype;
d.wo = function() {
  return R(this, 1);
};
d.wu = function(a) {
  T(this, 1, a);
};
d.sl = function() {
  return R(this, 2);
};
d.ym = function(a) {
  T(this, 2, a);
};
d.tH = function() {
  return fr(this, 3);
};
d.zN = function(a) {
  T(this, 3, a);
};
var qx = function(a) {
  P(this, a, 0, -1, null, null);
};
w(qx, O);
qx.prototype.b = function(a) {
  return mx(a, this);
};
var mx = function(a, b) {
  var c = {rw:R(b, 1)};
  a && (c.f = b);
  return c;
};
qx.prototype.sl = function() {
  return R(this, 1);
};
qx.prototype.ym = function(a) {
  T(this, 1, a);
};
var rx = function(a) {
  P(this, a, 0, -1, tx, null);
};
w(rx, O);
var tx = [3];
rx.prototype.b = function(a) {
  return nx(a, this);
};
var nx = function(a, b) {
  var c, e = {Dja:R(b, 1), Eja:(c = b.qW()) && $t(a, c), kna:Q(b.XG(), ux, a)};
  a && (e.f = b);
  return e;
};
d = rx.prototype;
d.pW = function() {
  return R(this, 1);
};
d.Y8 = function(a) {
  T(this, 1, a);
};
d.qW = function() {
  return U(this, Zt, 2);
};
d.XG = function() {
  return V(this, vx, 3);
};
d.Q9 = function(a) {
  X(this, 3, a);
};
var vx = function(a) {
  P(this, a, 0, -1, null, null);
};
w(vx, O);
vx.prototype.b = function(a) {
  return ux(a, this);
};
var ux = function(a, b) {
  var c = {x:+R(b, 1), y:+R(b, 2), width:+R(b, 3), height:+R(b, 4)};
  a && (c.f = b);
  return c;
};
d = vx.prototype;
d.A_ = function() {
  return +R(this, 1);
};
d.Uaa = function(a) {
  T(this, 1, a);
};
d.B_ = function() {
  return +R(this, 2);
};
d.Vaa = function(a) {
  T(this, 2, a);
};
d.Af = function() {
  return +R(this, 3);
};
d.mk = function(a) {
  T(this, 3, a);
};
d.tf = function() {
  return +R(this, 4);
};
d.ik = function(a) {
  T(this, 4, a);
};
var sx = function(a) {
  P(this, a, 0, -1, null, null);
};
w(sx, O);
sx.prototype.b = function(a) {
  return ox(a, this);
};
var ox = function(a, b) {
  var c = {rw:R(b, 1), T5:fr(b, 2)};
  a && (c.f = b);
  return c;
};
sx.prototype.sl = function() {
  return R(this, 1);
};
sx.prototype.ym = function(a) {
  T(this, 1, a);
};
sx.prototype.tH = function() {
  return fr(this, 2);
};
sx.prototype.zN = function(a) {
  T(this, 2, a);
};
var xx = function(a) {
  P(this, a, 0, -1, wx, null);
};
w(xx, O);
var wx = [3, 6];
xx.prototype.b = function(a) {
  return yx(a, this);
};
var yx = function(a, b) {
  var c, e = {fna:R(b, 1), nsa:(c = b.SH()) && zx(a, c), Upa:R(b, 3), username:R(b, 4), password:R(b, 5), yja:Q(b.rG(), Ct, a)};
  a && (e.f = b);
  return e;
};
d = xx.prototype;
d.KX = function() {
  return R(this, 1);
};
d.O9 = function(a) {
  T(this, 1, a);
};
d.SH = function() {
  return U(this, Ax, 2);
};
d.ON = function(a) {
  W(this, 2, a);
};
d.t_ = function() {
  return R(this, 4);
};
d.YN = function(a) {
  T(this, 4, a);
};
d.QY = function() {
  return R(this, 5);
};
d.yN = function(a) {
  T(this, 5, a);
};
d.rG = function() {
  return V(this, Bt, 6);
};
d.HM = function(a) {
  X(this, 6, a);
};
var Ax = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Ax, O);
Ax.prototype.b = function(a) {
  return zx(a, this);
};
var zx = function(a, b) {
  var c = {algorithm:R(b, 1), Ula:R(b, 2)};
  a && (c.f = b);
  return c;
};
Ax.prototype.LV = function() {
  return R(this, 1);
};
Ax.prototype.AM = function(a) {
  T(this, 1, a);
};
Ax.prototype.ud = function() {
  return R(this, 2);
};
Ax.prototype.UM = function(a) {
  T(this, 2, a);
};
var Cx = function(a) {
  P(this, a, 0, -1, Bx, null);
};
w(Cx, O);
var Bx = [5];
Cx.prototype.b = function(a) {
  return Dx(a, this);
};
var Dx = function(a, b) {
  var c, e = {psa:R(b, 1), send:R(b, 2), resolution:(c = b.Ub()) && $t(a, c), priority:R(b, 4), YB:R(b, 5)};
  a && (e.f = b);
  return e;
};
d = Cx.prototype;
d.yaa = function(a) {
  T(this, 1, a);
};
d.$c = function() {
  return R(this, 2);
};
d.MN = function(a) {
  T(this, 2, a);
};
d.Ub = function() {
  return U(this, Zt, 3);
};
d.Zp = function(a) {
  W(this, 3, a);
};
d.ej = function() {
  return R(this, 4);
};
d.BN = function(a) {
  T(this, 4, a);
};
d.ij = function() {
  return R(this, 5);
};
d.aq = function(a) {
  T(this, 5, a || []);
};
d.tn = function(a, b) {
  hr(this, 5, a, b);
};
var Ex = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Ex, O);
Ex.prototype.b = function(a) {
  return Fx(a, this);
};
var Fx = function(a, b) {
  var c, e = {tja:(c = b.lW()) && ps(a, c), gsa:b.NZ(), hsa:R(b, 3)};
  a && (e.f = b);
  return e;
};
Ex.prototype.lW = function() {
  return U(this, os, 1);
};
Ex.prototype.MZ = function() {
  return R(this, 2);
};
Ex.prototype.NZ = function() {
  return gr(this.MZ());
};
var Gx = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Gx, O);
Gx.prototype.b = function(a) {
  return Hx(a, this);
};
var Hx = function(a, b) {
  var c, e = {$:S(b, 1, ""), sessionId:S(b, 2, ""), namespace:S(b, 3, ""), resolution:S(b, 4, 0), Ipa:S(b, 5, 0), Fta:(c = b.x_()) && hu(a, c), zsa:S(b, 7, !1), vz:S(b, 8, "")};
  a && (e.f = b);
  return e;
};
d = Gx.prototype;
d.O = function() {
  return S(this, 1, "");
};
d.L = function(a) {
  T(this, 1, a);
};
d.s = function() {
  return S(this, 2, "");
};
d.Ca = function(a) {
  T(this, 2, a);
};
d.Ub = function() {
  return S(this, 4, 0);
};
d.Zp = function(a) {
  T(this, 4, a);
};
d.x_ = function() {
  return U(this, gu, 6);
};
d.Al = function() {
  return S(this, 8, "");
};
d.jk = function(a) {
  T(this, 8, a);
};
var Jx = function(a) {
  P(this, a, 0, -1, Ix, null);
};
w(Jx, O);
var Ix = [2, 3];
Jx.prototype.b = function(a) {
  return Kx(a, this);
};
var Kx = function(a, b) {
  var c, e = {J:(c = b.h()) && Hu(a, c), zd:Q(b.Na(), mu, a), jf:R(b, 3), Ne:S(b, 4, "")};
  a && (e.f = b);
  return e;
};
d = Jx.prototype;
d.h = function() {
  return U(this, Gu, 1);
};
d.j = function(a) {
  W(this, 1, a);
};
d.G = function() {
  this.j(void 0);
};
d.Na = function() {
  return V(this, lu, 2);
};
d.Ab = function() {
  return R(this, 3);
};
d.Nb = function() {
  return S(this, 4, "");
};
var Lx = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Lx, O);
Lx.prototype.b = function(a) {
  return Mx(a, this);
};
var Mx = function(a, b) {
  var c, e = {Toa:S(b, 1, ""), Wra:S(b, 2, ""), Pja:S(b, 3, 0), timestamp:(c = b.jj()) && ju(a, c), Yoa:(c = b.vY()) && Nx(a, c)};
  a && (e.f = b);
  return e;
};
Lx.prototype.jj = function() {
  return U(this, iu, 4);
};
Lx.prototype.KB = function(a) {
  W(this, 4, a);
};
Lx.prototype.vY = function() {
  return U(this, Ox, 5);
};
var Ox = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Ox, O);
Ox.prototype.b = function(a) {
  return Nx(a, this);
};
var Nx = function(a, b) {
  var c = {Ysa:S(b, 1, ""), xna:S(b, 2, !1)};
  a && (c.f = b);
  return c;
};
var Qx = function(a) {
  P(this, a, 0, -1, Px, null);
};
w(Qx, O);
var Px = [10];
Qx.prototype.b = function(a) {
  return Rx(a, this);
};
var Rx = function(a, b) {
  var c, e = {AA:S(b, 1, ""), title:S(b, 2, ""), resolution:S(b, 4, 0), bsa:S(b, 5, 0), usa:(c = b.UZ()) && ju(a, c), Asa:(c = b.WZ()) && ju(a, c), cla:S(b, 9, ""), jka:R(b, 10)};
  a && (e.f = b);
  return e;
};
d = Qx.prototype;
d.getTitle = function() {
  return S(this, 2, "");
};
d.setTitle = function(a) {
  T(this, 2, a);
};
d.Ub = function() {
  return S(this, 4, 0);
};
d.Zp = function(a) {
  T(this, 4, a);
};
d.UZ = function() {
  return U(this, iu, 7);
};
d.WZ = function() {
  return U(this, iu, 8);
};
var Tx = function(a) {
  P(this, a, 0, -1, Sx, null);
};
w(Tx, O);
var Sx = [2];
Tx.prototype.b = function(a) {
  return Ux(a, this);
};
var Ux = function(a, b) {
  var c, e = {J:(c = b.h()) && Hu(a, c), zd:Q(b.Na(), xu, a), Ne:S(b, 3, "")};
  a && (e.f = b);
  return e;
};
d = Tx.prototype;
d.h = function() {
  return U(this, Gu, 1);
};
d.j = function(a) {
  W(this, 1, a);
};
d.G = function() {
  this.j(void 0);
};
d.Na = function() {
  return V(this, wu, 2);
};
d.Nb = function() {
  return S(this, 3, "");
};
var Wx = function(a) {
  P(this, a, 0, -1, Vx, null);
};
w(Wx, O);
var Vx = [3];
Wx.prototype.b = function(a) {
  return Xx(a, this);
};
var Xx = function(a, b) {
  var c = {cpa:S(b, 1, "3.17.0.0"), $qa:S(b, 2, "3.18.0.0"), xja:Q(b.mW(), Yx, a)};
  a && (c.f = b);
  return c;
};
Wx.prototype.mW = function() {
  return V(this, Zx, 3);
};
var Zx = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Zx, O);
Zx.prototype.b = function(a) {
  return Yx(a, this);
};
var Yx = function(a, b) {
  var c = {rta:R(b, 1), name:R(b, 2), yra:R(b, 3), xra:R(b, 4), lma:R(b, 5)};
  a && (c.f = b);
  return c;
};
Zx.prototype.getName = function() {
  return R(this, 2);
};
Zx.prototype.Dm = function(a) {
  T(this, 2, a);
};
Zx.prototype.rf = function() {
  return R(this, 5);
};
var ay = function(a) {
  Rc.call(this);
  this.id = $x++;
  this.D8 = [];
  this.Tg = {};
  this.cp = {};
  this.dB = {};
  this.ne = {};
  this.Jk = {};
  this.gK = {};
  this.Vn = a ? a.Vn : new G;
  this.hba = !a;
  this.Mj = null;
  a ? (this.Mj = a, this.dB = a.dB, this.ne = a.ne, this.cp = a.cp, this.Jk = a.Jk) : v();
  a = this.fy();
  this != a && (a.lr ? a.lr.push(this) : a.lr = [this]);
};
w(ay, Rc);
var $x = 1, by = 0.05 > Math.random();
d = ay.prototype;
d.fy = function() {
  for (var a = this;a.Mj;) {
    a = a.Mj;
  }
  return a;
};
d.oU = function(a) {
  for (var b = this;b;) {
    if (b == a) {
      return !0;
    }
    b = b.Mj;
  }
  return !1;
};
d.get = function(a) {
  var b = this.yo(a);
  null == b && this.$ka && (b = {BOGUS:"Service " + a + " was not registered"});
  if (null == b) {
    throw new cy(a);
  }
  return b;
};
d.rj = function(a) {
  return !(!this.Tg[a] && !this.iy(a));
};
d.p1 = function(a) {
  return !!(this.Tg[a] || this.iy(a) || (a instanceof M ? a.I0() : this.cp[a]));
};
d.yo = function(a) {
  for (var b = this;b;b = b.Mj) {
    if (b.isDisposed()) {
      throw Error("AppContext is disposed.");
    }
    if (b.Tg[a]) {
      return b.Tg[a][0];
    }
    if (b.gK[a]) {
      break;
    }
  }
  if (b = this.iy(a)) {
    b = b(this);
    if (null == b) {
      throw Error("Factory method for service " + a + " returned null or undefined.");
    }
    this.hi(a, b);
    return b;
  }
  return null;
};
d.ho = function(a, b) {
  return this.QV([a], b)[a];
};
d.QV = function(a, b) {
  var c = this.ts(), e = !b;
  b = {};
  for (var f = [], g = [], k = {}, q = {}, r = this.yo(Eq), A = 0;A < a.length;A++) {
    var E = a[A], aa = this.yo(E);
    if (aa) {
      var ba = new xr;
      b[E] = ba;
      aa.bw && (ba.UD(aa.bw()), ba.eb(Aa(function(a) {
        return a;
      }, aa)));
      ba.callback(aa);
    } else {
      x(!e || c, "A module manager is required for async loading. (" + E + ")");
      var nb;
      E instanceof M ? nb = kq([E]).M2 : (aa = this.cp[E]) && (nb = [aa]);
      !e || nb && nb.length ? (nb && (r && E instanceof M && r.fsa() && (by && (ba = r.vsa(dy), q[E] = ba), r.aoa(E)), f.push.apply(f, nb), k[E] = eb(nb)), g.push(E)) : (ba = new xr, b[E] = ba, ba.Yc(new cy(E)));
    }
  }
  if (e) {
    if (f.length) {
      this.cw && this.cw.push("loaded(" + g + "," + f + ")\n" + gf());
      for (A = 0;A < g.length;A++) {
        this.Vn.dispatchEvent(new ey("o", g[A]));
      }
      a = this.ts().Una(f);
      for (A = 0;A < g.length;A++) {
        E = g[A], aa = k[E], ba = a[aa].lw(), b[E] = ba, q[E] && ba.eb(function() {
          r.Vla(q[E]);
        }), this.AR(ba, E, aa);
      }
    }
  } else {
    for (A = 0;A < g.length;A++) {
      E = g[A], aa = f[A], ba = new xr(u(this.jT, this, E)), b[E] = ba, (a = this.ne[E]) || (this.ne[E] = a = []), aa && this.mR(ba, E, aa), ba.eb(u(this.jy, this, E, aa)), a.push({Rc:this, d:ba});
    }
  }
  return b;
};
d.mR = function(a, b, c) {
  a.eb(function() {
    this.cw && this.cw.push("loaded(" + b + "," + c + ")\n" + gf());
    return this.ts().load(c);
  }, this);
  a.Mq(u(this.pH, this, b, c));
};
d.AR = function(a, b, c) {
  a.eb(function() {
    this.Vn.dispatchEvent(new ey("p", b));
  }, this);
  a.Mq(u(this.pH, this, b, c));
  a.eb(u(this.jy, this, b, c));
};
d.jy = function(a, b) {
  var c = this.yo(a);
  if (null == c) {
    if (this.Jk[a]) {
      var e = this.Jk[a].lw();
      e.eb(u(this.jy, this, a, b));
      return e;
    }
    throw new fy(a, b, "Module loaded but service or factory not registered with app contexts.");
  }
  return c.bw ? (e = new xr, e.UD(c.bw()), e.callback(c), e.eb(u(this.MH, this, a)), e) : this.MH(a);
};
d.MH = function(a) {
  this.Jk[a] && delete this.Jk[a];
  return this.get(a);
};
d.pH = function(a, b, c) {
  return c instanceof yr ? c : new gy(a, b, c);
};
d.hi = function(a, b, c) {
  if (this.isDisposed()) {
    c || Sc(b);
  } else {
    x(!this.Tg[a], 'Service for "%s" is already registered', a);
    this.D8.push(a);
    this.Tg[a] = [b, !c];
    c = this.vV(this, a);
    for (var e = 0;e < c.length;e++) {
      c[e].callback(null);
    }
    delete this.cp[a];
    return b;
  }
};
d.iy = function(a) {
  return this.dB[a];
};
d.vV = function(a, b) {
  var c = [], e = this.ne[b];
  e && (hb(e, function(b) {
    b.Rc.oU(a) && (c.push(b.d), ub(e, b));
  }), 0 == e.length && delete this.ne[b]);
  return c;
};
d.kT = function(a) {
  this.ne && xe(this.ne, function(b, c, e) {
    hb(b, function(c) {
      c.Rc == a && ub(b, c);
    });
    0 == b.length && delete e[c];
  });
};
d.jT = function(a, b) {
  var c = this.ne && this.ne[a];
  if (c) {
    for (var e = 0;e < c.length;++e) {
      if (c[e].Rc == this && c[e].d == b) {
        tb(c, e);
        break;
      }
    }
    0 == c.length && delete this.ne[a];
  }
};
d.U = function() {
  if (this.fy() == this) {
    var a = this.lr;
    if (a) {
      for (;a.length;) {
        a[0].Qa();
      }
    }
  } else {
    for (var a = this.fy().lr, b = 0;b < a.length;b++) {
      if (a[b] == this) {
        a.splice(b, 1);
        break;
      }
    }
  }
  for (var c in this.Tg) {
    a = this.Tg[c], a[1] && a[0].Qa && a[0].Qa();
  }
  this.Tg = null;
  this.hba && this.Vn.Qa();
  this.kT(this);
  this.ne = null;
  Sc(this.L4);
  this.gK = this.L4 = null;
  ay.T.U.call(this);
};
d.ts = function() {
  return this.L2 ? this.L2 : this.Mj ? this.Mj.ts() : null;
};
var cy = function(a) {
  Ba.call(this);
  this.id = a;
  this.message = 'Service for "' + a + '" is not registered';
};
w(cy, Ba);
var gy = function(a, b, c) {
  Ba.call(this);
  this.cause = c;
  this.message = 'Module "' + b + '" failed to load when requesting the service "' + a + '" [cause: ' + c + "]";
  this.stack = c.stack + "\nWRAPPED BY:\n" + this.stack;
};
w(gy, Ba);
var fy = function(a, b, c) {
  Ba.call(this);
  this.message = 'Configuration error when loading the module "' + b + '" for the service "' + a + '": ' + c;
};
w(fy, Ba);
var ey = function(a) {
  F.call(this, a);
};
w(ey, F);
var hy = new Fp("fva"), dy = new jq(hy, 1);
zf("fava.debug.errorContext");
var jy = function(a) {
  a.rj(Rq) || a.hi(Rq, iy.W());
}, iy = function() {
  this.a = zf("realtime.analytics.ImpressionLogger");
};
pa(iy);
iy.prototype.Ge = function(a, b, c, e, f, g, k) {
  a = "Impression: " + a;
  b && (a += " SID: " + b);
  c && (a += " PLID: " + c);
  e && (a += " HID: " + e);
  f && (a += " TS: " + f);
  g && (a += " XN: " + g);
  k && (a += " XS: " + k);
  K(this.a, a);
};
var ky = function(a) {
  var b = new Sv;
  b.M8(a);
  b.p9(nc && hc ? 2 : nc ? 3 : oc ? 4 : pc ? 5 : 1);
  b.N$(1);
  return b;
};
var my = function(a, b, c, e, f, g, k) {
  G.call(this);
  this.Eb = e;
  this.Yz = f;
  this.Xk = this.Eb.$E(c);
  this.vb = ++ly;
  this.m = zf("realtime.collections.Collection." + this.vb);
  this.up = f.Zh;
  this.Wd = k || null;
  this.ci = g && g.ci || null;
  this.dC = f.b_();
  this.ml = g && g.MG() || null;
  this.Jc = new tk(this);
  this.la(this.Jc);
  this.data = [];
  this.Tr = [];
  this.IF = {};
  this.Za = -2;
  this.sj = !0;
  this.Nh = H();
  this.state = "Ua";
  this.config = b.Uk();
  this.Li = ds.W();
  this.ei = {};
  this.HF = Bd;
};
w(my, G);
var ny = new I(10, 67);
my.prototype.Es = function(a) {
  return new oy(a.bn, a.data, [], "Qa");
};
var py = function(a, b) {
  return new oy(b.bn, [], a, "Qa");
}, ly = 0, qy = 0;
d = my.prototype;
d.cd = function() {
  "Ua" != this.state || this.Li.mj || (this.state = "Sa", this.ci && this.Jc.listen(this.ci, x(this.ml), this.IK));
};
d.start = function(a) {
  a && (x(!this.Cf()), this.Xk = pr(a));
  "Ua" == this.state && this.cd();
  if ("Sa" != this.state || this.Li.mj) {
    return null;
  }
  this.state = "Ta";
  this.PJ();
  K(this.m, "Collection started: " + this.toString() + ", " + this.qf());
  return null;
};
d.stop = function() {
  if ("Ta" == this.state || "Sa" == this.state) {
    this.flush(), this.Ku(), this.state = "Ua", K(this.m, "Collection stopped: " + this.toString() + ": " + this.qf());
  }
};
d.PJ = function() {
  this.sj && this.Nh && (K(this.m, "Initial data available: " + this.toString()), this.Nh.resolve(this.Tr), this.Nh = null);
};
d.pf = function() {
  return this.config;
};
d.Ku = function() {
  this.ci && this.Jc.Fc(this.ci, x(this.ml), this.IK);
};
d.ls = function() {
  return pr(this.Xk);
};
d.Mn = function(a) {
  return a ? this.Eb.x1(a) ? (x(this.Eb.cJ(this.Xk, a)), this.Eb.Mn(this.Eb.bl(a))) : this.Eb.Mn(this.Eb.ur(this.Xk), a) : this.Eb.Mn(this.Eb.ur(this.Xk));
};
d.Cf = function() {
  return "Ta" == this.state && !this.Li.mj;
};
d.Ss = function() {
  return "Ta" == this.state;
};
d.v1 = function() {
  return ("Ta" == this.state || "Sa" == this.state) && !this.Li.mj;
};
d.U = function() {
  this.flush();
  this.stop();
  null != this.Nh && (J(this.m, "Never any data: " + this.toString()), this.Nh.promise.cancel(), this.Nh = null);
  my.T.U.call(this);
};
d.get = function() {
  return this.Tr;
};
d.ho = function() {
  return null != this.Nh ? this.Nh.promise : Xd(this.get());
};
d.flush = function() {
  var a;
  do {
    this.iT(), a = this.Yn();
  } while (0 < a);
};
d.iT = function() {
  Hb(this.ei, function(a) {
    for (;a && 1 <= a.length && a[0].lu;) {
      a.shift();
    }
  });
};
d.na = function() {
  return z(this.data, function(a) {
    return a.cb();
  });
};
d.add = function(a, b) {
  return this.yy(a) && this.dC ? (a = this.hx("Wa", a), Od(this.Yn, this), a) : this.Zl("Wa", this.hg([a]), u(this.Es, this), a, b);
};
d.modify = function(a, b) {
  return this.yy(a) && this.dC ? (a = this.hx("Xa", a), Od(this.Yn, this), a) : this.Zl("Xa", this.ig([a]), u(this.Es, this), a, b);
};
d.remove = function(a, b, c) {
  var e = this.Xu(a);
  return this.yy(a) && null == c && this.dC ? (a = this.hx("Ya", e, b), Od(this.Yn, this), a) : this.Zl("Ya", this.gf([e], b), Aa(py, [e]), e, c);
};
d.hx = function(a, b, c) {
  var e = this.Xu(b).toString(), f = this.ei[e] || [];
  this.ei[e] = f;
  var e = null, g = f.length;
  if (1 <= g && !f[g - 1].lu) {
    if (g = f[g - 1], "Wa" == a) {
      if ("Wa" == g.type || "Xa" == g.type) {
        e = g.pb, f.pop(), this.ga("e");
      }
    } else {
      if ("Xa" == a && ("Wa" == g.type || "Xa" == g.type)) {
        return g.Pg = this.A2(g.Pg, b), this.ga("d"), g.pb.promise;
      }
    }
  }
  a = new ry(a, b, e, c);
  f.push(a);
  return a.pb.promise;
};
d.Yn = function() {
  var a = 0, b = {};
  Hb(this.ei, function(c) {
    if (c && 1 <= c.length && (c = c[0], !c.lu)) {
      c.lu = !0;
      if ("Ya" == c.type && c.LD) {
        var e = [c.Pg];
        this.Du(this.gf(e, c.LD), Aa(py, e), [c.pb], e);
      } else {
        e = b[c.type] || [], e.push(c), b[c.type] = e;
      }
      a++;
    }
  }, this);
  Hb(b, function(a, b) {
    if (1 <= a.length) {
      var c = [], e = [];
      y(a, function(a) {
        c.push(a.Pg);
        e.push(a.pb);
      });
      switch(b) {
        case "Wa":
          this.Du(this.hg(c), u(this.Es, this), e, c);
          break;
        case "Xa":
          this.Du(this.ig(c), u(this.Es, this), e, c);
          break;
        case "Ya":
          this.Du(this.gf(c), Aa(py, c), e, c);
          break;
        default:
          Xa("A request with type " + b + " was put in the queue.");
      }
    }
  }, this);
  return a;
};
d.Du = function(a, b, c, e) {
  null == a && y(c, function(a) {
    a.reject("Operation not available");
  });
  if (!this.Li.mj) {
    a.yB(this.config.fH());
    a.JB(this.config.GH());
    e = z(e, this.Xu, this);
    var f = a.getPromise();
    f.then(u(this.LF, this, e), u(this.LF, this, e));
    f.then(u(this.EK, this, a, b, c, e)).jb(u(this.FK, this, a, c));
    this.up.execute(a);
  }
};
d.Rb = function() {
  return Yd("Resync not supported");
};
d.Rl = function() {
  return !0;
};
d.hg = function(a) {
  return this.Yz.hg(a);
};
d.ig = function(a) {
  return this.Yz.ig(a);
};
d.gf = function(a, b) {
  return this.Yz.gf(z(a, this.vr, this), b);
};
d.Ws = function(a) {
  return this.Eb.Oy(a);
};
d.yy = function(a) {
  return a instanceof sy ? this.Eb.Oy(this.vr(a)) : this.Eb.Oy(a);
};
d.tc = function(a) {
  return this.ST(this.Eb.$E(this.Eb.bl(a)));
};
d.gw = function(a) {
  return this.Eb.cJ(this.Xk, this.vr(a));
};
d.Zl = function(a, b, c, e, f) {
  if (null == b) {
    return Yd("Operation not available");
  }
  a = H();
  this.aba(b, c, a, f);
  this.$U(b, null);
  return a.promise;
};
d.aba = function(a, b, c, e) {
  e = null != e ? e : Ya(this.config.fH());
  a.yB(e);
  a.JB(a.Ds() || Ya(this.config.GH()));
  !this.Li.mj && null != c && a.getPromise().then(u(this.EK, this, a, b, [c], null)).jb(u(this.FK, this, a, [c]));
};
d.$U = function(a, b) {
  this.Li.mj || (K(this.m, "Executing operation: " + a), this.up.execute(a), null != b && a.getPromise().then(b, b));
};
d.EK = function(a, b, c, e, f) {
  K(this.m, "Operation executed: " + a + ", result:" + f);
  this.ga("b");
  null != b && (this.Rl(f.bn) ? (a = b(f)) ? this.uA(a) : K(this.m, "Operation resulted in no update") : this.Cf() && Xa("Result of an operation must have a valid version number, if the collection is active."));
  !e || null == f.data || 1 >= f.data.length ? (x(1 == c.length, "The result has only one resource but the length of resolver list is " + c.length), c[0].resolve(f.data)) : (x(c.length == e.length, "Resolver list and resource list have different length"), y(c, function(a, b) {
    var c = e[b];
    b = ib(f.data, function(a) {
      return this.Xu(a).equals(c);
    }, this);
    0 == b.length && Bf(this.m, "Result data is empty after filtering for target resource id " + c);
    a.resolve(b);
  }, this));
};
d.FK = function(a, b, c) {
  var e = "Operation failed: " + c;
  Bf(this.m, e, c instanceof Error ? c : Error(e));
  this.ga("a", new ty(a.$H(), a.FH(), c));
  y(b, function(a) {
    a.reject(c);
  });
  null != c.response && (a = c.response.getResponseHeader(), b = ny.get(a.Ra()), null != b && this.rx(b, "Collection apiary operation failed with response code " + a.Ra() + " triggering endcause " + b));
  return c;
};
d.LF = function(a) {
  var b = !1;
  y(a, function(a) {
    var c = this.ei[a.toString()];
    c && 1 <= c.length ? (c.shift(), b = b || 1 <= c.length) : Bf(this.m, "A writing request with resource id " + a + " completed but it is not in the request queue.");
  }, this);
  b && this.Yn();
};
d.IK = function(a) {
  this.v1() && this.tA(a);
};
d.tA = function(a) {
  var b = this.fI(a);
  K(this.m, "Received push notification, version: " + b + ", checking if any updates apply to this collection " + this.toString());
  var c = this.zY(a);
  a = this.LW(a);
  c.length || a.length ? (K(this.m, "Notification applies to this collection: version: " + b + ", add/modify: " + c.length + ", remove:" + a.length), b = new oy(b, c, a, "Pa"), L(this.m, "Created partial update for notification: " + b), Af(this.m, tf, "Add/modify: [" + b.vq.join("|") + "], remove: [" + b.wq.join("|") + "]"), this.ga("f"), this.uA(b)) : K(this.m, "Notification does not apply to this collection, ignoring.");
};
d.Ow = function(a) {
  return this.Eb.Ow(a);
};
d.sr = function(a) {
  return this.Eb.sr(a);
};
d.fI = function() {
  return -2;
};
d.zY = function(a) {
  var b = [];
  y(a.notification.Na(), function(a) {
    a = this.Ow(a);
    this.Ws(a) ? this.gw(this.tc(a)) && b.push(a) : this.ga("z", "Pushed modified: " + a.cb());
  }, this);
  return b;
};
d.LW = function(a) {
  if (!a.notification.Ab) {
    return [];
  }
  var b = [];
  y(a.notification.Ab(), function(a) {
    var c = this.sr(a);
    this.Ws(c) ? (a = this.tc(c), this.gw(a) && b.push(a)) : this.ga("z", "Pushed deleted: " + a.cb());
  }, this);
  return b;
};
d.uA = function(a) {
  L(this.m, "Begin processing update: " + a);
  a instanceof oy && (L(this.m, "Applying partial update: " + a), this.aw(a));
  L(this.m, "Finish processing update: " + a + ": " + this.qf());
};
d.qf = function() {
  return "state: " + this.state + ", local version: " + this.Za + ", snapshot size: " + this.data.length;
};
d.aw = function(a) {
  L(this.m, "Processing partial update: " + a);
  Af(this.m, tf, "Add/modify: [" + a.vq.join("|") + "], remove: [" + a.wq.join("|") + "]");
  y(a.vq, function(a) {
    if (this.Ws(a)) {
      var b = pr(a);
      vb(this.data, function(b) {
        return this.tc(b).equals(this.tc(a));
      }, this);
      this.data.push(b);
    } else {
      this.ga("z", "Partial update: " + a.cb());
    }
  }, this);
  var b = [];
  y(a.wq, function(a) {
    vb(this.data, function(b) {
      return this.tc(b).equals(a);
    }, this) || b.push(a);
  }, this);
  0 < b.length && this.ga("A", "Resources not found: " + ef(b));
  this.qC();
};
d.qC = function() {
  var a = ib(this.data, this.HF, this), b = this.wT(a), c = b.yb, e = b.Ci, b = b.removed;
  if (0 < c.length || 0 < e.length || 0 < b.length) {
    K(this.m, "Obtained update of the filtered view : modified: " + c.length + ", added: " + e.length + ", removed:" + b.length), Af(this.m, tf, "Modified: [" + c.join("|") + "], added: [" + e.join("|") + "], removed: [" + b.join("|") + "]"), this.Tr = a, this.dispatchEvent(new uy(c, e, b));
  }
};
d.wT = function(a) {
  var b = {}, c = [], e = [];
  y(a, function(a) {
    var f = this.Eb.bl(a), g = f.join("/"), r = b[g];
    r || (r = [], b[g] = r);
    r.push({key:f, Pg:a});
    (g = (g = this.IF[g]) && mb(g, function(a) {
      return Fb(a.key, f);
    })) ? nr(a, g.Pg) || c.push(a) : e.push(a);
  }, this);
  var f = [];
  y(this.Tr, function(a) {
    var c = this.Eb.bl(a), e = b[c.join("/")];
    e && -1 != lb(e, function(a) {
      return Fb(c, a.key);
    }) || f.push(a);
  }, this);
  this.IF = b;
  return {yb:c, Ci:e, removed:f};
};
d.b1 = function(a) {
  this.HF = a;
  this.qC();
};
d.ga = function(a, b) {
  null != this.Wd && this.Wd.ga(a, b);
};
d.A2 = function(a, b) {
  var c = JSON.parse(a.cb());
  b = JSON.parse(b.cb());
  for (var e = 0;e < b.length;e++) {
    null != b[e] && !lr(c[e], b[e]) && (c[e] = b[e]);
  }
  return new a.constructor(c);
};
d.Xu = function(a) {
  return null == a || a instanceof sy ? a : this.tc(a);
};
var vy = function(a) {
  this.Oa = a;
  this.id = ++qy;
}, oy = function(a, b, c, e) {
  vy.call(this, a);
  this.ZO = e;
  this.vq = b;
  this.wq = c;
};
w(oy, vy);
oy.prototype.toString = function() {
  return "[Partial update id: " + this.id + ", version: " + this.Oa + ", add/modify: " + this.vq.length + ", remove: " + this.wq.length + ", type: " + this.ZO + "]";
};
my.prototype.rx = function(a, b) {
  "Va" != this.state && (this.Ku(), this.state = "Va", Bf(this.m, "Collection failed: " + this.toString() + ": " + this.qf(), Error(b)), this.dispatchEvent(new wy(a, b)));
};
var ry = function(a, b, c, e) {
  this.type = a;
  this.Pg = b;
  this.pb = c || H();
  this.LD = e || null;
  this.lu = !1;
};
my.prototype.vr = function(a) {
  db(a, sy);
  return a.Ns;
};
my.prototype.ST = function(a) {
  return new sy(this.Eb, a);
};
var sy = function(a, b) {
  this.N7 = a;
  this.Ns = b;
};
sy.prototype.equals = function(a) {
  db(a, sy);
  return this.N7.dJ(this.Ns, a.Ns);
};
sy.prototype.toString = function() {
  return this.Ns.cb();
};
var uy = function(a, b, c) {
  F.call(this, "Q");
  this.Ci = b;
  this.yb = a;
  this.removed = c;
};
w(uy, F);
var wy = function(a, b) {
  F.call(this, "S");
  this.hb = a;
  this.reason = b;
};
w(wy, F);
var ty = function(a, b, c) {
  ff(c);
  this.request = b;
  this.ix = c;
};
w(ty, Error);
var xy = function() {
  this.Ib = this.Gb = null;
  this.fk = [];
  this.yz = [];
  this.zz = new Ae;
  this.ta = [];
  this.Ms = "ICE";
  this.Ls = "full";
  this.LC = [];
};
d = xy.prototype;
d.SA = function() {
  this.Ib = this.Gb = null;
  this.fk = [];
  this.yz = [];
  this.zz.clear();
  this.ta = [];
  this.Ms = "ICE";
  this.Ls = "full";
  this.LC = [];
};
d.toSdp = function(a, b, c) {
  this.Gb && this.SA();
  this.Gb = a;
  this.Ib = c || null;
  this.LC = b || [];
  this.fk = this.fS();
  a = [this.Gb.ma, this.Gb.ha, this.Gb.getData()];
  y(a, function(a) {
    null != a && this.kS(a, this.Gb.kc(), this.Gb.Ah());
  }, this);
  this.fk.push(this.Ua("group:BUNDLE", this.yz.join(" ")));
  this.fk.push(this.Ua("ice-options:trickle"));
  this.Ib || (this.bE(this.fk, this.Ms, this.Ls), a = this.Ua("msid-semantic:", "WMS " + this.zz.H().join(" ")), this.fk.push(a));
  this.ta.push("");
  return this.fk.concat(this.ta).join("\r\n");
};
d.fS = function() {
  if (this.Ib) {
    return this.Ib.bI("session");
  }
  var a = Math.pow(2, 53) * Math.random(), b = [];
  b.push("v=0");
  b.push("o=- " + a + " 2 IN IP4 127.0.0.1");
  b.push("s=-");
  b.push("t=0 0");
  return b;
};
d.kS = function(a, b, c) {
  var e = a.N(), f = Sb(Np)[e], g = a.Ae();
  this.yz.push(g);
  var k = a.sc(), q = a.Bc, r = "RTP/SAVPF";
  b && b.ud() && (r = q ? "DTLS/SCTP" : "UDP/TLS/RTP/SAVPF");
  var A = "m=" + f + " 9 " + r;
  "DTLS/SCTP" == r ? A += " " + q.Wa() : y(k, function(a) {
    A += " " + a.yc;
  }, this);
  this.ta.push(A);
  r = "inactive";
  a.$c() && a.Ut ? r = "sendrecv" : a.Ut ? r = "recvonly" : a.$c() && (r = "sendonly");
  this.jS(f, g, r);
  this.wS(b);
  this.dS(c);
  this.oS(a.fj());
  this.bS(k, e);
  (b = a.Hc()) && this.XR(0 < k.length ? k[0].yc : null, b);
  this.qS(q);
  this.vS(a.lb());
};
d.Ua = function(a, b) {
  a = "a=" + a;
  null == b || Ga(b) || (a = a + " " + b);
  return a;
};
d.jS = function(a, b, c) {
  if (this.Ib) {
    if (a = this.Ib.bI(a)) {
      this.ta = this.ta.concat(a);
    }
  } else {
    this.ta.push("c=IN IP6 ::"), this.ta.push(this.Ua("rtcp:9", "IN IP6 ::")), this.ta.push(this.Ua(c)), this.ta.push(this.Ua("rtcp-mux"));
  }
  this.ta.push(this.Ua("mid:" + b));
  b = z(this.LC, function(a) {
    return this.Ua("x-google-flag:" + a);
  }, this);
  this.ta = this.ta.concat(b);
};
d.wS = function(a) {
  var b = a && a.di || "123456789012345678901234";
  this.ta.push(this.Ua("ice-ufrag:" + (a && a.wi || "1234567890123456")));
  this.ta.push(this.Ua("ice-pwd:" + b));
  a && (this.Ms = a.zf(), this.Ls = a.K2);
  this.bE(this.ta, this.Ms, this.Ls);
  a && a.ud() && (this.ta.push(this.Ua("fingerprint:" + a.ud())), this.ta.push(this.Ua("setup:" + (a.wF || "actpass"))));
};
d.bE = function(a, b, c) {
  "ICE" == b ? "lite" == c && a.push(this.Ua("ice-lite")) : Xa("google-ice is no longer supported.");
};
d.dS = function(a) {
  var b;
  0 < a.length && (b = a[0]);
  null != b && this.ta.push(this.Ua("crypto:" + b.Ho(), b.Lh() + " " + b.zl()));
};
d.oS = function(a) {
  y(a, function(a) {
    this.ta.push(this.Ua("extmap:" + a.getId(), a.Fl()));
  }, this);
};
d.bS = function(a, b) {
  y(a, function(a) {
    var c = a.yc, f = a.getName(), g = a.fg;
    if ("v" == b || "d" == b) {
      g = 90000;
    }
    f = f + "/" + g;
    "a" == b && 1 < a.ff && (f += "/" + a.ff);
    this.ta.push(this.Ua("rtpmap:" + c, f));
    a = a.Xx();
    if (0 < a.length) {
      var k = [];
      y(a, function(a) {
        a.getKey() && a.vc() && k.push(a.getKey() + "=" + a.vc());
      }, this);
      a = "";
      0 < k.length && (a = k.join("; "));
      this.ta.push(this.Ua("fmtp:" + c, a));
    }
    "v" != b || 100 != c || this.Ib || (a = "rtcp-fb:" + c, this.ta = this.ta.concat([this.Ua(a, "ccm fir"), this.Ua(a, "nack"), this.Ua(a, "goog-remb")]));
    this.Ib && (c = this.Ib.m_(c)) && (this.ta = this.ta.concat(c));
  }, this);
};
d.XR = function(a, b) {
  var c = b.Eg;
  -1 != c && this.ta.push("b=AS:" + c);
  ci && null != a && (a = "fmtp:" + a, c = b.qk, -1 != c && this.ta.push(this.Ua(a, "x-google-start-bitrate=" + c)), b = b.Ej, -1 != b && this.ta.push(this.Ua(a, "x-google-min-bitrate=" + b)));
};
d.qS = function(a) {
  a && this.ta.push(this.Ua("sctpmap:" + a.Wa() + " " + a.getName() + " " + a.Bj));
};
d.vS = function(a) {
  y(a, function(a) {
    if (!Ga(Pa(a.He))) {
      var b = a.ya(), e = x(a.He), f = a.Dj ? a.Dj : e;
      this.zz.add(e);
      var g = z(a.TH(), function(a) {
        return this.Ua("ssrc-group:" + a.Eo(), a.wd().join(" "));
      }, this);
      this.ta = this.ta.concat(g);
      y(a.wd(), function(a) {
        var c = "ssrc:" + a, c = [this.Ua(c, "cname:" + b), this.Ua(c, "msid:" + e + " " + f)];
        null != this.Ib && (a = this.Ib.o_(a)) && (c = c.concat(a));
        this.ta = this.ta.concat(c);
      }, this);
    }
  }, this);
};
var yy = function(a) {
  G.call(this);
  this.oi = a;
  this.oi.xu(this);
  this.la(this.oi);
};
w(yy, G);
d = yy.prototype;
d.mg = "bb";
d.na = function() {
  return {config:this.pf(), muted:this.To(), state:this.UW()};
};
d.K = function() {
  return this.oi;
};
d.To = function() {
  return "Ba" == this.K().getState();
};
d.pf = function() {
  return null;
};
d.UW = function() {
  switch(this.mg) {
    case "ab":
      return chrome.i18n.getMessage("6950033741572394811");
    case "bb":
      return chrome.i18n.getMessage("8757444822404164848");
    case "cb":
      return chrome.i18n.getMessage("4782049665629043191");
    case "db":
      return chrome.i18n.getMessage("2100823569845184829");
    case "eb":
      return chrome.i18n.getMessage("99290588561553105");
    case "fb":
      return chrome.i18n.getMessage("7017840133230118615");
  }
  return "";
};
d.QM = function(a) {
  this.mg = a;
  this.dispatchEvent("V");
};
d.zL = n;
d.nC = n;
d.aO = n;
var zy = function(a, b, c, e, f) {
  G.call(this);
  this.yn = b;
  this.zn = c;
  this.Sg = f || "https://clients6.google.com";
  this.Od = e;
  this.Sd = a;
  this.Ql = !1;
  this.X5 = "POST";
  this.ht = H();
  this.Sd.UI() ? this.ht.resolve() : this.Sd.hp(this.Ql ? "P" : "O", function() {
    this.ht.resolve();
  }, !1, this);
};
w(zy, G);
d = zy.prototype;
d.qo = function() {
};
d.ks = function() {
  return this.Sd;
};
d.request = function(a, b, c, e, f, g, k) {
  this.ht.promise.then(function() {
    var q = this.Ar().FB(this.Sg).ni("/" + this.yn + "/" + this.zn + "/" + a).vB(b).NB(c).OB(!l(k) || k).qu(e), r = H();
    r.promise.then(f, g || n);
    q.Op.mB(u(r.resolve, r)).sB(u(r.reject, r));
    this.Sd.request(q);
  }, null, this);
};
d.Xl = function(a, b, c, e) {
  var f = Ga(Pa(this.Od)) ? {} : {key:this.Od}, g = this.Ar().FB(this.Sg).ni("/" + this.yn + "/" + this.zn + "/" + a).vB(this.X5).NB(f).OB(!0).qu(b);
  null != c && g.MM(c);
  null != e && g.FN(e);
  var k = H();
  g.Op.mB(u(function(a) {
    var b = null;
    try {
      b = this.gU(a);
    } catch (E) {
      a = this.Ql ? new Bq("fatal", "response_decoding", null, a) : new Aq("fatal", "response_decoding", null, a);
      k.reject(a);
      return;
    }
    var c = this.wZ(b);
    1 == c ? k.resolve(b) : this.z1(c) ? g.Hm("r") : (a = this.Ql ? new Bq("fatal", "backend", null, a) : new Aq("fatal", "backend", null, a), k.reject(a));
  }, this)).sB(u(k.reject, k));
  this.ht.promise.then(u(this.Sd.request, this.Sd, g));
  return k.promise;
};
d.wZ = function(a) {
  var b = 0;
  a && ua(a.getResponseHeader) && (a = a.getResponseHeader()) && ua(a.Ra) && (b = a.Ra());
  return b;
};
d.z1 = function(a) {
  return this.Ql ? 2 == a || 3 == a ? !0 : !1 : !1;
};
d.gU = function(a) {
  a = bb(this.Ql ? a.Fr : a);
  if (0 < a.length) {
    var b = rr[a[0]];
    if (!b) {
      throw Error("Unknown JsPb message type: " + a[0]);
    }
    a = new b(a);
  } else {
    a = null;
  }
  return a;
};
d.Ar = function() {
  return this.Ql ? new Dq : new Lq;
};
var Ay = function(a) {
  this.Ni = null;
  this.P0 = !!a;
};
Ay.prototype.xE = function() {
  this.Ni = null;
};
Ay.prototype.wI = function() {
  return !!this.Ni;
};
Ay.prototype.wca = function(a) {
  this.P0 || this.xca(a);
};
Ay.prototype.xca = function(a) {
  if (!this.Ni || this.Ni.jj() < a.jj()) {
    this.Ni = a.Uk();
  }
};
var Cy = function(a) {
  P(this, a, 0, -1, By, null);
};
w(Cy, O);
var By = [5, 52];
Cy.prototype.b = function(a) {
  return Dy(a, this);
};
var Dy = function(a, b) {
  var c, e = {uja:R(b, 1), wsa:R(b, 2), Cba:R(b, 133), vja:R(b, 3), Dma:R(b, 105), mja:R(b, 107), nja:R(b, 104), $pa:R(b, 4), Zpa:R(b, 43), Dka:Q(b.GW(), Ey, a), dia:R(b, 28), Ela:R(b, 29), Xsa:R(b, 30), Uba:R(b, 112), Ska:R(b, 106), th:R(b, 100), Yja:R(b, 68), Xja:(c = b.uW()) && Fy(a, c), qma:R(b, 42), K5:Q(b.vs(), Gy, a), Ona:(c = b.VX()) && Hy(a, c)};
  a && (e.f = b);
  return e;
};
d = Cy.prototype;
d.FM = function(a) {
  T(this, 1, a);
};
d.TN = function(a) {
  T(this, 2, a);
};
d.SN = function(a) {
  T(this, 133, a);
};
d.GM = function(a) {
  T(this, 3, a);
};
d.I$ = function(a) {
  T(this, 4, a);
};
d.GW = function() {
  return V(this, Iy, 5);
};
d.n9 = function(a) {
  X(this, 5, a);
};
d.y9 = function(a) {
  T(this, 29, a);
};
d.VN = function(a) {
  T(this, 30, a);
};
d.uW = function() {
  return U(this, Jy, 69);
};
d.vs = function() {
  return V(this, Ky, 52);
};
d.VX = function() {
  return U(this, Ly, 135);
};
var Iy = function(a) {
  P(this, a, 0, -1, My, null);
};
w(Iy, O);
var My = [2, 13];
Iy.prototype.b = function(a) {
  return Ey(a, this);
};
var Ey = function(a, b) {
  var c, e = {Sra:R(b, 1), GU:R(b, 113), Kia:R(b, 118), zoa:Q(b.Eh(), Ny, a), fka:Q(b.zG(), Oy, a), Kqa:R(b, 34), Via:R(b, 92), vma:R(b, 94), Dta:R(b, 93), Rsa:R(b, 35), GT:R(b, 36), uqa:R(b, 54), Ita:R(b, 66), ema:fr(b, 71), Bka:S(b, 72, -1), Ata:S(b, 73, -1), Ana:S(b, 74, !1), Pia:S(b, 75, -1), Dsa:(c = b.ZZ()) && Py(a, c)};
  a && (e.f = b);
  return e;
};
d = Iy.prototype;
d.paa = function(a) {
  T(this, 1, a);
};
d.Eh = function() {
  return V(this, Qy, 2);
};
d.i$ = function(a) {
  X(this, 2, a);
};
d.zG = function() {
  return V(this, Ry, 13);
};
d.i9 = function(a) {
  X(this, 13, a);
};
d.U$ = function(a) {
  T(this, 34, a);
};
d.T8 = function(a) {
  T(this, 92, a);
};
d.J9 = function(a) {
  T(this, 94, a);
};
d.Taa = function(a) {
  T(this, 93, a);
};
d.Gaa = function(a) {
  T(this, 35, a);
};
d.qB = function(a) {
  T(this, 36, a);
};
d.ZZ = function() {
  return U(this, Sy, 129);
};
var Qy = function(a) {
  P(this, a, 0, -1, Ty, null);
};
w(Qy, O);
var Ty = [53, 54];
Qy.prototype.b = function(a) {
  return Ny(a, this);
};
var Ny = function(a, b) {
  var c, e = {Qoa:R(b, 1), jma:R(b, 2), xka:R(b, 3), voa:R(b, 4), Bna:R(b, 5), eM:R(b, 6), hja:R(b, 7), fqa:R(b, 8), eja:R(b, 9), eqa:R(b, 10), direction:R(b, 24), ssrc:R(b, 25), pia:fr(b, 117), Cla:R(b, 26), Xla:R(b, 27), lpa:R(b, 28), mf:R(b, 29), gma:R(b, 30), fma:R(b, 31), hma:fr(b, 50), qra:fr(b, 87), ima:fr(b, 51), rra:fr(b, 88), Cna:R(b, 37), Bqa:R(b, 38), ita:R(b, 39), Jia:R(b, 40), Iia:R(b, 41), kta:R(b, 42), Cra:R(b, 43), Tsa:R(b, 124), lia:R(b, 125), ira:R(b, 96), Nna:R(b, 80), Yra:R(b, 
  44), Xqa:R(b, 94), kla:R(b, 46), lla:R(b, 47), mla:R(b, 48), nla:R(b, 49), jla:fr(b, 63), wra:fr(b, 129), qsa:R(b, 53), qba:Q(b.zs(), Uy, a), width:R(b, 57), height:R(b, 58), Lta:R(b, 114), Kta:R(b, 115), Tqa:R(b, 113), Lna:R(b, 78), Kna:R(b, 79), wna:R(b, 59), zna:R(b, 60), nia:R(b, 65), mia:R(b, 95), Hla:fr(b, 68), msa:fr(b, 103), zqa:fr(b, 106), cia:fr(b, 107), Qra:fr(b, 104), Bja:R(b, 74), Lia:R(b, 75), Ala:R(b, 76), Cja:R(b, 77), tpa:R(b, 81), spa:R(b, 82), vpa:R(b, 83), wpa:R(b, 84), upa:R(b, 
  85), xpa:R(b, 86), Ppa:R(b, 89), Qpa:R(b, 112), Spa:R(b, 118), Rpa:R(b, 119), Aja:(c = b.oW()) && Av(a, c), zla:(c = b.eX()) && Av(a, c), Ika:(c = b.HW()) && Av(a, c), pra:(c = b.tZ()) && Av(a, c), fta:R(b, 108), eta:R(b, 109), dta:R(b, 110), mma:R(b, 130), Ena:R(b, 131)};
  a && (e.f = b);
  return e;
};
d = Qy.prototype;
d.to = function() {
  return R(this, 1);
};
d.kN = function(a) {
  T(this, 1, a);
};
d.tB = function(a) {
  T(this, 2, a);
};
d.LM = function(a) {
  T(this, 3, a);
};
d.hN = function(a) {
  T(this, 4, a);
};
d.bN = function(a) {
  T(this, 5, a);
};
d.$p = function(a) {
  T(this, 6, a);
};
d.oG = function() {
  return R(this, 7);
};
d.EM = function(a) {
  T(this, 7, a);
};
d.xN = function(a) {
  T(this, 8, a);
};
d.nG = function() {
  return R(this, 9);
};
d.DM = function(a) {
  T(this, 9, a);
};
d.wN = function(a) {
  T(this, 10, a);
};
d.jc = function() {
  return R(this, 24);
};
d.oe = function(a) {
  T(this, 24, a);
};
d.zg = function() {
  return R(this, 25);
};
d.GB = function(a) {
  T(this, 25, a);
};
d.L8 = function(a) {
  T(this, 117, a);
};
d.RM = function(a) {
  T(this, 26, a);
};
d.VM = function(a) {
  T(this, 27, a);
};
d.oN = function(a) {
  T(this, 28, a);
};
d.Nx = function() {
  return R(this, 29);
};
d.WM = function(a) {
  T(this, 29, a);
};
d.nX = function() {
  return R(this, 30);
};
d.XM = function(a) {
  T(this, 30, a);
};
d.F9 = function(a) {
  T(this, 31, a);
};
d.G9 = function(a) {
  T(this, 50, a);
};
d.H9 = function(a) {
  T(this, 51, a);
};
d.R$ = function(a) {
  T(this, 38, a);
};
d.Paa = function(a) {
  T(this, 39, a);
};
d.YV = function() {
  return R(this, 40);
};
d.P8 = function(a) {
  T(this, 40, a);
};
d.O8 = function(a) {
  T(this, 41, a);
};
d.WN = function(a) {
  T(this, 42, a);
};
d.gaa = function(a) {
  T(this, 43, a);
};
d.Iaa = function(a) {
  T(this, 124, a);
};
d.J8 = function(a) {
  T(this, 125, a);
};
d.Z$ = function(a) {
  T(this, 96, a);
};
d.b$ = function(a) {
  T(this, 80, a);
};
d.raa = function(a) {
  T(this, 44, a);
};
d.W$ = function(a) {
  T(this, 94, a);
};
d.u9 = function(a) {
  T(this, 46, a);
};
d.v9 = function(a) {
  T(this, 47, a);
};
d.w9 = function(a) {
  T(this, 48, a);
};
d.x9 = function(a) {
  T(this, 49, a);
};
d.t9 = function(a) {
  T(this, 63, a);
};
d.faa = function(a) {
  T(this, 129, a);
};
d.As = function() {
  return R(this, 53);
};
d.zaa = function(a) {
  T(this, 53, a || []);
};
d.zs = function() {
  return V(this, Vy, 54);
};
d.PN = function(a) {
  X(this, 54, a);
};
d.Af = function() {
  return R(this, 57);
};
d.mk = function(a) {
  T(this, 57, a);
};
d.tf = function() {
  return R(this, 58);
};
d.ik = function(a) {
  T(this, 58, a);
};
d.CN = function(a) {
  T(this, 113, a);
};
d.a$ = function(a) {
  T(this, 78, a);
};
d.Z9 = function(a) {
  T(this, 79, a);
};
d.U9 = function(a) {
  T(this, 59, a);
};
d.es = function() {
  return R(this, 65);
};
d.zM = function(a) {
  T(this, 65, a);
};
d.K8 = function(a) {
  T(this, 95, a);
};
d.B9 = function(a) {
  T(this, 68, a);
};
d.xaa = function(a) {
  T(this, 103, a);
};
d.Q$ = function(a) {
  T(this, 106, a);
};
d.I8 = function(a) {
  T(this, 107, a);
};
d.oaa = function(a) {
  T(this, 104, a);
};
d.Q8 = function(a) {
  T(this, 75, a);
};
d.t$ = function(a) {
  T(this, 81, a);
};
d.s$ = function(a) {
  T(this, 82, a);
};
d.v$ = function(a) {
  T(this, 83, a);
};
d.w$ = function(a) {
  T(this, 84, a);
};
d.u$ = function(a) {
  T(this, 85, a);
};
d.x$ = function(a) {
  T(this, 86, a);
};
d.C$ = function(a) {
  T(this, 89, a);
};
d.D$ = function(a) {
  T(this, 112, a);
};
d.F$ = function(a) {
  T(this, 118, a);
};
d.E$ = function(a) {
  T(this, 119, a);
};
d.oW = function() {
  return U(this, zv, 120);
};
d.eX = function() {
  return U(this, zv, 121);
};
d.HW = function() {
  return U(this, zv, 122);
};
d.tZ = function() {
  return U(this, zv, 123);
};
var Wy = {Iha:0, UQ:1, Iv:2, Hha:3}, Xy = {Kq:0, gD:1, Gha:2}, Yy = {QC:0, PC:1, OC:2, RC:4, tda:8, wda:16, vda:32, xda:64, uda:128, pda:256, sda:512, rda:1024, qda:2048, yda:1073741824}, Vy = function(a) {
  P(this, a, 0, -1, Zy, null);
};
w(Vy, O);
var Zy = [2];
Vy.prototype.b = function(a) {
  return Uy(a, this);
};
var Uy = function(a, b) {
  var c = {j8:R(b, 1), YB:R(b, 2)};
  a && (c.f = b);
  return c;
};
d = Vy.prototype;
d.Eo = function() {
  return R(this, 1);
};
d.LN = function(a) {
  T(this, 1, a);
};
d.ij = function() {
  return R(this, 2);
};
d.aq = function(a) {
  T(this, 2, a || []);
};
d.tn = function(a, b) {
  hr(this, 2, a, b);
};
var Ry = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Ry, O);
Ry.prototype.b = function(a) {
  return Oy(a, this);
};
var Oy = function(a, b) {
  var c, e = {BT:R(b, 1), Zla:R(b, 2), eM:R(b, 3), hta:R(b, 4), gja:R(b, 5), cta:R(b, 90), bta:R(b, 91), gta:R(b, 6), fja:R(b, 7), tra:(c = b.uZ()) && nv(a, c), nra:(c = b.rZ()) && nv(a, c), networkType:R(b, 55), jba:(c = b.my()) && $y(a, c)};
  a && (e.f = b);
  return e;
};
d = Ry.prototype;
d.ru = function(a) {
  T(this, 1, a);
};
d.D9 = function(a) {
  T(this, 2, a);
};
d.$p = function(a) {
  T(this, 3, a);
};
d.Oaa = function(a) {
  T(this, 4, a);
};
d.W8 = function(a) {
  T(this, 5, a);
};
d.Maa = function(a) {
  T(this, 90, a);
};
d.Laa = function(a) {
  T(this, 91, a);
};
d.Naa = function(a) {
  T(this, 6, a);
};
d.V8 = function(a) {
  T(this, 7, a);
};
d.uZ = function() {
  return U(this, mv, 8, 1);
};
d.baa = function(a) {
  W(this, 8, a);
};
d.rZ = function() {
  return U(this, mv, 9, 1);
};
d.aaa = function(a) {
  W(this, 9, a);
};
d.my = function() {
  return U(this, az, 56);
};
var az = function(a) {
  P(this, a, 0, -1, null, null);
};
w(az, O);
az.prototype.b = function(a) {
  return $y(a, this);
};
var $y = function(a, b) {
  var c = {Ota:R(b, 1), Ija:R(b, 2), Hja:R(b, 3), Gja:R(b, 4)};
  a && (c.f = b);
  return c;
}, Sy = function(a) {
  P(this, a, 0, -1, bz, null);
};
w(Sy, O);
var bz = [3];
Sy.prototype.b = function(a) {
  return Py(a, this);
};
var Py = function(a, b) {
  var c = {qqa:R(b, 1), nta:R(b, 2), rqa:R(b, 3)};
  a && (c.f = b);
  return c;
}, Jy = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Jy, O);
Jy.prototype.b = function(a) {
  return Fy(a, this);
};
var Fy = function(a, b) {
  var c = {gka:R(b, 1), fpa:R(b, 2)};
  a && (c.f = b);
  return c;
}, Ky = function(a) {
  P(this, a, 0, -1, cz, null);
};
w(Ky, O);
var cz = [3, 4];
Ky.prototype.b = function(a) {
  return Gy(a, this);
};
var Gy = function(a, b) {
  var c = {Cpa:R(b, 1), wp:R(b, 2), Gia:R(b, 3), Gta:R(b, 4)};
  a && (c.f = b);
  return c;
};
Ky.prototype.De = function() {
  return R(this, 2);
};
var Ly = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Ly, O);
Ly.prototype.b = function(a) {
  return Hy(a, this);
};
var Hy = function(a, b) {
  var c = {mra:R(b, 1), protocol:R(b, 2)};
  a && (c.f = b);
  return c;
};
Ly.prototype.yg = function() {
  return R(this, 2);
};
Ly.prototype.Yp = function(a) {
  T(this, 2, a);
};
var dz = function(a) {
  P(this, a, 0, -1, null, null);
};
w(dz, O);
dz.prototype.b = function(a) {
  return ez(a, this);
};
var ez = function(a, b) {
  var c, e = {code:R(b, 1), tsa:(c = b.TZ()) && Iv(a, c), Qqa:(c = b.eZ()) && Ev(a, c), Fra:R(b, 3), Sja:R(b, 4), rsa:R(b, 5), Cba:R(b, 7), Uba:R(b, 8)};
  a && (e.f = b);
  return e;
};
dz.prototype.TZ = function() {
  return U(this, Hv, 2);
};
dz.prototype.eZ = function() {
  return U(this, Dv, 6);
};
dz.prototype.SN = function(a) {
  T(this, 7, a);
};
var fz = function() {
}, gz = new Date(0) - new Date("1900/01/01 00:00 GMT");
d = fz.prototype;
d.g6 = function(a, b, c) {
  b && this.mV(a);
  b = Number(a.ssrc);
  null != b && (this.zR(a, b, c), null != a.bytesReceived && this.DR(a, b, c), this.lR(a, b, c));
};
d.mV = function(a) {
  null !== a && "googFrameWidthSent" in a && (a.googFrameWidthSent = 0);
  null !== a && "googFrameHeightSent" in a && (a.googFrameHeightSent = 0);
};
d.zR = function(a, b, c) {
  var e = a.googCaptureStartNtpTimeMs;
  null != e && 0 < e && (b = c.no(b), null != b && (e = e - gz + 1000 * b, a.oneWayDelayMs = v() - e));
};
d.DR = function(a, b, c) {
  b = c.pX(b);
  null != b && (null != b.hI && (a.fpsGraphicsInput = b.hI), null != b.iI && (a.fpsGraphicsOutput = b.iI));
};
d.lR = function(a) {
  var b = Yy.QC, c = a.googCpuLimitedResolution, e = a.googBandwidthLimitedResolution, f = a.googViewLimitedResolution;
  if (null != c || null != e || null != f) {
    "true" == c && (b |= Yy.PC), "true" == e && (b |= Yy.OC), "true" == f && (b |= Yy.RC), a.googAdaptationReason = b;
  }
};
var iz = function(a) {
  P(this, a, "chbarp", -1, hz, null);
};
w(iz, O);
var hz = [4];
iz.prototype.b = function(a) {
  var b, c = {Ka:(b = this.getResponseHeader()) && Kw(a, b), ZD:(b = this.io()) && Yv(a, b), J:(b = this.h()) && Z(a, b), qb:Q(this.M(), Yv, a)};
  a && (c.f = this);
  return c;
};
sr("chbarp", iz);
d = iz.prototype;
d.getResponseHeader = function() {
  return U(this, Jw, 1);
};
d.io = function() {
  return U(this, Xv, 2);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
d.M = function() {
  return V(this, Xv, 4);
};
d.ra = function(a) {
  X(this, 4, a);
};
var kz = function(a) {
  P(this, a, "chbmrp", -1, jz, null);
};
w(kz, O);
var jz = [4];
kz.prototype.b = function(a) {
  var b, c = {Ka:(b = this.getResponseHeader()) && Kw(a, b), ZD:(b = this.io()) && Yv(a, b), J:(b = this.h()) && Z(a, b), qb:Q(this.M(), Yv, a)};
  a && (c.f = this);
  return c;
};
sr("chbmrp", kz);
d = kz.prototype;
d.getResponseHeader = function() {
  return U(this, Jw, 1);
};
d.io = function() {
  return U(this, Xv, 2);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
d.M = function() {
  return V(this, Xv, 4);
};
d.ra = function(a) {
  X(this, 4, a);
};
var lz = function(a) {
  P(this, a, "chbqrp", -1, null, null);
};
w(lz, O);
lz.prototype.b = function(a) {
  var b, c = {Ka:(b = this.getResponseHeader()) && Kw(a, b), ZD:(b = this.io()) && Yv(a, b), J:(b = this.h()) && Z(a, b)};
  a && (c.f = this);
  return c;
};
sr("chbqrp", lz);
d = lz.prototype;
d.getResponseHeader = function() {
  return U(this, Jw, 1);
};
d.io = function() {
  return U(this, Xv, 2);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
var mz = function(a) {
  P(this, a, "chbrrp", -1, null, null);
};
w(mz, O);
mz.prototype.b = function(a) {
  var b, c = {Ka:(b = this.getResponseHeader()) && Kw(a, b), J:(b = this.h()) && Z(a, b)};
  a && (c.f = this);
  return c;
};
sr("chbrrp", mz);
mz.prototype.getResponseHeader = function() {
  return U(this, Jw, 1);
};
mz.prototype.h = function() {
  return U(this, Y, 2);
};
mz.prototype.j = function(a) {
  W(this, 2, a);
};
mz.prototype.G = function() {
  this.j(void 0);
};
var oz = function(a) {
  P(this, a, "chbsrp", -1, nz, null);
};
w(oz, O);
var nz = [2];
oz.prototype.b = function(a) {
  var b, c = {Ka:(b = this.getResponseHeader()) && Kw(a, b), Tia:Q(this.aW(), Yv, a), J:(b = this.h()) && Z(a, b)};
  a && (c.f = this);
  return c;
};
sr("chbsrp", oz);
d = oz.prototype;
d.getResponseHeader = function() {
  return U(this, Jw, 1);
};
d.aW = function() {
  return V(this, Xv, 2);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
var qz = function(a) {
  P(this, a, 0, -1, pz, null);
};
w(qz, O);
var pz = [2, 3];
qz.prototype.b = function(a) {
  return rz(a, this);
};
var rz = function(a, b) {
  var c, e = {J:(c = b.h()) && Z(a, c), zd:Q(b.Na(), Yv, a), jf:Q(b.Ab(), ts, a), Ne:(c = b.Nb()) && ts(a, c)};
  a && (e.f = b);
  return e;
};
d = qz.prototype;
d.h = function() {
  return U(this, Y, 1);
};
d.j = function(a) {
  W(this, 1, a);
};
d.G = function() {
  this.j(void 0);
};
d.Na = function() {
  return V(this, Xv, 2);
};
d.Ab = function() {
  return V(this, ss, 3);
};
d.Nb = function() {
  return U(this, ss, 4);
};
var tz = function(a) {
  P(this, a, "carp", -1, sz, null);
};
w(tz, O);
var sz = [2];
tz.prototype.b = function(a) {
  var b, c = {Ka:(b = this.getResponseHeader()) && Kw(a, b), qb:Q(this.M(), zs, a)};
  a && (c.f = this);
  return c;
};
sr("carp", tz);
tz.prototype.getResponseHeader = function() {
  return U(this, Jw, 1);
};
tz.prototype.M = function() {
  return V(this, ys, 2);
};
tz.prototype.ra = function(a) {
  X(this, 2, a);
};
var uz = function(a) {
  P(this, a, 0, -1, null, null);
};
w(uz, O);
uz.prototype.b = function(a) {
  return vz(a, this);
};
var vz = function(a, b) {
  var c, e = {jia:R(b, 1), Epa:(c = b.KY()) && Gw(a, c), z7:R(b, 3), dU:R(b, 5), Aia:(c = b.PV()) && Hs(a, c), Qka:b.OW(), zE:R(b, 7), i8:R(b, 8)};
  a && (e.f = b);
  return e;
};
d = uz.prototype;
d.KY = function() {
  return U(this, Fw, 4);
};
d.HH = function() {
  return R(this, 3);
};
d.PV = function() {
  return U(this, Gs, 6);
};
d.NW = function() {
  return R(this, 2);
};
d.OW = function() {
  return gr(this.NW());
};
var xz = function(a) {
  P(this, a, 0, -1, wz, null);
};
w(xz, O);
var wz = [4];
xz.prototype.b = function(a) {
  return yz(a, this);
};
var yz = function(a, b) {
  var c, e = {ob:(c = b.X()) && Iw(a, c), hangout:(c = b.sf()) && Qw(a, c), J:(c = b.h()) && Z(a, c), qb:Q(b.M(), Qw, a)};
  a && (e.f = b);
  return e;
};
d = xz.prototype;
d.X = function() {
  return U(this, Hw, 1);
};
d.setRequestHeader = function(a) {
  W(this, 1, a);
};
d.sf = function() {
  return U(this, Pw, 2);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
d.M = function() {
  return V(this, Pw, 4);
};
d.ra = function(a) {
  X(this, 4, a);
};
var Az = function(a) {
  P(this, a, "charp", -1, zz, null);
};
w(Az, O);
var zz = [5];
Az.prototype.b = function(a) {
  return Bz(a, this);
};
var Bz = function(a, b) {
  var c, e = {Ka:(c = b.getResponseHeader()) && Kw(a, c), hangout:(c = b.sf()) && Qw(a, c), TB:R(b, 4), J:(c = b.h()) && Z(a, c), qb:Q(b.M(), Qw, a)};
  a && (e.f = b);
  return e;
};
sr("charp", Az);
d = Az.prototype;
d.getResponseHeader = function() {
  return U(this, Jw, 1);
};
d.sf = function() {
  return U(this, Pw, 2);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
d.M = function() {
  return V(this, Pw, 5);
};
d.ra = function(a) {
  X(this, 5, a);
};
var Dz = function(a) {
  P(this, a, 0, -1, Cz, null);
};
w(Dz, O);
var Cz = [11];
Dz.prototype.b = function(a) {
  return Ez(a, this);
};
var Ez = function(a, b) {
  var c, e = {RI:S(b, 8, 0), $:R(b, 1), f1:(c = b.Sx()) && ww(a, c), nna:Q(b.NX(), Vw, a), Gpa:S(b, 3, 1), uka:R(b, 4), Fpa:R(b, 6), Pka:(c = b.MW()) && kt(a, c), zta:R(b, 9), lna:R(b, 99)};
  a && (e.f = b);
  return e;
};
d = Dz.prototype;
d.O = function() {
  return R(this, 1);
};
d.L = function(a) {
  T(this, 1, a);
};
d.Sx = function() {
  return U(this, vw, 2);
};
d.NX = function() {
  return V(this, Uw, 11);
};
d.MW = function() {
  return U(this, jt, 7);
};
var Gz = function(a) {
  P(this, a, 0, -1, Fz, null);
};
w(Gz, O);
var Fz = [4];
d = Gz.prototype;
d.b = function(a) {
  var b, c = {ob:(b = this.X()) && Iw(a, b), hangout:(b = this.sf()) && Qw(a, b), J:(b = this.h()) && Z(a, b), qb:Q(this.M(), Qw, a)};
  a && (c.f = this);
  return c;
};
d.X = function() {
  return U(this, Hw, 1);
};
d.setRequestHeader = function(a) {
  W(this, 1, a);
};
d.sf = function() {
  return U(this, Pw, 2);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
d.M = function() {
  return V(this, Pw, 4);
};
d.ra = function(a) {
  X(this, 4, a);
};
var Iz = function(a) {
  P(this, a, "chmrp", -1, Hz, null);
};
w(Iz, O);
var Hz = [4];
Iz.prototype.b = function(a) {
  var b, c = {Ka:(b = this.getResponseHeader()) && Kw(a, b), hangout:(b = this.sf()) && Qw(a, b), J:(b = this.h()) && Z(a, b), qb:Q(this.M(), Qw, a)};
  a && (c.f = this);
  return c;
};
sr("chmrp", Iz);
d = Iz.prototype;
d.getResponseHeader = function() {
  return U(this, Jw, 1);
};
d.sf = function() {
  return U(this, Pw, 2);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
d.M = function() {
  return V(this, Pw, 4);
};
d.ra = function(a) {
  X(this, 4, a);
};
var Kz = function(a) {
  P(this, a, 0, -1, Jz, null);
};
w(Kz, O);
var Jz = [6];
Kz.prototype.b = function(a) {
  return Lz(a, this);
};
var Lz = function(a, b) {
  var c, e = {ob:(c = b.X()) && Iw(a, c), wp:(c = b.De()) && bx(a, c), Cqa:(c = b.$Y()) && mt(a, c), aqa:R(b, 4), J:(c = b.h()) && Z(a, c), qb:Q(b.M(), bx, a)};
  a && (e.f = b);
  return e;
};
d = Kz.prototype;
d.X = function() {
  return U(this, Hw, 1);
};
d.setRequestHeader = function(a) {
  W(this, 1, a);
};
d.De = function() {
  return U(this, ax, 2);
};
d.$Y = function() {
  return U(this, lt, 3);
};
d.h = function() {
  return U(this, Y, 5);
};
d.j = function(a) {
  W(this, 5, a);
};
d.G = function() {
  this.j(void 0);
};
d.M = function() {
  return V(this, ax, 6);
};
d.ra = function(a) {
  X(this, 6, a);
};
var Nz = function(a) {
  P(this, a, "chparp", -1, Mz, null);
};
w(Nz, O);
var Mz = [5];
Nz.prototype.b = function(a) {
  return Oz(a, this);
};
var Oz = function(a, b) {
  var c, e = {Ka:(c = b.getResponseHeader()) && Kw(a, c), wp:(c = b.De()) && bx(a, c), J:(c = b.h()) && Z(a, c), errorCode:R(b, 4), qb:Q(b.M(), bx, a)};
  a && (e.f = b);
  return e;
};
sr("chparp", Nz);
d = Nz.prototype;
d.getResponseHeader = function() {
  return U(this, Jw, 1);
};
d.De = function() {
  return U(this, ax, 2);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
d.Jx = function() {
  return R(this, 4);
};
d.M = function() {
  return V(this, ax, 5);
};
d.ra = function(a) {
  X(this, 5, a);
};
var Qz = function(a) {
  P(this, a, 0, -1, Pz, null);
};
w(Qz, O);
var Pz = [4];
d = Qz.prototype;
d.b = function(a) {
  var b, c = {ob:(b = this.X()) && Iw(a, b), wp:(b = this.De()) && bx(a, b), J:(b = this.h()) && Z(a, b), qb:Q(this.M(), bx, a)};
  a && (c.f = this);
  return c;
};
d.X = function() {
  return U(this, Hw, 1);
};
d.setRequestHeader = function(a) {
  W(this, 1, a);
};
d.De = function() {
  return U(this, ax, 2);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
d.M = function() {
  return V(this, ax, 4);
};
d.ra = function(a) {
  X(this, 4, a);
};
var Sz = function(a) {
  P(this, a, "chpmrp", -1, Rz, null);
};
w(Sz, O);
var Rz = [4];
Sz.prototype.b = function(a) {
  var b, c = {Ka:(b = this.getResponseHeader()) && Kw(a, b), wp:(b = this.De()) && bx(a, b), J:(b = this.h()) && Z(a, b), qb:Q(this.M(), bx, a)};
  a && (c.f = this);
  return c;
};
sr("chpmrp", Sz);
d = Sz.prototype;
d.getResponseHeader = function() {
  return U(this, Jw, 1);
};
d.De = function() {
  return U(this, ax, 2);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
d.M = function() {
  return V(this, ax, 4);
};
d.ra = function(a) {
  X(this, 4, a);
};
var Tz = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Tz, O);
d = Tz.prototype;
d.b = function(a) {
  var b, c = {ob:(b = this.X()) && Iw(a, b), $:R(this, 2), za:R(this, 3), J:(b = this.h()) && Z(a, b)};
  a && (c.f = this);
  return c;
};
d.X = function() {
  return U(this, Hw, 1);
};
d.setRequestHeader = function(a) {
  W(this, 1, a);
};
d.O = function() {
  return R(this, 2);
};
d.L = function(a) {
  T(this, 2, a);
};
d.A = function() {
  return R(this, 3);
};
d.Sa = function(a) {
  T(this, 3, a);
};
d.h = function() {
  return U(this, Y, 4);
};
d.j = function(a) {
  W(this, 4, a);
};
d.G = function() {
  this.j(void 0);
};
var Uz = function(a) {
  P(this, a, "chpqrp", -1, null, null);
};
w(Uz, O);
Uz.prototype.b = function(a) {
  var b, c = {Ka:(b = this.getResponseHeader()) && Kw(a, b), wp:(b = this.De()) && bx(a, b), J:(b = this.h()) && Z(a, b)};
  a && (c.f = this);
  return c;
};
sr("chpqrp", Uz);
d = Uz.prototype;
d.getResponseHeader = function() {
  return U(this, Jw, 1);
};
d.De = function() {
  return U(this, ax, 2);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
var Wz = function(a) {
  P(this, a, 0, -1, Vz, null);
};
w(Wz, O);
var Vz = [6, 7];
d = Wz.prototype;
d.b = function(a) {
  var b, c = {ob:(b = this.X()) && Iw(a, b), $:R(this, 2), za:R(this, 3), hb:R(this, 5), J:(b = this.h()) && Z(a, b), zra:R(this, 6), qb:Q(this.M(), ot, a)};
  a && (c.f = this);
  return c;
};
d.X = function() {
  return U(this, Hw, 1);
};
d.setRequestHeader = function(a) {
  W(this, 1, a);
};
d.O = function() {
  return R(this, 2);
};
d.L = function(a) {
  T(this, 2, a);
};
d.A = function() {
  return R(this, 3);
};
d.Sa = function(a) {
  T(this, 3, a);
};
d.tl = function() {
  return R(this, 5);
};
d.Wp = function(a) {
  T(this, 5, a);
};
d.h = function() {
  return U(this, Y, 4);
};
d.j = function(a) {
  W(this, 4, a);
};
d.G = function() {
  this.j(void 0);
};
d.M = function() {
  return V(this, nt, 7);
};
d.ra = function(a) {
  X(this, 7, a);
};
var Xz = function(a) {
  P(this, a, "chprrp", -1, null, null);
};
w(Xz, O);
Xz.prototype.b = function(a) {
  var b, c = {Ka:(b = this.getResponseHeader()) && Kw(a, b), J:(b = this.h()) && Z(a, b), DL:R(this, 3)};
  a && (c.f = this);
  return c;
};
sr("chprrp", Xz);
Xz.prototype.getResponseHeader = function() {
  return U(this, Jw, 1);
};
Xz.prototype.h = function() {
  return U(this, Y, 2);
};
Xz.prototype.j = function(a) {
  W(this, 2, a);
};
Xz.prototype.G = function() {
  this.j(void 0);
};
var Yz = function(a) {
  P(this, a, 0, -1, null, null);
};
w(Yz, O);
Yz.prototype.b = function(a) {
  return Zz(a, this);
};
var Zz = function(a, b) {
  var c, e = {ob:(c = b.X()) && Iw(a, c), $:R(b, 2), J:(c = b.h()) && Z(a, c)};
  a && (e.f = b);
  return e;
};
d = Yz.prototype;
d.X = function() {
  return U(this, Hw, 1);
};
d.setRequestHeader = function(a) {
  W(this, 1, a);
};
d.O = function() {
  return R(this, 2);
};
d.L = function(a) {
  T(this, 2, a);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
var aA = function(a) {
  P(this, a, "chpsrp", -1, $z, null);
};
w(aA, O);
var $z = [2, 4];
aA.prototype.b = function(a) {
  return bA(a, this);
};
var bA = function(a, b) {
  var c, e = {Ka:(c = b.getResponseHeader()) && Kw(a, c), K5:Q(b.vs(), bx, a), J:(c = b.h()) && Z(a, c), ora:Q(b.sZ(), Wt, a)};
  a && (e.f = b);
  return e;
};
sr("chpsrp", aA);
d = aA.prototype;
d.getResponseHeader = function() {
  return U(this, Jw, 1);
};
d.vs = function() {
  return V(this, ax, 2);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
d.sZ = function() {
  return V(this, Vt, 4);
};
var dA = function(a) {
  P(this, a, 0, -1, cA, null);
};
w(dA, O);
var cA = [2, 3];
dA.prototype.b = function(a) {
  return eA(a, this);
};
var eA = function(a, b) {
  var c, e = {J:(c = b.h()) && Z(a, c), zd:Q(b.Na(), bx, a), jf:Q(b.Ab(), ot, a), hb:R(b, 4), Ne:(c = b.Nb()) && ot(a, c), DL:R(b, 6)};
  a && (e.f = b);
  return e;
};
d = dA.prototype;
d.h = function() {
  return U(this, Y, 1);
};
d.j = function(a) {
  W(this, 1, a);
};
d.G = function() {
  this.j(void 0);
};
d.Na = function() {
  return V(this, ax, 2);
};
d.Ab = function() {
  return V(this, nt, 3);
};
d.tl = function() {
  return R(this, 4);
};
d.Wp = function(a) {
  T(this, 4, a);
};
d.Nb = function() {
  return U(this, nt, 5);
};
var fA = function(a) {
  P(this, a, 0, -1, null, null);
};
w(fA, O);
fA.prototype.b = function(a) {
  return gA(a, this);
};
var gA = function(a, b) {
  var c, e = {RI:S(b, 1, 0), $:R(b, 2), Q5:(c = b.$x()) && ps(a, c), tna:R(b, 4), sna:R(b, 5), qla:(c = b.bX()) && Fx(a, c)};
  a && (e.f = b);
  return e;
};
fA.prototype.O = function() {
  return R(this, 2);
};
fA.prototype.L = function(a) {
  T(this, 2, a);
};
fA.prototype.$x = function() {
  return U(this, os, 3);
};
fA.prototype.bX = function() {
  return U(this, Ex, 6);
};
var iA = function(a) {
  P(this, a, 0, -1, hA, null);
};
w(iA, O);
var hA = [2];
iA.prototype.b = function(a) {
  return jA(a, this);
};
var jA = function(a, b) {
  var c, e = {J:(c = b.h()) && Z(a, c), zd:Q(b.Na(), gx, a)};
  a && (e.f = b);
  return e;
};
iA.prototype.h = function() {
  return U(this, Y, 1);
};
iA.prototype.j = function(a) {
  W(this, 1, a);
};
iA.prototype.G = function() {
  this.j(void 0);
};
iA.prototype.Na = function() {
  return V(this, fx, 2);
};
var kA = function(a) {
  P(this, a, 0, -1, null, null);
};
w(kA, O);
kA.prototype.b = function(a) {
  return lA(a, this);
};
var lA = function(a, b) {
  var c, e = {ob:(c = b.X()) && Iw(a, c), $:R(b, 2), J:(c = b.h()) && Z(a, c)};
  a && (e.f = b);
  return e;
};
d = kA.prototype;
d.X = function() {
  return U(this, Hw, 1);
};
d.setRequestHeader = function(a) {
  W(this, 1, a);
};
d.O = function() {
  return R(this, 2);
};
d.L = function(a) {
  T(this, 2, a);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
var mA = function(a) {
  P(this, a, "chqrp", -1, null, null);
};
w(mA, O);
mA.prototype.b = function(a) {
  return nA(a, this);
};
var nA = function(a, b) {
  var c, e = {Ka:(c = b.getResponseHeader()) && Kw(a, c), hangout:(c = b.sf()) && Qw(a, c), J:(c = b.h()) && Z(a, c)};
  a && (e.f = b);
  return e;
};
sr("chqrp", mA);
d = mA.prototype;
d.getResponseHeader = function() {
  return U(this, Jw, 1);
};
d.sf = function() {
  return U(this, Pw, 2);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
var pA = function(a) {
  P(this, a, 0, -1, oA, null);
};
w(pA, O);
var oA = [3];
pA.prototype.b = function(a) {
  return qA(a, this);
};
var qA = function(a, b) {
  var c, e = {ob:(c = b.X()) && Iw(a, c), fV:(c = b.Lx()) && gt(a, c), ona:Q(b.OX(), ww, a), npa:(c = b.DY()) && Ot(a, c), una:S(b, 5, !1), mediaType:S(b, 6, 1), TB:R(b, 7), J:(c = b.h()) && Z(a, c)};
  a && (e.f = b);
  return e;
};
d = pA.prototype;
d.X = function() {
  return U(this, Hw, 1);
};
d.setRequestHeader = function(a) {
  W(this, 1, a);
};
d.Lx = function() {
  return U(this, ft, 2);
};
d.TM = function(a) {
  W(this, 2, a);
};
d.OX = function() {
  return V(this, vw, 3);
};
d.DY = function() {
  return U(this, Nt, 4);
};
d.r$ = function(a) {
  W(this, 4, a);
};
d.aN = function(a) {
  T(this, 5, a);
};
d.P = function() {
  return S(this, 6, 1);
};
d.oc = function(a) {
  T(this, 6, a);
};
d.dg = function() {
  T(this, 6, void 0);
};
d.h = function() {
  return U(this, Y, 8);
};
d.j = function(a) {
  W(this, 8, a);
};
d.G = function() {
  this.j(void 0);
};
var rA = function(a) {
  P(this, a, "chrrp", -1, null, null);
};
w(rA, O);
rA.prototype.b = function(a) {
  return sA(a, this);
};
var sA = function(a, b) {
  var c, e = {Ka:(c = b.getResponseHeader()) && Kw(a, c), $:R(b, 2), errorCode:R(b, 3), TB:R(b, 4), J:(c = b.h()) && Z(a, c)};
  a && (e.f = b);
  return e;
};
sr("chrrp", rA);
d = rA.prototype;
d.getResponseHeader = function() {
  return U(this, Jw, 1);
};
d.O = function() {
  return R(this, 2);
};
d.L = function(a) {
  T(this, 2, a);
};
d.Jx = function() {
  return R(this, 3);
};
d.h = function() {
  return U(this, Y, 5);
};
d.j = function(a) {
  W(this, 5, a);
};
d.G = function() {
  this.j(void 0);
};
var uA = function(a) {
  P(this, a, 0, -1, tA, null);
};
w(uA, O);
var tA = [2, 3];
uA.prototype.b = function(a) {
  return vA(a, this);
};
var vA = function(a, b) {
  var c, e = {J:(c = b.h()) && Z(a, c), zd:Q(b.Na(), Qw, a), jf:Q(b.Ab(), it, a), Ne:(c = b.Nb()) && it(a, c)};
  a && (e.f = b);
  return e;
};
d = uA.prototype;
d.h = function() {
  return U(this, Y, 1);
};
d.j = function(a) {
  W(this, 1, a);
};
d.G = function() {
  this.j(void 0);
};
d.Na = function() {
  return V(this, Pw, 2);
};
d.Ab = function() {
  return V(this, ht, 3);
};
d.Nb = function() {
  return U(this, ht, 4);
};
var wA = function(a) {
  P(this, a, 0, -1, null, null);
};
w(wA, O);
wA.prototype.b = function(a) {
  return xA(a, this);
};
var xA = function(a, b) {
  var c, e = {mediaType:R(b, 1), Bsa:(c = b.XH()) && Dx(a, c)};
  a && (e.f = b);
  return e;
};
d = wA.prototype;
d.P = function() {
  return R(this, 1);
};
d.oc = function(a) {
  T(this, 1, a);
};
d.dg = function() {
  T(this, 1, void 0);
};
d.XH = function() {
  return U(this, Cx, 2);
};
d.Caa = function(a) {
  W(this, 2, a);
};
var yA = function(a) {
  P(this, a, "chselrp", -1, null, null);
};
w(yA, O);
yA.prototype.b = function(a) {
  var b, c = {Ka:(b = this.getResponseHeader()) && Kw(a, b), J:(b = this.h()) && Z(a, b)};
  a && (c.f = this);
  return c;
};
sr("chselrp", yA);
yA.prototype.getResponseHeader = function() {
  return U(this, Jw, 1);
};
yA.prototype.h = function() {
  return U(this, Y, 2);
};
yA.prototype.j = function(a) {
  W(this, 2, a);
};
yA.prototype.G = function() {
  this.j(void 0);
};
var zA = function(a) {
  P(this, a, 0, -1, null, null);
};
w(zA, O);
zA.prototype.b = function(a) {
  return AA(a, this);
};
var AA = function(a, b) {
  var c, e = {ob:(c = b.X()) && Iw(a, c), sessionId:R(b, 2), J:(c = b.h()) && Z(a, c)};
  a && (e.f = b);
  return e;
};
d = zA.prototype;
d.X = function() {
  return U(this, Hw, 1);
};
d.setRequestHeader = function(a) {
  W(this, 1, a);
};
d.s = function() {
  return R(this, 2);
};
d.Ca = function(a) {
  T(this, 2, a);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
var CA = function(a) {
  P(this, a, 0, -1, BA, null);
};
w(CA, O);
var BA = [4];
CA.prototype.b = function(a) {
  return DA(a, this);
};
var DA = function(a, b) {
  var c, e = {ob:(c = b.X()) && Iw(a, c), source:(c = b.K()) && kx(a, c), J:(c = b.h()) && Z(a, c), qb:Q(b.M(), kx, a)};
  a && (e.f = b);
  return e;
};
d = CA.prototype;
d.X = function() {
  return U(this, Hw, 1);
};
d.setRequestHeader = function(a) {
  W(this, 1, a);
};
d.K = function() {
  return U(this, jx, 2);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
d.M = function() {
  return V(this, jx, 4);
};
d.ra = function(a) {
  X(this, 4, a);
};
var FA = function(a) {
  P(this, a, "chsoarp", -1, EA, null);
};
w(FA, O);
var EA = [4];
FA.prototype.b = function(a) {
  return GA(a, this);
};
var GA = function(a, b) {
  var c, e = {Ka:(c = b.getResponseHeader()) && Kw(a, c), source:(c = b.K()) && kx(a, c), J:(c = b.h()) && Z(a, c), qb:Q(b.M(), kx, a)};
  a && (e.f = b);
  return e;
};
sr("chsoarp", FA);
d = FA.prototype;
d.getResponseHeader = function() {
  return U(this, Jw, 1);
};
d.K = function() {
  return U(this, jx, 2);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
d.M = function() {
  return V(this, jx, 4);
};
d.ra = function(a) {
  X(this, 4, a);
};
var IA = function(a) {
  P(this, a, 0, -1, HA, null);
};
w(IA, O);
var HA = [4];
d = IA.prototype;
d.b = function(a) {
  var b, c = {ob:(b = this.X()) && Iw(a, b), source:(b = this.K()) && kx(a, b), J:(b = this.h()) && Z(a, b), qb:Q(this.M(), kx, a)};
  a && (c.f = this);
  return c;
};
d.X = function() {
  return U(this, Hw, 1);
};
d.setRequestHeader = function(a) {
  W(this, 1, a);
};
d.K = function() {
  return U(this, jx, 2);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
d.M = function() {
  return V(this, jx, 4);
};
d.ra = function(a) {
  X(this, 4, a);
};
var KA = function(a) {
  P(this, a, "chsomrp", -1, JA, null);
};
w(KA, O);
var JA = [4];
KA.prototype.b = function(a) {
  var b, c = {Ka:(b = this.getResponseHeader()) && Kw(a, b), source:(b = this.K()) && kx(a, b), J:(b = this.h()) && Z(a, b), qb:Q(this.M(), kx, a)};
  a && (c.f = this);
  return c;
};
sr("chsomrp", KA);
d = KA.prototype;
d.getResponseHeader = function() {
  return U(this, Jw, 1);
};
d.K = function() {
  return U(this, jx, 2);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
d.M = function() {
  return V(this, jx, 4);
};
d.ra = function(a) {
  X(this, 4, a);
};
var MA = function(a) {
  P(this, a, 0, -1, null, null);
};
w(MA, O);
d = MA.prototype;
d.b = function(a) {
  var b, c = {ob:(b = this.X()) && Iw(a, b), $:R(this, 2), za:R(this, 3), sourceId:R(this, 4)};
  a && (c.f = this);
  return c;
};
d.X = function() {
  return U(this, Hw, 1);
};
d.setRequestHeader = function(a) {
  W(this, 1, a);
};
d.O = function() {
  return R(this, 2);
};
d.L = function(a) {
  T(this, 2, a);
};
d.A = function() {
  return R(this, 3);
};
d.Sa = function(a) {
  T(this, 3, a);
};
d.ya = function() {
  return R(this, 4);
};
d.Qf = function(a) {
  T(this, 4, a);
};
var NA = function(a) {
  P(this, a, "chsoqrp", -1, null, null);
};
w(NA, O);
NA.prototype.b = function(a) {
  var b, c = {Ka:(b = this.getResponseHeader()) && Kw(a, b), source:(b = this.K()) && kx(a, b)};
  a && (c.f = this);
  return c;
};
sr("chsoqrp", NA);
NA.prototype.getResponseHeader = function() {
  return U(this, Jw, 1);
};
NA.prototype.K = function() {
  return U(this, jx, 2);
};
var OA = function(a) {
  P(this, a, 0, -1, null, null);
};
w(OA, O);
OA.prototype.b = function(a) {
  return PA(a, this);
};
var PA = function(a, b) {
  var c, e = {ob:(c = b.X()) && Iw(a, c), $:R(b, 2), za:R(b, 3), J:(c = b.h()) && Z(a, c)};
  a && (e.f = b);
  return e;
};
d = OA.prototype;
d.X = function() {
  return U(this, Hw, 1);
};
d.setRequestHeader = function(a) {
  W(this, 1, a);
};
d.O = function() {
  return R(this, 2);
};
d.L = function(a) {
  T(this, 2, a);
};
d.A = function() {
  return R(this, 3);
};
d.Sa = function(a) {
  T(this, 3, a);
};
d.h = function() {
  return U(this, Y, 4);
};
d.j = function(a) {
  W(this, 4, a);
};
d.G = function() {
  this.j(void 0);
};
var RA = function(a) {
  P(this, a, "chsosrp", -1, QA, null);
};
w(RA, O);
var QA = [2];
RA.prototype.b = function(a) {
  return SA(a, this);
};
var SA = function(a, b) {
  var c, e = {Ka:(c = b.getResponseHeader()) && Kw(a, c), P7:Q(b.Do(), kx, a), J:(c = b.h()) && Z(a, c)};
  a && (e.f = b);
  return e;
};
sr("chsosrp", RA);
d = RA.prototype;
d.getResponseHeader = function() {
  return U(this, Jw, 1);
};
d.Do = function() {
  return V(this, jx, 2);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
var UA = function(a) {
  P(this, a, 0, -1, TA, null);
};
w(UA, O);
var TA = [2, 3];
UA.prototype.b = function(a) {
  return VA(a, this);
};
var VA = function(a, b) {
  var c, e = {J:(c = b.h()) && Z(a, c), zd:Q(b.Na(), kx, a), jf:Q(b.Ab(), It, a), Ne:(c = b.Nb()) && It(a, c)};
  a && (e.f = b);
  return e;
};
d = UA.prototype;
d.h = function() {
  return U(this, Y, 1);
};
d.j = function(a) {
  W(this, 1, a);
};
d.G = function() {
  this.j(void 0);
};
d.Na = function() {
  return V(this, jx, 2);
};
d.Ab = function() {
  return V(this, Ht, 3);
};
d.Nb = function() {
  return U(this, Ht, 4);
};
var WA = function(a) {
  P(this, a, 0, -1, null, null);
};
w(WA, O);
WA.prototype.b = function(a) {
  return XA(a, this);
};
var XA = function(a, b) {
  var c, e = {direction:R(b, 1), mediaType:R(b, 2), sessionId:R(b, 3), pO:R(b, 4), $:R(b, 5), za:R(b, 6), sourceId:R(b, 7), Kpa:(c = b.wg()) && YA(a, c), request:(c = b.Kh()) && Dx(a, c), R2:(c = b.Be()) && ZA(a, c), Eta:R(b, 11)};
  a && (e.f = b);
  return e;
};
d = WA.prototype;
d.jc = function() {
  return R(this, 1);
};
d.oe = function(a) {
  T(this, 1, a);
};
d.P = function() {
  return R(this, 2);
};
d.oc = function(a) {
  T(this, 2, a);
};
d.dg = function() {
  T(this, 2, void 0);
};
d.s = function() {
  return R(this, 3);
};
d.Ca = function(a) {
  T(this, 3, a);
};
d.Vb = function() {
  return R(this, 4);
};
d.lk = function(a) {
  T(this, 4, a);
};
d.O = function() {
  return R(this, 5);
};
d.L = function(a) {
  T(this, 5, a);
};
d.A = function() {
  return R(this, 6);
};
d.Sa = function(a) {
  T(this, 6, a);
};
d.ya = function() {
  return R(this, 7);
};
d.Qf = function(a) {
  T(this, 7, a);
};
d.wg = function() {
  return U(this, $A, 8);
};
d.pN = function(a) {
  W(this, 8, a);
};
d.Kh = function() {
  return U(this, Cx, 9);
};
d.caa = function(a) {
  W(this, 9, a);
};
d.Be = function() {
  return U(this, aB, 10);
};
d.AB = function(a) {
  W(this, 10, a);
};
d.w_ = function() {
  return R(this, 11);
};
d.Cu = function(a) {
  T(this, 11, a);
};
var $A = function(a) {
  P(this, a, 0, -1, bB, null);
};
w($A, O);
var bB = [1, 2];
$A.prototype.b = function(a) {
  return YA(a, this);
};
var YA = function(a, b) {
  var c = {YB:R(b, 1), qba:Q(b.zs(), cB, a)};
  a && (c.f = b);
  return c;
};
d = $A.prototype;
d.ij = function() {
  return R(this, 1);
};
d.aq = function(a) {
  T(this, 1, a || []);
};
d.tn = function(a, b) {
  hr(this, 1, a, b);
};
d.zs = function() {
  return V(this, dB, 2);
};
d.PN = function(a) {
  X(this, 2, a);
};
var dB = function(a) {
  P(this, a, 0, -1, eB, null);
};
w(dB, O);
var eB = [2];
dB.prototype.b = function(a) {
  return cB(a, this);
};
var cB = function(a, b) {
  var c = {j8:R(b, 1), YB:R(b, 2)};
  a && (c.f = b);
  return c;
};
d = dB.prototype;
d.Eo = function() {
  return R(this, 1);
};
d.LN = function(a) {
  T(this, 1, a);
};
d.ij = function() {
  return R(this, 2);
};
d.aq = function(a) {
  T(this, 2, a || []);
};
d.tn = function(a, b) {
  hr(this, 2, a, b);
};
var aB = function(a) {
  P(this, a, 0, -1, null, null);
};
w(aB, O);
aB.prototype.b = function(a) {
  return ZA(a, this);
};
var ZA = function(a, b) {
  var c = {muted:R(b, 1)};
  a && (c.f = b);
  return c;
};
aB.prototype.wo = function() {
  return R(this, 1);
};
aB.prototype.wu = function(a) {
  T(this, 1, a);
};
var fB = function(a) {
  P(this, a, 0, -1, null, null);
};
w(fB, O);
d = fB.prototype;
d.b = function(a) {
  var b, c = {ob:(b = this.X()) && Iw(a, b), direction:R(this, 2), sessionId:R(this, 3), pO:R(this, 4), $:R(this, 5)};
  a && (c.f = this);
  return c;
};
d.X = function() {
  return U(this, Hw, 1);
};
d.setRequestHeader = function(a) {
  W(this, 1, a);
};
d.jc = function() {
  return R(this, 2);
};
d.oe = function(a) {
  T(this, 2, a);
};
d.s = function() {
  return R(this, 3);
};
d.Ca = function(a) {
  T(this, 3, a);
};
d.Vb = function() {
  return R(this, 4);
};
d.lk = function(a) {
  T(this, 4, a);
};
d.O = function() {
  return R(this, 5);
};
d.L = function(a) {
  T(this, 5, a);
};
var gB = function(a) {
  P(this, a, 0, -1, null, null);
};
w(gB, O);
gB.prototype.b = function(a) {
  return hB(a, this);
};
var hB = function(a, b) {
  var c, e = {ob:(c = b.X()) && Iw(a, c), direction:R(b, 2), sessionId:R(b, 3), $:R(b, 4), J:(c = b.h()) && Z(a, c)};
  a && (e.f = b);
  return e;
};
d = gB.prototype;
d.X = function() {
  return U(this, Hw, 1);
};
d.setRequestHeader = function(a) {
  W(this, 1, a);
};
d.jc = function() {
  return R(this, 2);
};
d.oe = function(a) {
  T(this, 2, a);
};
d.s = function() {
  return R(this, 3);
};
d.Ca = function(a) {
  T(this, 3, a);
};
d.O = function() {
  return R(this, 4);
};
d.L = function(a) {
  T(this, 4, a);
};
d.h = function() {
  return U(this, Y, 5);
};
d.j = function(a) {
  W(this, 5, a);
};
d.G = function() {
  this.j(void 0);
};
var jB = function(a) {
  P(this, a, 0, -1, iB, null);
};
w(jB, O);
var iB = [2, 3];
jB.prototype.b = function(a) {
  return kB(a, this);
};
var kB = function(a, b) {
  var c, e = {J:(c = b.h()) && Hu(a, c), zd:Q(b.Na(), Hx, a), jf:Q(b.Ab(), fu, a), Ne:(c = b.Nb()) && fu(a, c)};
  a && (e.f = b);
  return e;
};
d = jB.prototype;
d.h = function() {
  return U(this, Gu, 1);
};
d.j = function(a) {
  W(this, 1, a);
};
d.G = function() {
  this.j(void 0);
};
d.Na = function() {
  return V(this, Gx, 2);
};
d.Ab = function() {
  return V(this, eu, 3);
};
d.Nb = function() {
  return U(this, eu, 4);
};
var mB = function(a) {
  P(this, a, 0, -1, lB, null);
};
w(mB, O);
var lB = [2];
mB.prototype.b = function(a) {
  return nB(a, this);
};
var nB = function(a, b) {
  var c, e = {J:(c = b.h()) && Hu(a, c), zd:Q(b.Na(), Mx, a), Ne:S(b, 3, "")};
  a && (e.f = b);
  return e;
};
d = mB.prototype;
d.h = function() {
  return U(this, Gu, 1);
};
d.j = function(a) {
  W(this, 1, a);
};
d.G = function() {
  this.j(void 0);
};
d.Na = function() {
  return V(this, Lx, 2);
};
d.Nb = function() {
  return S(this, 3, "");
};
var pB = function(a) {
  P(this, a, 0, -1, oB, null);
};
w(pB, O);
var oB = [2, 3];
pB.prototype.b = function(a) {
  return qB(a, this);
};
var qB = function(a, b) {
  var c, e = {J:(c = b.h()) && Hu(a, c), zd:Q(b.Na(), Rx, a), jf:R(b, 3), Ne:S(b, 4, "")};
  a && (e.f = b);
  return e;
};
d = pB.prototype;
d.h = function() {
  return U(this, Gu, 1);
};
d.j = function(a) {
  W(this, 1, a);
};
d.G = function() {
  this.j(void 0);
};
d.Na = function() {
  return V(this, Qx, 2);
};
d.Ab = function() {
  return R(this, 3);
};
d.Nb = function() {
  return S(this, 4, "");
};
var rB = function(a, b, c, e, f, g, k) {
  my.call(this, a, b, c, e, f, g, k);
  this.xO = f;
  this.Za = -1;
  this.sj = !1;
  this.at = -1;
  this.dc = [];
  this.gu = this.Yr = this.Tu = this.ct = null;
  this.Uo = !1;
  this.zJ = 0;
  this.rq = null;
  this.Xg = new Yp(this.config.CZ(), this.config.d_());
  this.ID = new gv(this.JD, 0, this);
};
w(rB, my);
d = rB.prototype;
d.start = function(a) {
  rB.T.start.call(this, a);
  if ("Ta" != this.state) {
    return null;
  }
  this.Jc.listen(this.up, "w", this.oK);
  this.RA(!0);
  K(this.m, "Starting initial resync.");
  return this.Qm("hb", !0);
};
d.Ku = function() {
  rB.T.Ku.call(this);
  this.Jc.Fc(this.up, "w", this.oK);
  je(this.gu);
  this.gu = null;
  this.Xg.reset();
  je(this.Tu);
  this.Tu = null;
  je(this.Yr);
  this.rq = this.Yr = null;
  this.sj = !1;
};
d.query = function(a, b) {
  return this.Zl("Za", this.qh(a), null, null, b);
};
d.search = function(a) {
  return this.Zl("$a", this.rh(), null, null, a);
};
d.fC = function(a) {
  "gb" != a && 0 == this.Xg.On && this.up.r7();
  L(this.m, "Starting sync. Type: " + a);
  var b = "ib" == a || "jb" == a, c = this.rh(), e = -2;
  this.config.$Z() && (9E4 > v() - this.zJ ? (e = this.Za, c.$N(e)) : this.zJ = v());
  c = this.Zl("$a", c, function(b) {
    return e != b.bn ? new sB(b.bn, b.data, a) : null;
  }, null);
  c.then(u(this.C4, this, b)).jb(u(this.B4, this, b));
  this.ct = c;
  this.ct.jb(n);
  return c;
};
d.Rl = function(a) {
  return 0 <= a;
};
d.rh = function() {
  return this.xO.rh(this.ls());
};
d.qh = function(a) {
  return this.xO.qh(this.vr(a));
};
d.oK = function() {
  this.Qm("gb", !0);
};
d.Rb = function() {
  return null != this.Qm("kb", !0) || this.ct ? x(this.ct) : Yd("Collection not yet started, so cannot resync.");
};
d.tA = function(a) {
  this.y1(a) ? this.Rb() : rB.T.tA.call(this, a);
};
d.fI = function(a) {
  var b;
  ua(a.notification.h) && null != a.notification.h() && (b = a.notification.h().zf());
  x(null != b, "Received notification without a server version");
  return b;
};
d.y1 = function(a) {
  var b = !1;
  a = a.notification.Nb();
  null != a && "" != a && (b = this.sr(a), b = this.tc(b), b = this.gw(b));
  return b;
};
d.uA = function(a) {
  L(this.m, "Begin processing update: " + a);
  var b = a.Oa == this.at;
  this.J6(a.Oa);
  this.RA(!1);
  if (a instanceof sB) {
    this.PR(a);
  } else {
    this.m2(a.vq, a.wq);
    if (this.Rl(this.Za) && a.Oa <= this.Za) {
      "Pa" == a.ZO && this.ga("h");
      var c = !1;
      b && (this.ga("i"), c = !0);
      this.fJ(a.Oa) && (this.ga("j"), c = !0);
      c && this.Qm("lb", !0);
      this.ga("g");
      L(this.m, "Ignoring update " + a + " below or equal to local version (" + this.Za + ")");
      return;
    }
    b = mb(this.dc, function(b) {
      return b.Oa <= a.Oa;
    }, this);
    if (null != b && a.Oa == b.Oa) {
      this.ga("g");
      J(this.m, "Duplicate update received, ignoring it.");
      return;
    }
    L(this.m, "Queuing partial update: " + a);
    sb(this.dc, a, b);
  }
  a instanceof sB ? this.JD() : this.ID.bo();
  L(this.m, "Finish processing update: " + a + ": " + this.qf());
};
d.m2 = function(a, b) {
  this.Rl(this.Za) || (L(this.m, "Dispatch early notification: "), this.dispatchEvent(new tB(a, b)));
};
d.Qm = function(a, b) {
  if (!this.Cf() || this.Uo) {
    return null;
  }
  this.Xg.reset();
  var c = null;
  this.Uo = !0;
  b ? c = this.fC(a) : this.ZB();
  return c;
};
d.gx = function() {
  this.Uo && (K(this.m, "Ending resync"), this.Uo = !1, this.dispatchEvent("T"));
};
d.ZB = function() {
  var a = this.Xg.vc();
  this.ga("m");
  K(this.m, "Scheduling resync timer, backoff count: " + this.Xg.On + ", backoff: " + a);
  this.gu = ie(this.t4, a, this);
};
d.t4 = function() {
  K(this.m, "Resync timer triggered, " + this.qf());
  this.gu = null;
  this.Cf() ? (this.ga("n"), this.fC("lb")) : this.gx();
};
d.C4 = function(a) {
  K(this.m, (a ? "Poll" : "Resync") + " operation executed, " + this.qf());
  this.AL(!1);
  if (this.sj || !this.Cf()) {
    this.gx();
  } else {
    a = !1;
    var b = this.config.BZ();
    this.Xg.On >= b ? (this.ga("l"), K(this.m, "Hard sync threshold reached (" + b + "), doing a hard resync"), a = !0) : this.dc.length > this.config.cI() && (this.ga("k"), L(this.m, "Number of queued updates is larger than the max (" + this.config.cI() + "), clearing the queue"), a = !0);
    a ? (qb(this.dc), this.Xg.reset(), this.fC("mb")) : (this.Xg.ar(), this.ZB());
  }
};
d.B4 = function(a, b) {
  var c = (a ? "Poll" : "Resync") + " error: " + b;
  Bf(this.m, c, b instanceof Error ? b : Error(c));
  this.ga(a ? "y" : "o");
  this.AL(!0);
  this.Cf() ? (this.Xg.ar(), this.ZB()) : this.gx();
};
d.qf = function() {
  return rB.T.qf.call(this) + ", is synced: " + this.sj + ", is resyncing: " + this.Uo + ", queue size: " + this.dc.length + ", highest observed server version: " + this.at + (0 < this.dc.length ? ", smallest queued version: " + eb(this.dc).Oa + ", largest queued version: " + this.dc[0].Oa : "");
};
d.JD = function() {
  this.ID.stop();
  if (0 != this.dc.length && this.Rl(this.Za)) {
    L(this.m, "Trying to apply any queued updates, " + this.qf());
    for (var a = 0;0 < this.dc.length && eb(this.dc).Oa <= this.Za;) {
      var b = this.dc.pop();
      L(this.m, "Tossing queued update " + b + " below or equal to local version (" + this.Za + ")");
      a++;
    }
    0 < a && L(this.m, "Tossed " + a + " queued old updates below or equal to local version (" + this.Za + ")");
    for (a = 0;0 < this.dc.length;) {
      if (b = eb(this.dc), b.Oa == this.Za) {
        this.dc.pop(), a++;
      } else {
        if (b.Oa == this.Za + 1) {
          this.Za = b.Oa, this.aw(b), this.dc.pop(), a++;
        } else {
          L(this.m, "Unable to incrementally apply next queued update,  lowest queue update version: " + b.Oa + ", local version:" + this.Za + ", remaining queue length: " + this.dc.length);
          break;
        }
      }
    }
    L(this.m, "Applied " + a + " queued updates");
  }
  (this.sj = 0 == this.dc.length && this.Rl(this.Za)) ? this.PJ() : this.Qm("lb", !1);
};
d.TK = function(a) {
  this.Cf() && (this.ga("p"), K(this.m, "Executing poll sync operation"), this.Qm(a, !0), this.RA(!0));
};
d.RA = function(a) {
  if (this.Cf()) {
    K(this.m, "Scheduling next poll for " + this.config.YH() / 1000 + " seconds from now");
    je(this.Tu);
    this.Tu = ie(Aa(this.TK, "ib"), this.config.YH(), this);
    var b = this.config.mX();
    null != b || (b = 90000);
    a && 0 < b && (je(this.Yr), this.Yr = ie(Aa(this.TK, "jb"), b, this));
  }
};
d.AL = function(a) {
  if (a) {
    if (null != this.rq) {
      a = v() - this.rq;
      var b = "Sync operations failing for a period of " + a / 1000 + " seconds (limit configured to: " + this.config.qy() / 1000 + " seconds).";
      J(this.m, b);
      a >= this.config.qy() && this.rx(22, b);
    } else {
      this.rq = v(), J(this.m, "Sync operation failed, we will continue retrying for up to " + this.config.qy() / 1000 + " seconds before shutting down...");
    }
  } else {
    this.rq = null;
  }
};
d.PR = function(a) {
  L(this.m, "Processing full update: " + a);
  Af(this.m, tf, "Snapshot: [" + a.data.join("|") + "]");
  if (this.Za >= a.Oa && 100 > this.Za - a.Oa) {
    var b = [];
    this.Za == a.Oa && (y(a.data, function(a) {
      var c = mb(this.data, function(b) {
        return this.tc(a).equals(this.tc(b));
      }, this);
      uB(c, a) || b.push({local:c && c.cb(), server:a.cb()});
    }, this), y(this.data, function(c) {
      null != mb(a.data, function(a) {
        return this.tc(c).equals(this.tc(a));
      }, this) || b.push({local:c.cb(), server:null});
    }, this));
    if (0 != b.length) {
      J(this.m, "Reapplying update with version that's the same, update: " + a.Oa + ", local: " + this.Za + ", type: " + a.sq), this.ga("x", b);
    } else {
      this.ga("u");
      switch(a.sq) {
        case "lb":
          this.ga("v");
          break;
        case "ib":
          this.ga("w");
      }
      L(this.m, "Ignoring update with version not newer than local version, update: " + a.Oa + ", local: " + this.Za + ", type: " + a.sq);
      return;
    }
  }
  this.Za > a.Oa && this.fJ(a.Oa) && this.ga("j", "" + (this.Za - a.Oa));
  this.ga("q");
  switch(a.sq) {
    case "ib":
      this.ga("s");
      break;
    case "lb":
      this.ga("r");
      break;
    case "mb":
      this.ga("t");
  }
  var c = ib(a.data, function(a) {
    if (this.Ws(a)) {
      return !0;
    }
    this.ga("z", "Full update: " + a.cb());
    return !1;
  }, this), e = [];
  y(this.data, function(a) {
    mb(c, function(b) {
      return this.tc(a).equals(this.tc(b));
    }, this) || e.push(this.tc(a));
  }, this);
  L(this.m, "Applying full update as partial and advancing version from " + this.Za + " to " + a.Oa);
  this.Za = a.Oa;
  this.aw(new oy(a.Oa, c, e, "Ra"));
};
d.fJ = function(a) {
  return 100 < this.Za - a;
};
d.J6 = function(a) {
  this.at = Math.max(this.at, a);
};
var uB = function(a, b) {
  return a == b || a instanceof b.constructor && vB(JSON.parse(a.cb()), JSON.parse(b.cb()));
}, vB = function(a, b) {
  var c = sa(a), e = sa(b);
  if (c && e) {
    var c = {}, f;
    for (f in a) {
      a.hasOwnProperty(f) && (c[f] = 0);
    }
    for (f in b) {
      b.hasOwnProperty(f) && (c[f] = 0);
    }
    for (f in c) {
      if (!vB(a[f], b[f])) {
        return !1;
      }
    }
    return !0;
  }
  return a == b || null == a && e && 0 == b.length || null == b && c && 0 == a.length;
}, sB = function(a, b, c) {
  vy.call(this, a);
  this.data = b;
  this.sq = c;
};
w(sB, vy);
sB.prototype.toString = function() {
  return "[Full update id: " + this.id + ", version: " + this.Oa + ", resource count: " + this.data.length + ", sync type: " + this.sq + "]";
};
var tB = function(a, b) {
  F.call(this, "R");
  this.yb = a;
  this.removed = b;
};
w(tB, F);
var wB = function(a, b, c) {
  av.call(this, a, c, "Na");
  this.C = b;
  this.Ia = new tk(this);
  this.la(this.Ia);
  this.Ia.listen(this.ir, "W", function(a) {
    this.A4(a.Kba);
  });
};
w(wB, av);
wB.prototype.s = function() {
  return this.C;
};
wB.prototype.A4 = function(a) {
  null == a || Ga(a) || this.dispatchEvent(new xB(this.C, a));
};
var xB = function(a, b) {
  F.call(this, "X");
  this.sessionId = a;
  this.url = b;
};
w(xB, F);
var zB = function(a) {
  P(this, a, "hc:cc", -1, yB, null);
};
w(zB, O);
var yB = [14, 15];
zB.prototype.b = function(a) {
  var b, c = {clientId:R(this, 1), j6:R(this, 2), appName:R(this, 3), appVersion:R(this, 4), X7:R(this, 5), nT:R(this, 6), wta:R(this, 7), V5:R(this, 8), Fka:fr(this, 9), Eka:R(this, 10), Gka:R(this, 11), Wsa:R(this, 12), bka:(b = this.Ex()) && Ou(a, b), Jla:R(this, 14), ama:R(this, 15), Y7:R(this, 16), tqa:(b = this.uH()) && Xx(a, b), gla:R(this, 18), Uka:(b = this.IG()) && AB(a, b)};
  a && (c.f = this);
  return c;
};
sr("hc:cc", zB);
d = zB.prototype;
d.rc = function() {
  return R(this, 1);
};
d.Pe = function(a) {
  T(this, 1, a);
};
d.xg = function() {
  return R(this, 2);
};
d.setProperty = function(a) {
  T(this, 2, a);
};
d.eG = function() {
  return R(this, 3);
};
d.BM = function(a) {
  T(this, 3, a);
};
d.OV = function() {
  return R(this, 4);
};
d.CM = function(a) {
  T(this, 4, a);
};
d.wf = function() {
  return R(this, 5);
};
d.yu = function(a) {
  T(this, 5, a);
};
d.Ic = function() {
  return R(this, 6);
};
d.zm = function(a) {
  T(this, 6, a);
};
d.Fs = function() {
  return R(this, 7);
};
d.Raa = function(a) {
  T(this, 7, a);
};
d.dj = function() {
  return R(this, 8);
};
d.Xp = function(a) {
  T(this, 8, a);
};
d.EG = function() {
  return fr(this, 9);
};
d.OM = function(a) {
  T(this, 9, a);
};
d.DG = function() {
  return R(this, 10);
};
d.NM = function(a) {
  T(this, 10, a);
};
d.FG = function() {
  return R(this, 11);
};
d.PM = function(a) {
  T(this, 11, a);
};
d.ZH = function() {
  return R(this, 12);
};
d.Jaa = function(a) {
  T(this, 12, a);
};
d.Ex = function() {
  return U(this, Nu, 13);
};
d.f9 = function(a) {
  W(this, 13, a);
};
d.Kx = function() {
  return R(this, 14);
};
d.C9 = function(a) {
  T(this, 14, a || []);
};
d.El = function() {
  return R(this, 16);
};
d.zu = function(a) {
  T(this, 16, a);
};
d.uH = function() {
  return U(this, Wx, 17);
};
d.P$ = function(a) {
  W(this, 17, a);
};
d.ms = function() {
  return R(this, 18);
};
d.s9 = function(a) {
  T(this, 18, a);
};
d.IG = function() {
  return U(this, BB, 19);
};
var BB = function(a) {
  P(this, a, 0, -1, null, null);
};
w(BB, O);
BB.prototype.b = function(a) {
  return AB(a, this);
};
var AB = function(a, b) {
  var c = {ioa:S(b, 1, 60000), hoa:S(b, 2, 1), pja:S(b, 3, 0)};
  a && (c.f = b);
  return c;
};
BB.prototype.eY = function() {
  return S(this, 1, 60000);
};
BB.prototype.dY = function() {
  return S(this, 2, 1);
};
BB.prototype.qG = function() {
  return S(this, 3, 0);
};
var CB = function() {
  this.pp = this.op = this.tq = this.zt = this.Jf = null;
};
d = CB.prototype;
d.Gh = function() {
  return this.Jf;
};
d.Ug = function(a) {
  this.Jf = a;
  return this;
};
d.p$ = function(a) {
  this.zt = a;
  return this;
};
d.Cs = function() {
  return this.tq;
};
d.bq = function(a) {
  this.tq = a;
  return this;
};
d.uo = function() {
  return this.op;
};
d.Cm = function(a) {
  this.op = a;
  return this;
};
d.Al = function() {
  return this.pp;
};
d.jk = function(a) {
  this.pp = a;
  return this;
};
d.OR = function(a) {
  if (this.zt) {
    var b = a.pG() || new Cy;
    b.I$(this.zt);
    a.lB(b);
  }
  this.HD(a);
};
d.HD = function(a) {
  this.Jf && a.Ug(this.Jf);
  this.tq && a.bq(this.tq);
  this.op && a.Cm(this.op);
  this.pp && a.jk(this.pp);
};
d.toString = function() {
  return "{ ParticipantLogId: " + (this.Jf || "") + ", MucJid: " + (this.zt || "") + ", SyntheticId: " + (this.tq || "") + ", MeetingCode: " + (this.op || "") + ", MeetingSpaceId: " + (this.pp || "") + " }";
};
var DB = function(a, b, c, e, f, g) {
  zy.call(this, a, b, c, e, f);
  this.In = g || new Ay;
};
w(DB, zy);
d = DB.prototype;
d.LT = function() {
  return new zy(this.ks(), this.yn, this.zn, this.Od, this.Sg);
};
d.Xl = function(a, b, c, e, f) {
  f || this.LI(b);
  return DB.T.Xl.call(this, a, b, c, e).then(this.v5, null, this);
};
d.LI = function(a) {
  if (a && this.In.wI() && ua(a.h) && ua(a.j)) {
    var b = db(a.h() || new Y, Y);
    b.uB(this.In.Ni);
    a.j(b);
  }
};
d.v5 = function(a) {
  ua(a.getResponseHeader) && 1 == x(a.getResponseHeader()).Ra() && this.rC(a);
  return a;
};
d.rC = function(a) {
  (a = this.gV(a)) && this.In.wca(a);
};
d.gV = function(a) {
  return (a = ua(a.h) && a.h() || null) && a.os();
};
d.os = function() {
  return this.In.Ni;
};
d.yE = function() {
  this.In.xE();
};
d.sendBeacon = function(a, b) {
  var c;
  c = this.Sg;
  a = "/" + this.yn + "/" + this.zn + "/" + a;
  if (0 <= c.indexOf("#") || 0 <= c.indexOf("?")) {
    throw Error("goog.uri.utils: Fragment or query identifiers are not supported: [" + c + "]");
  }
  var e = c.length - 1;
  0 <= e && c.indexOf("/", e) == e && (c = c.substr(0, c.length - 1));
  Da(a, "/") && (a = a.substr(1));
  c = Qa(c, "/", a);
  this.Od && (c = Nc(c, "key", this.Od));
  this.LI(b);
  b = b.cb();
  c = Nc(c, encodeURIComponent("$ct"), "application/json+protobuf");
  if (null == navigator.sendBeacon || !navigator.sendBeacon(c, b)) {
    a = c;
    var e = "POST", f = b;
    c = Nc(c, encodeURIComponent("$httpMethod"), "POST");
    c = Nc(c, encodeURIComponent("$req"), b);
    2048 > c.length && (a = c, e = "GET", f = null);
    try {
      var g = Df.Jn();
      g.open(e, a, !1);
      g.send(f);
    } catch (k) {
      g = zf("realtime.network.Beacon"), Bf(g, "Cannot fallback from sendBeacon", k);
    }
  }
};
zf("goog.debug.ErrorReporter");
var FB = function(a) {
  P(this, a, 0, -1, EB, null);
};
w(FB, O);
var EB = [1];
FB.prototype.b = function(a) {
  return GB(a, this);
};
var GB = function(a, b) {
  var c, e = {Bpa:Q(b.JY(), HB, a), reason:R(b, 15), Jra:R(b, 16), networkType:R(b, 17), jba:(c = b.my()) && $y(a, c)};
  a && (e.f = b);
  return e;
};
FB.prototype.JY = function() {
  return V(this, IB, 1);
};
FB.prototype.my = function() {
  return U(this, az, 18);
};
var IB = function(a) {
  P(this, a, 0, -1, JB, null);
};
w(IB, O);
var JB = [8, 9, 10, 11, 12, 13];
IB.prototype.b = function(a) {
  return HB(a, this);
};
var HB = function(a, b) {
  var c = {Yna:R(b, 1), Ola:R(b, 2), Oqa:R(b, 3), Esa:R(b, 4), Poa:R(b, 5), Pqa:R(b, 6), Nqa:R(b, 7), Csa:Q(b.YZ(), KB, a), cna:Q(b.HX(), KB, a), dna:Q(b.IX(), KB, a), lta:Q(b.j_(), KB, a), Usa:Q(b.f_(), KB, a), osa:Q(b.SZ(), KB, a)};
  a && (c.f = b);
  return c;
};
d = IB.prototype;
d.YZ = function() {
  return V(this, LB, 8);
};
d.HX = function() {
  return V(this, LB, 9);
};
d.IX = function() {
  return V(this, LB, 10);
};
d.j_ = function() {
  return V(this, LB, 11);
};
d.f_ = function() {
  return V(this, LB, 12);
};
d.SZ = function() {
  return V(this, LB, 13);
};
var LB = function(a) {
  P(this, a, 0, -1, null, null);
};
w(LB, O);
LB.prototype.b = function(a) {
  return KB(a, this);
};
var KB = function(a, b) {
  var c = {eM:R(b, 1), error:R(b, 2)};
  a && (c.f = b);
  return c;
};
LB.prototype.$p = function(a) {
  T(this, 1, a);
};
LB.prototype.getError = function() {
  return R(this, 2);
};
var MB = function(a) {
  P(this, a, 0, -1, null, null);
};
w(MB, O);
MB.prototype.b = function(a) {
  return NB(a, this);
};
var NB = function(a, b) {
  var c, e = {ob:(c = b.X()) && Iw(a, c), invitation:(c = b.$i()) && gA(a, c), J:(c = b.h()) && Z(a, c)};
  a && (e.f = b);
  return e;
};
d = MB.prototype;
d.X = function() {
  return U(this, Hw, 1);
};
d.setRequestHeader = function(a) {
  W(this, 1, a);
};
d.$i = function() {
  return U(this, fA, 2);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
var OB = function(a) {
  P(this, a, "chpara", -1, null, null);
};
w(OB, O);
OB.prototype.b = function(a) {
  return PB(a, this);
};
var PB = function(a, b) {
  var c, e = {Ka:(c = b.getResponseHeader()) && Kw(a, c), invitation:(c = b.$i()) && gA(a, c), J:(c = b.h()) && Z(a, c)};
  a && (e.f = b);
  return e;
};
sr("chpara", OB);
d = OB.prototype;
d.getResponseHeader = function() {
  return U(this, Jw, 1);
};
d.$i = function() {
  return U(this, fA, 2);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
var QB = function(a) {
  P(this, a, 0, -1, null, null);
};
w(QB, O);
QB.prototype.b = function(a) {
  return RB(a, this);
};
var RB = function(a, b) {
  var c, e = {ob:(c = b.X()) && Iw(a, c), invitation:(c = b.$i()) && Ez(a, c), J:(c = b.h()) && Z(a, c)};
  a && (e.f = b);
  return e;
};
d = QB.prototype;
d.X = function() {
  return U(this, Hw, 1);
};
d.setRequestHeader = function(a) {
  W(this, 1, a);
};
d.$i = function() {
  return U(this, Dz, 2);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
var SB = function(a) {
  P(this, a, "chiarp", -1, null, null);
};
w(SB, O);
SB.prototype.b = function(a) {
  return TB(a, this);
};
var TB = function(a, b) {
  var c, e = {Ka:(c = b.getResponseHeader()) && Kw(a, c), invitation:(c = b.$i()) && Ez(a, c), errorCode:R(b, 3), J:(c = b.h()) && Z(a, c)};
  a && (e.f = b);
  return e;
};
sr("chiarp", SB);
d = SB.prototype;
d.getResponseHeader = function() {
  return U(this, Jw, 1);
};
d.$i = function() {
  return U(this, Dz, 2);
};
d.Jx = function() {
  return R(this, 3);
};
d.h = function() {
  return U(this, Y, 4);
};
d.j = function(a) {
  W(this, 4, a);
};
d.G = function() {
  this.j(void 0);
};
var VB = function(a) {
  P(this, a, 0, -1, UB, null);
};
w(VB, O);
var UB = [3, 4, 5, 6];
VB.prototype.b = function(a) {
  return WB(a, this);
};
var WB = function(a, b) {
  var c, e = {mediaType:S(b, 1, 4), transport:(c = b.kc()) && yx(a, c), aka:Q(b.xG(), wt, a), wka:Q(b.CG(), At, a), Ira:Q(b.JH(), Et, a), Kka:Q(b.GG(), xA, a), yoa:(c = b.hY()) && tt(a, c), Pra:R(b, 8)};
  a && (e.f = b);
  return e;
};
d = VB.prototype;
d.P = function() {
  return S(this, 1, 4);
};
d.oc = function(a) {
  T(this, 1, a);
};
d.dg = function() {
  T(this, 1, void 0);
};
d.kc = function() {
  return U(this, xx, 2);
};
d.XN = function(a) {
  W(this, 2, a);
};
d.xG = function() {
  return V(this, vt, 3);
};
d.d9 = function(a) {
  X(this, 3, a);
};
d.CG = function() {
  return V(this, zt, 4);
};
d.KM = function(a) {
  X(this, 4, a);
};
d.JH = function() {
  return V(this, Dt, 5);
};
d.iaa = function(a) {
  X(this, 5, a);
};
d.GG = function() {
  return V(this, wA, 6);
};
d.o9 = function(a) {
  X(this, 6, a);
};
d.hY = function() {
  return U(this, st, 7);
};
d.iN = function(a) {
  W(this, 7, a);
};
d.IZ = function() {
  return R(this, 8);
};
d.maa = function(a) {
  T(this, 8, a);
};
var YB = function(a) {
  P(this, a, 0, -1, XB, null);
};
w(YB, O);
var XB = [4];
YB.prototype.b = function(a) {
  return ZB(a, this);
};
var ZB = function(a, b) {
  var c, e = {ob:(c = b.X()) && Iw(a, c), stream:(c = b.ib()) && XA(a, c), J:(c = b.h()) && Z(a, c), qb:Q(b.M(), XA, a)};
  a && (e.f = b);
  return e;
};
d = YB.prototype;
d.X = function() {
  return U(this, Hw, 1);
};
d.setRequestHeader = function(a) {
  W(this, 1, a);
};
d.ib = function() {
  return U(this, WA, 2);
};
d.kk = function(a) {
  W(this, 2, a);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
d.M = function() {
  return V(this, WA, 4);
};
d.ra = function(a) {
  X(this, 4, a);
};
var aC = function(a) {
  P(this, a, "chstarp", -1, $B, null);
};
w(aC, O);
var $B = [4];
aC.prototype.b = function(a) {
  return bC(a, this);
};
var bC = function(a, b) {
  var c, e = {Ka:(c = b.getResponseHeader()) && Kw(a, c), stream:(c = b.ib()) && XA(a, c), J:(c = b.h()) && Z(a, c), qb:Q(b.M(), XA, a)};
  a && (e.f = b);
  return e;
};
sr("chstarp", aC);
d = aC.prototype;
d.getResponseHeader = function() {
  return U(this, Jw, 1);
};
d.ib = function() {
  return U(this, WA, 2);
};
d.kk = function(a) {
  W(this, 2, a);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
d.M = function() {
  return V(this, WA, 4);
};
d.ra = function(a) {
  X(this, 4, a);
};
var dC = function(a) {
  P(this, a, 0, -1, cC, null);
};
w(dC, O);
var cC = [4];
d = dC.prototype;
d.b = function(a) {
  var b, c = {ob:(b = this.X()) && Iw(a, b), stream:(b = this.ib()) && XA(a, b), J:(b = this.h()) && Z(a, b), qb:Q(this.M(), XA, a)};
  a && (c.f = this);
  return c;
};
d.X = function() {
  return U(this, Hw, 1);
};
d.setRequestHeader = function(a) {
  W(this, 1, a);
};
d.ib = function() {
  return U(this, WA, 2);
};
d.kk = function(a) {
  W(this, 2, a);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
d.M = function() {
  return V(this, WA, 4);
};
d.ra = function(a) {
  X(this, 4, a);
};
var fC = function(a) {
  P(this, a, "chstmrp", -1, eC, null);
};
w(fC, O);
var eC = [4];
fC.prototype.b = function(a) {
  var b, c = {Ka:(b = this.getResponseHeader()) && Kw(a, b), stream:(b = this.ib()) && XA(a, b), J:(b = this.h()) && Z(a, b), qb:Q(this.M(), XA, a)};
  a && (c.f = this);
  return c;
};
sr("chstmrp", fC);
d = fC.prototype;
d.getResponseHeader = function() {
  return U(this, Jw, 1);
};
d.ib = function() {
  return U(this, WA, 2);
};
d.kk = function(a) {
  W(this, 2, a);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
d.M = function() {
  return V(this, WA, 4);
};
d.ra = function(a) {
  X(this, 4, a);
};
var gC = function(a) {
  P(this, a, "chstqrp", -1, null, null);
};
w(gC, O);
gC.prototype.b = function(a) {
  var b, c = {Ka:(b = this.getResponseHeader()) && Kw(a, b), stream:(b = this.ib()) && XA(a, b)};
  a && (c.f = this);
  return c;
};
sr("chstqrp", gC);
gC.prototype.getResponseHeader = function() {
  return U(this, Jw, 1);
};
gC.prototype.ib = function() {
  return U(this, WA, 2);
};
gC.prototype.kk = function(a) {
  W(this, 2, a);
};
var iC = function(a) {
  P(this, a, "chstsrp", -1, hC, null);
};
w(iC, O);
var hC = [2];
iC.prototype.b = function(a) {
  return jC(a, this);
};
var jC = function(a, b) {
  var c, e = {Ka:(c = b.getResponseHeader()) && Kw(a, c), P7:Q(b.Do(), XA, a), J:(c = b.h()) && Z(a, c)};
  a && (e.f = b);
  return e;
};
sr("chstsrp", iC);
d = iC.prototype;
d.getResponseHeader = function() {
  return U(this, Jw, 1);
};
d.Do = function() {
  return V(this, WA, 2);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
var lC = function(a) {
  P(this, a, 0, -1, kC, null);
};
w(lC, O);
var kC = [2, 3];
lC.prototype.b = function(a) {
  return mC(a, this);
};
var mC = function(a, b) {
  var c, e = {J:(c = b.h()) && Z(a, c), zd:Q(b.Na(), XA, a), jf:Q(b.Ab(), Kt, a), Ne:(c = b.Nb()) && Kt(a, c)};
  a && (e.f = b);
  return e;
};
d = lC.prototype;
d.h = function() {
  return U(this, Y, 1);
};
d.j = function(a) {
  W(this, 1, a);
};
d.G = function() {
  this.j(void 0);
};
d.Na = function() {
  return V(this, WA, 2);
};
d.Ab = function() {
  return V(this, Jt, 3);
};
d.Nb = function() {
  return U(this, Jt, 4);
};
var oC = function(a) {
  P(this, a, 0, -1, nC, null);
};
w(oC, O);
var nC = [11];
oC.prototype.b = function(a) {
  return pC(a, this);
};
var pC = function(a, b) {
  var c, e = {clientId:R(b, 1), $:R(b, 2), Oj:R(b, 14), Vna:R(b, 21), za:R(b, 3), oja:(c = b.pG()) && Dy(a, c), rja:(c = b.kW()) && qv(a, c), hka:(c = b.BW()) && GB(a, c), bma:(c = b.lX()) && uv(a, c), Qsa:(c = b.e_()) && Kv(a, c), qja:(c = b.iW()) && ez(a, c), xqa:(c = b.YY()) && Cv(a, c), Cma:(c = b.rX()) && yv(a, c), aja:R(b, 11), V5:R(b, 12), coa:R(b, 9), boa:R(b, 13), Rba:R(b, 16), Y7:R(b, 18), Uja:R(b, 19), Vja:R(b, 20), ZJ:R(b, 22), vz:R(b, 23)};
  a && (e.f = b);
  return e;
};
d = oC.prototype;
d.rc = function() {
  return R(this, 1);
};
d.Pe = function(a) {
  T(this, 1, a);
};
d.O = function() {
  return R(this, 2);
};
d.L = function(a) {
  T(this, 2, a);
};
d.Gh = function() {
  return R(this, 14);
};
d.Ug = function(a) {
  T(this, 14, a);
};
d.ia = function() {
  return R(this, 21);
};
d.A = function() {
  return R(this, 3);
};
d.Sa = function(a) {
  T(this, 3, a);
};
d.pG = function() {
  return U(this, Cy, 4);
};
d.lB = function(a) {
  W(this, 4, a);
};
d.kW = function() {
  return U(this, pv, 5);
};
d.BW = function() {
  return U(this, FB, 6);
};
d.lX = function() {
  return U(this, tv, 7);
};
d.e_ = function() {
  return U(this, Jv, 8);
};
d.iW = function() {
  return U(this, dz, 10);
};
d.YY = function() {
  return U(this, Bv, 17);
};
d.rX = function() {
  return U(this, xv, 15);
};
d.K9 = function(a) {
  W(this, 15, a);
};
d.kB = function(a) {
  T(this, 11, a || []);
};
d.dj = function() {
  return R(this, 12);
};
d.Xp = function(a) {
  T(this, 12, a);
};
d.f$ = function(a) {
  T(this, 9, a);
};
d.e$ = function(a) {
  T(this, 13, a);
};
d.Cs = function() {
  return R(this, 16);
};
d.bq = function(a) {
  T(this, 16, a);
};
d.El = function() {
  return R(this, 18);
};
d.zu = function(a) {
  T(this, 18, a);
};
d.uo = function() {
  return R(this, 22);
};
d.Cm = function(a) {
  T(this, 22, a);
};
d.Al = function() {
  return R(this, 23);
};
d.jk = function(a) {
  T(this, 23, a);
};
var qC = function(a) {
  P(this, a, 0, -1, null, null);
};
w(qC, O);
qC.prototype.b = function(a) {
  return rC(a, this);
};
var rC = function(a, b) {
  var c, e = {Yka:(c = b.JG()) && Kx(a, c), jsa:(c = b.RH()) && Ux(a, c), hra:(c = b.DH()) && qB(a, c), Zoa:(c = b.nH()) && nB(a, c), Uia:(c = b.bW()) && kB(a, c)};
  a && (e.f = b);
  return e;
};
d = qC.prototype;
d.JG = function() {
  return U(this, Jx, 1);
};
d.RH = function() {
  return U(this, Tx, 2);
};
d.DH = function() {
  return U(this, pB, 3);
};
d.nH = function() {
  return U(this, mB, 4);
};
d.bW = function() {
  return U(this, jB, 5);
};
var sC = function() {
};
sC.prototype.a = zf("fava.debug.DebugService");
sC.prototype.F1 = null;
var tC = new sC;
var uC = function() {
  return new lq(WA, [WA.prototype.O, WA.prototype.jc, WA.prototype.s], [WA.prototype.L, WA.prototype.oe, WA.prototype.Ca], [WA.prototype.Vb], [WA.prototype.lk], Jt, [Jt.prototype.O, Jt.prototype.jc, Jt.prototype.s], [Jt.prototype.L, Jt.prototype.oe, Jt.prototype.Ca], [Jt.prototype.Vb], [Jt.prototype.lk]);
};
var vC = function(a) {
  G.call(this);
  this.Gr = a;
  this.BC = this.Gr.qG();
  this.Sw = 0;
  this.lv = !1;
};
w(vC, G);
vC.prototype.I_ = function(a) {
  a = a.Eh();
  if (null != a) {
    for (var b = 0;b < a.length;++b) {
      if (0 == a[b].jc() && 2 == a[b].to() && (0 == a[b].Af() || 0 == a[b].tf())) {
        this.B7();
        return;
      }
    }
    for (b = 0;b < a.length;++b) {
      switch(a[b].jc()) {
        case 2:
          this.bT(a[b]);
      }
    }
  }
};
vC.prototype.B7 = function() {
  this.BC = this.Gr.qG();
};
vC.prototype.bT = function(a) {
  x(2 == a.jc());
  0 < this.BC ? --this.BC : a.YV() < this.Gr.eY() ? this.lv || (++this.Sw, this.Sw >= this.Gr.dY() && (this.dispatchEvent(new wC(0)), this.lv = !0)) : (this.lv && (this.dispatchEvent(new wC(1)), this.lv = !1), this.Sw = 0);
};
var wC = function(a) {
  F.call(this, "Z");
  this.id = a;
};
w(wC, F);
var xC = "https://clients2.google.com/cr/report", AC = function(a, b, c, e) {
  var f = new FormData;
  f.append("prod", kc ? "Google_Talk_Plugin_Mac" : lc ? "Google_Talk_Plugin" : "Google_Talk_Plugin_Linux");
  f.append("ver", "10.0.0.0-calls");
  f.append("email", b);
  f.append("type", "log");
  f.append("log", new Blob([a]), e);
  if (a = c) {
    try {
      a = !!navigator.sendBeacon && navigator.sendBeacon(xC, f);
    } catch (k) {
      yC(k, "Failed to upload callgrok log with sendBeacon"), a = !1;
    }
  }
  if (a) {
    return Cr(new zC(200, ""));
  }
  try {
    var g = new xr;
    Jf(xC, function(a) {
      a = a.target;
      a.$d() ? g.callback(new zC(a.Ra(), a.Dl())) : (a = Error(a.rm + " " + a.Ra() + " " + a.Dl()), g.Yc(a), yC(a, "Failed to upload callgrok log with XhrIo"));
    }, "POST", f);
    return g;
  } catch (k) {
    return yC(k, "Failed to upload callgrok log with XhrIo"), Dr(k);
  }
}, yC = function(a, b) {
  var c = tC.F1;
  c && c.Ura(a, b);
}, zC = function(a, b) {
  this.VL = a;
  this.responseText = b;
};
var CC = function(a) {
  P(this, a, 0, -1, BC, null);
};
w(CC, O);
var BC = [3, 4, 5, 6];
CC.prototype.b = function(a) {
  return DC(a, this);
};
var DC = function(a, b) {
  var c = {sessionId:R(b, 1), Oja:Q(b.sW(), WB, a), Zra:Q(b.LH(), WB, a), Rqa:Q(b.yH(), St, a), Ima:R(b, 6), type:R(b, 7)};
  a && (c.f = b);
  return c;
};
d = CC.prototype;
d.s = function() {
  return R(this, 1);
};
d.Ca = function(a) {
  T(this, 1, a);
};
d.sW = function() {
  return V(this, VB, 3);
};
d.nB = function(a) {
  X(this, 3, a);
};
d.LH = function() {
  return V(this, VB, 4);
};
d.yH = function() {
  return V(this, Rt, 5);
};
d.V$ = function(a) {
  X(this, 5, a);
};
d.ZM = function(a) {
  T(this, 6, a || []);
};
d.N = function() {
  return R(this, 7);
};
d.Rf = function(a) {
  T(this, 7, a);
};
var EC = function(a) {
  P(this, a, 0, -1, null, null);
};
w(EC, O);
d = EC.prototype;
d.b = function(a) {
  var b, c = {ob:(b = this.X()) && Iw(a, b), sessionId:R(this, 2), $na:(b = this.aY()) && pC(a, b), J:(b = this.h()) && Z(a, b)};
  a && (c.f = this);
  return c;
};
d.X = function() {
  return U(this, Hw, 1);
};
d.setRequestHeader = function(a) {
  W(this, 1, a);
};
d.s = function() {
  return R(this, 2);
};
d.Ca = function(a) {
  T(this, 2, a);
};
d.aY = function() {
  return U(this, oC, 3);
};
d.d$ = function(a) {
  W(this, 3, a);
};
d.h = function() {
  return U(this, Y, 4);
};
d.j = function(a) {
  W(this, 4, a);
};
d.G = function() {
  this.j(void 0);
};
var FC = function() {
  G.call(this);
  this.$ = this.b7 = null;
};
w(FC, G);
d = FC.prototype;
d.na = function() {
  return {hangoutId:this.$, isInProgress:"INPROGRESS" == this.getState(), remoteJid:this.b7, sessionId:this.s(), state:this.getState()};
};
d.Rb = n;
d.update = function() {
  return !0;
};
d.Rk = n;
d.gk = n;
d.oD = n;
d.L = function(a) {
  this.$ = a;
};
var GC = function(a, b) {
  F.call(this, "aa");
  this.Tj = a;
  this.Uj = b;
};
w(GC, F);
var HC = function(a) {
  F.call(this, "ca");
  this.En = a;
};
w(HC, F);
var IC = function(a) {
  F.call(this, "ba");
  this.message = a;
};
w(IC, F);
var JC = function(a) {
  F.call(this, "ea");
  this.te = a;
};
w(JC, F);
var KC = function(a, b) {
  F.call(this, "da");
  this.RU = a;
  this.hb = b;
};
w(KC, F);
var LC = function(a, b, c) {
  F.call(this, "$");
  this.za = a;
  this.label = b;
  this.payload = c;
};
w(LC, F);
var MC = function(a) {
  F.call(this, "ga");
  this.Vs = a;
};
w(MC, F);
var NC = function() {
  G.call(this);
};
w(NC, G);
NC.prototype.na = function() {
  return {id:this.s(), isInProgress:"INPROGRESS" == this.getState(), state:this.getState()};
};
NC.prototype.pause = n;
NC.prototype.resume = n;
NC.prototype.q3 = n;
var OC = function(a, b, c) {
  F.call(this, "ja");
  this.Ci = B(a);
  this.yb = B(b);
  this.removed = B(c);
};
w(OC, F);
var PC = function(a) {
  F.call(this, "ka");
  this.US = B(a);
};
w(PC, F);
var RC = function() {
  this.oz = !1;
  this.$B = null;
  this.Bz = new Qr;
  this.Dg = {};
  this.mz = QC();
  this.mz.jb(n);
  this.cL = Uv.W();
  this.Qn = null;
};
pa(RC);
d = RC.prototype;
d.pi = function(a) {
  x(null == this.Dg[a]);
  this.Qn = a;
  this.Dg[a] = this.Bz;
  this.Bz = new Qr;
  this.Dg[a].open(this.mz, "hangouts-call-" + a + ".log");
  var b = new Date;
  this.Hb(a, "### Start [" + b.toString() + "] ### " + a);
  this.Hb(a, "Current time is " + b.toUTCString());
  this.Hb(a, "Google Talk Plugin Version: 10.0.0.0");
  this.Hb(a, "User agent: " + Vb);
};
d.Hb = function(a, b, c) {
  var e = v();
  null == this.$B && (this.$B = e);
  b = "[" + ((e - this.$B) / 1000).toFixed(3) + "s]" + (null != c ? c : 8) + " " + b + "\n";
  if (null != a) {
    a = this.Dg[a], null != a && a.write([b]);
  } else {
    for (a in this.Dg) {
      this.Dg[a].write([b]);
    }
    null != a || this.Bz.write([b]);
  }
  this.oz && window.console.log(b);
};
d.si = function(a) {
  x(null != this.Dg[a]);
  var b = new Date;
  this.Hb(a, "### Stop [" + b.toString() + "] ### " + a);
  this.Hb(a, "Current time is " + b.toUTCString());
  delete this.Dg[a];
};
d.Mca = function(a, b) {
  this.cL.add(b, a);
  return this.Nca(a, b);
};
d.Nca = function(a, b) {
  var c = "hangouts-call-" + a + ".log", e = this.Dg[a];
  if (null != e) {
    return AC(e.gG(), b, !0, c).eb(u(this.VK, this, a, b)).Mq(u(this.Vz, this, a, b));
  }
  var e = new Qr, f = new xr;
  e.open(this.mz, c, !0).then(function() {
    x(e).Bb() ? (this.Hb(this.Qn, "JS log for " + a + " has no content", 9), f.callback(new zC(null, "No log content for session " + a))) : AC(e.gG(), b, !1).eb(u(this.VK, this, a, b)).Mq(u(this.Vz, this, a, b)).nE(f);
  }, function(c) {
    this.Vz(a, b, c);
    f.Yc(c);
  }, this);
  return f;
};
var QC = function() {
  var a = h.requestFileSystem || h.webkitRequestFileSystem;
  if (!a) {
    return Yd("Filesystem API not accessible");
  }
  var b = H();
  a(window.TEMPORARY, 0, function(a) {
    a.root.getDirectory("log_v2", {create:!0}, u(b.resolve, b), u(b.reject, b));
  }, u(b.reject, b));
  return b.promise;
};
RC.prototype.VK = function(a, b, c) {
  200 == c.VL ? (this.Hb(this.Qn, "JS log upload for " + a + " successful: " + c.responseText), this.cL.remove(b, a)) : this.Hb(this.Qn, "JS log upload for " + a + " failure " + c.VL + ": " + c.responseText, 10);
};
RC.prototype.Vz = function(a, b, c) {
  this.Hb(this.Qn, "JS log upload for " + a + " failed: " + c, 10);
};
var TC = function(a) {
  P(this, a, 0, -1, SC, null);
};
w(TC, O);
var SC = [4];
TC.prototype.b = function(a) {
  return UC(a, this);
};
var UC = function(a, b) {
  var c, e = {ob:(c = b.X()) && Iw(a, c), session:(c = b.xf()) && DC(a, c), J:(c = b.h()) && Z(a, c), qb:Q(b.M(), DC, a)};
  a && (e.f = b);
  return e;
};
d = TC.prototype;
d.X = function() {
  return U(this, Hw, 1);
};
d.setRequestHeader = function(a) {
  W(this, 1, a);
};
d.xf = function() {
  return U(this, CC, 2);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
d.M = function() {
  return V(this, CC, 4);
};
d.ra = function(a) {
  X(this, 4, a);
};
var WC = function(a) {
  P(this, a, "chsearp", -1, VC, null);
};
w(WC, O);
var VC = [4];
WC.prototype.b = function(a) {
  return XC(a, this);
};
var XC = function(a, b) {
  var c, e = {Ka:(c = b.getResponseHeader()) && Kw(a, c), session:(c = b.xf()) && DC(a, c), J:(c = b.h()) && Z(a, c), qb:Q(b.M(), DC, a)};
  a && (e.f = b);
  return e;
};
sr("chsearp", WC);
d = WC.prototype;
d.getResponseHeader = function() {
  return U(this, Jw, 1);
};
d.xf = function() {
  return U(this, CC, 2);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
d.M = function() {
  return V(this, CC, 4);
};
d.ra = function(a) {
  X(this, 4, a);
};
var ZC = function(a) {
  P(this, a, 0, -1, YC, null);
};
w(ZC, O);
var YC = [4];
d = ZC.prototype;
d.b = function(a) {
  var b, c = {ob:(b = this.X()) && Iw(a, b), session:(b = this.xf()) && DC(a, b), J:(b = this.h()) && Z(a, b), qb:Q(this.M(), DC, a)};
  a && (c.f = this);
  return c;
};
d.X = function() {
  return U(this, Hw, 1);
};
d.setRequestHeader = function(a) {
  W(this, 1, a);
};
d.xf = function() {
  return U(this, CC, 2);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
d.M = function() {
  return V(this, CC, 4);
};
d.ra = function(a) {
  X(this, 4, a);
};
var aD = function(a) {
  P(this, a, "chsemrp", -1, $C, null);
};
w(aD, O);
var $C = [4];
aD.prototype.b = function(a) {
  var b, c = {Ka:(b = this.getResponseHeader()) && Kw(a, b), session:(b = this.xf()) && DC(a, b), J:(b = this.h()) && Z(a, b), qb:Q(this.M(), DC, a)};
  a && (c.f = this);
  return c;
};
sr("chsemrp", aD);
d = aD.prototype;
d.getResponseHeader = function() {
  return U(this, Jw, 1);
};
d.xf = function() {
  return U(this, CC, 2);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
d.M = function() {
  return V(this, CC, 4);
};
d.ra = function(a) {
  X(this, 4, a);
};
var bD = function(a) {
  P(this, a, "chseqrp", -1, null, null);
};
w(bD, O);
bD.prototype.b = function(a) {
  return cD(a, this);
};
var cD = function(a, b) {
  var c, e = {Ka:(c = b.getResponseHeader()) && Kw(a, c), session:(c = b.xf()) && DC(a, c), J:(c = b.h()) && Z(a, c)};
  a && (e.f = b);
  return e;
};
sr("chseqrp", bD);
d = bD.prototype;
d.getResponseHeader = function() {
  return U(this, Jw, 1);
};
d.xf = function() {
  return U(this, CC, 2);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
var eD = function(a) {
  P(this, a, 0, -1, dD, null);
};
w(eD, O);
var dD = [2, 3];
eD.prototype.b = function(a) {
  return fD(a, this);
};
var fD = function(a, b) {
  var c, e = {J:(c = b.h()) && Z(a, c), zd:Q(b.Na(), DC, a), jf:Q(b.Ab(), Gt, a), Ne:(c = b.Nb()) && Gt(a, c)};
  a && (e.f = b);
  return e;
};
d = eD.prototype;
d.h = function() {
  return U(this, Y, 1);
};
d.j = function(a) {
  W(this, 1, a);
};
d.G = function() {
  this.j(void 0);
};
d.Na = function() {
  return V(this, CC, 2);
};
d.Ab = function() {
  return V(this, Ft, 3);
};
d.Nb = function() {
  return U(this, Ft, 4);
};
var gD = function() {
  this.a = zf("realtime.media.apiary.Parser");
};
d = gD.prototype;
d.tS = function(a, b, c, e) {
  var f = new jx;
  f.L(a);
  f.Sa(b.A());
  f.Qf(b.getId());
  f.oc(this.hh(b.N()));
  a = "Ba" == b.getState();
  f.AB(new px);
  f.Be().wu(a);
  "a" == b.N() ? (null != c && f.Be().ym(c), null != e && (f.q$(new qx), f.Bl().ym(e)), null != b.Mp && (c = new sx, c.zN(b.Mp), c.ym(b.A()), f.O$(c))) : "v" == b.N() && (f.Saa(new rx), f.Gl().Y8(this.aS(b.Kb)), b = b.gI(), null != b && f.Gl().Q9(z(b, this.yS, this)));
  return f;
};
d.B5 = function(a) {
  var b = a.A(), c = a.ya(), e = this.Nj(a.P()), f = "ya", g;
  null != a.Gl() && (f = this.Y4(a.Gl().pW()), g = this.If(a.Gl().XG(), this.J5, this) || void 0);
  var k;
  if (null != a.ay()) {
    var q = a.ay().tH();
    k = t(q) ? q : void 0;
  }
  var r = a.Be() && a.Be().wo() ? "Ba" : "Aa", q = null;
  null != b && null != c && null != e && (q = new Wr(b, c, e, null != f ? f : void 0, r, k, g));
  b = null;
  null != a.Be() && (b = a.Be().sl());
  c = null;
  null != a.Bl() && (c = a.Bl().sl());
  return {source:q, jpa:b, ipa:c};
};
d.yS = function(a) {
  var b = new vx;
  b.Uaa(a.left);
  b.Vaa(a.top);
  b.mk(a.width);
  b.ik(a.height);
  return b;
};
d.J5 = function(a) {
  var b = a.A_(), c = a.B_(), e = a.Af();
  a = a.tf();
  return null != b && null != c && null != e && null != a ? new Zq(b, c, e, a) : null;
};
d.aS = function(a) {
  switch(a) {
    case "wa":
      return 1;
    case "xa":
      return 2;
  }
  J(this.a, "Unknown media content: " + a);
};
d.Y4 = function(a) {
  switch(a) {
    case 1:
      return "wa";
    case 2:
      return "xa";
  }
  J(this.a, "Unknown capture type: " + a);
  return "ya";
};
d.rS = function(a, b, c, e, f) {
  e = new CC;
  null != a.s() && e.Ca(a.s());
  e.Rf(f ? 2 : 1);
  f = [];
  null != b && (e.ZM([b]), null != c && (f = c));
  b = a.ma;
  x(b, "Empty audio description for bundled calls");
  f = f.concat(b.ze());
  b = a.ha;
  null != b && (f = f.concat(b.ze()));
  b = [];
  c = [a.ma, a.ha, a.getData()];
  c = this.BS(c);
  f = this.iS(c, f, a.kc(), a.Ah());
  f.oc(4);
  b.push(f);
  e.nB(b);
  a = z(a.fs(), function(a) {
    var b = new Rt;
    b.a9(a.getChannelId());
    b.E9(a.Mx());
    var c = a.vg();
    b.X9(c);
    switch(c) {
      case "collections":
        b.Rf(1);
        break;
      case "msodc":
        b.Rf(2);
    }
    a = a.zg();
    null != a && b.GB(a);
    return b;
  });
  e.V$(a);
  return e;
};
d.bA = function(a, b) {
  var c = null, e = null, f = null, g = null, k = [], q = l(b) ? b : !0;
  b = a.s();
  var r = a.LH();
  if (0 < r.length) {
    x(4 == r[0].P(), "Non-bundled calls are not supported.");
    var f = this.p5(r[0], q), c = this.kC(f, "a"), e = this.kC(f, "v"), f = this.kC(f, "d"), A = r[0].kc();
    A && (g = this.G5(A, q));
    (q = r[0].CG()) && (k = this.If(q, this.aA, this) || []);
  }
  a = z(a.yH(), function(a) {
    return new rp(Za(a.getChannelId()), a.Mx(), Ya(a.zg()), Za(a.vg()));
  }, this);
  return new Uq(c, e, f, null == b ? void 0 : b, a, g, k);
};
d.kC = function(a, b) {
  var c = ib(a.sc(), function(a) {
    return a.P() == b;
  }), e = "d" == b ? a.Bc : null;
  if (0 == c.length && null == e) {
    return null;
  }
  var f = ib(a.fj(), function(a) {
    return a.P() == b;
  });
  a = ib(a.ze(), function(a) {
    return a.P() == b;
  });
  return (new wq(b, c, f)).Ck(a).hn(e);
};
d.iS = function(a, b, c, e) {
  var f = new VB;
  f.oc(this.hh(a.N()) || void 0);
  f.d9(z(a.sc(), this.cS, this));
  f.KM(z(e, this.aE, this));
  f.iaa(z(a.fj(), this.pS, this));
  null != c && f.XN(this.xS(c));
  a.Bc && f.maa(a.Bc.getName());
  a.Hc() && f.iN(this.hS(a.Hc()));
  f.o9(z(b, this.lS, this));
  return f;
};
d.lS = function(a) {
  var b = new Cx;
  b.MN(a.$c());
  var c = new Zt;
  c.ik(a.tf());
  c.mk(a.Af());
  c.YM(a.rf());
  b.Zp(c);
  c = new wA;
  c.Caa(b);
  c.oc(this.hh(a.P()) || void 0);
  return c;
};
d.hS = function(a) {
  var b = new st;
  -1 != a.Ej && b.mN(a.Ej);
  -1 != a.Eg && b.fN(a.Eg);
  -1 != a.qk && b.RN(a.qk);
  return b;
};
d.BS = function(a) {
  for (var b = [], c = [], e = [], f = null, g = null, k = 0;k < a.length;k++) {
    null != a[k] && (b = b.concat(a[k].sc()), c = c.concat(a[k].fj()), e = e.concat(a[k].ze()), !f && a[k].Bc && (f = a[k].Bc), !g && a[k].Hc() && (g = a[k].Hc()));
  }
  return a[0].zi(b).DP(c).Ck(e).ov(g).hn(f);
};
d.p5 = function(a) {
  var b = this.Nj(a.P());
  if (null == b) {
    return null;
  }
  var c = this.If(a.xG(), this.$z, this) || [], e = this.If(a.JH(), u(function(a) {
    return this.w5(a, b || void 0);
  }, this)) || [], f = [];
  y(a.GG(), function(a) {
    var b = this.Nj(a.P());
    null != b && (a = this.ZK(a.XH(), b, "", ""), f.push(a));
  }, this);
  var g = null;
  (a = a.IZ()) && (g = (new Wp).hc(a).rv(5000).GC(256).S());
  return (new wq(b, c, e)).Ck(f).hn(g);
};
d.hh = function(a) {
  switch(a) {
    case "a":
      return 1;
    case "v":
      return 2;
    case "d":
      return 3;
  }
  J(this.a, "Unknown media type: " + a);
};
d.Nj = function(a, b) {
  switch(a) {
    case 1:
      return "a";
    case 2:
      return "v";
    case 3:
      return "d";
    case 4:
      return "a";
  }
  if (l(b)) {
    return b;
  }
  J(this.a, "Unknown media type: " + a);
  return null;
};
d.cS = function(a) {
  var b = new vt;
  b.oc(this.hh(a.P()));
  b.M$(a.yc);
  b.Dm(a.getName());
  b.K$(z(a.Xx(), function(a) {
    var b = new yt;
    b.V9(a.getKey());
    b.QB(a.vc());
    return b;
  }, this));
  b.R8(a.gh);
  b.kaa(a.fg);
  b.Z8(a.ff);
  return b;
};
d.$z = function(a) {
  var b = this.Nj(a.P()), c = a.RY(), e = a.getName();
  if (null == b || null == c || null == e) {
    return J(this.a, "Bad codec: " + a), null;
  }
  var f = (new oq).La(b).hd(c).hc(e), b = a.ZV();
  null != b && f.Xe(b);
  b = a.HZ();
  null != b && f.Md(b);
  b = a.rW();
  null != b && f.Ld(b);
  y(a.rH(), function(a) {
    var b = a.getKey() || "";
    a = a.vc() || "";
    f.Fq(b, a);
  }, this);
  return f.S();
};
d.aE = function(a) {
  var b = this.eS(a.Lh());
  if (null == b) {
    return J(this.a, "Unknown crypto suite: " + a.Lh()), null;
  }
  var c = new zt;
  c.Faa(b);
  c.W9(a.zl());
  c.vaa(a.Fo() || void 0);
  c.Haa(a.Ho());
  return c;
};
d.aA = function(a) {
  var b = this.d5(a.Lh());
  if (null == b) {
    return J(this.a, "Unknown crypto suite: " + a.Lh()), null;
  }
  var c = a.zl(), e = a.Fo();
  if (null == c) {
    return J(this.a, "Bad crypto: " + a), null;
  }
  a = (new Sp).JC(b).FC(c).KC(1);
  e && a.EP(e);
  return a.S();
};
d.eS = function(a) {
  switch(a) {
    case "AES_CM_128_HMAC_SHA1_32":
      return 2;
    case "AES_CM_128_HMAC_SHA1_80":
      return 1;
  }
  J(this.a, "Unknown crypto suite: " + a);
  return null;
};
d.d5 = function(a) {
  switch(a) {
    case 2:
      return "AES_CM_128_HMAC_SHA1_32";
    case 1:
      return "AES_CM_128_HMAC_SHA1_80";
  }
  J(this.a, "Unknown crypto suite: " + a);
  return null;
};
d.pS = function(a) {
  var b = new Dt;
  b.Qaa(a.Fl());
  b.tu(a.getId());
  a = a.P();
  b.oc(a ? this.hh(a) : void 0);
  return b;
};
d.w5 = function(a, b) {
  var c = a.Fl() || "", e = a.getId();
  b = this.Nj(a.P(), b);
  if (null == c || null == e) {
    return J(this.a, "Missing RTP header extension id or uri: " + a), null;
  }
  a = (new Up).kn(c).en(e);
  b && a.La(b);
  return a.S();
};
d.xS = function(a) {
  var b = new xx;
  b.O9(this.gS(a.zf()));
  b.YN(a.wi);
  b.yN(a.di);
  b.HM(z(a.jo(), this.$D, this));
  var c = a.ud();
  c && (a = new Ax, c = c.split(" "), x(2 == c.length), a.AM(c[0]), a.UM(c[1]), b.ON(a));
  return b;
};
d.G5 = function(a, b) {
  var c = this.o5(a.KX());
  if (null == c) {
    return null;
  }
  b = b && "ICE" === c ? "lite" : "full";
  var e = a.t_() || "", f = a.QY() || "", g = this.X4(a.rG());
  a = a.SH();
  var k;
  a && (k = a.LV() + " " + a.ud());
  return new rq(c, e, f, k, g, b);
};
d.X4 = function(a) {
  return this.If(a, u(function(a) {
    return this.W4(a);
  }, this)) || [];
};
d.$D = function(a) {
  var b = new Bt;
  b.h9(this.YR(a.Zi()));
  b.Yp(this.ZR(a.yg()));
  b.R9(a.xl());
  b.Fm(a.Wa());
  b.Rf(this.$R(a.N()));
  b.BN(a.ej());
  b.y$(a.xo());
  b.I9(a.wl());
  return b;
};
d.W4 = function(a) {
  var b = this.R4(a.Zi()), c = a.ej();
  null != c || (c = 0);
  var e = this.V4(a.N()), f = this.U4(a.yg()), g = a.xl(), k = a.Wa();
  if (!(b && e && f && g && k)) {
    return J(this.a, "Missing or unknown candidate parmeters: " + a), null;
  }
  var q = c.toString(), r = a.xo() || "";
  a = a.wl() || 0;
  return new zp(b, c, e, f, g, k, q, a, r);
};
d.gS = function(a) {
  switch(a) {
    case "GICE":
      return 1;
    case "ICE":
      return 2;
  }
  J(this.a, "Unknown ICE version: " + a);
};
d.o5 = function(a) {
  switch(a) {
    case 1:
      return "GICE";
    case 2:
      return "ICE";
  }
  J(this.a, "Unknown ICE version: " + a);
  return null;
};
d.YR = function(a) {
  switch(a) {
    case 1:
      return 1;
    case 2:
      return 2;
  }
  J(this.a, "Unknown ICE component: " + a);
};
d.R4 = function(a) {
  switch(a) {
    case 1:
      return 1;
    case 2:
      return 2;
  }
  J(this.a, "Unknown ICE component: " + a);
  return null;
};
d.ZR = function(a) {
  switch(a) {
    case "UDP":
      return 1;
    case "TCP":
      return 2;
    case "SSLTCP":
      return 3;
  }
  J(this.a, "Unknown candidate protocol: " + a);
};
d.U4 = function(a) {
  switch(a) {
    case 1:
      return "UDP";
    case 2:
      return "TCP";
    case 3:
      return "SSLTCP";
  }
  J(this.a, "Unknown candidate protocol: " + a);
  return null;
};
d.$R = function(a) {
  switch(a) {
    case "LOCAL":
      return 1;
    case "PEER_REFLEX":
      return 2;
    case "STUN":
      return 3;
    case "RELAY":
      return 4;
  }
  J(this.a, "Unknown candidate type: " + a);
};
d.V4 = function(a) {
  switch(a) {
    case 1:
      return "LOCAL";
    case 2:
      return "PEER_REFLEX";
    case 3:
      return "STUN";
    case 4:
      return "RELAY";
  }
  J(this.a, "Unknown ICE type: " + a);
  return null;
};
d.cE = function(a, b, c) {
  var e = new WA;
  e.oe(2);
  null != a && e.Ca(a);
  e.L(b);
  e.Sa(c.A());
  e.oc(this.hh(c.P()));
  e.Qf(c.ya());
  e.lk(c.Vb());
  "v" == c.P() && e.Cu(c.sh);
  a = new $A;
  a.aq(c.wd());
  a.PN(z(c.TH(), this.uS, this));
  e.pN(a);
  return e;
};
d.E5 = function(a) {
  return this.If(a, this.D5, this) || [];
};
d.D5 = function(a) {
  var b = this.Nj(a.P());
  if (null == b) {
    return J(this.a, "Unknown stream media type: " + a), null;
  }
  var c = a.A(), e = a.ya(), f = a.Vb();
  if (null == c || null == e || null == f) {
    return J(this.a, "Missing stream parmeters: " + a), null;
  }
  var g = a.Be(), g = g && g.wo() || !1, k = a.w_() || !0, q = [], r = [];
  a = a.wg();
  null != a && (q = this.If(a.ij(), this.km, this) || [], r = this.If(a.zs(), this.cA, this) || []);
  return (new zq).La(b).qv(c).Wf(e).Dk(f).AP(g).Zca(k).Ze(q).IC(r).gn(f).S();
};
d.km = function(a) {
  return a >>> 0;
};
d.uS = function(a) {
  var b = new dB;
  b.LN(a.Eo());
  b.aq(a.wd());
  return b;
};
d.cA = function(a) {
  var b = this.If(a.ij(), this.km) || [], c = a.Eo();
  return null == c ? (J(this.a, "Unknown ssrc group semantics: " + a), null) : (new qq).sv(c).Ze(b).S();
};
d.mS = function(a, b, c, e) {
  var f = new WA;
  f.oe(1);
  f.Ca(a);
  f.L(b);
  f.Sa(c.A());
  f.oc(this.hh(c.P()));
  f.Qf(c.ya());
  a = new Cx;
  a.yaa(!0);
  a.MN(e);
  e = c.Ub();
  null != e && (b = new Zt, b.ik(e.height), b.mk(e.width), b.YM(c.rf()), a.Zp(b));
  f.caa(a);
  return f;
};
d.aL = function(a) {
  return this.If(a, this.F5, this) || [];
};
d.F5 = function(a) {
  var b = this.Nj(a.P());
  if (null == b) {
    return J(this.a, "Unknown stream request media type: " + a), null;
  }
  var c = a.A(), e = a.ya();
  if (null == c || null == e) {
    return J(this.a, "Missing stream request parmeters: " + a), null;
  }
  a = a.Kh();
  return this.ZK(a, b, c, e);
};
d.ZK = function(a, b, c, e) {
  var f = !1, g = void 0, k = void 0;
  if (null != a && a.$c() && (f = a.$c(), null == f && (f = void 0), null != a.Ub())) {
    var q = a.Ub().Af(), r = a.Ub().tf(), k = a.Ub().oX();
    null == k && (k = void 0);
    null != q && null != r && (g = new Ji(q, r));
  }
  return new Bp(c, e, b, g, k, f);
};
d.If = function(a, b, c) {
  null != c && (b = u(b, c));
  if (null == a || !sa(a)) {
    return null;
  }
  c = [];
  for (var e = 0;e < a.length;e++) {
    var f = a[e];
    if (null == f) {
      return J(this.a, "Failed to parse: " + a), null;
    }
    var g = b(f);
    if (null == g) {
      return J(this.a, "Failed to parse: " + f), null;
    }
    c.push(g);
  }
  return c;
};
var hD = function(a, b, c, e) {
  if (null == a) {
    return e = zf("realtime.media.apiary.RpcEventDispatcher"), Bf(e, "Failed to report impression on RPC request because thenable is null for rpc " + b + "with sessionId " + c), Yd();
  }
  a = a.then();
  e.dispatchEvent(new Vr(b, "Ca", c));
  var f = ie(a.cancel, 90000, a), g = !1;
  a.jb(function(a) {
    g = !0;
    return a;
  }).then(function(a) {
    je(f);
    var e = "Da";
    a instanceof Sd ? e = "Fa" : g && (e = "Ea");
    Ga(Pa(c)) && (1 > a.length || !(a[0] instanceof CC) ? c = null : (a = a[0], c = null != a ? a.s() : null));
    this.dispatchEvent(new Vr(b, e, c));
  }, null, e);
  return a;
};
var iD = function() {
  G.call(this);
  this.F = "INITIAL";
  this.yh = void 0;
};
w(iD, G);
d = iD.prototype;
d.na = function() {
  return {state:this.getState(), endCause:this.tl(), id:this.s(), isInProgress:"INPROGRESS" == this.getState(), localId:this.ia(), localDescription:this.uf().na(), localSession:this.R.na(), options:this.Ce().na(), remoteAudioCodecs:z(this.pZ(), function(a) {
    return a.toString();
  }), remoteSession:this.pa.na(), useEarlyMedia:this.eI()};
};
d.getState = function() {
  return this.F;
};
d.gk = n;
d.Aaa = function(a, b, c) {
  this.F != a && (this.F = a, this.yh = b, this.dispatchEvent(new $u(a, b, c)));
};
d.tl = function() {
  return this.yh;
};
var jD = function(a) {
  F.call(this, "qa");
  this.te = a;
};
w(jD, F);
var kD = function(a) {
  F.call(this, "sa");
  this.sessionId = a;
};
w(kD, F);
var lD = function(a) {
  F.call(this, "ma");
  this.id = a;
};
w(lD, F);
var mD = function(a) {
  F.call(this, "na");
  this.sessionDescription = a;
};
w(mD, F);
var nD = function(a, b, c) {
  F.call(this, "va");
  this.Vv = a;
  this.LA = b;
  this.sessionId = c || null;
};
w(nD, F);
var oD = function() {
  F.call(this, "ta");
};
w(oD, F);
var pD = function(a, b) {
  F.call(this, "pa");
  this.En = a;
  this.sessionId = b;
};
w(pD, F);
var qD = function() {
  var a = Kj(), b = null, c = a;
  try {
    do {
      try {
        c.location.origin == a.location.origin && (b = c.chrome && c.chrome.runtime || b);
      } catch (e) {
      }
      if (c == c.parent) {
        break;
      }
      c = c.parent;
    } while (null != c);
  } catch (e) {
  }
  return b;
}, rD = function() {
  return "https:" == Kj().location.protocol ? "nkeimhogjdpnpccoofpliimaahmaaome" : "hoblmflfjcnhdllclikeemgdcbbflkhi";
}, tD = function(a) {
  RC.W().Hb(null, "talk.media.webrtc.Extension: Sending message " + ef(a));
  var b = new xr, c = qD(), e = a.method;
  if (c && null != c.sendMessage) {
    var e = sD(b, e), f = Kj().location;
    a.origin = f.origin + "/";
    var g = Qc(f.href, "tabId");
    g && (a.tabId = g);
    (f = Qc(f.href, "winUrl")) && (a.winUrl = f);
    c.sendMessage(rD(), a, e);
  } else {
    RC.W().Hb(null, "talk.media.webrtc.Extension: Cannot find appropriate chrome.runtime when sending " + e, 10), b.Yc("Cannot find appropriate chrome.runtime");
  }
  return b;
}, uD = function(a) {
  var b = qD();
  if (b && null != b.connect) {
    RC.W().Hb(null, "talk.media.webrtc.Extension: Opening port named " + a);
    a = b.connect(rD(), {name:a});
    var c = u(a.disconnect, a);
    jd(Kj(), "unload", c);
    a.onDisconnect.addListener(function() {
      sd(window, "unload", c);
    });
    return a;
  }
  return null;
}, sD = function(a, b) {
  return function(c) {
    var e = "No response from extension";
    if (null != c) {
      if (e = c.error, null != e) {
        e = "Extension reported " + e.name + ": " + e.message;
      } else {
        RC.W().Hb(null, "talk.media.webrtc.Extension: Received response to " + b + ": " + ef(c.value));
        a.callback(c.value);
        return;
      }
    }
    var f = qD();
    f && null != f.lastError && (e = e + " Chrome reported: " + f.lastError.message);
    RC.W().Hb(null, "talk.media.webrtc.Extension: Received error to " + b + ": " + e, 10);
    a.Yc(e);
    x(null == c, e);
  };
};
var vD = function(a, b) {
  this.ua = a;
  this.C = b || null;
  this.a = zf(a);
  this.kp = RC.W();
};
d = vD.prototype;
d.SB = function(a) {
  Bf(this.a, a);
  this.kp.Hb(this.C, "Error(" + this.ua + "): " + a, 10);
};
d.l = function(a) {
  J(this.a, a);
  this.kp.Hb(this.C, "Warning(" + this.ua + "): " + a, 9);
};
d.info = function(a) {
  K(this.a, a);
  this.kp.Hb(this.C, this.ua + ": " + a, 8);
};
d.config = function(a) {
  Af(this.a, rf, a);
  this.kp.Hb(this.C, this.ua + ": " + a, 7);
};
d.w = function(a) {
  L(this.a, a);
  this.kp.Hb(this.C, this.ua + ": " + a, 8);
};
var wD = function(a) {
  P(this, a, 0, -1, null, null);
};
w(wD, O);
wD.prototype.b = function(a) {
  return xD(a, this);
};
var xD = function(a, b) {
  var c, e = {Nma:(c = b.zX()) && Lz(a, c), Aoa:(c = b.iY()) && UC(a, c), Koa:(c = b.pY()) && ZB(a, c), Moa:(c = b.rY()) && hB(a, c), Foa:(c = b.mY()) && DA(a, c), Hoa:(c = b.oY()) && PA(a, c), Pma:(c = b.BX()) && Zz(a, c), Sma:(c = b.CX()) && lA(a, c), Ema:(c = b.sX()) && yz(a, c), Uma:(c = b.DX()) && qA(a, c), Lma:(c = b.wX()) && RB(a, c), Jma:(c = b.uX()) && NB(a, c), Coa:(c = b.kY()) && AA(a, c)};
  a && (e.f = b);
  return e;
};
d = wD.prototype;
d.zX = function() {
  return U(this, Kz, 1);
};
d.iY = function() {
  return U(this, TC, 2);
};
d.pY = function() {
  return U(this, YB, 3);
};
d.rY = function() {
  return U(this, gB, 4);
};
d.k$ = function(a) {
  W(this, 4, a);
};
d.mY = function() {
  return U(this, CA, 5);
};
d.oY = function() {
  return U(this, OA, 6);
};
d.j$ = function(a) {
  W(this, 6, a);
};
d.BX = function() {
  return U(this, Yz, 7);
};
d.L9 = function(a) {
  W(this, 7, a);
};
d.CX = function() {
  return U(this, kA, 8);
};
d.M9 = function(a) {
  W(this, 8, a);
};
d.sX = function() {
  return U(this, xz, 9);
};
d.DX = function() {
  return U(this, pA, 10);
};
d.wX = function() {
  return U(this, QB, 11);
};
d.uX = function() {
  return U(this, MB, 12);
};
d.kY = function() {
  return U(this, zA, 13);
};
var yD = function(a) {
  P(this, a, 0, -1, null, null);
};
w(yD, O);
yD.prototype.b = function(a) {
  return zD(a, this);
};
var zD = function(a, b) {
  var c, e = {Oma:(c = b.AX()) && Oz(a, c), Boa:(c = b.jY()) && XC(a, c), Loa:(c = b.qY()) && bC(a, c), Noa:(c = b.jH()) && jC(a, c), Goa:(c = b.nY()) && GA(a, c), Ioa:(c = b.hH()) && SA(a, c), Qma:(c = b.RG()) && bA(a, c), Tma:(c = b.TG()) && nA(a, c), Fma:(c = b.tX()) && Bz(a, c), Vma:(c = b.EX()) && sA(a, c), Mma:(c = b.xX()) && TB(a, c), Kma:(c = b.vX()) && PB(a, c), Doa:(c = b.lY()) && cD(a, c)};
  a && (e.f = b);
  return e;
};
d = yD.prototype;
d.AX = function() {
  return U(this, Nz, 1);
};
d.jY = function() {
  return U(this, WC, 2);
};
d.qY = function() {
  return U(this, aC, 3);
};
d.jH = function() {
  return U(this, iC, 4);
};
d.nY = function() {
  return U(this, FA, 5);
};
d.hH = function() {
  return U(this, RA, 6);
};
d.RG = function() {
  return U(this, aA, 7);
};
d.TG = function() {
  return U(this, mA, 8);
};
d.tX = function() {
  return U(this, Az, 9);
};
d.EX = function() {
  return U(this, rA, 10);
};
d.xX = function() {
  return U(this, SB, 11);
};
d.vX = function() {
  return U(this, OB, 12);
};
d.lY = function() {
  return U(this, bD, 13);
};
var AD = function(a) {
  P(this, a, 0, -1, null, null);
};
w(AD, O);
AD.prototype.b = function(a) {
  return BD(a, this);
};
var BD = function(a, b) {
  var c, e = {Rma:(c = b.SG()) && eA(a, c), Eoa:(c = b.gH()) && fD(a, c), Ooa:(c = b.kH()) && mC(a, c), wia:(c = b.fG()) && Sw(a, c), Joa:(c = b.iH()) && VA(a, c), Gma:(c = b.QG()) && rz(a, c), Wma:(c = b.UG()) && vA(a, c), dka:(c = b.yG()) && Nw(a, c), Sqa:(c = b.zH()) && jA(a, c), zja:(c = b.sG()) && tw(a, c), Woa:b.tY(), Xoa:(c = b.lH()) && rC(a, c)};
  a && (e.f = b);
  return e;
};
d = AD.prototype;
d.SG = function() {
  return U(this, dA, 1);
};
d.gH = function() {
  return U(this, eD, 2);
};
d.kH = function() {
  return U(this, lC, 3);
};
d.fG = function() {
  return U(this, Rw, 4);
};
d.iH = function() {
  return U(this, UA, 5);
};
d.QG = function() {
  return U(this, qz, 7);
};
d.UG = function() {
  return U(this, uA, 8);
};
d.yG = function() {
  return U(this, Mw, 9);
};
d.zH = function() {
  return U(this, iA, 10);
};
d.sG = function() {
  return U(this, sw, 11);
};
d.sY = function() {
  return R(this, 12);
};
d.tY = function() {
  return gr(this.sY());
};
d.lH = function() {
  return U(this, qC, 13);
};
var CD = function(a, b, c, e, f, g) {
  G.call(this);
  this.a = zf("realtime.media.apiary.Client");
  this.Fd = a;
  this.O7 = b;
  this.k6 = c;
  this.Rd = l(g) ? g : 8;
  this.Jf = f || Ra();
  this.XA = ky(e);
  this.oi = 37;
  "hangout_lite" == c && (this.oi = 55);
};
w(CD, G);
d = CD.prototype;
d.gN = function(a) {
  this.Fg = a;
};
d.IN = function(a) {
  this.Vu = a;
};
d.o6 = function(a) {
  var b = new zA;
  b.setRequestHeader(this.YE());
  b.Ca(a);
  return this.IJ("media_sessions/query", b).then(this.JZ, null, this);
};
d.JZ = function(a) {
  return null != a ? a.xf() : null;
};
d.Ym = function(a, b) {
  a = this.WE(a, b);
  return this.IJ("media_sessions/log", a).jb(function(a) {
    J(this.a, "Failed to upload log data: " + a);
    throw a;
  }, this);
};
d.WE = function(a, b) {
  a = a.Uk();
  a.f$(this.oi);
  a.e$(this.k6);
  var c = new EC;
  c.setRequestHeader(this.YE());
  c.Ca(b);
  c.d$(a);
  return c;
};
d.YE = function() {
  var a = new Hw;
  a.pB(new Os);
  a.Dx().Pe(this.Rd);
  var b = new Ks;
  b.DB(this.O7);
  b.Ug(this.Jf);
  a.oB(b);
  a.Bm("en");
  a.EB(this.XA);
  return a;
};
d.j0 = function(a) {
  if (null == a) {
    throw new DD("Got empty response.");
  }
  if (l(a.getResponseHeader)) {
    var b = a.getResponseHeader();
    if (null != b) {
      if (b = b.Ra(), 1 != b) {
        throw new DD("Got bad status in response header.", b);
      }
    } else {
      throw new DD("Missing response header.");
    }
  }
  return a;
};
d.IJ = function(a, b) {
  if (null == this.Fd) {
    var c = "Failed to " + a + " " + b + ": no service";
    J(this.a, c);
    return Yd(c);
  }
  return this.Fd.Xl(a, b, this.Vu, this.Fg).then(this.j0, function(c) {
    J(this.a, "Failed to " + a + " " + b + ": " + c);
    throw c;
  }, this);
};
var DD = function(a, b) {
  Ba.call(this);
  this.desc = a;
  this.status = b || 0;
};
w(DD, Ba);
var ED = function() {
  tk.call(this);
  this.gt = new I;
  this.mm = new I;
  this.yj = new I;
  this.T1(document, "visibilitychange", this.pca, !1, this);
  this.Gs = new vD("talk.media.webrtc.OutputTracker");
};
w(ED, tk);
var FD = new M("Y2E25b"), GD = function(a, b) {
  var c = b.S5 - a.S5;
  0 == c && (c = b.Nx() - a.Nx());
  return c;
}, HD = function(a) {
  this.XK = a;
};
HD.prototype.no = function() {
  return this.XK.no();
};
d = ED.prototype;
d.I6 = function(a, b) {
  this.yj.Ma(a) || this.yj.set(a, []);
  this.yj.get(a).push(new HD(b));
};
d.vL = function(a, b) {
  var c = this.yj.get(a);
  null != c ? vb(c, function(a) {
    return a.XK == b;
  }, this) ? 0 == c.length && this.yj.remove(a) : this.Gs.l("recordBeforeAudioStop: No matching element found for ssrc " + a) : this.Gs.l("recordBeforeAudioStop: No info found for ssrc " + a);
};
d.pX = function(a) {
  var b = this.gt.get(a);
  null != b && (x(0 < b.length), y(b, function(b) {
    this.$O(a, b);
  }, this));
  var c = this.mm.get(a);
  if (null == c) {
    return null;
  }
  this.mm.remove(a);
  b = ID(c);
  c = JD(c);
  return null != b || null != c ? {hI:b, iI:c} : null;
};
d.$O = function(a, b) {
  b = b.yd;
  b.end.Dr < b.start.Dr ? this.Gs.l("Non-monotonic frame count: " + b.end.Dr) : (this.mm.Ma(a) || this.mm.set(a, []), -1 > b.sma() && this.Gs.l("Negative fps! s:{" + b.start.toString() + "} e:{" + b.end.toString() + "}"), this.mm.get(a).push(b));
};
d.pca = function() {
  this.gt.forEach(function(a, b) {
    x(0 < a.length);
    y(a, function(a) {
      x(null != a);
      this.$O(b, a);
    }, this);
  }, this);
};
var ID = function(a) {
  var b = 0, c = 0;
  y(a, function(a) {
    b += a.end.Dr - a.start.Dr;
    c += a.end.timestamp - a.start.timestamp;
  });
  return 0 == c ? null : b / c;
}, JD = function(a) {
  var b = [];
  y(a, function(a) {
    a.hidden || (b.push({t:a.start.timestamp, c:1, i:a}), b.push({t:a.end.timestamp, c:-1, i:a}));
  });
  Db(b, "t");
  var c = 0, e = 0, f = -Infinity, g = [];
  y(b, function(a) {
    var b = a.t, k = b - f;
    0 < g.length && (c += b - f, e += g[0].Nx() * k);
    1 == a.c ? (a = a.i, pb(g, a) || g.push(a), Bb(g, GD)) : ub(g, a.i);
    f = b;
  });
  x(0 == g.length, "Open and close steps must balance");
  return 0 == c ? null : e / c;
};
ED.prototype.no = function(a) {
  a = this.gt.get(a) || this.yj.get(a);
  if (null == a) {
    return null;
  }
  x(0 < a.length);
  var b = 0, c = !1;
  y(a, function(a) {
    a = a.no();
    null != a && (b = Math.max(a, b), c = !0);
  });
  return c ? b : null;
};
ED.prototype.U = function() {
  this.gt.clear();
  this.yj.clear();
  this.mm.clear();
  ED.T.U.call(this);
};
var LD = function(a) {
  P(this, a, 0, -1, KD, null);
};
w(LD, O);
var KD = [2];
d = LD.prototype;
d.b = function(a) {
  var b, c = {ob:(b = this.X()) && Iw(a, b), TU:Q(this.ns(), xD, a), J:(b = this.h()) && Z(a, b)};
  a && (c.f = this);
  return c;
};
d.X = function() {
  return U(this, Hw, 1);
};
d.setRequestHeader = function(a) {
  W(this, 1, a);
};
d.ns = function() {
  return V(this, wD, 2);
};
d.SM = function(a) {
  X(this, 2, a);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
var ND = function(a) {
  P(this, a, "chbrp", -1, MD, null);
};
w(ND, O);
var MD = [2];
ND.prototype.b = function(a) {
  var b, c = {Ka:(b = this.getResponseHeader()) && Kw(a, b), TU:Q(this.ns(), zD, a), J:(b = this.h()) && Z(a, b)};
  a && (c.f = this);
  return c;
};
sr("chbrp", ND);
d = ND.prototype;
d.getResponseHeader = function() {
  return U(this, Jw, 1);
};
d.ns = function() {
  return V(this, yD, 2);
};
d.SM = function(a) {
  X(this, 2, a);
};
d.h = function() {
  return U(this, Y, 3);
};
d.j = function(a) {
  W(this, 3, a);
};
d.G = function() {
  this.j(void 0);
};
var OD = function(a) {
  P(this, a, 0, -1, null, null);
};
w(OD, O);
OD.prototype.b = function(a) {
  return PD(a, this);
};
var PD = function(a, b) {
  var c, e = {xsa:(c = b.VH()) && vz(a, c), notification:(c = b.Vx()) && BD(a, c), bna:(c = b.WG()) && ix(a, c)};
  a && (e.f = b);
  return e;
};
OD.prototype.VH = function() {
  return U(this, uz, 1);
};
OD.prototype.Vx = function() {
  return U(this, AD, 2);
};
OD.prototype.WG = function() {
  return U(this, hx, 3);
};
var RD = function(a, b, c, e, f) {
  Rc.call(this);
  this.xz = a;
  this.nS = b;
  this.zZ = c || this.AZ;
  this.jB = e || null;
  this.jG = f || null;
  x(!(this.jG ^ this.jB), "Both bulk operation functions must be supplied, or none");
  this.kv = -1;
  this.Zb = H();
  this.Lp = null;
  this.zI = !1;
  this.Fg = 0;
  this.Vu = void 0;
  this.vb = ++QD;
};
w(RD, Rc);
var QD = 0;
d = RD.prototype;
d.$N = function(a) {
  this.kv = a;
  this.JN();
};
d.getPromise = function() {
  return this.Zb.promise;
};
d.yI = function() {
  return this.zI;
};
d.JJ = function() {
  this.zI = !0;
};
d.getMethodName = function() {
  return this.xz;
};
d.Oba = function() {
  return !!this.jB;
};
d.Kh = function() {
  null == this.Lp && (this.Lp = this.Ar(), this.JN());
  return this.Lp;
};
d.dW = function(a) {
  var b = new wD;
  x(this.jB).call(b, a);
  return b;
};
d.xZ = function(a) {
  return new mp(this.yZ(a), this.u_(a));
};
d.eW = function(a) {
  return x(x(this.jG).call(a), "Expected response in HangoutBulkResponseEntry was empty");
};
d.u_ = function(a) {
  return ua(a.h) && null != a.h() ? a.h().zf() : -1;
};
d.yB = function(a) {
  this.Fg = a;
};
d.ss = function() {
  return this.Fg;
};
d.JB = function(a) {
  this.Vu = a;
};
d.Ds = function() {
  return this.Vu;
};
d.JN = function() {
  if (null != this.Lp && -1 != this.kv) {
    var a = this.Lp;
    if (ua(a.j)) {
      var b = new Y;
      b.setVersion(this.kv);
      a.j(b);
    } else {
      ua(a.G) && a.G();
    }
  }
};
d.$H = function() {
  return this.xz;
};
d.FH = function() {
  return this.Kh().toString();
};
d.toString = function() {
  return "[Operation id: " + this.vb + ": " + this.xz + ", version: " + this.kv + "]";
};
d.Ar = function() {
  return this.nS();
};
d.yZ = function(a) {
  return this.zZ(a);
};
d.AZ = function() {
  return [];
};
var SD = function() {
  Ba.call(this);
};
w(SD, Ba);
SD.prototype.message = "Operation has already been executed.";
SD.prototype.name = "AlreadyExecutedError";
var TD = function(a) {
  this.g = new vD(a);
};
TD.prototype.error = function(a) {
  this.g.SB(a);
};
TD.prototype.l = function(a) {
  this.g.l(a);
};
TD.prototype.info = function(a) {
  this.g.info(a);
};
TD.prototype.w = function(a) {
  this.g.w(a);
};
var VD = function(a) {
  P(this, a, "hcbu", -1, UD, null);
};
w(VD, O);
var UD = [1];
VD.prototype.b = function(a) {
  var b = {Dpa:Q(this.Wx(), PD, a)};
  a && (b.f = this);
  return b;
};
sr("hcbu", VD);
VD.prototype.Wx = function() {
  return V(this, OD, 1);
};
var WD = function(a, b, c, e, f) {
  G.call(this);
  this.a = zf("realtime.collections.apiary.OperationExecutor");
  this.ih = [];
  this.Yv = b;
  this.qp = b instanceof DB ? b : null;
  this.Py = a;
  this.Jf = c || null;
  this.Rd = l(e) ? e : 8;
  this.XA = ky(f || 0);
};
w(WD, Ur);
d = WD.prototype;
d.rl = function() {
  return this.Yv;
};
d.Cx = function() {
  var a = new Hw;
  a.pB(new Os);
  a.Dx().Pe(this.Rd);
  var b = new Ks;
  null != this.Jf && b.Ug(this.Jf);
  a.oB(b);
  a.tG().DB(this.Py);
  a.Bm("en");
  a.EB(this.XA);
  return a;
};
d.execute = function(a, b) {
  a = db(a, RD);
  if (a.yI()) {
    throw new SD(a);
  }
  this.qp && !l(b) && a.Oba() ? (this.ih.push(a), 1 == this.ih.length && Od(this.YU, this)) : this.CF(a, b);
};
d.YU = function() {
  for (var a = 0;a + 5 < this.ih.length;) {
    this.BF(zb(this.ih, a, a + 5)), a += 5;
  }
  1 == this.ih.length - a ? this.CF(this.ih[a]) : this.BF(zb(this.ih, a));
  this.ih.length = 0;
};
d.CF = function(a, b) {
  var c = a.getMethodName(), e = a.Kh();
  e.setRequestHeader(this.Cx());
  K(this.a, "Making request for operation: " + a + ", jid: " + this.Py);
  var f = a.ss();
  b = l(b) ? b : a.Ds();
  this.Yv.Xl(c, e, b, f).then(u(this.WK, this, a)).jb(u(this.Sr, this, a));
};
d.WK = function(a, b) {
  var c = b.getResponseHeader();
  x(null != c, "Missing response header");
  if (1 == c.Ra()) {
    b = a.xZ(b), K(this.a, "Apiary operation succeeded for " + a + ", result: " + b), a.JJ(), a.Zb.resolve(b);
  } else {
    var e = Error(c.$X());
    e.stack = c.gX();
    Bf(this.a, "Apiary operation " + a + " failed with status " + c.Ra(), e);
    this.Sr(a, new Aq("fatal", "backend", null, b));
  }
};
d.Sr = function(a, b) {
  a.JJ();
  Bf(this.a, "Apiary operation failed for " + a + ": " + b);
  a.Zb.reject(b);
};
d.BF = function(a) {
  var b = new LD;
  b.setRequestHeader(this.Cx());
  b.SM(z(a, function(a) {
    var b = a.Kh();
    return a.dW(b);
  }, this));
  K(this.a, "Making bulk request for " + a.length + "operations , jid: " + this.Py);
  var c = Math.max.apply(null, z(a, function(a) {
    return a.ss();
  })), e = Math.min.apply(null, z(a, function(a) {
    return a.Ds();
  }));
  this.Yv.Xl("hangouts/bulk", b, e, c).then(u(this.AS, this, a)).jb(u(this.zS, this, a));
};
d.AS = function(a, b) {
  this.qp.rC(b);
  var c = b.ns();
  y(a, function(a, f) {
    (f = a.eW(c[f])) ? (this.qp.rC(f), this.WK(a, f)) : this.Sr(a, new Aq("fatal", "backend", null, b));
  }, this);
};
d.zS = function(a, b) {
  y(a, function(a) {
    this.Sr(a, b);
  }, this);
};
var XD = function(a, b) {
  yy.call(this, a);
  this.Xb = new TD("realtime.media.api.webrtc.Capture");
  this.settings = b;
  this.tk = this.Id = null;
  this.jp = new Ae;
  this.sk = new I;
  this.bd = !1;
  this.nP = "";
  this.Fe = !1;
  this.sb = null;
};
w(XD, yy);
d = XD.prototype;
d.U = function() {
  this.Sn();
  this.jp.clear();
  this.sb = null;
  XD.T.U.call(this);
};
d.toString = function() {
  return "Capture(source=" + this.K() + " muted=" + this.bd + " paused=" + this.Fe + " stream=" + (this.Id ? this.Id.id : null) + " streamUrl=" + this.tk + ")";
};
d.Nu = function(a) {
  a && y(xb(a.getAudioTracks(), a.getVideoTracks()), function(a) {
    ud(a);
    a.stop();
  });
};
d.Sn = function() {
  this.sk.forEach(this.Nu, this);
  this.sk.clear();
  this.Nu(this.Id);
  this.Id = null;
  this.tk && (window.URL.revokeObjectURL(this.tk), this.tk = null);
};
d.hO = function() {
  this.Xb.info("Starting media for " + this);
  this.QM("ab");
  return this.Aq().then(Ad(this));
};
d.aO = function(a) {
  this.nP = a;
  if (this.Id) {
    var b = xb([this.Id], this.sk.H());
    y(b, function(b) {
      y(b.getVideoTracks(), function(b) {
        "contentHint" in b && (b.contentHint = a);
      });
    });
  }
};
d.getDeviceId = function() {
  return this.settings.deviceId;
};
d.pf = function() {
  return this.sb;
};
d.ib = function(a) {
  return this.Id ? this.sk.get(a, null) : null;
};
d.NT = function(a, b) {
  return new wB(this, a, b);
};
d.zL = function(a) {
  this.Xb.info("Registering sessionId=" + a + " with " + this);
  this.jp.add(a);
  this.Id && this.sk.set(a, this.Id.clone());
};
d.nC = function(a) {
  this.Xb.info("Unregistering sessionId=" + a + " with " + this);
  this.jp.remove(a);
  this.Nu(this.ib(a));
  this.sk.remove(a);
};
d.Qba = n;
d.stop = function() {
  this.Xb.info("Stopping " + this);
  this.Sn();
  this.jp.clear();
  this.dispatchEvent(new YD(this.tk));
  this.QM("fb");
  return !0;
};
d.cm = function() {
  if ("fb" == this.mg) {
    return !1;
  }
  this.dK(!0);
  return !0;
};
d.nca = function() {
  if ("fb" == this.mg) {
    return !1;
  }
  this.dK(!1);
  return !0;
};
d.To = function() {
  switch(this.mg) {
    case "cb":
    case "db":
    case "eb":
      return !0;
    default:
      return this.bd;
  }
};
d.dK = function(a) {
  this.Xb.info("Setting mute state to mute=" + a + " for " + this);
  this.bd = a;
  this.settings = this.settings.dda(this.bd);
  this.bd ? this.Sn() : this.Aq();
  this.Hca();
  this.dispatchEvent("U");
};
d.pause = function() {
  this.Fe || "fb" == this.mg || (this.Xb.info("Pausing " + this), this.Fe = !0, this.Sn());
};
d.resume = function() {
  this.Fe && "fb" != this.mg && (this.Xb.info("Resuming " + this), this.Fe = !1, this.Aq());
};
d.Hca = function() {
  this.K().ec(this.To() ? "Ba" : "Aa");
};
d.Aq = function() {
  if ("ab" != this.mg) {
    return this.Xb.info("Skipping update usermedia for " + this + " while device in state=" + this.mg), Xd();
  }
  if (null == this.settings.deviceId) {
    return this.Xb.info("Skipping update usermedia for " + this + " with null deviceId."), Xd();
  }
  if (this.bd) {
    return this.Xb.info("Skipping update usermedia for " + this + " because capture is currently muted."), Xd();
  }
  if (this.Fe) {
    return this.Xb.info("Skipping update usermedia for " + this + " because capture is currently paused."), Xd();
  }
  var a = this.s_();
  if (!a) {
    return a = "Attempting to update usermedia for " + this + " with null constraints", this.Xb.error(a), Yd(a);
  }
  var b = this.settings;
  this.Xb.info("Attempting to update UserMedia for " + this);
  return tr(a).then(function(a) {
    this.bd || this.Fe || !this.settings.equals(b) ? (this.Xb.info("Capture settings changed during stream acquisition for " + this), this.Nu(a)) : this.wK(a);
  }, function(a) {
    this.Xb.l("Error calling getUserMedia=" + a + " in " + this);
    throw a;
  }, this);
};
d.s_ = function() {
  var a = {audio:!1, video:!1}, b = this.K().N();
  switch(b) {
    case "a":
      b = this.settings.ys();
      a.audio = b;
      break;
    case "v":
      b = this.settings.ys();
      a.video = b;
      break;
    default:
      return this.Xb.error("Invalid mediaType=" + b + " for " + this), null;
  }
  return a;
};
d.wK = function(a) {
  this.Xb.info("getUserMedia success for stream=" + a.id + " in " + this);
  0 == a.getAudioTracks().length && 0 == a.getVideoTracks().length ? this.Xb.l("No media tracks for stream=" + a.id + " in " + this) : (this.Sn(), this.Id = a, this.tk = window.URL.createObjectURL(a), y(xb(this.Id.getAudioTracks(), this.Id.getVideoTracks()), function(a) {
    jd(a, "ended", this.E4, void 0, this);
  }, this), y(this.jp.H(), function(a) {
    this.sk.set(a, this.Id.clone());
  }, this), this.Xb.info("Stream changed in " + this), this.aO(this.nP), this.dispatchEvent(new YD(this.tk)));
};
d.E4 = n;
d.kR = function(a) {
  x(a.$c());
  x(a.P() == this.K().N());
  var b = a.Ub();
  if (b) {
    x("v" == this.K().N());
    var c = this.settings;
    c.minHeight = b.height;
    c.maxHeight = b.height;
    c.minWidth = b.width;
    c.maxWidth = b.width;
  }
  if (a = a.rf()) {
    x("v" == this.K().N()), c = this.settings, c.wt = a, c.mt = a;
  }
};
var YD = function(a) {
  F.call(this, "W");
  this.Kba = a;
};
w(YD, F);
var ZD = function() {
  this.g = new TD("realtime.media.api.webrtc.ExtensionDelegate");
};
w(ZD, Hq);
dq(ZD, Hq, 1);
d = ZD.prototype;
d.lo = function(a) {
  return tD({method:"cpu.getInfo"}).nR(function(b) {
    a(b);
  });
};
d.mo = function() {
  return uD("processCpu");
};
d.lN = function(a, b) {
  var c = tD({method:"logging.setMetadata", metaData:[{key:"sessionId", value:a}, {key:"url", value:window.location.href}]}).then(function() {
    this.g.w("Extension logging setMetadata succeeded for " + a);
  }, function(b) {
    this.g.w("Extension loggings setMetadata failed for session: " + a + ", error: " + b);
  }, this);
  b && c.jb(function() {
    return this.lN(a, !1);
  }, this);
  return c;
};
d.pi = function(a) {
  return this.lN(a, !0).then(function() {
    return this.gO(!0);
  }, void 0, this);
};
d.si = function(a, b) {
  if (b) {
    return tD({method:"logging.stopAndUpload"}).then(function(a) {
      this.g.info("logging.stopAndUpload succeeded with result=" + ef(a));
    }, function(a) {
      this.g.l("logging.stopAndUpload failed with error=" + a);
      throw a;
    }, this);
  }
  this.Vd(!1);
  return tD({method:"logging.stop"}).then(function() {
    this.g.info("logging.stop succeeded");
    if (a) {
      return (0 <= Ta(ck, 42) ? tD({method:"logging.store", logId:a}) : tD({method:"logging.stop"})).then();
    }
  }, void 0, this).jb(function(a) {
    this.g.l("logging.stop failed with error=" + a);
    throw a;
  }, this);
};
d.Vd = function(a) {
  return a ? tD({method:"logging.startRtpDump", incoming:!0, outgoing:!0}).then(function() {
    this.g.info("logging.startRtpDump succeeded");
  }, function(a) {
    this.g.info("logging.startRtpDump failed with error=" + a);
    throw a;
  }, this) : tD({method:"logging.stopRtpDump", incoming:!0, outgoing:!0}).then(function() {
    this.g.info("logging.stopRtpDump succeeded");
  }, function(a) {
    this.g.info("logging.stopRtpDump failed with error=" + a);
    throw a;
  }, this);
};
d.gO = function(a) {
  var b = tD({method:"logging.start"}).then();
  a && b.jb(function() {
    return this.gO(!1);
  }, this);
  return b;
};
d.ev = function() {
  return tD({method:"logging.uploadOnRenderClose"}).then();
};
var $D = function(a) {
  this.g = new TD("realtime.media.api.webrtc.LoggingManager");
  this.ad = fv(a, Rq, jy);
  this.zC = null;
  this.Fk = new Ae;
  this.fv = new Ae;
  this.Pl = !1;
  this.At = this.oq = this.Gf = null;
  this.bJ = this.UB = !1;
};
d = $D.prototype;
d.mc = function(a) {
  this.g.info("Logging manager initialized with userId=" + a);
  this.zC = a;
  return Xd(7);
};
d.Vd = function(a, b) {
  this.g.info("enableRtpHeaderDump called with sessionId=" + a + " and enable=" + b);
  this.bJ == b ? this.g.info("Ignoring enableRtpHeaderDump call for sessionId=" + a + " as header dump already in state with enable=" + b) : this.Pl ? Gq.W().Vd(b).then(function() {
    this.g.info("RTP header dump succeeded for sessionId=" + a + " and enable=" + b);
    this.bJ = b;
  }, function(c) {
    this.g.l("Error setting RTP header dump for sessionId=" + a + " and enable=" + b + ". Error=" + c);
    throw c;
  }, this) : this.Gf ? (this.g.info("Delaying rtp header dump request until native WebRTC logging has started."), this.Gf.then(function() {
    this.Vd(a, b);
  }, void 0, this)) : this.g.l("enableRtpHeaderDump called when native logging is not active or pending");
};
d.pi = function(a) {
  x(!this.Fk.contains(a));
  this.g.info("Starting logging for sessionId=" + a);
  this.Fk.add(a);
  this.ad.then(function(a) {
    a.Ge(3220);
  });
  RC.W().pi(a);
  this.q2(a);
};
d.si = function(a) {
  if (this.Fk.contains(a)) {
    this.g.info("Stopping logging for sessionId=" + a);
    this.Fk.remove(a);
    this.ad.then(function(a) {
      a.Ge(3221);
    });
    var b = this.fv.contains(a);
    this.fv.remove(a);
    b ? (this.g.info("Uploading logs for " + a), this.ad.then(function(a) {
      a.Ge(2494);
    }), this.zC ? (this.g.info("################# Save #################"), b = RC.W().Mca(a, this.zC).then(function() {
      this.ad.then(function(a) {
        a.Ge(2495);
      });
    }, function() {
      this.ad.then(function(a) {
        a.Ge(2496);
      });
    }, this)) : (this.g.l("Failed to upload beacause of missing user identifier."), b = Xd())) : b = Xd();
    var c = this.SJ();
    ae([b, c]).Um(function() {
      RC.W().si(a);
    }, this);
  } else {
    this.g.info("Skipping stopLogging call for sessionId=" + a + " as logging is not active for this session.");
  }
};
d.Xm = function(a) {
  this.g.info("Log upload requested for sessionId=" + a);
  this.fv.add(a);
  this.Pl ? this.PA() : this.Gf && this.Gf.then(this.PA, void 0, this);
};
d.q2 = function(a) {
  this.Pl || this.Gf || (this.g.info("Requesting native WebRTC logging for sessionId=" + a), this.Gf = Gq.W().pi(a).then(function() {
    this.Pl = !0;
    this.At = a;
    this.g.info("Native WebRTC logging started for sessionId=" + a);
  }, function(b) {
    this.g.l("Native WebRTC logging failed to start for sessionId=" + a + ", error: " + b);
    throw b;
  }, this).Um(function() {
    this.Gf = null;
  }, this), this.fv.contains(a) && this.Gf.then(function() {
    this.PA();
  }, void 0, this));
};
d.SJ = function() {
  if (this.oq) {
    return this.oq;
  }
  if (!this.Pl) {
    return Xd();
  }
  if (this.Gf) {
    return this.Gf.then(function() {
      this.SJ();
    }, void 0, this);
  }
  if (!this.Fk.Bb()) {
    return this.g.info("Ignoring native WebRTC logging stop request due to active session ids=" + this.Fk.H()), Xd();
  }
  x(null != this.At);
  this.g.info("Stopping native WebRTC logging.");
  return this.oq = Gq.W().si(this.At, this.UB).then(function() {
    this.g.info("Request to stop native WebRTC logging succeeded");
  }, function(a) {
    this.g.l("Request to stop native WebRTC logging failed with error=" + a);
    throw a;
  }, this).Um(function() {
    this.Pl = !1;
    this.oq = this.At = null;
  }, this);
};
d.PA = function() {
  this.UB || (this.g.info("Requesting upload of the native WebRTC logs"), this.UB = !0, Gq.W().ev().then(function() {
    this.g.info("Native uploadLogOnRenderClose succeeded.");
  }, function(a) {
    this.g.l("Native uploadLogOnRenderClose failed with error=" + a);
    throw a;
  }, this));
};
var aE = function(a, b) {
  this.g = new TD("realtime.media.api.webrtc.PeerConnection");
  this.ka = this.QT(a, b);
};
d = aE.prototype;
d.QT = function(a, b) {
  var c = {iceServers:[{url:"stun:stun.l.google.com:19302"}, {url:"stun:stun1.l.google.com:19302"}, {url:"stun:stun2.l.google.com:19302"}, {url:"stun:stun3.l.google.com:19302"}, {url:"stun:stun4.l.google.com:19302"}], bundlePolicy:"max-bundle"};
  if (ci) {
    return a = {mandatory:{RtpDataChannels:!0, DtlsSrtpKeyAgreement:a}, optional:[{googHighStartBitrate:!0}, {googHighBitrate:!0}, {googPayloadPadding:!0}, {googSkipEncodingUnusedStreams:!0}, {googScreencastMinBitrate:400}, {googVeryHighBitrate:!0}]}, b ? (a.optional.push({googCpuOveruseDetection:!0}), a.optional.push({googCpuOveruseEncodeUsage:!0}), a.optional.push({googCpuUnderuseThreshold:55}), a.optional.push({googCpuOveruseThreshold:85})) : a.optional.push({googCpuOveruseDetection:!1}), this.g.info("Creating new PeerConnection with config=" + 
    ef(c) + " constraints=" + ef(a)), new webkitRTCPeerConnection(c, a);
  }
  if (Zh) {
    return this.g.info("Creating new PeerConnection with config=" + ef(c)), new RTCPeerConnection(c);
  }
  Xa();
};
d.createDataChannel = function(a) {
  var b;
  ci && (b = {reliable:!1});
  return this.ka.createDataChannel(a, b);
};
d.signalingState = function() {
  return this.ka.signalingState;
};
d.iceConnectionState = function() {
  return this.ka.iceConnectionState;
};
d.close = function() {
  this.ka.close();
  this.ka.onicecandidate = null;
  this.ka.oniceconnectionstatechange = null;
  this.ka.onaddstream = null;
  this.ka.onremovestream = null;
  this.ka.ondatachannel = null;
};
d.addStream = function(a) {
  ci ? this.ka.addStream(a) : y(a.getTracks(), function(b) {
    this.ka.addTrack(b, a);
  }, this);
};
d.removeStream = function(a) {
  if (ci) {
    this.ka.removeStream(a);
  } else {
    var b = !1;
    y(a.getTracks(), function(a) {
      y(this.ka.getSenders(), function(c) {
        c.track.id == a.id && (this.ka.removeTrack(c), b = !0);
      }, this);
    }, this);
    x(b, "Could not find sender for the given stream.");
  }
};
d.createOffer = function(a) {
  a = a || bE();
  var b = H();
  if (ci) {
    return this.ka.createOffer(function(a) {
      b.resolve(a);
    }, function(a) {
      b.reject(a);
    }, a), b.promise;
  }
  Zh ? b.resolve(this.ka.createOffer(a)) : b.reject("Unsupported platform");
  b.promise.jb(function(a) {
    this.g.error("createOffer Failed: " + a);
    throw a;
  }, this);
  return b.promise;
};
d.createAnswer = function() {
  var a = H();
  if (ci) {
    return this.ka.createAnswer(function(b) {
      a.resolve(b);
    }, function(b) {
      a.reject(b);
    }), a.promise;
  }
  Zh ? a.resolve(this.ka.createAnswer()) : a.reject("Unsupported platform");
  a.promise.jb(function(a) {
    this.g.error("createAnswer Failed: " + a);
    throw a;
  }, this);
  return a.promise;
};
var bE = function() {
  if (ci) {
    return {mandatory:{OfferToReceiveAudio:!0, OfferToReceiveVideo:!0}};
  }
  if (Zh) {
    return {Lpa:1, Mpa:1};
  }
  Xa();
  return {};
};
d = aE.prototype;
d.getStats = function() {
  var a = H();
  ci ? this.ka.getStats(function(b) {
    a.resolve(b);
  }) : Zh ? a.resolve(this.ka.getStats()) : a.reject("Unsupported platform");
  return a.promise;
};
d.addIceCandidate = function(a) {
  var b = H();
  ci ? this.ka.addIceCandidate(a, function() {
    b.resolve();
  }, function(a) {
    b.reject(a);
  }) : Zh ? b.resolve(this.ka.addIceCandidate(a)) : b.reject("Unsupported platform");
  b.promise.jb(function(a) {
    this.g.l("addIceCandidate Failed: " + a);
    throw a;
  }, this);
  return b.promise;
};
d.setLocalDescription = function(a) {
  var b = H();
  ci ? this.ka.setLocalDescription(a, function() {
    b.resolve();
  }, function(a) {
    b.reject(a);
  }) : Zh ? b.resolve(this.ka.setLocalDescription(a)) : b.reject("Unsupported platform");
  b.promise.jb(function(b) {
    this.g.l("setLocalDescription Failed: " + b);
    this.g.l("The current signalingState is : " + this.signalingState());
    this.g.l("The offending SDP was: \n" + a.sdp);
    throw b;
  }, this);
  return b.promise;
};
d.setRemoteDescription = function(a) {
  var b = H();
  ci ? this.ka.setRemoteDescription(a, function() {
    b.resolve();
  }, function(a) {
    b.reject(a);
  }) : Zh ? b.resolve(this.ka.setRemoteDescription(a)) : b.reject("Unsupported platform");
  b.promise.jb(function(b) {
    this.g.l("setRemoteDescription Failed: " + b);
    this.g.l("The current signalingState is : " + this.signalingState());
    this.g.l("The offending SDP was: \n" + a.sdp);
    throw b;
  }, this);
  return b.promise;
};
d.getLocalStreams = function() {
  return this.ka.getLocalStreams();
};
var cE = function() {
  this.g = new TD("realtime.media.api.webrtc.Utils");
  this.Ta = new wr;
  this.xA = new Kr(16, !1);
  this.tr = {};
  this.X1();
  this.S0();
}, dE = new I({neon:1, sse2:2, ssse3:4, sse4_1:8, sse4_2:16, avx:32});
d = cE.prototype;
d.Go = function() {
  var a = new Jv;
  a.G$(this.NY());
  a.H$(Nq);
  a.S8(this.cW());
  a.U8(ck);
  this.SI() ? a.JM("ARM") : (a.k9(6), a.m9(14), a.JM("GenuineIntel"), a.l9(this.c5(this.tr)), a.qB(this.tr.numOfProcessors));
  return a;
};
d.cW = function() {
  var a = "Other";
  cc ? a = "Opera" : dc ? a = "Internet Explorer" : Zh ? a = "Firefox" : ci ? a = "Chrome" : di && (a = "Safari");
  return a;
};
d.NY = function() {
  var a = "other";
  lc ? a = "windows" : kc ? a = -1 != jc.indexOf("Intel") ? "mac" : "mac-ppc" : 0 <= Vb.indexOf("CrOS") ? a = "cros" : mc && (a = "linux");
  return a;
};
d.createOffer = function(a, b, c) {
  var e = this.HV(!!b), f = null;
  b || (f = [(new Sp).JC("AES_CM_128_HMAC_SHA1_80").FC(this.FV(128, 112)).KC(1).S()]);
  b = this.RV();
  a = this.v_(a);
  c = this.FW(!!c);
  return new Uq(b, a, c, void 0, null, e, f);
};
d.RV = function() {
  var a = [(new oq).La("a").hd(103).hc("ISAC").Xe(0).Md(16000).Ld(1).S(), (new oq).La("a").hd(111).hc("opus").Xe(0).Md(48000).Ld(2).S(), (new oq).La("a").hd(0).hc("PCMU").Xe(64000).Md(8000).Ld(1).S(), (new oq).La("a").hd(8).hc("PCMA").Xe(64000).Md(8000).Ld(1).S(), (new oq).La("a").hd(106).hc("CN").Xe(0).Md(32000).Ld(1).S(), (new oq).La("a").hd(105).hc("CN").Xe(0).Md(16000).Ld(1).S(), (new oq).La("a").hd(13).hc("CN").Xe(0).Md(8000).Ld(1).S(), (new oq).La("a").hd(126).hc("telephone-event").Xe(0).Md(8000).Ld(1).S()], 
  b = [(new Up).kn("urn:ietf:params:rtp-hdrext:ssrc-audio-level").en(1).La("a").S(), (new Up).kn("http://www.webrtc.org/experiments/rtp-hdrext/abs-send-time").en(3).La("a").S()];
  return new wq("a", a, b);
};
d.v_ = function(a) {
  var b = [(new oq).La("v").hd(100).hc("VP8").Xe(400).Md(30).Ld(640).S(), (new oq).La("v").hd(96).hc("rtx").Md(90000).Ld(1).S()];
  a && b.push((new oq).La("v").hd(97).hc("H264").Xe(400).Md(30).Ld(640).S());
  a = [(new Up).kn("urn:ietf:params:rtp-hdrext:toffset").en(2).La("v").S(), (new Up).kn("http://www.webrtc.org/experiments/rtp-hdrext/abs-send-time").en(3).La("v").S()];
  return new wq("v", b, a);
};
d.FW = function(a) {
  var b = new wq("d", [], []);
  a ? (a = (new Wp).rv(5000).hc("webrtc-datachannel").GC(256).cda(10000).S(), b = b.hn(a)) : (a = [(new oq).La("d").hd(101).hc("google-data").S()], b = b.zi(a));
  return b;
};
d.HV = function(a) {
  var b = Fj(this.dy(12)), c = Fj(this.dy(18)), b = new rq("ICE", b, c);
  a && (b = b.vP("fingerprint:sha-256 00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00"));
  return b;
};
d.FV = function(a, b) {
  a = this.dy(Math.ceil((a + b) / 8));
  return "inline:" + Fj(a);
};
d.dy = function(a) {
  try {
    return this.xA.AH(a);
  } catch (b) {
    return this.g.l("Forced to collect entropy the slow way. This indicates a failure in js.crypto.random."), this.xA.tT(), this.xA.AH(a);
  }
};
d.SO = function(a) {
  Gq.W().lo(u(function(b) {
    b && a && a(b);
  }, this));
};
d.SI = function() {
  return -1 != jc.indexOf("armv7l");
};
d.c5 = function(a) {
  if (null == a) {
    return this.g.l("Cannot get cpuFlags from null."), -1;
  }
  var b = a.features;
  if (b) {
    var c = 0;
    y(b, function(a) {
      c |= dE.get(a, 0);
    });
    return c;
  }
  return a.cpuHasSSE2 ? 2 : -1;
};
d.S0 = function() {
  this.SO(u(function(a) {
    a && this.e8(a);
  }, this));
};
d.e8 = function(a) {
  this.tr = a;
  this.Baa("scp", a);
};
d.X1 = function() {
  var a = this.d2("scp", u(this.JW, this));
  a && (this.tr = a);
};
d.JW = function() {
  return this.SI() ? {archName:"armv7l", modelName:"Unknown ARM device", numOfProcessors:2} : {archName:"x86", modelName:"Unknown x86 device", numOfProcessors:4};
};
d.Baa = function(a, b) {
  this.Ta.isAvailable() ? this.Ta.set(a, ef(b)) : this.g.error("Error in saving " + a + " to local storage.");
};
d.d2 = function(a, b) {
  var c = null;
  if (this.Ta.isAvailable()) {
    a = this.Ta.get(a);
    var e = null != a;
    try {
      c = df(a);
    } catch (f) {
      e = !1;
    }
    !e && b && (c = b());
  } else {
    this.g.error("Error in retrieving cpu info from local storage.");
  }
  return c;
};
var eE = function(a) {
  this.Zh = a;
};
w(eE, Hp);
d = eE.prototype;
d.hg = function(a) {
  return new RD("hangout_participants/add", function() {
    var b = new Kz;
    b.ra(a);
    return b;
  }, function(a) {
    return a.M();
  });
};
d.ig = function(a) {
  return new RD("hangout_participants/modify", function() {
    var b = new Qz;
    b.ra(a);
    return b;
  }, function(a) {
    return a.M();
  });
};
d.gf = function(a, b) {
  var c = b && b.jYdIne || 0;
  return new RD("hangout_participants/remove", function() {
    var b = new Wz;
    b.ra(a);
    b.Wp(c);
    return b;
  });
};
d.qh = function(a) {
  return new RD("hangout_participants/query", function() {
    var b = new Tz;
    b.L(a.O());
    b.Sa(a.A());
    return b;
  }, function(a) {
    return [a.De()];
  });
};
d.rh = function(a) {
  return new RD("hangout_participants/search", function() {
    var b = new Yz;
    b.L(a.O());
    return b;
  }, function(a) {
    return a.vs();
  }, wD.prototype.L9, yD.prototype.RG);
};
var fE = function(a) {
  this.Zh = a;
};
w(fE, Hp);
d = fE.prototype;
d.hg = function(a) {
  return new RD("hangouts/add", function() {
    var b = new xz;
    b.ra(a);
    return b;
  }, function(a) {
    return a.M();
  });
};
d.ig = function(a) {
  return new RD("hangouts/modify", function() {
    var b = new Gz;
    b.ra(a);
    return b;
  }, function(a) {
    return a.M();
  });
};
d.gf = function() {
  return null;
};
d.qh = function(a) {
  return new RD("hangouts/query", function() {
    var b = new kA;
    b.L(a.O());
    return b;
  }, function(a) {
    return [a.sf()];
  }, wD.prototype.M9, yD.prototype.TG);
};
d.rh = function(a) {
  return this.qh(a);
};
var gE = function(a) {
  this.Zh = a;
};
w(gE, xp);
gE.prototype.hg = function(a) {
  return new RD("media_sessions/add", function() {
    var b = new TC;
    b.ra(a);
    return b;
  }, function(a) {
    return a.M();
  });
};
gE.prototype.ig = function(a) {
  return new RD("media_sessions/modify", function() {
    var b = new ZC;
    b.ra(a);
    return b;
  }, function(a) {
    return a.M();
  });
};
gE.prototype.gf = function() {
  return null;
};
var hE = function(a) {
  this.Zh = a;
};
w(hE, Hp);
d = hE.prototype;
d.hg = function(a) {
  return new RD("media_sources/add", function() {
    var b = new CA;
    b.ra(a);
    return b;
  }, function(a) {
    return a.M();
  });
};
d.ig = function(a) {
  return new RD("media_sources/modify", function() {
    var b = new IA;
    b.ra(a);
    return b;
  }, function(a) {
    return a.M();
  });
};
d.gf = function() {
  return null;
};
d.qh = function(a) {
  return new RD("media_sources/query", function() {
    var b = new MA;
    b.L(a.O());
    b.Sa(a.A());
    b.Qf(a.ya());
    return b;
  }, function(a) {
    return [a.K()];
  });
};
d.rh = function(a) {
  return new RD("media_sources/search", u(function() {
    var b = new OA;
    b.L(a.O());
    return b;
  }, this), function(a) {
    return a.Do();
  }, wD.prototype.j$, yD.prototype.hH);
};
var iE = function(a) {
  this.Zh = a;
};
w(iE, Hp);
d = iE.prototype;
d.hg = function(a) {
  return new RD("media_streams/add", function() {
    var b = new YB;
    b.ra(a);
    return b;
  }, function(a) {
    return a.M();
  });
};
d.ig = function(a) {
  return new RD("media_streams/modify", function() {
    var b = new dC;
    b.ra(a);
    return b;
  }, function(a) {
    return a.M();
  });
};
d.gf = function() {
  return null;
};
d.qh = function(a) {
  return new RD("media_streams/query", function() {
    var b = new fB;
    b.L(a.O());
    b.oe(a.jc());
    b.Ca(a.s());
    b.lk(a.Vb());
    return b;
  }, function(a) {
    return [a.ib()];
  });
};
d.rh = function(a) {
  return new RD("media_streams/search", u(function() {
    var b = new gB;
    b.L(a.O());
    b.Ca(a.s());
    b.oe(a.jc());
    return b;
  }, this), function(a) {
    return a.Do();
  }, wD.prototype.k$, yD.prototype.jH);
};
var jE = function(a) {
  G.call(this);
  this.Fu = a;
  this.B = new tk(this);
  this.la(this.B);
};
w(jE, G);
var kE = function(a) {
  this.g = new TD("realtime.media.api.webrtc.DataPointManager");
  this.Lj = a;
  this.hJ = new Wq;
  this.Zo = -1;
  this.w2 = new fz;
  this.kj = new wp;
  this.Tca = new cE;
  this.Oi = null;
};
d = kE.prototype;
d.rba = function() {
  this.Oi || (this.Oi = Gq.W().mo()) && this.Oi.onMessage.addListener(u(this.kj.BR, this.kj));
};
d.Eba = function() {
  this.Oi && (this.Oi.disconnect(), this.Oi = null);
};
d.KT = function(a, b, c) {
  var e = new Iy;
  y(a.result(), function(a) {
    a.timestamp && 0 < a.timestamp.getTime() && this.kj.K6(a.timestamp);
    switch(a.type) {
      case "ssrc":
        this.km(this.OA(a), b, e);
        break;
      case "VideoBwe":
        this.O4(this.OA(a), e);
        break;
      case "googCandidatePair":
        this.T4(this.OA(a), e);
    }
  }, this);
  this.Tca.SO(u(this.o3, this, e, c));
};
d.o3 = function(a, b, c) {
  var e = this.h5(a);
  3 != e ? this.g.error("Uncompatible version number: " + e) : (this.kj.FR(c), c = this.kj.HU(), 0 > c || (a.paa(Math.round(c)), this.Zo >= c && this.g.l("Elapsed time in jmidata decreased from " + this.Zo + " to " + c), this.Zo = c, this.kj.hT(), b(a)));
};
d.h5 = function(a) {
  var b = this.kj.toJson();
  if (null == b) {
    return 0;
  }
  t(b.tabCpuUsage) && a.U$(Math.round(b.tabCpuUsage));
  t(b.browserCpuUsage) && a.T8(Math.round(b.browserCpuUsage));
  t(b.gpuCpuUsage) && a.J9(Math.round(b.gpuCpuUsage));
  t(b.pluginCpuUsage) && a.Taa(Math.round(b.pluginCpuUsage));
  t(b.totalCpuUsage) && a.Gaa(Math.round(b.totalCpuUsage));
  t(b.numOfProcessors) && a.qB(Math.round(b.numOfProcessors));
  return this.MY(b.jmiVersion);
};
d.km = function(a, b, c) {
  this.w2.g6(a, b, this.Lj);
  this.g.w("SSRC: " + ef(a));
  if (null != a) {
    b = null !== a && "audioInputLevel" in a || null !== a && "audioOutputLevel" in a;
    var e = null !== a && "bytesSent" in a, f = new Qy;
    this.C5(a, f, e, b);
    b ? this.N4(a, f, e) : this.I5(a, f, e);
    this.Aca(a, f, e, b);
    this.wD(c, f);
  }
};
d.C5 = function(a, b, c, e) {
  b.kN(e ? 1 : 2);
  b.oe(c ? 0 : 1);
  t(a.ssrc) && (b.GB(a.ssrc), b.zaa([a.ssrc]));
  b.tB(Math.round(sp(a.fractionLost)));
  b.LM(Math.round(sp(a.packetsLost)));
  b.hN(Math.round(sp(a.highestSequenceNumber)));
  b.bN(Math.round(sp(a.googJitterReceived)));
  b.$p(Math.round(sp(a.googRtt)));
  b.EM(Math.round(sp(a.bytesSent)));
  b.xN(Math.round(sp(a.packetsSent)));
  b.DM(Math.round(sp(a.bytesReceived)));
  b.wN(Math.round(sp(a.packetsReceived)));
  c ? null != a.googCodecName && b.raa(a.googCodecName) : (null != a.googCodecName && b.W$(a.googCodecName), t(a.oneWayDelayMs) && b.C$(Math.round(a.oneWayDelayMs)), t(a.oneWayMaxDelayMs) && b.D$(Math.round(a.oneWayMaxDelayMs)), t(a.oneWayStddevDelayMs) && b.F$(Math.round(a.oneWayStddevDelayMs)), t(a.oneWayMinDelayMs) && b.E$(Math.round(a.oneWayMinDelayMs)));
};
d.N4 = function(a, b, c) {
  c ? (t(a.aecDivergentFilterFraction) && b.L8(a.aecDivergentFilterFraction), t(a.audioInputLevel) && b.RM(Math.round(a.audioInputLevel)), t(a.googEchoCancellationEchoDelayMedian) && b.u9(Math.round(a.googEchoCancellationEchoDelayMedian)), t(a.googEchoCancellationEchoDelayStdDev) && b.v9(Math.round(a.googEchoCancellationEchoDelayStdDev)), t(a.googEchoCancellationReturnLoss) && b.w9(Math.round(a.googEchoCancellationReturnLoss)), t(a.googEchoCancellationReturnLossEnhancement) && b.x9(Math.round(a.googEchoCancellationReturnLossEnhancement)), 
  t(a.googEchoCancellationQualityMin) && b.t9(a.googEchoCancellationQualityMin), t(a.googResidualEchoLikelihood) && b.faa(a.googResidualEchoLikelihood)) : (t(a.audioOutputLevel) && b.RM(Math.round(a.audioOutputLevel)), t(a.googPreferredJitterBufferMs) && b.R$(Math.round(a.googPreferredJitterBufferMs)), t(a.googCurrentDelayMs) && b.Paa(Math.round(a.googCurrentDelayMs)), t(a.googExpandRate) && b.B9(a.googExpandRate), t(a.googSpeechExpandRate) && b.xaa(a.googSpeechExpandRate), t(a.googPreemptiveExpandRate) && 
  b.Q$(a.googPreemptiveExpandRate), t(a.googAccelerateRate) && b.I8(a.googAccelerateRate), t(a.googSecondaryDecodedRate) && b.oaa(a.googSecondaryDecodedRate), t(a.googDecodingCTSG) && b.t$(Math.round(a.googDecodingCTSG)), t(a.googDecodingCTN) && b.s$(Math.round(a.googDecodingCTN)), t(a.googDecodingNormal) && b.v$(Math.round(a.googDecodingNormal)), t(a.googDecodingPLC) && b.w$(Math.round(a.googDecodingPLC)), t(a.googDecodingCNG) && b.u$(Math.round(a.googDecodingCNG)), t(a.googDecodingPLCCNG) && b.x$(Math.round(a.googDecodingPLCCNG)));
};
d.Aca = function(a, b, c) {
  a = this.hJ.zca(a, this.Zo, c);
  null != a && (b.tB(a.i2), c ? b.WN(a.XD) : b.Z$(a.XD));
};
d.I5 = function(a, b, c) {
  c ? (t(a.googFirsReceived) && b.VM(Math.round(a.googFirsReceived)), t(a.googNacksReceived) && b.oN(Math.round(a.googNacksReceived)), t(a.googFrameRateInput) && b.WM(Math.round(a.googFrameRateInput)), t(a.googFrameRateSent) && b.XM(Math.round(a.googFrameRateSent)), t(a.googFrameWidthSent) && b.mk(Math.round(a.googFrameWidthSent)), t(a.googFrameHeightSent) && b.ik(Math.round(a.googFrameHeightSent)), t(a.googQpSent) && b.CN(Math.round(a.googQpSent)), t(a.googAdaptationChanges) && b.K8(Math.round(a.googAdaptationChanges)), 
  t(a.googAvgEncodeMs) && b.Q8(Math.round(a.googAvgEncodeMs))) : (t(a.googFirsSent) && b.VM(Math.round(a.googFirsSent)), t(a.googNacksSent) && b.oN(Math.round(a.googNacksSent)), t(a.googFrameRateOutput) && b.WM(Math.round(a.googFrameRateOutput)), t(a.googFrameRateReceived) && b.XM(Math.round(a.googFrameRateReceived)), t(a.googFrameRateDecoded) && b.F9(Math.round(a.googFrameRateDecoded)), t(a.fpsGraphicsInput) && b.G9(a.fpsGraphicsInput), t(a.fpsGraphicsOutput) && b.H9(a.fpsGraphicsOutput), t(a.googFrameWidthReceived) && 
  b.mk(Math.round(a.googFrameWidthReceived)), t(a.googFrameHeightReceived) && b.ik(Math.round(a.googFrameHeightReceived)), t(a.googQpReceived) && b.CN(Math.round(a.googQpReceived)));
  c && b.zM(this.vT(a));
};
d.vT = function(a) {
  var b = Yy.QC, c = lE(a.googCpuLimitedResolution), e = lE(a.googBandwidthLimitedResolution);
  a = lE(a.googViewLimitedResolution);
  null != c && null != e && null != a && (c && (b |= Yy.PC), e && (b |= Yy.OC), a && (b |= Yy.RC));
  return b;
};
d.T4 = function(a, b) {
  this.g.w("CandidatePair: " + ef(a));
  if (null != a) {
    var c = b.zG(), e = new Ry;
    e.$p(Math.round(sp(a.googRtt)));
    e.Oaa(Math.round(sp(a.bytesSent)));
    t(a.packetsSent) && e.Maa(Math.round(a.packetsSent));
    t(a.packetsDiscardedOnSend) && e.Laa(Math.round(a.packetsDiscardedOnSend));
    e.Naa(Math.round(sp(a.bytesReceived)));
    e.D9(this.xT(a));
    var f = new mv, g = new mv;
    this.S4(a, f, g);
    e.baa(f);
    e.aaa(g);
    e.ru(f.ib());
    a = this.hJ.rca(a, this.Zo);
    e.W8(a ? a.z8 : -1);
    e.V8(a ? a.M6 : -1);
    c.push(e);
    b.i9(c);
  }
};
d.xT = function(a) {
  var b = 0;
  "true" == a.googActiveConnection && (b |= 1);
  "true" == a.googWritable && (b |= 2);
  "true" == a.googReadable && (b |= 4);
  return b;
};
d.S4 = function(a, b, c) {
  b.$M(a.googLocalAddress || "");
  c.$M(a.googRemoteAddress || "");
  var e = a.googChannelId, f = 0;
  Da(e, "Channel-audio-") ? f = 1 : Da(e, "Channel-video-") && (f = 2);
  b.kk(f);
  c.kk(f);
  e = {local:1, stun:2, relay:3};
  b.ru(e[a.googLocalCandidateType] || 0);
  c.ru(e[a.googRemoteCandidateType] || 0);
  a = {udp:1, tcp:2, ssltcp:3}[a.googTransportType] || 0;
  b.Yp(a);
  c.Yp(a);
};
d.O4 = function(a, b) {
  this.g.w("Bwe: " + ef(a));
  if (null != a) {
    var c = new Qy;
    c.kN(2);
    c.oe(2);
    t(a.googAvailableSendBandwidth) && c.P8(Math.round(a.googAvailableSendBandwidth));
    t(a.googAvailableReceiveBandwidth) && c.O8(Math.round(a.googAvailableReceiveBandwidth));
    t(a.googTransmitBitrate) && c.WN(Math.round(a.googTransmitBitrate));
    t(a.googRetransmitBitrate) && c.gaa(Math.round(a.googRetransmitBitrate));
    t(a.googTargetEncBitrate) && c.Iaa(Math.round(a.googTargetEncBitrate));
    t(a.googActualEncBitrate) && c.J8(Math.round(a.googActualEncBitrate));
    t(a.googBucketDelay) && c.b$(Math.round(a.googBucketDelay));
    c.tB(-1);
    c.LM(-1);
    c.hN(-1);
    c.bN(-1);
    c.$p(-1);
    c.EM(-1);
    c.xN(-1);
    c.DM(-1);
    c.wN(-1);
    this.wD(b, c);
  }
};
d.OA = function(a) {
  var b = {};
  y(a.names(), function(c) {
    var e = a.stat(c);
    null != e && (isNaN(e) || p(e) && Ga(e) || (e = Number(e)));
    b[c] = e;
  });
  return b;
};
d.wD = function(a, b) {
  b = b || new Qy;
  var c = a.Eh();
  c.push(b);
  a.i$(c);
  return b;
};
d.MY = function(a, b) {
  return t(a) ? a : l(b) ? b : -1;
};
var lE = function(a) {
  return "true" != a && "false" != a ? null : "true" == a;
};
var mE = function() {
  G.call(this);
  this.a = zf("realtime.pushnotifications.Dispatcher");
};
w(mE, G);
new M("GNN9hf");
var nE = [{lc:AD.prototype.gH, eventType:"Wa"}, {lc:AD.prototype.kH, eventType:"Ya"}, {lc:AD.prototype.UG, eventType:"Ta"}, {lc:AD.prototype.SG, eventType:"Ua"}, {lc:AD.prototype.iH, eventType:"Xa"}, {lc:AD.prototype.fG, eventType:"Pa"}, {lc:AD.prototype.QG, eventType:"Qa"}, {lc:AD.prototype.sG, eventType:"Ra"}, {lc:AD.prototype.zH, eventType:"db"}, {lc:AD.prototype.yG, eventType:"Sa"}, {lc:AD.prototype.lH, eventType:"Za"}], oE = [{lc:qC.prototype.JG, eventType:"$a"}, {lc:qC.prototype.nH, eventType:"ab"}, 
{lc:qC.prototype.DH, eventType:"bb"}, {lc:qC.prototype.RH, eventType:"cb"}];
mE.prototype.e0 = function(a) {
  a = yp(a);
  a = new VD(a);
  this.H_(a);
};
mE.prototype.H_ = function(a) {
  a = a.Wx();
  K(this.a, "handlePushNotification invoked, batch size: " + a.length);
  y(a, this.K_, this);
};
mE.prototype.K_ = function(a) {
  var b = a.Vx(), c, e;
  if (null != b) {
    for (a = 0;a < nE.length;a++) {
      if (e = nE[a].lc.call(b), null != e) {
        if ("Za" == nE[a].eventType) {
          for (var f = e, g = oE, k = 0;k < nE.length;k++) {
            if (e = g[k].lc.call(f), null != e) {
              c = g[k].eventType;
              break;
            }
          }
        } else {
          c = nE[a].eventType;
          break;
        }
      }
    }
  } else {
    b = a.WG(), null != b && (e = b.VG(), null != e && (c = "Va"));
  }
  x(null == e || null != c, "eventType must be set ifnotification is set");
  null != e ? (K(this.a, "Received notification of type " + c + "."), this.dispatchEvent(new pE(c, e))) : J(this.a, "A batch notification is empty.");
};
var pE = function(a, b) {
  F.call(this, a);
  this.notification = b;
};
w(pE, F);
var qE = function(a, b, c, e, f) {
  G.call(this);
  this.g = new TD("realtime.media.api.webrtc.PeerController");
  this.Oca = e.jP;
  this.Zm = e.Zm;
  this.C = a;
  this.ll = b;
  this.zp = e.zp;
  this.Ol = e.vC;
  this.vw = l(f) ? f : 3;
  this.pba = new br;
  this.Ia = new tk(this);
  this.la(this.Ia);
  this.me = this.I = null;
  this.pq = {};
  this.CL = [];
  this.Qt = [];
  this.Lj = c;
  this.Uw = new kE(this.Lj);
  this.kP = {};
  this.$o = v();
  this.oJ = 0;
  this.Fe = !1;
  this.$u = 1;
  this.Lk = {};
  this.It = {};
  this.remoteDescription = this.localDescription = null;
  this.qq = {};
  this.Br = new I;
  this.cF = new I;
  this.kM = new Ru;
  this.jM = new xy;
  this.av = null;
  this.kb = [];
  this.Fi = null;
  this.Pt = !1;
  this.ac = null;
  this.q7 = 0;
  this.ui = null;
};
w(qE, G);
var rE = null, sE = null, tE = !ci || 0 <= Ta(ck, 40) ? 100 : 200;
d = qE.prototype;
d.toString = function() {
  return "PeerController(sessionId=" + this.C + ")";
};
d.ja = function(a) {
  this.g.info("[" + this + "] " + a);
};
d.Kc = function(a) {
  this.g.l("[" + this + "] " + a);
};
d.nz = function(a) {
  this.g.error("[" + this + "] " + a);
};
d.stopSession = function(a) {
  this.I && (this.PO(), this.I.close(), this.I = null);
  this.me && (this.me.close(), this.me = null);
  this.ac && (this.ac.cancel(), this.ac = null);
  this.Fi && (this.Fi.stop(), this.Pt = !1, this.$o = 0, this.dispatchEvent(new uE(a)));
  this.Uw.Eba();
  for (var b in this.qq) {
    this.qq[b].pb.promise.then(window.URL.revokeObjectURL);
  }
  this.Ew(0);
};
d.Uh = function(a) {
  this.kP[a] || (this.kP[a] = !0, this.dispatchEvent(new vE(this.C, a)));
};
d.Kz = function(a) {
  null != a && (this.ja("Got local candidate: " + a.candidate), a = this.kM.Q4(a), x(null != a), this.dispatchEvent(new wE(this.C, [a])), a = a.N(), this.Uh("send candidate " + a));
};
d.BG = function(a) {
  this.ja("Calling createOffer for credentials");
  var b = bE();
  a && (b.IceRestart = !0);
  return this.I.createOffer(b).then(function(a) {
    this.ja("createOffer for credentials successfully completed");
    a = this.kM.parse(x(a.sdp));
    this.ui = x(a.kc());
    this.dispatchEvent(new xE(this.C, this.ui.wi, this.ui.di));
  }, function(a) {
    this.ja("createOffer for credentials failed with error=" + a);
    throw a;
  }, this);
};
d.V2 = function(a) {
  x(null != a);
  x(null != this.remoteDescription);
  var b = a.getAudioTracks(), c = a.getVideoTracks(), e = a.id;
  this.ja("Remote stream added with id=" + a.id + " audioTracks=" + b.length + " videoTracks=" + c.length);
  var f = function(a) {
    return a.He == e;
  };
  jb(this.remoteDescription.ma.lb(), f) || jb(this.remoteDescription.ha.lb(), f) ? 0 < b.length ? this.zp ? (x(0 == c.length), this.ja("Creating audio output for stream id=" + e), a = new Pr(this.ll, a), this.Lk[e] = a, (b = this.UV(this.remoteDescription, e)) ? (this.pq[e] = b, this.Lj.I6(b, a)) : this.Kc("Participant left before their audio was added")) : this.ja("Ignoring incoming audio track as audio output is disabled.") : (x(0 < c.length), b = Pb(this.qq, e, {pb:H(), PF:!1}), a = window.URL.createObjectURL(a), 
  this.ja("Creating video url for stream id=" + e + " url=" + a), b.pb.resolve(a), b.PF = !0) : this.ja("Ignoring incoming tracks with no matching msid.");
};
d.r4 = function(a) {
  if (null != a) {
    var b = a.id;
    if (0 < a.getAudioTracks().length) {
      var c = this.Lk[b];
      if (null != c) {
        var e = this.pq[b];
        e && (delete this.pq[b], this.Lj.vL(e, c));
        Sc(c);
        delete this.Lk[b];
      } else {
        this.Kc("Audio stream was deleted before removal.");
      }
    }
    0 < a.getVideoTracks().length && (a = this.qq[b], delete this.qq[b], null != a ? a.PF ? this.Kc("Asked to remove stream that was never added.") : a.pb.promise.then(window.URL.revokeObjectURL) : this.Kc("Video stream was deleted before removal."));
  } else {
    this.Kc("Stream remove handler called with null stream.");
  }
};
d.ld = function(a) {
  this.ja("Adding capture=" + a);
  x(this.localDescription);
  var b = this.kb;
  pb(b, a) || b.push(a);
  this.Ia.listen(a, "W", this.kI);
  return (b = a.ib(this.C)) ? this.UO(b, a.K().N()) : this.cH(a.K().N());
};
d.je = function(a) {
  this.ja("Removing capture=" + a);
  var b = a.ib(this.C);
  this.ML(b);
  ub(this.kb, a);
  this.Ia.Fc(a, "W", this.kI);
};
d.fY = function(a, b) {
  return mb(a.lb(), function(a) {
    return a.ya() == b;
  });
};
d.kI = function(a) {
  a = a.target;
  var b = a.ib(this.C);
  b && this.UO(b, a.K().N());
};
d.vD = function(a, b) {
  var c, e, f;
  switch(b) {
    case "a":
      c = a.getAudioTracks();
      e = this.localDescription.ma;
      f = "1";
      break;
    case "v":
      c = a.getVideoTracks();
      e = this.localDescription.ha;
      f = "2";
      break;
    default:
      return this.nz("Unsupported media type encountered."), null;
  }
  if (null == e) {
    return this.Kc("MediaDescription cannot be null."), null;
  }
  a = (new zq(this.fY(e, f))).gn(a.id).zP(c[0].id).S();
  this.localDescription = "a" == b ? this.localDescription.We(e.Qc([a])) : this.localDescription.qe(e.Qc([a]));
  this.ja("New streamInfo=" + a + " added to local description");
  return a;
};
d.Qv = function(a) {
  a && !this.Fe && this.I && (this.ja("Adding stream with id=" + a.id + " to peer"), this.I.addStream(a));
};
d.ML = function(a) {
  a && this.I && (this.ja("Removing stream with id=" + a.id + " to peer"), this.I.removeStream(a));
};
d.UO = function(a, b) {
  b = this.vD(a, b);
  this.Qv(a);
  this.MA();
  return b;
};
d.vba = function() {
  this.Uh("send initiate");
  this.D7();
};
d.createOffer = function(a) {
  var b = a.Zm ? rE : sE;
  null == b && (this.Kc("PeerController must be initialized prior to using it.  Using an empty local offer."), Xa("PeerController must be initialized prior to using it.  Using an empty local offer."), b = new Uq);
  var c = a.Hc();
  c && (b = b.qe(b.ha.ov(c)));
  var c = a.Aa ? [8579373] : this.ds(1), c = (new zq).La("a").Wf("1").Dk(this.Qw("1")).Ze(c).S(), e = a.xC ? 3 : 1, f = a.Aa ? [8579374] : this.ds(e), g = [];
  1 < f.length && (e = (new qq).sv("SIM").Ze(f).S(), g.push(e));
  e = !1;
  if (a.iP && (e = -1 != lb(b.ha.sc(), function(a) {
    return "rtx" == a.getName();
  }))) {
    for (var k = a.Aa ? [8579375] : this.ds(f.length), q = 0;q < k.length;q++) {
      var r = (new qq).sv("FID").Ze([f[q], k[q]]).S();
      f.push(k[q]);
      g.push(r);
    }
  }
  f = (new zq).La("v").Wf("2").Dk(this.Qw("2")).Ze(f).IC(g).S();
  g = this.ds(1);
  g = (new zq).La("d").Wf("3").Dk(this.Qw("3")).Ze(g);
  a.Aa || g.gn("dataSendChannel");
  g = g.S();
  b = this.uT(b, [c], [f], [g]);
  b = this.nV(b, e, a);
  (c = b.ma) && (b = b.We(c.zi(z(c.sc(), function(a) {
    return (new oq(a)).eda([]).S();
  }))));
  a.$m || (b = b.qe(null));
  a.wC || (b = b.Ye(null));
  return this.localDescription = b;
};
d.ds = function(a) {
  for (var b = [], c = 0;c < a;c++) {
    b.push(this.pba.XT());
  }
  return b;
};
d.uT = function(a, b, c, e) {
  null != a.ma && 0 == a.ma.lb().length && (a = a.We(a.ma.Qc(b)));
  null != a.ha && 0 == a.ha.lb().length && (a = a.qe(a.ha.Qc(c)));
  null != a.getData() && 0 == a.getData().lb().length && (a = a.Ye(a.getData().Qc(e)));
  return a;
};
d.Qw = function(a) {
  return this.C + "/" + a;
};
d.nV = function(a, b, c) {
  return Vq(a, function(a) {
    a = a.getName();
    return Ea(a, "vp8") || Ea(a, "h264-svc") || b && Ea(a, "rtx") || c.FD && Ea(a, "vp9") || c.$F() && Ea(a, "h264");
  });
};
d.cH = function(a) {
  var b;
  switch(a) {
    case "a":
      b = this.localDescription.ma;
      break;
    case "v":
      b = this.localDescription.ha;
      break;
    case "d":
      b = this.localDescription.getData();
  }
  return null != b ? b.lb()[0] : null;
};
var yE = function(a) {
  var b = new aE(a, !0), c = b.createDataChannel("sendDataChannel");
  a = b.createOffer().then(function(a) {
    c.close();
    return null != a.sdp ? (a = (new Ru).parse(a.sdp), a.Ye(a.getData().Qc([]))) : null;
  });
  a.Um(function() {
    "closed" != b.signalingState() && b.close();
  });
  return a;
}, zE = function() {
  var a = yE(!0).then(function(a) {
    rE = a;
  }), b = yE(!1).then(function(a) {
    sE = a;
  });
  return ae([a, b]).then(function(a) {
    return jb(a, ra) ? 2 : 7;
  });
};
d = qE.prototype;
d.D7 = function() {
  null != this.I && (this.PO(), this.I.close(), this.Ew(0));
  this.ja("Instantiating new peer");
  this.I = new aE(this.Zm, this.Oca);
  this.W6();
  this.$u = 1;
  this.I.ka.onicecandidate = u(function(a) {
    this.Kz(a.candidate);
  }, this);
  this.I.ka.oniceconnectionstatechange = u(this.F3, this);
  this.I.ka.onaddstream = u(function(a) {
    this.V2(a.stream);
  }, this);
  this.I.ka.onremovestream = u(function(a) {
    this.r4(a.stream);
  }, this);
  this.I.ka.ondatachannel = u(function(a) {
    this.s3(a.channel);
  }, this);
  this.me = this.I.createDataChannel("dataSendChannel");
  this.me.onopen = u(function() {
    this.ja("send datachannel is open.");
  }, this);
  this.me.onclose = u(function() {
    this.ja("send datachannel is closed.");
  }, this);
  this.me.onerror = u(function(a) {
    this.Kc("send datachannel error: " + a);
  }, this);
  this.Qt = B(this.CL);
  this.ac && this.ac.cancel();
  this.ac = this.BG();
  this.Uw.rba();
  this.Fi || (this.Fi = new he(tE), this.Ia.listen(this.Fi, "tick", this.o2), 3 == this.vw && this.Fi.start());
  y(this.kb, function(a) {
    a = a.ib(this.C);
    this.Qv(a);
  }, this);
};
d.F3 = function() {
  this.ja("ICE connection state changed to: " + this.I.iceConnectionState());
  if ("disconnected" == this.I.iceConnectionState()) {
    x(this.localDescription), this.Uh("transport not writable"), this.dispatchEvent(new AE(!1)), this.ja("Initiating ICE restart"), this.ac && this.ac.cancel(), this.ac = this.BG(), x(this.localDescription), x(this.remoteDescription), this.MA();
  } else {
    if ("connected" == this.I.iceConnectionState() || "completed" == this.I.iceConnectionState()) {
      this.Ew(2), this.Uh("transport writable"), this.dispatchEvent(new AE(!0));
    }
  }
};
d.o2 = function() {
  !this.Fi.enabled && 3 == this.vw || this.Pt || (this.Pt = !0, this.I.getStats().then(this.h6, void 0, this));
};
d.h6 = function(a) {
  this.Pt = !1;
  if (!Zh) {
    this.Rca(a);
    this.Qca(a);
    var b = v();
    10000 <= b - this.$o && (this.$o = 0 == this.$o ? b : this.$o + 10000, b = jb(this.kb, function(a) {
      return "v" == a.K().N() && !a.To();
    }), jb(this.kb, function(a) {
      return "xa" == a.K().Kb;
    }), this.Uw.KT(a, !b, u(function(a) {
      this.dispatchEvent(new BE(a));
    }, this)));
  }
};
d.UE = function(a) {
  var b = Number(a);
  a = 0 == b && Ga(a) ? NaN : b;
  x(0 <= a && 32768 >= a, "levelNum outside of valid range: " + a);
  for (var b = [2000, 4000, 10000, 19000, 22000, 32769], c = 0;b[c] <= a;) {
    ++c;
  }
  return c;
};
d.Qca = function(a) {
  var b = 0, c = new I;
  y(a.result(), function(a) {
    var e = a.stat("ssrc"), g = a.stat("audioOutputLevel");
    Ga(Pa(e)) || Ga(Pa(g)) || c.set(e, this.UE(g));
    a = a.stat("audioInputLevel");
    Ga(Pa(a)) || (b = this.UE(a));
  }, this);
  this.dispatchEvent(new Hr(this.C, b, c));
};
d.Rca = function(a) {
  var b = v();
  if (!(1000 > b - this.oJ)) {
    this.oJ = b;
    var c = b = !1;
    a = a.result();
    for (var e = 0;e < a.length;++e) {
      var f = a[e];
      if ("ssrc" == f.type) {
        var g = f.names();
        if (pb(g, "packetsReceived")) {
          var k = Number(f.stat("ssrc"));
          this.It[k] = this.It[k] || 0;
          f = Number(f.stat("packetsReceived"));
          0 >= f - this.It[k] || (this.It[k] = f, pb(g, "audioOutputLevel") ? b = !0 : pb(g, "googFrameRateReceived") && (c = !0));
        }
      }
    }
    this.dispatchEvent(new CE(b, c));
  }
};
d.UV = function(a, b) {
  return null != a.ma && (a = a.ma.lb(), a = mb(a, function(a) {
    return a.Vb() == b;
  }), null != a && (a = a.wd(), 0 != a.length)) ? (x(1 == a.length), a[0]) : null;
};
d.Nq = function(a) {
  y(a, function(a) {
    var b, e = a.Zi();
    b = a.yg();
    var f = a.xl(), g = a.Wa(), k = a.Fp, q = a.Gp, r = a.N(), A = Sb(Mp)[r], E = a.ej(), aa = a.wl();
    a = [a.co, e, b.toLowerCase(), E, f, g, "typ", A];
    switch(r) {
      case "LOCAL":
        "TCP" == b && a.push("tcptyp", "active");
        break;
      case "STUN":
      case "RELAY":
      case "PEER_REFLEX":
        a.push("raddr", k, "rport", q);
        break;
      default:
        Xa("Unexpected candidate type: " + r);
    }
    a.push("generation", aa);
    b = new RTCIceCandidate({sdpMLineIndex:0, candidate:"candidate:" + a.join(" ")});
    null != b && (this.Uh("recv candidate "), this.I && this.I.ka.remoteDescription && this.I.ka.remoteDescription.sdp ? this.I.addIceCandidate(b) : this.Qt.push(b), this.CL.push(b));
  }, this);
};
d.Dba = function() {
  1 == this.$u && 4 != this.vw && (this.av = ie(function() {
    1 == this.$u && (this.Kc("Transport writable timeout failed, aborting."), this.dispatchEvent(new DE(27, this.C)));
  }, 55E3, this));
};
d.Ew = function(a) {
  x(1 != a);
  null != this.av && (je(this.av), this.av = null, this.$u = a);
};
d.setLocalDescription = function(a) {
  x(null == this.remoteDescription);
  this.Uh("recv local description");
  this.localDescription = a;
  y(this.kb, function(a) {
    var b = a.ib(this.C);
    b && this.vD(b, a.K().N());
  }, this);
  return this.ac = this.ac.then(function() {
    return this.cN("offer", a);
  }, void 0, this).then(function() {
    this.ja("Initial setLocalDescription offer succeeded");
  }, function(a) {
    this.Kc("Initial setLocalDescription offer failed with error=" + a);
    if (a instanceof Sd) {
      throw a;
    }
    this.dispatchEvent(new DE(19, this.C, a.toString()));
    throw a;
  }, this);
};
d.cN = function(a, b) {
  b = this.jM.toSdp(this.IR(a, b));
  this.ja("Calling setLocalDescription");
  return this.I.setLocalDescription(new RTCSessionDescription({type:a, sdp:b})).then(function() {
    this.ja("setLocalDescription succeeded");
  }, function(a) {
    this.ja("setLocalDescription failed with error=" + a);
    throw a;
  }, this);
};
d.IR = function(a, b) {
  var c = x(this.ui);
  this.ui.ud() && (c = c.tP("offer" == a ? "actpass" : "active"));
  b = b.Gq(c);
  b = this.CD(b, "local");
  jb(this.kb, function(a) {
    return "a" == a.K().N();
  }) || (b = b.We(b.ma.Qc([])));
  jb(this.kb, function(a) {
    return "v" == a.K().N();
  }) || (b = b.qe(b.ha.Qc([])));
  return b;
};
d.setRemoteDescription = function(a) {
  x(null != this.localDescription);
  this.Uh("recv remote description");
  var b = null == this.remoteDescription;
  this.remoteDescription = a;
  return b ? (this.Dba(), this.ac = this.ac.then(function() {
    return this.GN("answer", a);
  }, void 0, this).then(function() {
    this.ja("Initial setRemoteDescription answer succeeded");
  }, function(a) {
    this.Kc("Initial setRemoteDescription answer failed for with error=" + a);
    if (a instanceof Sd) {
      throw a;
    }
    this.dispatchEvent(new DE(19, this.C, a.toString()));
    throw a;
  }, this)) : this.MA();
};
d.GN = function(a, b) {
  var c = [];
  this.Ol && c.push("conference");
  b = this.JR(a, b);
  var e = Gb(b.getData().lb(), function(a) {
    return a.He || a.ya();
  }, this);
  this.cF = new I(e);
  b = this.jM.toSdp(b, c);
  this.ja("Calling setRemoteDescription with type=" + a);
  return this.I.setRemoteDescription(new RTCSessionDescription({type:a, sdp:b})).then(function() {
    this.ja("setRemoteDescription succeeded");
    y(this.Qt, function(a) {
      this.I.addIceCandidate(a);
    }, this);
    this.Qt.length = 0;
  }, function(a) {
    this.ja("setRemoteDescription failed with error=" + a);
    throw a;
  }, this);
};
d.JR = function(a, b) {
  b = b.getData().Bc ? b.Ye(b.getData().Qc([])) : this.qaa(b);
  b.kc() && b.kc().ud() && (b = b.Gq(b.kc().tP("offer" == a ? "actpass" : "active")));
  return b = this.CD(b, "remote");
};
d.CD = function(a, b) {
  if (!Zh) {
    return a;
  }
  var c = u(function(a) {
    return !jb(a, function(a) {
      return 0 < ib(this.I.getLocalStreams(), function(b) {
        return b.id == a.He;
      }).length;
    }, this);
  }, this);
  "remote" == b ? (c(this.localDescription.ma.lb()) && (a = a.We(a.ma.HC(!1))), c(this.localDescription.ha.lb()) && (a = a.qe(a.ha.HC(!1))), c(this.localDescription.getData().lb()) && (a = a.Ye(a.getData().HC(!1)))) : (c(this.localDescription.ma.lb()) && (a = a.We(a.ma.jn(!1))), c(this.localDescription.ha.lb()) && (a = a.qe(a.ha.jn(!1))), c(this.localDescription.getData().lb()) && (a = a.Ye(a.getData().jn(!1))));
  return a;
};
d.qaa = function(a) {
  var b = (new zq).La("d").Wf("dataSendChannel").Dk("dataSendChannel").Ze([0]).gn("dataSendChannel").S(), c = a.getData().lb();
  c.push(b);
  b = a.getData().Qc(c);
  return a.Ye(b);
};
d.L5 = function() {
  var a = this.I.getLocalStreams();
  y(a, function(a) {
    this.ML(a);
  }, this);
  this.Fe = !0;
};
d.Q7 = function() {
  this.Fe = !1;
  y(this.kb, function(a) {
    a = a.ib(this.C);
    this.Qv(a);
  }, this);
};
d.MA = function() {
  if (!this.I) {
    return Xd();
  }
  if (!this.ac) {
    var a = "Attempting to reneogitate before credentials were requested in " + this;
    this.Kc(a);
    return Yd(a);
  }
  var b = this.q7++;
  this.ja("Queuing renegotiation with id=" + b);
  return this.ac = this.ac.then(function() {
    this.ja("Setting offer in renegotiation with id=" + b);
    return this.GN("offer", x(this.remoteDescription));
  }, void 0, this).then(function() {
    this.ja("Creating answer for renegotiation with id=" + b);
    return this.I.createAnswer();
  }, void 0, this).then(function() {
    this.ja("Setting answer in renegotiation with id=" + b);
    return this.cN("answer", x(this.localDescription));
  }, void 0, this).then(function() {
    this.ja("Renegotiation successfull with id=" + b);
  }, function(a) {
    this.Kc("Renegotiation failed with id=" + b + " with error=" + a);
    if (a instanceof Sd) {
      throw a;
    }
    this.dispatchEvent(new DE(19, this.C, a.toString()));
    throw a;
  }, this);
};
d.U = function() {
  for (var a in this.Lk) {
    var b = this.Lk[a], c = this.pq[a];
    c && (delete this.pq[a], this.Lj.vL(c, b));
    Sc(b);
  }
  this.Lk = {};
  Sc(this.Lj);
  this.I && (this.I.close(), this.I = null);
  this.me && (this.me.close(), this.me = null);
  qE.T.U.call(this);
};
d.Rk = function() {
  this.Uh("recv view request");
};
d.s3 = function(a) {
  this.Br.set(a.label, a);
  a.onopen = u(function(a) {
    this.ja("receive datachannel " + a.label + " is open.");
  }, this, a);
  a.onclose = u(function(a) {
    this.ja("receive datachannel " + a.label + " is closed.");
    this.Br.remove(a.label);
  }, this, a);
  a.onerror = u(function(a, c) {
    this.Kc("receive datachannel " + a.label + " threw error: " + c);
    this.Br.remove(a.label);
  }, this, a);
  a.onmessage = u(this.t3, this, a);
};
d.gk = function(a, b) {
  var c = this.Br.get(a) || this.me;
  x(null != c);
  this.ja("sendData: label:" + a + "data: " + b);
  if (null != c) {
    var e = c.readyState;
    "open" == e ? c.send(b) : this.ja("Message dropped: dataChannel " + a + " is in " + e + " state");
  } else {
    this.Kc("Unknown dataChannel for label " + a + ", cannot send data: " + b);
  }
};
d.t3 = function(a, b) {
  x(a != this.me);
  b = Za(b.data);
  var c = this.cF.get(a.label), c = c ? c.A() : a.label;
  null != b && (this.ja("dataReceived: participantId:" + c + " label:" + a.label + "data: " + b), this.dispatchEvent(new EE(this.C, c, a.label, b)));
};
d.W6 = function() {
  this.Ia.listen(this.I.ka, "signalingstatechange", this.PK);
};
d.PO = function() {
  this.Ia.Fc(this.I.ka, "signalingstatechange", this.PK);
};
d.PK = function(a) {
  a.target == this.I.ka && "closed" == this.I.signalingState() && this.dispatchEvent(new DE(4, this.C));
};
var CE = function(a, b) {
  F.call(this, "hb");
  this.Tj = a;
  this.Uj = b;
};
w(CE, F);
var BE = function(a) {
  F.call(this, "lb");
  this.te = a;
};
w(BE, F);
var uE = function(a) {
  F.call(this, "mb");
  this.hb = a;
};
w(uE, F);
var wE = function(a, b) {
  F.call(this, "jb");
  this.sessionId = a;
  this.En = b;
};
w(wE, F);
var vE = function(a, b) {
  F.call(this, "ib");
  this.sessionId = a;
  this.message = b;
};
w(vE, F);
var xE = function(a, b, c) {
  F.call(this, "nb");
  this.sessionId = a;
  this.jca = b;
  this.n6 = c;
};
w(xE, F);
var AE = function(a) {
  F.call(this, "ob");
  this.Vs = a;
};
w(AE, F);
var EE = function(a, b, c, e) {
  F.call(this, "fb");
  this.sessionId = a;
  this.za = b;
  this.label = c;
  this.payload = e;
};
w(EE, F);
var DE = function(a, b, c) {
  F.call(this, "gb");
  this.hb = a;
  this.sessionId = b;
  this.th = c;
};
w(DE, F);
var GE = function(a, b) {
  zB.call(this, b);
  if (a instanceof DB) {
    b = a, a = a.LT();
  } else {
    if (a instanceof zy) {
      b = a;
      var c = new Ay;
      b = new DB(b.ks(), b.yn, b.zn, b.Od, b.Sg, c);
    } else {
      a = b = a;
    }
  }
  this.qp = b;
  this.C_ = a;
  this.Wd = new FE;
  this.ci = new mE;
  null != this.rc() || this.Pe(32);
  this.setProperty(this.xg() || "rmjs");
  this.BM(this.eG() || "Unknown");
  this.CM(this.OV() || "0.0");
  null != this.wf() || this.yu(0);
  this.zm(this.Ic() || this.xg() + Ra().toUpperCase());
  this.Raa(this.Fs() || this.Ic() + "@fake.com");
  null != this.EG() || this.OM(0.01);
  this.NM(this.DG() || null);
  this.PM(this.FG() || "https://clients2.google.com/cr/report");
  this.Jaa(this.ZH() || null);
  this.f9(this.Ex() || new Nu);
  null != this.dj() || this.Xp(!1);
  null != this.El() || this.zu(!1);
  this.C9(this.Kx() || []);
  this.P$(this.uH() || new Wx);
  this.s9(this.ms() || null);
};
w(GE, zB);
var HE = new M("CgjDUd");
d = GE.prototype;
d.register = function(a) {
  a.hi(HE, this);
  return this;
};
d.zm = function(a, b) {
  b = b ? Ra().toUpperCase() : "";
  GE.T.zm.call(this, a + b);
};
d.rl = function() {
  return this.qp;
};
d.Io = function() {
  return new mq(this.Kx(), this.dj() || !1, !!this.El());
};
d.Dh = function() {
  return this.Wd;
};
d.Ih = function() {
  return this.ci;
};
d.AW = function() {
  var a = new Os;
  a.Pe(this.rc());
  var b = new Ks;
  b.DB(this.Ic());
  var c = new Hw;
  c.pB(a);
  c.oB(b);
  c.Bm("en");
  c.EB(ky(this.wf()));
  return c;
};
var FE = function() {
};
FE.prototype.ga = n;
var IE = function(a, b, c) {
  G.call(this);
  this.vU = b;
  this.Wd = c;
  this.B = new tk(this);
  this.la(this.B);
  this.B.removeAll();
  this.B.listen(a, "v", this.g4);
};
w(IE, G);
IE.prototype.g4 = function(a) {
  this.Wd.ga("C");
  this.vU.e0(a.data);
  this.g2(a.data);
};
IE.prototype.g2 = function(a) {
  a = yp(a);
  a = (new VD(a)).Wx();
  0 == a.length ? this.Wd.ga("G") : 1 == a.length ? y(a, this.e2, this) : this.Wd.ga("H");
};
IE.prototype.e2 = function(a) {
  var b = a.VH();
  (b = b && b.HH()) && this.Wd.ga("V", b);
  a = a.Vx();
  if (null != a) {
    for (var c, e = 0;e < nE.length;e++) {
      if (b = nE[e].lc.call(a), null != b) {
        c = nE[e].eventType;
        this.f2(c);
        break;
      }
    }
    c || this.Wd.ga("T");
  } else {
    this.Wd.ga("I");
  }
};
IE.prototype.f2 = function(a) {
  switch(a) {
    case "Wa":
      a = "K";
      break;
    case "Ya":
      a = "L";
      break;
    case "Ta":
      a = "M";
      break;
    case "Ua":
      a = "N";
      break;
    case "Xa":
      a = "O";
      break;
    case "Pa":
      a = "P";
      break;
    case "Qa":
      a = "Q";
      break;
    case "Ra":
      a = "R";
      break;
    case "db":
      a = "S";
      break;
    case "Sa":
      a = "U";
      break;
    default:
      a = "J";
  }
  this.Wd.ga(a);
};
var JE = function() {
  tq(this);
};
pa(JE);
JE.prototype.pf = function(a, b) {
  a = this.Lb.pf(a, b);
  x(null != a, "Could not create config!");
  return a;
};
JE.prototype.Cl = function(a, b, c, e) {
  a = this.Lb.Cl(a, b, c, e);
  x(null != a, "Could not create operation executor!");
  return a;
};
JE.prototype.Ih = function(a, b) {
  a = this.Lb.Ih(a, b);
  x(null != a, "Could not create push notification dispatcher!");
  return a;
};
JE.prototype.Dh = function(a, b) {
  a = this.Lb.Dh(a, b);
  x(null != a, "Could not create collection event reporter!");
  return a;
};
var KE = function() {
};
w(KE, bq);
cq(KE, JE);
KE.prototype.pf = iq();
KE.prototype.Cl = iq();
KE.prototype.Ih = iq();
KE.prototype.Dh = iq();
var LE = function(a) {
  G.call(this);
  this.Rc = a;
  this.Wc = null;
  this.nr = H();
  this.JI = 0;
  this.cV = H();
  ae([this.nr.promise, this.cV.promise]);
  this.lm = null;
  tq(this);
};
w(LE, G);
cq(Tq, LE);
var ME = function(a) {
  a.rj(Sq) || (Sq.o$(""), a.hi(Sq, new LE(a)));
};
d = LE.prototype;
d.mc = function(a) {
  null == this.lm && (this.lm = ae([this.Lb.mc(a || {}) || Xd(7), this.nr.promise]).then(function(a) {
    return a[0];
  }), this.lm.then(this.uu, this.uu, this), this.lm.jb(u(function() {
    this.lm = null;
  }, this)));
  return this.lm;
};
d.uu = function(a) {
  a != this.JI && t(a) && Lb(op, a) && (this.JI = a, this.dispatchEvent("q"));
};
d.So = function() {
  var a = this.Lb.So();
  return null != a ? a : !0;
};
d.Go = function() {
  return this.Lb.Go() || null;
};
d.b9 = function(a) {
  x(null === this.Wc, "setClientConfig can only be called once");
  this.Wc = a;
  this.nr.resolve(a);
  return this;
};
d.zr = function(a, b) {
  return x(this.Lb.zr(a, b), "Could not create remote session!");
};
d.xr = function(a, b, c) {
  return x(this.Lb.xr(a, b, c), "Could not create local session!");
};
d.Mf = function(a, b) {
  x(this.Lb.Mf(a, b), "Could not request log upload");
};
d.al = function(a) {
  return x(this.Lb.al(a), "Could not create logger!");
};
var NE = function(a, b, c, e) {
  FC.call(this);
  this.g = new TD("realtime.media.api.webrtc.LocalSession");
  this.C = a;
  this.Cb = b;
  this.aa = c;
  this.zj = e;
  this.B = new tk(this);
  this.la(this.B);
  this.B.listen(this.Cb, "fb", this.W3);
  this.B.listen(this.Cb, "gb", this.X3);
  this.B.listen(this.Cb, "hb", this.Y3);
  this.B.listen(this.Cb, "ib", this.Z3);
  this.B.listen(this.Cb, "jb", this.a4);
  this.B.listen(this.Cb, "lb", this.c4);
  this.B.listen(this.Cb, "mb", this.b4);
  this.B.listen(this.Cb, "nb", this.d4);
  this.B.listen(this.Cb, "ob", this.e4);
  this.F = "INITIAL";
  this.kb = new Ae;
  this.yh = void 0;
  this.Hg = this.Kn();
};
w(NE, FC);
d = NE.prototype;
d.Sb = function(a, b, c) {
  this.F != a && (this.F = a, !t(this.yh) && t(b) && (this.yh = b), this.dispatchEvent(new $u(this.F, this.yh, c)));
};
d.getState = function() {
  return this.F;
};
d.s = function() {
  return this.C;
};
d.wg = function() {
  return this.Hg;
};
d.Kn = function() {
  return this.Cb.createOffer(this.aa);
};
d.cd = function() {
  if ("INITIAL" != this.F) {
    return this.g.l("Called prepare in a bad state."), !1;
  }
  this.zj.pi(this.C);
  this.Cb.vba();
  this.Cb.setLocalDescription(this.Hg);
  this.Sb("STARTING");
  return !0;
};
d.start = function(a) {
  if ("STARTING" != this.F) {
    return this.g.l("Called start in a bad state."), !1;
  }
  this.s8("RemoteSessionId=" + a.s());
  this.Sb("INPROGRESS");
  this.CB(a);
  return !0;
};
d.connect = n;
d.update = function(a) {
  switch(this.F) {
    case "INITIAL":
      return this.g.l("Update called before started."), !1;
    case "STOPPED":
      return this.g.l("Update called after stopped."), !1;
  }
  this.CB(a);
  return !0;
};
d.stop = function(a, b) {
  if ("STOPPED" == this.F) {
    return !1;
  }
  this.Sb("STOPPED", a, b);
  x(null != this.yh);
  this.Cb.stopSession(this.yh);
  this.zj.si(this.C);
  return !0;
};
d.pause = function() {
  if ("INPROGRESS" != this.getState()) {
    return !1;
  }
  this.Cb.L5();
  this.Sb("PAUSED");
  return !0;
};
d.resume = function() {
  if ("PAUSED" != this.getState()) {
    return !1;
  }
  this.Cb.Q7();
  this.Sb("INPROGRESS");
  return !0;
};
d.Xm = function() {
  this.zj.Xm(this.C);
};
d.Nq = function(a) {
  this.Cb.Nq(a);
};
d.ld = function(a) {
  var b = a.K().N();
  switch(this.F) {
    case "STOPPED":
    case "FINISHED":
      return this.g.l("Add local stream called after ended."), null;
  }
  var c = db(a, XD);
  if (this.kb.contains(c)) {
    return this.g.error("Capture " + a + " has already been added."), null;
  }
  a.zL(this.C);
  c = this.Cb.ld(c);
  if (null == c) {
    return this.g.error("A stream for capture of type: " + b + ", was not created."), null;
  }
  this.kb.add(a);
  return c;
};
d.je = function(a) {
  switch(this.F) {
    case "STOPPED":
      this.g.l("Remove local stream called after stopped.");
  }
  var b = db(a, XD);
  this.Cb.je(b);
  a.nC(this.C);
  this.kb.remove(a);
};
d.qE = function(a) {
  if ("INPROGRESS" == this.F && 0 != a.length) {
    var b = a[0];
    y(this.kb.H(), function(a) {
      b.P() == a.K().N() && a.kR(b);
    }, this);
  }
};
d.gk = function(a, b) {
  null != this.Ux("d") ? this.Cb.gk(a, b) : this.g.l("Sending data without data stream.");
};
d.Vd = function(a) {
  this.g.info("enableRtpHeaderDump called with enable=" + a + " for sessionId=" + this.C);
  this.zj.Vd(this.C, a);
};
d.iB = function(a) {
  null != a.ma && this.CB(a);
};
d.Ux = function(a) {
  return this.Cb.cH(a);
};
d.Y3 = function(a) {
  this.dispatchEvent(new GC(a.Tj, a.Uj));
};
d.a4 = function(a) {
  a.sessionId == this.C && this.dispatchEvent(new HC(a.En));
};
d.Z3 = function(a) {
  a.sessionId == this.C && this.dispatchEvent(new IC(a.message));
};
d.c4 = function(a) {
  this.dispatchEvent(new JC(a.te));
};
d.b4 = function(a) {
  this.dispatchEvent(new KC(0, a.hb));
};
d.X3 = function(a) {
  a.sessionId == this.C && this.stop(a.hb, a.th);
};
d.d4 = function(a) {
  this.C == a.sessionId && (a = this.Hg.kc().FP(a.jca).CP(a.n6), this.Hg = this.Hg.Gq(a));
};
d.e4 = function(a) {
  this.dispatchEvent(new MC(a.Vs));
};
d.W3 = function(a) {
  this.C == a.sessionId && this.dispatchEvent(new LC(a.za, a.label, a.payload));
};
d.oD = function(a) {
  var b = this.Hg.getData().lb();
  jb(b, function(b) {
    return b.He == a.vg();
  }) || (b.push(this.oL(a)), b = this.Hg.getData().Qc(b), this.Hg = this.Hg.Ye(b));
};
d.s8 = function(a) {
  this.g.info("sendLogComment: " + a);
};
d.CB = function(a) {
  if (null != a.xH() && null != a.getData()) {
    var b = z(a.fs(), this.oL, this), b = a.getData().Qc(xb(a.getData().lb(), b));
    a = a.Ye(b);
  }
  this.g.info("Session " + this.s() + " setting remote descriptions: " + ef(a.na()));
  this.Cb.setRemoteDescription(a);
};
d.oL = function(a) {
  var b = a.zg(), c = a.vg() || "local_push_channel", e = a.getChannelId() || "";
  return (new zq).La("d").qv(e).Wf(c).Dk(b.toString()).tn(b).gn(a.vg()).S();
};
var OE = function(a) {
  Tq.call(this, a);
  this.Lr = new Pj;
  this.XI = !1;
  this.zj = new $D(this.Rc);
};
la(OE, Tq);
OE.prototype.mc = function() {
  var a = this, b = [this.Tq.nr.promise.then(function(b) {
    return a.zj.mc(b.Fs());
  }), zE()];
  return ae(b).then(function(b) {
    a.XI = b.every(function(a) {
      return 7 == a;
    });
    xC = x(a.Rc.get(HE).FG());
    return b;
  });
};
OE.prototype.So = function() {
  return this.XI;
};
OE.prototype.al = function(a) {
  return this.So() ? new TD(a) : null;
};
OE.prototype.xr = function(a, b, c) {
  if (this.So()) {
    a.get(HE);
    var e = a.yo(FD);
    null == e && (e = new ED(a), a.hi(FD, e));
    a = new qE(b, this.Lr, e, c);
    b = new NE(b, a, c, this.zj);
    b.la(a);
    return b;
  }
  return null;
};
dq(OE, Tq, 6);
var QE = function(a, b) {
  XD.call(this, a, PE);
  this.nc = b;
};
la(QE, XD);
QE.prototype.jN = function(a) {
  this.nc = a;
  this.Aq();
};
QE.prototype.Aq = function() {
  this.wK(this.nc.clone());
  return Xd();
};
var PE = new vq(!1, 30, 320, 180, 30, 640, 360);
var RE = function() {
  this.qx = null;
};
w(RE, KE);
dq(RE, KE);
RE.prototype.pf = function(a, b) {
  return x(b.Ex());
};
RE.prototype.Cl = function(a, b, c) {
  if (c) {
    return new WD(x(c || b.Ic()), x(b.rl()), void 0, b.rc(), b.wf());
  }
  this.qx || (this.qx = new WD(x(b.Ic()), x(b.rl()), void 0, b.rc(), b.wf()));
  return this.qx;
};
RE.prototype.Ih = function(a, b) {
  return b.Ih();
};
RE.prototype.Dh = function(a, b) {
  return b.Dh();
};
var SE = function(a) {
  this.Ta = new wr;
  this.sb = null;
  this.mT = fv(a, HE).then(function(a) {
    return this.sb = a;
  }, null, this);
  this.pm = null;
  this.F6 = fv(a, Sq, ME).then(function(a) {
    return this.pm = a;
  }, null, this);
  this.yK = H();
  this.xK = this.yK.promise;
  this.Sq = null;
  this.Sp = !1;
  this.Uv = [];
  this.AI = this.uE = !1;
}, TE = function(a) {
  a.rj(Oq) || a.hi(Oq, new SE(a));
};
d = SE.prototype;
d.ql = function() {
  this.OJ();
  return this.Sq || !1;
};
d.oR = function(a) {
  this.sb = this.sb || a.Qd;
  this.pm = this.pm || a.sL;
  this.OJ();
  a.rb.Gk(this.ql());
  Math.random() <= this.sb.EG() && a.rb.ux();
  this.Uv.push(a);
  a.onConnect.then(u(this.h3, this, a));
  a.onDisconnect.then(u(this.pK, this, a), u(this.pK, this, a));
};
d.Mf = function(a, b) {
  var c = this.kz();
  null != c && c.O() == a && (b ? Xd(!0) : this.xK.then(function() {
    return this.ql();
  }, void 0, this)).then(function(a) {
    a && this.DF(u(function() {
      y(c.gj() || [], function(a) {
        this.pm.Mf(x(a.bH()), c.O());
      }, this);
    }, this));
  }, void 0, this);
};
d.bV = function(a) {
  this.sb ? a() : this.mT.then(a);
};
d.DF = function(a) {
  this.pm ? a() : this.F6.then(a);
};
d.h3 = function(a) {
  this.cT(a);
  this.fM(a);
};
d.pK = function(a) {
  this.fM(a);
  ub(this.Uv, a);
};
d.OJ = function() {
  this.AI || this.AF();
};
d.AF = function(a) {
  this.bV(u(function() {
    this.AI = !0;
    this.Sp = null;
    var b = H();
    b.promise.then(u(this.P3, this), u(this.O3, this, a));
    var c = this.sb.DG();
    if (null != c) {
      null != a && (c = Nc(c, "set", String(a)));
      var e = Df.Jn();
      e.open("GET", c, !0);
      e.onreadystatechange = function() {
        4 == e.readyState && (200 == e.status ? b.resolve(e.responseText) : b.reject(null));
      };
      e.send(null);
    } else {
      b.reject(null);
    }
  }, this));
};
d.P3 = function(a) {
  this.Sp = "true" == a;
  this.AK();
};
d.O3 = function(a) {
  this.Sp = l(a) ? a : this.ql();
  this.AK();
};
d.AK = function() {
  this.yK.resolve();
  null === this.Sq && (this.Sq = this.Sp, y(this.Uv, function(a) {
    a.rb.Gk(this.ql());
  }, this));
  this.Sp != this.Sq && this.AF(this.ql());
};
d.cT = function(a) {
  if (!this.uE) {
    this.uE = !0;
    var b = this.kz();
    null != b && (null != b.tl() && 3456E5 > v() - b.getTime() && this.Lca(b), a = a.$, b.O() == a.get() && 6E4 > v() - b.getTime() && this.xK.then(function() {
      this.ql() && this.DF(u(function() {
        y(b.gj() || [], function(a) {
          this.pm.Mf(x(a.bH()), b.O());
        }, this);
      }, this));
    }, void 0, this));
  }
};
d.eE = function(a, b) {
  a += b;
  b = new Dp;
  b.update(a, a.length);
  return String.fromCharCode.apply(String, b.digest());
};
d.Lca = function(a) {
  if (null != a.xg() && null != a.wf() && null != a.Gh() && 0 != (a.gj() || []).length) {
    var b = this.bG(a);
    y(a.gj(), function(c) {
      b.Ym(this.eH(a, c), x(c.ey()));
    }, this);
  }
};
d.q_ = function() {
  var a = this.kz();
  if (null == a || null == a.xg() || null == a.wf() || null == a.Gh() || 0 == (a.gj() || []).length) {
    return [];
  }
  var b = this.bG(a);
  return z(a.gj(), function(c) {
    return b.WE(this.eH(a, c), x(c.ey()));
  }, this);
};
d.bG = function(a) {
  x(this.sb, "ClientConfig not set.");
  return new CD(this.sb.C_, x(a.Ic() || a.Gh()), x(a.xg()), a.wf() || 0, void 0, a.rc() || this.sb.rc());
};
d.eH = function(a, b) {
  x(this.sb, "ClientConfig not set.");
  var c = new Cy;
  c.TN((new Date(a.getTime())).toString());
  c.VN(a.tl());
  c.GM(-2);
  c.FM(x(b.ey()));
  b = new oC;
  b.lB(c);
  b.L(a.O());
  b.kB(this.sb.Kx());
  b.Xp(this.sb.dj());
  b.Ug(a.Gh());
  b.bq(a.Cs());
  b.Cm(a.uo());
  b.jk(a.Al());
  return b;
};
d.kz = function() {
  if (!this.Ta.isAvailable()) {
    return null;
  }
  x(this.sb, "ClientConfig not set.");
  var a = this.Ta.get("report_luak");
  this.Ta.remove("report_luak");
  if ("hc:rc" != bb(df(a || "[]"))[0]) {
    return null;
  }
  a = new Tu(bb(df(a)));
  return a.GZ() == this.eE(x(this.sb.Fs()), a.getTime()) ? a : null;
};
d.fM = function(a) {
  if (this.Ta.isAvailable()) {
    x(this.sb, "ClientConfig not set.");
    var b = new Tu;
    b.L(a.$.get());
    var c = v();
    b.setTime(c);
    b.jaa(this.eE(x(this.sb.Fs()), c));
    b.setProperty(this.sb.xg());
    b.yu(this.sb.wf());
    b.Ug(a.Oj);
    b.zm(this.sb.Ic());
    var e = [];
    Hb(a.rb.mZ(), function(a, b) {
      var c = new Vu;
      c.$$(a);
      c.c$(b);
      e.push(c);
    });
    0 != e.length && (b.taa(e), c = a.onDisconnect, c.qc && b.Wp(c.get()), a = a.hB, (c = a.Cs()) && b.bq(c), (c = a.uo()) && b.Cm(c), (a = a.Al()) && b.jk(a), this.Ta.set("report_luak", b.cb()));
  }
};
var VE = function(a, b, c) {
  return UE(a, b, [c], new lq(Pw, [Pw.prototype.O], [Pw.prototype.L], [], [], ht, [ht.prototype.O], [ht.prototype.L], [], []), fE, "Ta");
}, WE = function(a, b, c) {
  return UE(a, b, [c], new lq(jx, [jx.prototype.O], [jx.prototype.L], [jx.prototype.A, jx.prototype.ya], [jx.prototype.Sa, jx.prototype.Qf], Ht, [Ht.prototype.O], [Ht.prototype.L], [Ht.prototype.A, Ht.prototype.ya], [Ht.prototype.Sa, Ht.prototype.Qf]), hE, "Xa");
}, UE = function(a, b, c, e, f, g) {
  var k = JE.W();
  f = new f(k.Cl(a, b));
  g = new np(k.Ih(a, b), g);
  return new rB(a, k.pf(a, b), c, e, f, g, k.Dh(a, b));
};
var XE = function(a, b, c, e) {
  var f = JE.W(), g = new Lu;
  a = new rB(a, f.pf(a, b), c, e, g);
  g.e9(a);
  return a;
};
var YE = function(a, b, c, e, f) {
  iD.call(this);
  this.a = zf("realtime.media.session.SessionImpl");
  this.g = b.al("realtime.media.session.SessionImpl");
  this.g.info("Creating a new session with localSessionId=" + c.s() + " remoteSessionId=" + e.uc() + " earlyMediaHangoutId=" + f.Ud + " P2P=" + f.Aa + " useAudio=" + f.Cq + " useVideo=" + f.$m);
  this.ad = fv(a, Rq, jy);
  this.B = new tk(this);
  this.la(this.B);
  this.R = c;
  this.la(this.R);
  this.B.listen(this.R, "$", this.r3);
  this.B.listen(this.R, "ca", this.Mz);
  this.B.listen(this.R, "aa", this.Q3);
  this.B.listen(this.R, "ba", this.K3);
  this.B.listen(this.R, "ea", this.M3);
  this.B.listen(this.R, "da", this.L3);
  this.B.listen(this.R, "L", this.zK);
  this.B.listen(this.R, "ga", this.F4);
  this.pa = e;
  this.la(this.pa);
  this.B.listen(this.pa, "L", this.MK);
  this.B.listen(this.pa, "na", this.Pz);
  this.B.listen(this.pa, "ra", this.R3);
  this.B.listen(this.pa, "ka", this.p4);
  this.B.listen(this.pa, "la", this.q4);
  this.B.listen(this.pa, "ja", this.Qz, !0);
  this.DI = !1;
  this.Hp = [];
  this.EA = H();
  this.Tp = H();
  this.aa = f;
  this.Th = {};
  this.Kp = this.Jp = null;
  this.kq = new I;
  this.fb = this.az = null;
  this.Mg = [];
  this.ie = [];
  this.gA = {};
  this.dt = new Ki(20);
  this.Ks = this.xw = null;
  this.bz = this.$y = this.ou = v();
  this.nJ = this.mJ = !1;
  this.Rq = !0;
  this.Dp = this.MO = !1;
  this.WJ = 0;
  this.fi = b;
  a = (a = b.Wc) && a.IG() || new BB;
  this.fz = void 0;
  this.PE = new vC(a);
  this.B.listen(this.PE, "Z", this.m3);
  this.Kr = H();
  this.OE = this.Hn = null;
  this.xi = [];
};
w(YE, iD);
var ZE = new Ji(1280, 720);
d = YE.prototype;
d.gk = function(a, b) {
  this.R.gk(a, b);
};
d.Gk = function(a) {
  this.aa.Qi || (this.aa = x(this.aa).rP(a), this.aa.Ri && this.R.Xm());
};
d.ux = function() {
  this.aa.Ri || (this.aa = x(this.aa).sP(), this.aa.Qi && this.R.Xm());
};
d.Vd = function(a) {
  this.R.Vd(a);
};
d.eI = function() {
  return null != this.aa.Ud && 0 < this.aa.ze().length;
};
d.cd = function(a) {
  if ("INITIAL" != this.getState()) {
    return J(this.a, "Starting session after already started."), !1;
  }
  this.Sb("STARTING");
  if (!this.R.wg()) {
    return this.g.l(this.R.s() + " preparation failed because local session failed to create an offer."), !1;
  }
  null != a && (a = a.xH("msodc"), null != a && this.R.oD(a));
  if (!this.R.cd()) {
    return this.g.l(this.R.s() + " preparation failed because because local session failed to prepare."), !1;
  }
  this.R.Vd(this.aa.ms());
  this.aa.Ud && this.aa.ze().length && this.g.info("Request early media for hangout " + this.aa.Ud);
  a = this.eI() ? this.aa.Ud : null;
  return this.pa.cd(a) ? !0 : (this.g.l("Failed to prepare session because remote session failed to prepare."), !1);
};
d.start = function(a) {
  this.DI = !0;
  if ("INITIAL" == this.getState() && !this.cd(a)) {
    return !1;
  }
  this.az = a;
  this.g.info(this.ia() + " starting with remote description: " + ef(a));
  var b = a.ma;
  null != b && (a = a.We(b.kL("opus")), this.Hp = b.sc(), this.dispatchEvent(new oD(this.Hp)));
  a = Vq(a, function(a) {
    return !Ea(a.getName(), "h264");
  });
  this.fb = a = this.nU(a);
  b = a.s();
  if (null == b) {
    return J(this.a, "Received remote description without session id."), this.stop(16), !1;
  }
  y(this.Mg, function(b) {
    a = a.dv(b.Vv, b.LA);
  }, this);
  qb(this.Mg);
  this.Ca(b);
  this.pa.start(b);
  this.R.start(a);
  this.R.qE(this.xi);
  this.Sb("STARTED");
  b = this.ZF(a);
  0 < b.length && this.R.Nq(b);
  this.Ju();
  this.ot();
  this.EA.resolve();
  this.aa.Ri && this.aa.Qi && this.R.Xm();
  return !0;
};
d.Rb = function() {
  this.pa.Rb();
  this.R.Rb();
};
d.rr = function(a, b, c) {
  this.g.info("Connecting session " + this.R.s() + " to hangout id: " + a);
  this.R.L(a);
  this.R.connect();
  this.pa.rr(a, b, c);
  this.EA.promise.then(function() {
    this.pa.Ym(x(this.fi.Go()));
  }, null, this);
};
d.pause = function() {
  this.g.info("Attempting to pause session " + this.R.s());
  if ("INPROGRESS" != this.getState()) {
    return !1;
  }
  y(this.ie, function(a) {
    "d" != a.getInfo().P() && a.ec("Oa");
  });
  if (!this.R.pause()) {
    return this.g.error("Failed to pause session " + this.R.s()), !1;
  }
  this.ww();
  this.Sb("PAUSED");
  return !0;
};
d.resume = function() {
  this.g.info("Attempting to resume session " + this.R.s());
  if ("PAUSED" != this.getState()) {
    return !1;
  }
  if (!this.R.resume()) {
    return this.g.error("Failed to resume session " + this.R.s()), !1;
  }
  this.pa.resume();
  y(this.ie, function(a) {
    "d" != a.getInfo().P() && a.ec("Na");
  });
  this.dispatchEvent("ua");
  this.Sb("INPROGRESS");
  this.dispatchEvent(new nD([], [], this.ia()));
  this.Ju();
  return !0;
};
d.stop = function(a, b) {
  if ("STOPPED" == this.getState() || "FINISHED" == this.getState()) {
    return this.g.info(this.R.s() + " ignoring call to stop with endCause: " + a + " and debug information: " + b + ", because it has already stopped."), !0;
  }
  this.g.info(this.R.s() + " stopping because stop called with endCause: " + a + " and debug information: " + b);
  this.B.Fc(this.R, "L", this.zK);
  this.B.Fc(this.pa, "L", this.MK);
  this.B.Fc(this.Jp, "G", this.NK);
  this.B.Fc(this.Kp, "G", this.OK);
  var c;
  if (c = this.aa.Qi) {
    a: {
      switch(a) {
        case 3:
        case 8:
        case 10:
        case 102:
        case 13:
        case 58:
        case 19:
        case 15:
        case 16:
        case 17:
        case 23:
        case 26:
        case 28:
        case 29:
        case 32:
        case 33:
        case 34:
          c = !0;
          break a;
        default:
          c = !1;
      }
    }
  }
  c && this.R.Xm();
  this.ww();
  this.R.stop(a);
  this.pa.stop(a, b);
  this.Sb("STOPPED", a, b);
  ke(2000).Um(this.Kr.resolve, this.Kr);
  return !0;
};
d.U = function() {
  this.stop(this.DI ? 6 : 72);
  this.Kr.promise.Um(G.prototype.U, this);
};
d.ld = function(a) {
  switch(this.getState()) {
    case "STOPPED":
    case "FINISHED":
      return J(this.a, "Adding stream after end."), !1;
  }
  if (this.Th[this.so(a)]) {
    return a.Qba(), !1;
  }
  var b = this.R.ld(a);
  if (null == b) {
    return !1;
  }
  "v" == a.K().N() && this.EA.promise.then(function() {
    var a = [];
    if (this.aa.Aa) {
      var b = this.fb.ha;
      null != b && (a = b.ze());
    } else {
      a.push(new Bp("", "", "v", ZE, 30, !0, this.s() || void 0));
    }
    0 < a.length && this.pE(a);
  }, null, this);
  this.pa.uR([b]);
  "xa" == a.K().Kb ? this.pa.rI(b.Vb()) : "v" == a.K().N() && this.B.listen(a.K(), "x", this.QK);
  b = a.NT(this.ia(), b);
  this.Th[this.so(a)] = b;
  this.dispatchEvent(new nD([b.getInfo()], []));
  this.B.listen(a, "U", this.rK);
  this.g.info(this.ia() + " successfully added capture: " + ef(a.na()));
  return !0;
};
d.Ce = function() {
  return this.aa;
};
d.je = function(a) {
  switch(this.getState()) {
    case "STOPPED":
    case "FINISHED":
      return J(this.a, "Removing stream after end."), !1;
  }
  "xa" == a.K().Kb ? this.pa.qI() : "v" == a.K().N() && this.B.Fc(a.K(), "x", this.QK);
  this.B.Fc(a, "U", this.rK);
  this.R.je(a);
  var b = this.Th[this.so(a)];
  b && (delete this.Th[this.so(a)], this.dispatchEvent(new nD([], [b.getInfo()])));
  return !0;
};
d.QK = function(a) {
  "xa" == a.target.Kb ? this.pa.rI() : "wa" == a.target.Kb && this.pa.qI();
};
d.Em = function(a) {
  this.g.info(this.R.s() + " now has these participants: " + ef(a));
  if (this.aa.Aa) {
    if (2 < a.length) {
      this.stop(51);
      return;
    }
    if (2 > a.length && "INPROGRESS" == this.getState()) {
      this.stop(52);
      return;
    }
  }
  this.pa.Em(a);
};
d.Daa = function(a) {
  this.Jp = a;
  this.B.listen(this.Jp, "G", this.NK);
};
d.Sb = function(a, b, c) {
  this.g.info(this.R.s() + " changed state from " + this.getState() + " to " + a);
  c && this.g.info("State change due to " + c);
  this.Aaa(a, b, c);
};
d.Rk = function(a) {
  switch(this.getState()) {
    case "STOPPED":
    case "FINISHED":
      return J(this.a, "Changing stream requests after end."), !1;
  }
  a = ib(a, function(a) {
    return null == this.dH(new Wr(a.A(), a.ya(), a.P()));
  }, this);
  y(a, function(a) {
    this.g.info(this.ia() + " received stream request for DOWN stream from UI: " + a);
  }, this);
  if (null != this.Jp) {
    return this.Jp.hM(a), !0;
  }
  this.oE(a);
  return !0;
};
d.NK = function(a) {
  this.QN(a.QA);
  this.oE(a.QA);
};
d.oE = function(a) {
  this.pa.Rk(a);
  this.gA = {};
  y(a, function(a) {
    if (a.$c()) {
      var b = a.A();
      a = a.ya();
      this.gA[b + a] = !0;
    }
  }, this);
  y(this.ie, this.HB, this);
};
d.HB = function(a) {
  var b = a.A(), c = a.ya();
  a.daa(this.gA[b + c] || !1);
};
d.QN = function(a) {
  for (var b = 0;b < a.length;b++) {
    if (null != a[b].wd()) {
      for (var c = a[b].wd(), e = 0;e < c.length;e++) {
        var f = c[e], g = a[b].es();
        null === f || null === g || this.kq.set(f, g);
      }
    }
  }
};
d.Eaa = function(a) {
  this.Kp = a;
  this.B.listen(this.Kp, "G", this.OK);
};
d.pE = function(a) {
  K(this.a, "Stream Requests for UP streams received from remote side: " + ef(a));
  null != this.Kp ? this.Kp.hM(a) : this.pI(a);
};
d.rK = function(a) {
  var b = a.target;
  a = b.To();
  (b = this.Th[this.so(b)]) ? (a = (new zq(b.getInfo())).AP(a).S(), b.P9(a), this.pa.Ica(a)) : this.g.l(this.ia() + " muted unknown capture.");
};
d.OK = function(a) {
  this.pI(a.QA);
};
d.pI = function(a) {
  var b = ib(a, function(a) {
    a = a.s();
    return !(null != a && this.s() != a);
  }, this);
  if (0 != b.length) {
    this.QN(b);
    this.xi = xb(ib(this.xi, function(a) {
      return -1 == lb(b, function(b) {
        return a.LJ(b);
      });
    }, this), ib(b, function(a) {
      return a.$c();
    }, this));
    var c = this.aa.RS;
    void 0 != c && (this.xi = z(this.xi, function(a) {
      return a.rf() > c ? a.wP(c) : a;
    }));
    K(this.a, "Sending stream requests for UP streams to local session: " + ef(this.xi));
    this.R.qE(this.xi);
    this.fb && this.fb.ha && (a = this.fb.ha.Bx(), (this.fb = this.kD(this.fb)) && this.fb.ha && this.fb.ha.Bx() != a && this.R.update(this.fb));
  }
};
d.kD = function(a) {
  if (!this.H0() || !this.aa.cP) {
    return a;
  }
  var b = mb(this.xi, function(a) {
    return !Ga(a.ya()) && null != a.Ub();
  }, this);
  if (!b) {
    return a;
  }
  var b = b.Ub(), c = 2500;
  180 >= b.height && 320 >= b.width && (c = 100 + Math.floor(20 * Math.random()));
  return a.qe(a.ha.pP(c));
};
d.H0 = function() {
  return ci && 0 <= Ta(ck, 54);
};
d.uf = function() {
  return x(this.R.wg());
};
d.ib = function(a) {
  var b = this.dH(a);
  return null != b ? b : ob(this.ie, function(b) {
    return b.getInfo().j2(a);
  }, this);
};
d.getLocalStreams = function() {
  return Jb(this.Th);
};
d.getRemoteStreams = function() {
  return this.ie;
};
d.na = function() {
  var a = YE.T.na.call(this), b = this.fi.Go();
  Ub(a, {audioOptions:this.aa.Xq.na(), systemInfo:b ? b.cb() : "Unavailable"});
  return a;
};
d.dH = function(a) {
  var b = ib(Jb(this.Th), function(b) {
    b = b.ir.K();
    return a.getId() == b.getId() && a.N() == b.N() && (a.A() == b.A() || "" == a.A());
  });
  return 1 < b.length ? (x(2 == b.length), x("v" == a.N()), b = mb(b, function(a) {
    return "xa" == a.ir.K().Kb;
  }), x(b), b) : 1 == b.length ? b[0] : null;
};
d.so = function(a) {
  a = a.K();
  return a.getId() + a.Kb;
};
d.s = function() {
  return this.pa.s();
};
d.ia = function() {
  return this.R.s();
};
d.Ux = function(a) {
  return this.R.Ux(a);
};
d.ZF = function(a) {
  return (a = a.kc()) ? a.jo() : [];
};
d.Mz = function(a) {
  switch(this.getState()) {
    case "INITIAL":
      J(this.a, "Received local candidates before starting.");
      return;
    case "STOPPED":
    case "FINISHED":
      J(this.a, "Received local candiates after stopped.");
      return;
  }
  y(a.En, function(a) {
    2 != a.Zi() && (this.aa.Aa && "UDP" != a.yg() || 0 > lb(this.dt.H(), function(b) {
      return b == a ? !0 : b && a ? b.Kw === a.Kw && b.qA === a.qA && b.Jd === a.Jd && b.vA === a.vA && b.Hy === a.Hy && b.Ja === a.Ja && b.co === a.co && b.xx === a.xx && b.Az === a.Az && b.Fp === a.Fp && b.Gp === a.Gp : !1;
    }) && this.dt.add(a));
  }, this);
  null == this.xw && (this.xw = ie(function() {
    this.Tp.promise.then(this.l8, null, this);
    this.xw = null;
  }, 500, this));
};
d.l8 = function(a) {
  this.g.info(this.ia() + "Sending local candidates over to the other side: " + ef(this.dt.H()));
  this.dispatchEvent(new pD(this.dt.H(), a));
};
d.Y0 = function(a) {
  a = a.Eh();
  if (null != a) {
    for (var b = 0;b < a.length;b++) {
      var c = a[b];
      if (null != c && 2 == c.to()) {
        var e = null != c.es() ? c.es() : 0;
        if (null != c.zg() && null != this.kq.get(c.zg())) {
          e |= this.kq.get(c.zg());
        } else {
          if (null != c.As()) {
            for (var f = c.As(), g = 0;g < f.length;g++) {
              if (null != f[g] && null != this.kq.get(f[g])) {
                e |= this.kq.get(f[g]);
                break;
              }
            }
          }
        }
        c.zM(e);
      }
    }
  }
};
d.laa = function(a) {
  (a = a.Eh()) && y(a, function(a) {
    if (a && a.to() == Wy.Iv) {
      var b = !1, e = a.As()[0];
      if (a.jc() == Xy.gD) {
        var f = ob(this.ie, function(a) {
          return a.getInfo().Vb() == e;
        }, this);
        f && (b = !f.getInfo().sh);
      } else {
        a.jc() == Xy.Kq && (f = Mb(this.Th, function(a) {
          return a.getInfo().wd()[0] == e;
        }, this)) && (b = "xa" == f.ir.K().Kb);
      }
      a.U9(b);
    }
  }, this);
};
d.m3 = function(a) {
  this.dispatchEvent(new lD(a.id));
};
d.M3 = function(a) {
  null != a.te && (this.Y0(a.te), this.laa(a.te), this.fz = a.te, this.Rq || (this.Rq = "PAUSED" != this.getState()), this.Rq && 0 >= --this.WJ && (this.WJ = 1, this.pa.Kca(a.te), this.fz = void 0, this.Rq = "PAUSED" != this.getState()), this.PE.I_(a.te), this.dispatchEvent(new jD(a.te)));
};
d.L3 = function(a) {
  this.pa.pV(a.RU, a.hb, this.fz);
};
d.K3 = function(a) {
  this.g.info(this.ia() + " latency event: " + a.message);
  "transport writable" == a.message ? (this.MO = !0, this.aa.Aa && this.aa.fU ? (this.ad.then(function(a) {
    a.Ge(3261, this.s() || void 0);
  }, null, this), this.stop(54)) : (this.Dp || ie(this.C0, 10000, this), this.dispatchEvent(new nD([], [], this.ia())), this.ot())) : "render first video frame" == a.message ? (this.Dp = !0, this.ot()) : "transport not writable" == a.message && (this.aa.Aa ? this.stop(10, "P2P session ending. Falling back to cloud.") : this.Rb());
};
d.C0 = function() {
  this.Dp || (this.Dp = !0, this.ot());
};
d.ot = function() {
  "STARTED" == this.getState() && this.MO && this.Dp && this.Sb("INPROGRESS");
};
d.r3 = function(a) {
  switch(a.label) {
    case "collections":
      this.dispatchEvent(new Jr(a.payload));
      break;
    case "msodc":
      this.pa.q3(a.label, a.payload);
      break;
    case "dataSendChannel":
      this.g.error("Received data on the broadcast data channel. Data:" + a.payload);
      break;
    default:
      this.dispatchEvent(new Ir(a.za, a.payload));
  }
};
d.Ju = function() {
  this.Ks = ie(this.W_, 5000, this);
};
d.ww = function() {
  je(this.Ks);
  this.Ks = null;
};
d.Q3 = function(a) {
  if (null != this.Ks) {
    a.Tj != this.mJ && (a.Tj ? this.g.info(this.ia() + " started receiving audio") : this.g.l(this.ia() + " stopped receiving audio!"), this.mJ = a.Tj);
    a.Uj != this.nJ && (a.Uj ? this.g.info(this.ia() + " started receiving video") : this.g.l(this.ia() + " stopped receiving video!"), this.nJ = a.Uj);
    var b = v();
    a.Tj && (this.$y = b);
    a.Uj && (this.bz = b);
    if (a.Tj || a.Uj) {
      this.ww(), this.Ju();
    }
  }
};
d.W_ = function() {
  var a = v(), b = (a - this.$y) / 1000, a = (a - this.bz) / 1000;
  this.dispatchEvent(new kD(this.s(), b, a));
  this.$y == this.ou ? this.g.info(this.ia() + " has never received audio") : 5000 < b && this.g.info(this.ia() + " has not received audio for " + b + " seconds");
  this.bz == this.ou ? this.g.info(this.ia() + " has never received video") : 5000 < a && this.g.info(this.ia() + " has not received video for " + a + " seconds");
  this.Ju();
};
d.zK = function(a) {
  if ("STOPPED" == this.R.getState()) {
    K(this.a, "Stopping session because local session stopped with endCause: " + a.hb);
    x(null != a.hb);
    switch(this.getState()) {
      case "INITIAL":
        J(this.a, "Local session stopped before starting.");
        this.Sb("STOPPED", a.hb, a.th);
        return;
      case "STOPPED":
        J(this.a, "Local session stopped after already stopped.");
        return;
    }
    this.stop(a.hb, a.th);
  }
};
d.MK = function(a) {
  if ("STOPPED" == this.pa.getState()) {
    x(null != a.hb);
    switch(this.getState()) {
      case "INITIAL":
        J(this.a, "Remote session stopped before starting.");
        return;
      case "STOPPED":
        J(this.a, "Remote session stopped after already stopped.");
        return;
    }
    this.stop(a.hb, a.th);
  }
};
d.F4 = function(a) {
  this.g.info(this.ia() + " transport state event: transport IS " + (a.Vs ? "" : "NOT ") + "writable");
  if (a.Vs) {
    if (null != this.Hn) {
      var b = Math.round((v() - this.OE) / 1000);
      je(this.Hn);
      this.Hn = null;
      this.ad.then(function(a) {
        a.Ge(3062, this.s() || void 0, void 0, void 0, void 0, b);
      }, null, this);
    }
  } else {
    null == this.Hn && (this.OE = v(), this.Hn = ie(u(this.stop, this, 10), 4E4), this.ad.then(function(a) {
      a.Ge(3061);
    }, null, this));
  }
};
d.Pz = function(a) {
  this.dispatchEvent(a);
};
d.Bca = function(a) {
  switch(this.getState()) {
    case "INITIAL":
    case "STARTING":
      J(this.a, "Remote description changed before starting.");
      return;
    case "STOPPED":
    case "FINISHED":
      J(this.a, "Remote description changed after end.");
      return;
  }
  if (this.E8(this.az, a)) {
    this.az = Rb(a);
    this.g.info(this.ia() + " received modified remote description: " + ef(a));
    var b = this.ZF(a);
    0 < b.length && this.R.Nq(b);
    a = this.GD(a);
    a = this.kD(a);
    a = Vq(a, function(a) {
      return !Ea(a.getName(), "h264");
    });
    this.fb = this.fb.Gq(a.kc()).qP(a.Ah());
    this.fb = this.fb.z2(a);
    a = this.fb.ma;
    null != a && (this.Hp = a.sc(), this.dispatchEvent(new oD(this.Hp)));
    null == a && null == this.fb.ha || this.R.update(this.fb);
  }
};
d.Ca = function(a) {
  null != a && null == this.pa.s() && (this.pa.Ca(a), this.Tp.resolve(a), this.g.info("Session IDs are now set: LocalSession ID: " + this.ia() + ", RemoteSession ID: " + this.pa.uc()), this.g.info("Note: Session " + this.ia() + " is not yet active."));
};
d.E8 = function(a, b) {
  return null != a ? this.VJ(a.ma, b.ma) || this.VJ(a.ha, b.ha) || this.fca(a.kc(), b.kc()) || this.aU(a.Ah(), b.Ah()) : !0;
};
d.VJ = function(a, b) {
  return null != a || null != b ? null != a && null != b ? this.sT(a.sc(), b.sc()) || this.HQ(a.fj(), b.fj()) : !0 : !1;
};
d.sT = function(a, b) {
  if (a.length != b.length) {
    return !0;
  }
  for (var c = 0;c < a.length;c++) {
    var e = a[c], f = b[c];
    if (e.yc != f.yc || e.getName() != f.getName() || e.gh != f.gh || e.fg != f.fg || e.ff != f.ff) {
      return !0;
    }
  }
  return !1;
};
d.aU = function(a, b) {
  if (a.length != b.length) {
    return !0;
  }
  for (var c = 0;c < a.length;c++) {
    var e = a[c], f = b[c];
    if (e.Lh() != f.Lh() || e.zl() != f.zl() || e.Fo() != f.Fo() || e.Ho() != f.Ho()) {
      return !0;
    }
  }
  return !1;
};
d.HQ = function(a, b) {
  if (a.length != b.length) {
    return !0;
  }
  for (var c = 0;c < a.length;c++) {
    var e = a[c], f = b[c];
    if (e.Fl() != f.Fl() || e.getId() != f.getId()) {
      return !0;
    }
  }
  return !1;
};
d.fca = function(a, b) {
  return null == a && null == b ? !1 : null == a || null == b || a.zf() != b.zf() || a.wi != b.wi || a.di != b.di || this.OS(a.jo(), b.jo()) ? !0 : !1;
};
d.OS = function(a, b) {
  if (a.length != b.length) {
    return !0;
  }
  for (var c = 0;c < a.length;c++) {
    var e = a[c], f = b[c];
    if (e.Zi() != f.Zi() || e.ej() != f.ej() || e.N() != f.N() || e.yg() != f.yg() || e.xl() != f.xl() || e.Wa() != f.Wa() || e.co != f.co || e.wl() != f.wl() || e.xo() != f.xo() || e.Fp != f.Fp || e.Gp != f.Gp) {
      return !0;
    }
  }
  return !1;
};
d.R3 = function() {
  "STOPPED" != this.getState() ? J(this.a, "Logging finished before media stopped!") : (this.Sb("FINISHED"), this.Kr.resolve());
};
d.Qz = function(a) {
  switch(this.getState()) {
    case "INITIAL":
      this.g.l("Received remote streams before starting.");
      return;
    case "STOPPED":
    case "FINISHED":
      J(this.a, "Received remote streams after end.");
      return;
  }
  var b = ib(a.Ci, function(a) {
    return "a" != a.P() ? !0 : this.aa.Cq;
  }, this);
  "STARTING" == this.getState() ? (this.g.info(this.ia() + " queuing stream changes:."), this.Mg.push({Vv:b, LA:a.removed})) : (this.g.info(this.ia() + " sending stream adds."), this.fb = this.fb.dv(b, a.removed), this.R.update(this.fb));
  y(a.removed, this.n7, this);
  y(a.yb, this.Cca, this);
  y(b, this.CR, this);
  (0 < a.removed.length || 0 < a.yb.length || 0 < b.length) && this.dispatchEvent(new nD(xb(b, a.yb), a.removed));
};
d.CR = function(a) {
  a = new bv(this.R.s(), a);
  this.HB(a);
  this.ie.push(a);
};
d.Cca = function(a) {
  var b = lb(this.ie, function(b) {
    return b.getInfo().matches(a);
  }, this);
  if (-1 == b) {
    J(this.a, "Tried to update non-existant remote stream: " + a);
  } else {
    var c = new bv(this.R.s(), a);
    this.HB(c);
    this.ie[b] = c;
  }
};
d.n7 = function(a) {
  var b = lb(this.ie, function(b) {
    return b.getInfo().matches(a);
  }, this);
  if (-1 == b) {
    J(this.a, "Tried to remove non-existant remote stream: " + a);
  } else {
    var c = this.ie[b];
    tb(this.ie, b);
    c.ec("Oa");
  }
};
d.p4 = function(a) {
  switch(this.getState()) {
    case "INITIAL":
      this.g.l("Received remote stream requests before starting.");
      return;
    case "STOPPED":
    case "FINISHED":
      J(this.a, "Received remote stream requests after end.");
      return;
  }
  this.pE(a.US);
};
d.q4 = function(a) {
  this.gk(a.label, a.payload);
};
d.iB = function(a) {
  null != a && (this.g.info(this.ia() + " setting audio options to: " + ef(a.na())), this.aa = this.aa.Xca(a), this.fb = this.GD(x(this.fb)), this.R.iB(this.fb, a));
};
d.GD = function(a) {
  var b = a.ma, c = this.aa.Xq;
  c.lM || (b = b.k7("CN"));
  var e = b.sc(), f = lb(e, function(a) {
    return a.lt("OPUS");
  });
  if (-1 != f) {
    if (!c.sM && 1 < e.length) {
      tb(e, f);
    } else {
      var g = c.eP && !(ci && !(0 <= Ta(ck, "48")));
      e[f] = (new oq(e[f])).Fq("stereo", c.vM ? "1" : "0").Fq("useinbandfec", c.fP ? "1" : "0").Fq("usedtx", g ? "1" : "0").S();
    }
    b = b.zi(e);
  }
  c = c.fL;
  null != c && (b = b.kL(c));
  return a.We(b);
};
d.nU = function(a) {
  if (a.ma && a.ma.Ae() != this.uf().ma.Ae()) {
    var b = this.uf().ma.Ae();
    a = a.We(a.ma.pv(b));
  }
  a.ha && a.ha.Ae() != this.uf().ha.Ae() && (b = this.uf().ha.Ae(), a = a.qe(a.ha.pv(b)));
  a.getData() && a.getData().Ae() != this.uf().getData().Ae() && (b = this.uf().getData().Ae(), a = a.Ye(a.getData().pv(b)));
  return a;
};
d.pZ = function() {
  return B(this.Hp);
};
d.toString = function() {
  return "Session(Id=" + this.s() + " p2p=" + this.aa.Aa + " useAudio=" + this.aa.Cq + " useVideo=" + this.aa.$m + ")";
};
var $E = function(a, b, c, e, f, g) {
  G.call(this);
  this.a = zf("realtime.media.api.apiary.RemoteSession");
  this.g = b.al("realtime.media.api.apiary.RemoteSession");
  this.Ba = a;
  this.Wc = x(b.Wc, "A ClientConfig was not registered on the Media Api before creating the RemoteSession.");
  this.Rd = c;
  this.Oe = this.da = this.sa = this.fB = this.C = null;
  this.Sd = e;
  this.Sd.gN(8);
  this.Sd.IN(3E3);
  this.Vf = f;
  this.aa = g;
  this.g.info("Creating a new remote session with earlyMediaHangoutId=" + g.Ud + " P2P=" + g.Aa + " useAudio=" + g.Cq + " useVideo=" + g.$m);
  this.nb = this.Ya = null;
  this.QL = !1;
  this.B = new tk(this);
  this.la(this.B);
  this.cc = new gD;
  this.F = "INITIAL";
  this.Pi = [];
  this.Tt = [];
  this.Mg = [];
  this.or = {};
  this.Vl = {};
  this.ve = {};
  this.sJ = {};
  this.Mw = H();
  this.MI = H();
  this.QF = new Ae;
  this.Ty = null;
  Qu(a);
  a.ho(Pq).then(function(a) {
    var b = [a.eb("mediaSessionStartTime", u(this.UH, this)), a.eb("mediaUpStreams", u(this.p_, this)), a.eb("mediaDownStreams", u(this.YW, this)), a.eb("mediaPerfDataPoint", u(this.TY, this))];
    this.xD(function() {
      y(b, a.GA, a);
    });
  }, function(a) {
    J(this.a, "Error getting DiagnosticDataService: " + a);
  }, this);
  this.Tp = H();
  this.Tp.promise.then(function() {
    this.YA();
  }, null, this);
};
w($E, NC);
d = $E.prototype;
d.UH = function() {
  return (new Date(this.gE)).toString();
};
d.p_ = function() {
  return null != this.Ya ? this.Ya.na() : null;
};
d.YW = function() {
  return null != this.nb ? this.nb.na() : null;
};
d.TY = function() {
  return null != this.Ty ? this.Ty.cb() : null;
};
d.Sb = function(a, b, c) {
  this.F != a && (this.g.info("Session " + this.uc() + " state changed from " + this.F + " to " + a), this.F = a, this.dispatchEvent(new $u(a, b, c)));
};
d.getState = function() {
  return this.F;
};
d.W0 = function(a, b) {
  null != this.Ya ? (Bf(this.a, "Local streams collection already initiated"), x(!1, "Local streams collection already initiated")) : (this.aa.Aa ? (K(this.a, "Preparing p2p local streams collection."), this.Ya = XE(this.Ba, this.Wc, [b, 2, a], uC())) : (K(this.a, "Starting normal local streams collection."), this.Ya = UE(this.Ba, this.Wc, [b, 2, a], uC(), iE, "Ya"), this.B.listen(this.Ya, "S", this.SK), this.Ya.start()), this.B.listen(this.Ya, "Q", this.N3), this.la(this.Ya));
};
d.Z5 = function(a) {
  null != this.nb ? (Bf(this.a, "Remote streams collection already initiated"), x(!1, "Remote streams collection already initiated")) : (this.aa.Aa ? (K(this.a, "Preparing p2p remote streams collection."), this.nb = XE(this.Ba, this.Wc, [a, 1, ""], uC())) : (K(this.a, "Preparing normal remote streams collection."), this.nb = UE(this.Ba, this.Wc, [a, 1, ""], uC(), iE, "Ya"), this.B.listen(this.nb, "S", this.SK), this.B.listen(this.nb, "R", this.B3)), this.la(this.nb), this.nb.cd(), this.B.listen(this.nb, 
  "Q", this.Qz));
};
d.yba = function(a, b) {
  x(null != this.nb, "Remote streams collection has not been initiated");
  var c = this.nb, e = c.ls();
  e.Ca(a);
  e.L(b);
  b = c.start(e);
  this.a1();
  this.aa.Aa || hD(b, "Ga", a, this).jb(function() {
    this.g.error("Stopping session " + this.uc() + " because downstream search failed.");
    this.stop(16);
  }, this);
};
d.a1 = function() {
  this.aa.Aa || (null == this.Pi ? J(this.a, "Attempting to install collection filters with null participants. setParticipants() must be called prior to this call!") : this.nb.b1(u(function(a) {
    return pb(this.Pi, a.A() || "");
  }, this)));
};
d.cd = function(a) {
  if ("INITIAL" != this.F) {
    return !1;
  }
  this.QL = null != a;
  this.Z5(a || "");
  this.Sb("STARTING");
  return !0;
};
d.start = function(a) {
  this.Ca(a);
  this.Sb("STARTED");
  this.Mw.promise.then(this.qV, null, this);
  return !0;
};
d.rr = function(a, b, c) {
  this.g.info("Attempting to connect session " + this.uc() + " to Hangout: " + a);
  switch(this.F) {
    case "INITIAL":
      J(this.a, "Connect to hangout called before starting.");
      return;
    case "STOPPED":
    case "FINISHED":
      J(this.a, "Connect to hangout called after end.");
      return;
  }
  null != this.sa ? Bf(this.a, "Multiple hangouts per RemoteSession not yet supported.") : (this.sa = a, this.da = b, this.Oe = c, this.gE = v(), this.fE = this.yO(), this.Mw.resolve());
};
d.qV = function() {
  x(this.C, "Remote session running with no sessionId.");
  x(this.sa, "Remote session running with no hangoutId.");
  var a = this.Oe && this.Oe.Gh() || "";
  this.g.info("Session " + this.uc() + " is started and connected to Hangout: " + this.sa + " with participantId: " + this.da + " and participantLogId: " + a);
  this.W0(this.C, this.sa);
  this.rD(this.C, this.sa, this.Tt);
  qb(this.Tt);
  this.yba(this.C, this.sa);
  0 < this.Mg.length && (this.ty(this.Mg), qb(this.Mg));
  this.Sb("INPROGRESS");
  this.MI.resolve();
  this.sA();
};
d.Em = function(a) {
  this.Pi = a;
  null != this.nb && this.nb.qC();
  this.aa.Aa && this.Mw.promise.then(function() {
    var b = ib(a, function(a) {
      return a != this.da;
    }, this);
    if (1 != b.length) {
      1 < b.length && this.stop(51);
    } else {
      var c = new WA([1, 1, this.C, "8579373", this.sa, b[0], "1", [[8579373], []]]), b = new WA([1, 2, this.C, "8579374", this.sa, b[0], "2", [[8579374, 8579375], [["FID", [8579374, 8579375]]]]]);
      this.nb.add(c);
      this.nb.add(b);
    }
  }, null, this);
};
d.Rb = function() {
  this.Ya && this.Ya.Rb();
  this.nb && this.nb.Rb();
};
d.resume = function() {
  this.Vl = {};
};
d.stop = function(a, b) {
  this.g.info("Session " + this.uc() + " stopping because stop was called with endCause: " + a);
  if ("STOPPED" == this.F) {
    return !1;
  }
  null == this.s() || "STARTING" != this.F && "INPROGRESS" != this.F || (Sc(this.Ya), this.Ya = null, Sc(this.nb), this.nb = null, Hb(this.ve, function(a) {
    a.cancel();
  }), this.ve = {});
  this.Sb("STOPPED", a, b);
  return !0;
};
d.Ym = function(a) {
  var b = this.s(), c = this.sa, e = this.da;
  null != b ? null != c ? (a.L(c), null != this.Rd && a.Pe(this.Rd), null != e && a.Sa(e), a.kB(this.Vf.kG()), a.Xp(this.Vf.dj()), a.zu(this.Vf.El()), this.Oe && this.Oe.HD(a), this.Sd.Ym(a, b)) : J(this.a, "UploadLogData before we have a hangoutId.") : J(this.a, "UploadLogData before we have a sessionId.");
};
d.Kca = function(a) {
  var b = this.s(), c = this.sa;
  null != b ? null != c ? (this.Ty = a = this.tca(a), this.bP(b, c, a)) : J(this.a, "Upload log data before we have a hangoutId.") : J(this.a, "Upload log data before we have a sessionId.");
};
d.pV = function(a, b, c) {
  var e = this.s(), f = this.sa;
  null != e ? null != f ? this.bP(e, f, c, a, b).then(function() {
    this.dispatchEvent("ra");
  }, null, this) : J(this.a, "Finalize log data uploads before we have a hangoutId.") : J(this.a, "Finalize log data uploads before we have a sessionId.");
};
d.yO = function() {
  return window.performance && window.performance.now ? window.performance.now() : v();
};
d.YA = function() {
  this.isDisposed() || "STOPPED" == this.F || "FINISHED" == this.F || ie(function() {
    var a = this.s();
    x(a);
    this.Sd.o6(a).then(this.i4, this.h4, this);
  }, 1E4, this);
};
d.i4 = function(a) {
  this.isDisposed() || (null != a ? (a = this.cc.bA(a, !this.aa.Aa), null != a ? (this.dispatchEvent(new mD(a)), this.YA()) : this.g.info("Session " + this.uc() + " could not parse description from session query.")) : J(this.a, "Received null session proto."));
};
d.h4 = function(a) {
  if (!this.isDisposed()) {
    switch(a.status) {
      case 4:
      case 5:
      case 7:
        this.stop(15, "ClientResponseStatus: " + a.status + " with desc: " + a.desc);
        break;
      case 11:
        this.stop(41, "ClientResponseStatus: " + a.status + " with desc: " + a.desc);
        break;
      default:
        this.YA();
    }
  }
};
d.qO = function(a, b) {
  return a.$c() != b.$c() || a.rf() != b.rf() || this.F7(a.Ub(), b.Ub());
};
d.F7 = function(a, b) {
  return null != a || null != b ? null != a && null != b ? a.width != b.width || a.height != b.height : !0 : !1;
};
d.tca = function(a) {
  null != a.Eh() && (a = a.Uk(), y(a.Eh(), function(a) {
    if (2 == a.to()) {
      var b = a.As()[0] >>> 0, e = this.sJ[b];
      null != e && (a.a$(e.width), a.Z9(e.height), L(this.a, "Set last request width/height " + e.width + "/" + e.height + " for ssrc " + b + " in jmidata"));
    }
  }, this));
  return a;
};
d.bP = function(a, b, c, e, f) {
  if (null == c && null == e) {
    return Yd("Nothing to upload");
  }
  var g = new Cy;
  g.TN(this.UH());
  g.SN(this.gE);
  var k = -2;
  null != this.fE && (k = (this.yO() - this.fE) / 1000, k = Math.round(k));
  g.GM(k);
  null != a && g.FM(a);
  null != e && g.y9(e);
  null != f && g.VN(f);
  null != c && g.n9([c]);
  c = new oC;
  c.lB(g);
  c.L(b);
  null != this.da && c.Sa(this.da);
  null != this.Rd && c.Pe(this.Rd);
  c.kB(this.Vf.kG());
  c.Xp(this.Vf.dj());
  c.zu(this.Vf.El());
  this.Oe && this.Oe.OR(c);
  return this.Sd.Ym(c, a);
};
d.uR = function(a) {
  switch(this.F) {
    case "INITIAL":
    case "STARTING":
    case "STARTED":
      yb(this.Tt, a);
      return;
    case "STOPPED":
    case "FINISHED":
      J(this.a, "Add local streams called after end.");
      return;
  }
  var b = this.s(), c = this.sa;
  null == b ? this.g.error("Attempting to add local streams before we have a sessionId.") : null != c ? this.rD(b, c, a) : yb(this.Tt, a);
};
d.rD = function(a, b, c) {
  x(this.Ya, "Local streams collection unavailable.");
  y(c, function(c) {
    c = (new zq(c)).qv(x(this.da)).S();
    var e = this.cc.cE(a, b, c), g = this.Ya.Eb, k = !!mb(this.Ya.get(), function(a) {
      return g.dJ(e, a);
    }), k = hD(k ? this.Ya.modify(e) : this.Ya.add(e), "Ia", a, this);
    "d" != c.P() && k.jb(function(a) {
      this.g.error("Stopping because addLocalStream failed with error: " + a);
      this.stop(16);
    }, this);
  }, this);
};
d.Ica = function(a) {
  this.MI.promise.then(u(function() {
    x(this.sa);
    var b = (new zq(a)).qv(x(this.da)).S(), c = this.cc.cE(this.s(), this.sa, b), e = new aB;
    e.wu(b.wo());
    c.AB(e);
    this.Ya.modify(c);
  }, this));
};
d.s = function() {
  return this.C;
};
d.Ca = function(a) {
  this.C != a && (this.g.info("Session id changing from " + this.uc() + " to " + (a || "{unset}")), x(null == this.C), this.C = a, this.Tp.resolve());
};
d.uc = function() {
  if (null == this.C) {
    return "{unset}";
  }
  null == this.fB && (this.fB = this.C.substring(0, 6) + "{#" + (this.C.length - 7) + "}" + this.C.substring(this.C.length - 1));
  return this.fB;
};
d.rI = function() {
  if (null != this.Ya) {
    var a = mb(this.Ya.get(), function(a) {
      return 2 == a.P();
    });
    null == a ? this.g.l("Attempting to signal screencast started, but no video stream found!") : (a = a.clone(), a.Cu(!1), a.Cu(!1), this.Ya.modify(a));
  }
};
d.qI = function() {
  if (null != this.Ya) {
    var a = mb(this.Ya.get(), function(a) {
      return 2 == a.P();
    });
    null == a ? this.g.l("Attempting to signal screencast ended, but no video stream found!") : (a = a.clone(), a.Cu(!0), this.Ya.modify(a));
  }
};
d.Rk = function(a) {
  this.or = {};
  y(a, function(a) {
    this.or[this.ZE(a)] = a;
  }, this);
  this.sA();
};
d.sA = function() {
  switch(this.F) {
    case "INITIAL":
    case "STARTING":
    case "STOPPED":
    case "FINISHED":
      return;
  }
  if (null == this.s()) {
    this.g.error("Ignoring changed stream requests because we don't have a sessionId.");
  } else {
    if (null == this.sa) {
      this.g.error("Ignoring changed stream requests because we don't have a hangoutId.");
    } else {
      var a = {}, b = this.cc.hh("v");
      y(this.nb.get(), function(c) {
        c.P() == b && (a[this.ZE(c)] = c);
      }, this);
      Hb(this.or, function(b, e) {
        if (a[e]) {
          var c = a[e], g = c.Vb(), k = this.Vl[g];
          if (!k || this.qO(k, b)) {
            this.Vl[g] = b, this.zw(c, b), this.ve[e] && this.ve[e].cancel(), delete this.ve[e];
          }
        } else {
          K(this.a, "Skipping stream request for " + b.A() + " (no matching stream was found).");
        }
      }, this);
      Hb(a, function(a, b) {
        var c = a.Vb();
        if (!this.or[b]) {
          var e = this.Vl[c];
          if (e) {
            var k = e.yP(0, 0).xP(0).jn(!1);
            this.qO(e, k) && (this.Vl[c] = k, this.zw(a, k));
          } else {
            if (!this.ve[b]) {
              var q = this.cc.aL([a])[0].yP(0, 0).xP(0).jn(!1);
              this.ve[b] = ke(2E3);
              this.ve[b].then(function() {
                delete this.ve[b];
                this.Vl[c] = q;
                this.zw(a, q);
              }, void 0, this);
            }
          }
        }
      }, this);
      Hb(this.ve, function(b, e) {
        a[e] || (b.cancel(), delete this.ve[e]);
      }, this);
    }
  }
};
d.zw = function(a, b) {
  if ("STOPPED" != this.F && "FINISHED" != this.F) {
    this.QF.contains(b.A()) && (b = b.Wf(""));
    var c = a.Vb(), e = b.$c();
    if (!b.Ub() || 0 >= b.Ub().height || 0 >= b.Ub().width || 0 >= b.rf()) {
      e = !1;
    }
    var f = x(this.s()), g = x(this.sa), e = this.cc.mS(f, g, b, e);
    e.lk(c);
    this.g.info("Session " + this.uc() + " sending stream request: " + b.toString() + " with streamId: " + c);
    e.pN(a.wg());
    this.nb.modify(e);
    b = b.Ub();
    null != b && null != a.wg() && null != a.wg().ij() && (a = a.wg().ij()[0] >>> 0, null != a && (this.sJ[a] = b, L(this.a, "Building map: last request width/height " + b.width + "/" + b.height + " for ssrc " + a)));
  }
};
d.ZE = function(a) {
  return (a.A() || "") + "/" + (a.ya() || "");
};
d.Qz = function(a) {
  null != a.Ci && 0 < a.Ci.length && this.ty(a.Ci);
  null != a.yb && 0 < a.yb.length && this.a0(a.yb);
  null != a.removed && 0 < a.removed.length && this.g0(a.removed);
};
d.B3 = function(a) {
  var b = a.yb ? a.yb.length : 0;
  L(this.a, "Received early streams push notification with " + b + " modified streams");
  if (this.QL && 0 != b) {
    if ("INPROGRESS" == this.F) {
      this.ty(a.yb);
    } else {
      if ("STARTING" == this.F || "STARTED" == this.F) {
        this.Mg = xb(this.Mg, a.yb);
      }
    }
  }
};
d.ty = function(a) {
  var b = this.dA(a);
  null != b ? 0 == b.length ? J(this.a, "Got empty streamInfos: " + a) : (a = ib(b, function(a) {
    return a.A() != this.da;
  }, this), this.sA(), y(a, function(a) {
    this.g.info("Session " + this.uc() + " notified of new remote stream: " + a.toString());
  }, this), this.dispatchEvent(new OC(a, [], []))) : J(this.a, "Failed to parse streamInfos: " + b);
};
d.a0 = function(a) {
  var b = this.dA(a);
  null == b ? J(this.a, "Failed to parse streamInfos: " + b) : 0 == b.length ? J(this.a, "Got empty streamInfos: " + a) : (y(b, function(a) {
    this.g.info("Session " + this.uc() + " received modified remote stream: " + a.toString());
  }, this), this.dispatchEvent(new OC([], b, [])));
};
d.g0 = function(a) {
  var b = this.dA(a);
  null != b ? 0 == b.length ? J(this.a, "Got empty streamInfos: " + a) : (y(b, function(a) {
    this.g.info("Session " + this.uc() + " removing remote stream: " + a.toString());
  }, this), this.dispatchEvent(new OC([], [], b))) : J(this.a, "Failed to parse streamInfos: " + b);
};
d.dA = function(a) {
  a = this.cc.E5(a);
  return a = z(a, function(a) {
    if ("" == a.ya()) {
      var b;
      "a" == a.P() ? b = "1" : "v" == a.P() ? b = "2" : "d" == a.P() && (b = "3");
      a = (new zq(a)).Wf(x(b)).S();
      this.QF.add(a.A());
    }
    return a;
  }, this);
};
d.N3 = function(a) {
  if (sa(a.removed) && 0 < a.removed.length) {
    0 == this.Ya.get().length && (this.g.info("Session " + this.uc() + " terminating to handle Reflector failover."), this.Sb("STOPPED", 26));
  } else {
    if (sa(a.yb) && 0 < a.yb.length) {
      var b = this.cc.aL(a.yb);
      null != b ? 0 == b.length ? J(this.a, "Got empty stream requests: " + a) : this.dispatchEvent(new PC(b)) : J(this.a, "Failed to parse stream requests: " + a);
    }
  }
};
d.SK = function(a) {
  this.g.error("Stopping session " + this.s() + " because stream collection failed, with reason: " + a.reason);
  this.stop(a.hb);
};
var aF = function(a, b, c, e) {
  var f = 0;
  l(e) && (c = c.Uk(), c.aN(!0), f = v() + e);
  var g = H(), k = function(a) {
    v() >= f ? g.reject(a) : ie(r, 5000);
  }, q = function(c) {
    var e = c.getResponseHeader();
    x(null != e, "Missing response header");
    1 == e.Ra() ? (c = Za(c.O(), "Resolve response missing hangout id"), g.resolve(VE(a, b, c))) : k(new Aq("fatal", "backend", null, c));
  }, r = function() {
    var e = c, f = db(JE.W().Cl(a, b), WD), g = f.rl(), e = e.Uk();
    e.setRequestHeader(f.Cx());
    g.Xl("hangouts/resolve", e).then(q).jb(k);
  };
  r();
  return g.promise;
};
var bF = function(a, b, c, e) {
  G.call(this);
  this.a = zf("realtime.media.session.SessionManager");
  this.fi = b;
  this.Wc = x(this.fi.Wc, "A ClientConfig was not registered on the Media Api before creating the SessionManager.");
  this.g = this.fi.al("realtime.media.session.SessionManager");
  this.B = new tk(this);
  this.la(this.B);
  this.Ba = a;
  this.Oe = this.da = this.sa = null;
  this.F = "INITIAL";
  this.Of = null;
  this.Gd = new I;
  xe(Zu, function(a) {
    this.Gd.set(a, new Ae);
  }, this);
  this.Gc = new Ae;
  this.nu = new I;
  this.gg = null;
  this.Td = new Xp;
  this.cc = new gD;
  this.oca = c;
  this.FU = e;
  this.rn = [];
  this.Pi = [];
  this.HI = new Iq(this.Ba);
  this.hl = this.td = null;
  this.R0();
  this.aJ = H();
  this.Px = H();
  ae([this.aJ.promise, this.Px.promise]).then(function() {
    this.Rv(!0);
  }, null, this);
  this.ad = fv(a, Rq, jy);
};
w(bF, G);
var cF = new Bp("", "", "a"), dF = new Bp("", "", "v", new Ji(320, 180), 30), eF = new Bp("", "", "v", ZE, 30);
d = bF.prototype;
d.R0 = function() {
  Qu(this.Ba);
  this.Ba.ho(Pq).then(function(a) {
    this.td = a;
    this.hl = [this.td.eb("sessionManagerState", u(this.getState, this)), this.td.eb("p2pSessionActive", u(function() {
      return jb(this.tg(), function(a) {
        return a.Ce().Aa;
      });
    }, this)), this.td.eb("sessions", u(function() {
      return z(this.Gc.H(), function(a) {
        return a.na();
      }, this);
    }, this))];
  }, function(a) {
    J(this.a, "Error getting DiagnosticDataService: " + a);
  }, this);
};
d.U = function() {
  y(this.Gc.H(), Sc);
  null != this.td && y(this.hl, this.td.GA, this.td);
  bF.T.U.call(this);
};
d.getState = function() {
  return this.F;
};
d.ec = function(a, b, c) {
  a != this.F && (this.g.info("SessionManager changed state from " + this.F + " to " + a), this.F = a, this.dispatchEvent(new $u(a, b, c)));
};
d.cd = function(a) {
  if ("INITIAL" != this.getState()) {
    return !1;
  }
  this.X0();
  this.uca(a);
  this.gg = this.Rv(!1);
  if (null == this.gg) {
    return this.g.error("Failed to create the cloud session."), this.stop(16), !1;
  }
  this.ec("STARTING");
  return !0;
};
d.start = function() {
};
d.Rb = function() {
  this.Of && this.Of.Rb();
  y(this.Gc.H(), function(a) {
    a.Rb();
  });
};
d.connect = function(a, b, c) {
  if ("STARTING" != this.getState() && "INPROGRESS" != this.getState()) {
    return !1;
  }
  this.sa = a;
  this.da = b;
  this.Oe = c;
  this.g.info("Connecting to hangoutId: " + a + ", with participantId: " + b + " and sessionLogData: " + c);
  this.Px.resolve(this.sa);
  var e = xb(this.tg(), this.Yx(), this.Bs());
  y(e, function(e) {
    e.rr(a, b, c);
  }, this);
  return !0;
};
d.uca = function(a) {
  this.g.info("Updating desfault options to: " + ef(a.na()));
  this.Td = a;
  this.Td.Aa && this.aJ.resolve(!0);
  if (null == this.sa || Ga(this.sa)) {
    this.sa = this.Td.Ud;
  }
  null == this.sa || Ga(this.sa) || this.Px.resolve(this.sa);
};
d.yT = function(a, b) {
  b.Aa || (b.Ic() ? a = a.BP(new rp("call/" + b.Ic(), 1, null, "collections")) : J(this.a, "Collections' push channel not added. ClientResource not available"), b.gP && (a = a.BP(new rp("msodc", 3, null, "msodc"))));
  return a;
};
d.mZ = function() {
  var a = {};
  y(this.Gc.H(), function(b) {
    b.Ce().Aa || (a[b.ia()] = b.s());
  });
  return a;
};
d.getLocalStreams = function() {
  var a = [];
  y(this.tg(), function(b) {
    yb(a, b.getLocalStreams());
  });
  return a;
};
d.getRemoteStreams = function() {
  var a = [];
  y(this.tg(), function(b) {
    yb(a, b.getRemoteStreams());
  });
  return a;
};
d.Gk = function(a) {
  y(this.Gc.H(), function(b) {
    b.Gk(a);
  });
  this.Td = this.Td.rP(a);
};
d.ux = function() {
  this.Td.Ri || (y(this.Gc.H(), function(a) {
    a.ux();
  }), this.Td = this.Td.sP());
};
d.ly = function() {
  return this.Td;
};
d.ld = function(a) {
  this.g.info("Adding capture: " + ef(a.na()));
  var b = !0;
  y(this.YF(), function(c) {
    c = c.ld(a);
    b = b && c;
  });
  "xa" == a.K().Kb && (b = !0);
  b ? this.rn.push(a) : this.je(a);
  return b;
};
d.je = function(a) {
  var b = !0;
  y(this.YF(), function(c) {
    x(a);
    b = b && c.je(a);
  });
  return b = b && ub(this.rn, a);
};
d.js = function() {
  return this.rn.concat();
};
d.ib = function(a, b) {
  var c = xb(this.tg(), this.Bs(), this.py());
  if (null != b) {
    var e = mb(this.Gc.H(), function(a) {
      return a.ia() == b;
    });
    e && c.unshift(e);
  }
  if (0 == c.length) {
    return this.g.info("No active session to get stream from to render source: " + a), null;
  }
  for (e = 0;e < c.length;e++) {
    var f = c[e], g = f.ib(a);
    if (null != g) {
      return this.g.info("Using stream: " + g.getInfo() + " from " + f.ia() + " to render source: " + a), g;
    }
  }
  this.g.l("Unable to find stream to use to render source: " + a);
  return null;
};
d.Rk = function(a) {
  var b = xb(this.py(), this.Bs(), this.tg());
  y(b, function(b) {
    b.Rk(a);
  });
};
d.Em = function(a) {
  y(this.Gc.H(), function(b) {
    b.Em(a);
  }, this);
  this.Pi = a;
};
d.stop = function(a, b) {
  this.g.info("Stopping video call because stop called with endCause: " + a);
  if ("INITIAL" == this.getState() || "STOPPED" == this.getState() || "FINISHED" == this.getState()) {
    return !1;
  }
  this.ec("STOPPED", a, b);
  y(this.Gc.H(), function(c) {
    c.stop(a, b);
  });
  return !0;
};
d.Rv = function(a) {
  var b = this.KZ(this.Td, a);
  if (null == b) {
    return null;
  }
  var c = this.sS(b);
  if (null == c) {
    return this.g.l("Failed to build session."), null;
  }
  var e = this.yT(c.uf(), b);
  a = this.cc.rS(e, b.Ud, b.ze(), b.Ic(), a);
  if (null == a) {
    return this.g.l("Failed to parse session info."), null;
  }
  a = this.Of.add(a);
  a.then(function(a) {
    x(null != b);
    x(null != c);
    this.F_(c, a, b);
    return a;
  }, null, this).jb(function(a) {
    this.g.l("Failed to add session to collection. Error: " + a);
    c.stop(16);
    throw a;
  }, this);
  hD(a, "Ha", null, this);
  return c;
};
d.TT = function(a) {
  a.Hc() || (a = a.ov(this.HI.Hc()));
  var b = this.fi.xr(this.Ba, this.GV(a), a);
  if (a.Aa && 2 < this.Pi.length) {
    return this.g.info("Not creating p2p session due to too many participants."), null;
  }
  var c = this.fi.zr(this.Ba, a);
  return new YE(this.Ba, this.fi, b, c, a);
};
d.sS = function(a) {
  a = this.TT(a);
  if (null == a) {
    return null;
  }
  this.Gc.add(a);
  this.Gd.get(a.getState()).add(a);
  this.nu.set(a.ia(), a.getState());
  a.Daa(this.FU);
  a.Eaa(this.oca);
  a.Em(this.Pi);
  this.B.listen(a, ["u", "v", "sa", "va", "qa"], this.dispatchEvent);
  this.B.listen(a.pa, "ja", this.dispatchEvent);
  this.B.listen(a, "L", this.Rz);
  this.B.listen(a, "pa", this.Mz);
  this.B.listen(a, "na", this.Pz);
  this.B.listen(a, "oa", this.I3);
  return a;
};
d.zba = function(a, b) {
  a.start(b);
  y(this.rn, function(b) {
    a.ld(b);
  });
};
d.Tba = function(a) {
  this.Gd.get(a.getState()).remove(a);
  this.nu.remove(a.ia());
  this.Gc.remove(a);
  Sc(a);
};
d.YF = function() {
  return xb(this.MX(), this.py(), this.Bs(), this.Yx(), this.tg());
};
d.Yx = function() {
  return this.Gd.get("PAUSED").H();
};
d.tg = function() {
  return this.Gd.get("INPROGRESS").H();
};
d.Bs = function() {
  return this.Gd.get("STARTED").H();
};
d.py = function() {
  return this.Gd.get("STARTING").H();
};
d.MX = function() {
  return this.Gd.get("INITIAL").H();
};
d.F_ = function(a, b, c) {
  K(this.a, "Session add response received.");
  1 > b.length || !(b[0] instanceof CC) ? (this.g.info("Stopping remote session due to receiving null session proto."), a.stop(16)) : (b = b[0], null != b ? (c = this.cc.bA(b, !c.Aa), null != c ? this.uy(a, c) : (this.g.info("Stopping session due to inability to parse session proto."), a.stop(16))) : (this.g.info("Stopping session due to inability to parse session proto."), a.stop(16)));
};
d.X0 = function() {
  var a = this.Ba, b = this.Wc, c = new lq(CC, [], [], [CC.prototype.s], [CC.prototype.Ca], Ft, [], [], [Ft.prototype.s], [Ft.prototype.Ca]), e = JE.W(), f = new gE(e.Cl(a, b)), g = new np(e.Ih(a, b), "Wa");
  this.Of = new my(a, e.pf(a, b), [], c, f, g, e.Dh(a, b));
  this.la(this.Of);
  this.Of.cd();
  this.B.listen(this.Of, "Q", this.x4);
  this.B.listen(this.Of, "S", this.y4);
};
d.GV = function(a) {
  return "c" + Math.round(2147483648 * Math.random()) + Math.round(2147483648 * Math.random()) + (a.Aa ? "_P2P" : "_NMS");
};
d.KZ = function(a, b) {
  var c = a.Ud || this.sa;
  null != c && a.DD ? (a = a.Ck([cF, dF]), a = a.uP(c)) : a = a.uP(null);
  a = a.jda(b);
  if (b) {
    a = a.kda(!1);
    if (null == this.gg) {
      return Bf(this.a, "P2P session starting first! This is bad!"), x(!1), null;
    }
    a = a.gda(!1);
    a = a.Ck([cF, eF]);
  }
  return a;
};
d.x4 = function(a) {
  null != a.yb && 0 < a.yb.length && this.b0(a.yb);
  null != a.removed && 0 < a.removed.length && this.h0(a.removed);
};
d.y4 = function(a) {
  this.g.error("Stopping video call because session collection failed, with reason: " + a.reason);
  this.stop(a.hb);
};
d.b0 = function(a) {
  y(a, function(a) {
    var b = mb(this.Gc.H(), function(b) {
      return a.s() == b.s();
    });
    if (b) {
      var e = !b.Ce().Aa, e = this.cc.bA(a, e);
      null != e && this.uy(b, e);
    } else {
      Bf(this.a, "Received modification for a session that we don't have!");
    }
  }, this);
};
d.h0 = function(a) {
  y(a, function(a) {
    var b = mb(this.Gc.H(), function(b) {
      return a.s() == b.s();
    });
    b ? b.stop(25) : this.g.error("Received removal of a session that we don't have! Session id: " + a.s());
  }, this);
};
d.Pz = function(a) {
  this.uy(a.currentTarget, a.sessionDescription);
};
d.uy = function(a, b) {
  var c = a.getState(), e = "INITIAL" == c, f = "INITIAL" == c || "STARTING" == c, c = "INITIAL" != c && "STARTING" != c;
  b.M0() || (f = e = !1);
  var g = b.kc();
  null != g && null != g.wi && null != g.di && 0 != g.jo().length || (f = !1);
  g = b.s();
  null != g && a.Ca(g);
  e && (this.g.info("Received remote description for session " + a.pa.uc() + " with sufficient data to allow session preparation."), a.cd(b));
  f ? (this.g.info("Received remote description for session " + a.pa.uc() + " with sufficient data to allow starting the session."), this.zba(a, b)) : c && a.Bca(b);
};
d.I3 = function(a) {
  if ("INPROGRESS" != this.getState()) {
    J(this.a, "Ingress bandwidth updated before started.");
  } else {
    var b = this.HI.Hc(), c = new st;
    -1 != b.Ej && c.mN(b.Ej);
    -1 != b.Eg && c.fN(b.Eg);
    -1 != b.qk && c.RN(b.qk);
    b = new VB;
    b.iN(c);
    c = new CC;
    c.Ca(a.sessionId);
    a = this.sa || this.Td.Ud;
    null === a || c.ZM([a]);
    c.nB([b]);
    this.Of.modify(c);
  }
};
d.Mz = function(a) {
  switch(this.getState()) {
    case "INITIAL":
      J(this.a, "Received local candidates before starting.");
      return;
    case "STOPPED":
    case "FINISHED":
      J(this.a, "Received local candiates after end.");
      return;
  }
  var b = a.target, c = [];
  y(a.En, function(a) {
    a = this.cc.$D(a);
    c.push(a);
    a.dg();
  }, this);
  if (!(1 > c.length)) {
    var e = new xx;
    e.HM(c);
    var f = b.uf().kc();
    if (f && (e.YN(f.wi), e.yN(f.di), f.ud())) {
      var g = new Ax;
      g.AM(f.ud().split(" ")[0]);
      g.UM(f.ud().split(" ")[1]);
      e.ON(g);
    }
    var k = [];
    y(b.uf().Ah(), function(a) {
      k.push(this.cc.aE(a));
    }, this);
    b = new VB;
    b.oc(4);
    b.XN(e);
    b.KM(k);
    e = new CC;
    e.Ca(a.sessionId);
    e.nB([b]);
    this.Of.modify(e);
  }
};
d.Rz = function(a) {
  var b = a.target, c = this.nu.get(b.ia()), e = b.getState();
  if (c != e) {
    this.nu.set(b.ia(), e);
    this.Gd.get(c).remove(b);
    this.Gd.get(e).add(b);
    switch(e) {
      case "STARTED":
        this.o0(b);
        break;
      case "INPROGRESS":
        this.n0(b);
        break;
      case "STOPPED":
        x(null != a.hb);
        this.p0(b, a.hb, a.th);
        break;
      case "FINISHED":
        this.m0(b);
    }
    this.dispatchEvent(a);
  }
};
d.o0 = function(a) {
  null != this.sa && null != this.da && null != this.Oe && a.rr(this.sa, this.da, this.Oe);
};
d.n0 = function(a) {
  if ("INITIAL" == this.getState() || "STOPPED" == this.getState() || "FINISHED" == this.getState()) {
    Bf(this.a, "Should not have new active sessions now.");
  } else {
    "STARTING" == this.getState() && this.ec("INPROGRESS");
    a.iB(this.Td.Xq);
    var b = a.ia(), c = this.tg();
    y(c, function(c) {
      b != c.ia() && (c.pause(), this.NA(c, a));
    }, this);
  }
};
d.p0 = function(a, b, c) {
  y(this.rn, function(b) {
    b.nC(a.ia());
  });
  if (26 == b) {
    b = this.gg, this.gg = this.Rv(!1), b && (this.gg ? this.NA(b, this.gg) : this.g.error("Cloud session" + b.s() + " to cloud handoff failed"));
  } else {
    55 == b && this.ad.then(function(b) {
      b.Ge(3262, a.s() || void 0);
    }, null, this);
    var e = this.Gd.get("STOPPED").V() + this.Gd.get("FINISHED").V();
    this.Gc.V() == e ? "STOPPED" != this.F && (this.g.info("All sessions now stopped."), this.stop(b, c)) : 0 == this.tg().length && y(this.Yx(), function(b) {
      b.resume();
      this.NA(a, b);
    }, this);
  }
};
d.m0 = function(a) {
  this.Tba(a);
  this.Gc.V() == this.Gd.get("FINISHED").V() && ("STOPPED" != this.F ? J(this.a, "Session Manager finished before stopping.") : this.ec("FINISHED"));
};
d.NA = function(a, b) {
  var c;
  c = a.Ce().Aa ? 5 : b.Ce().Aa ? 4 : 6;
  var e = new xv;
  e.Rf(c);
  e.z9(0);
  e.T$(a.s());
  e.z$(b.s());
  e.c9(v());
  var f = new oC;
  f.K9(e);
  a.pa.Ym(f);
  4 == c && this.ad.then(function(a) {
    a.Ge(3260, b.s() || void 0);
  }, null, this);
  this.g.info("Handing off from " + (a.Ce().Aa ? "P2P" : "RF") + " session to " + (b.Ce().Aa ? "P2P" : "RF") + " session");
};
var fF = function(a) {
  Tq.call(this, a);
};
w(fF, Tq);
dq(fF, Tq, 1);
fF.prototype.zr = function(a, b) {
  var c = x(this.Tq.Wc, "ClientConfig is missing"), e = new CD(c.rl(), x(c.Ic()), x(c.xg()), c.wf(), void 0, c.rc());
  a = new $E(a, this.Tq, c.Ic(), e, c.Io(), b);
  a.la(e);
  return a;
};
var gF = function(a, b) {
  tk.call(this);
  this.Pf = a;
  this.Pa = b;
  this.jd = null;
  this.kb = [];
  this.xy = this.zy = !1;
  this.cc = new gD;
  this.dz = null;
};
w(gF, tk);
d = gF.prototype;
d.U = function() {
  y(this.kb, function(a) {
    this.Pf.je(a);
  }, this);
  this.kb = [];
  this.jd = null;
  gF.T.U.call(this);
};
d.ld = function(a) {
  this.listen(a.K(), ["x", "y", "z", "A"], this.TJ);
  this.kb.push(a);
  this.Pf.ld(a);
  this.Lw();
};
d.je = function(a) {
  this.Fc(a.K(), ["x", "y", "z", "A"], this.TJ);
  ub(this.kb, a);
  this.Pf.je(a);
  this.Lw();
};
d.vI = function(a) {
  return pb(this.kb, a);
};
d.Lw = function() {
  var a = this.jd, b = this.kb[this.kb.length - 1] || null;
  y(this.kb, function(a) {
    "xa" == a.K().Kb && (b = a);
  });
  a != b && (this.jd = b, this.qz());
};
d.TJ = function(a) {
  var b = this.jd;
  this.Lw();
  b && b == this.jd && a.target == b.K() && this.qz();
};
d.qz = function() {
  this.isDisposed() || (this.xy ? this.zy = !0 : (this.zy = !1, this.xy = !0, ae([this.Pa.$, this.Pa.za, this.Pa.Tf]).then(function(a) {
    this.l6(a[0], a[1], a[2]);
  }, this.Ft, this)));
};
d.l6 = function(a, b, c) {
  var e;
  null != this.jd ? (e = this.cc.tS(a, this.jd.K()), e.L(a), e.Sa(b), e.Qf(this.jd.K().getId()), this.dz = e) : this.dz && (e = this.dz, e.Be().wu(!0));
  e ? c.add(e).then(this.Ft, this.Ft, this) : this.Ft();
};
d.Ft = function() {
  this.xy = !1;
  this.zy && this.qz();
};
var hF = function(a, b, c, e, f) {
  G.call(this);
  this.cc = new gD;
  this.Ff = a;
  this.pk = b;
  this.Nt = c;
  this.Pf = f;
  this.Ng = new I;
  this.lz = new Xr;
  this.B = new tk(this);
  this.la(this.B);
  this.B.listen(this.pk, "Q", this.eC);
  this.B.listen(this.Pf, ["va", "L"], this.eC);
  y(e, this.Pv, this);
};
w(hF, Wu);
d = hF.prototype;
d.Pv = function(a) {
  this.lz.add(a);
};
d.JL = function(a) {
  this.lz.remove(a);
};
d.oy = function(a) {
  return a == this.Ff ? this.lz : this.Ng.get(a, null);
};
d.BB = function(a) {
  var b = new Ae;
  y(a, function(a) {
    if (a != this.Ff && (b.add(a), !this.Ng.Ma(a))) {
      var c = new Xr;
      this.Ng.set(a, c);
      this.dispatchEvent(new $r("D", Za(a), c));
    }
  }, this);
  y(this.Ng.ub(), function(a) {
    if (!b.contains(a)) {
      var c = this.Ng.get(a);
      this.Ng.remove(a) && this.dispatchEvent(new $r("E", a, c));
    }
  }, this);
  this.eC();
};
d.eC = function() {
  var a = new Ae;
  y(this.pk.get(), function(b) {
    this.t0(b);
    a.add(this.cs(x(b.A()), x(b.ya())));
  }, this);
  y(this.Pf.getRemoteStreams(), function(b) {
    var c = b.A(), e = b.ya();
    if (c != this.Ff && !a.contains(this.cs(c, e))) {
      b = b.getInfo().P();
      var f = this.Ng.get(c);
      null != f && !f.Vr(b, e, c) && f.add(new Wr(c, e, b));
      a.add(this.cs(c, e));
    }
  }, this);
  y(this.Ng.H(), function(b) {
    y(b.getSources(), function(c) {
      a.contains(this.cs(x(c.A()), x(c.getId()))) || b.remove(c);
    }, this);
  }, this);
};
d.cs = function(a, b) {
  return a + "/" + b;
};
d.t0 = function(a) {
  var b = this.Ng.get(a.A());
  if (null != b && (a = this.cc.B5(a).source, null != a)) {
    var c = b.Vr(a.N(), a.getId(), a.A());
    null != c ? (c.j9(a.Kb), c.eaa(a.Mp), c.ec(a.getState()), c.bO(a.gI())) : b.add(a);
  }
};
var jF = function(a, b, c) {
  G.call(this);
  this.Pf = x(a);
  this.Fu = x(b);
  this.Ff = x(c);
  this.a = zf("realtime.media.detours.FreezeDetector");
  this.B = new tk(this);
  this.la(this.B);
  this.jq = new I;
  this.Pb = new I;
  this.Pb.set(c, new iF);
  var e = this.Fu.oy(c);
  null != e && y(e.getSources(), function(a) {
    a = e.Vr(a.N(), a.getId(), a.A());
    null == a || "v" != a.N() && "a" != a.N() || (this.KO(a), (a = this.Pf.ib(a)) && this.LO(a.getInfo()));
  }, this);
  this.B.listen(this.Pf, "qa", this.X_).listen(this.Pf, "va", this.z0).listen(this.Fu, "D", this.v0).listen(this.Fu, "E", this.w0).listen(e, "B", this.uI).listen(e, "C", this.u0);
};
w(jF, G);
d = jF.prototype;
d.X_ = function(a) {
  a = a.te.Eh();
  if (null != a) {
    var b = v();
    y(a, function(a) {
      var c = a.zg();
      if (null != c && this.jq.Ma(c)) {
        var f = this.jq.get(c);
        if (this.Pb.Ma(f)) {
          var g = "", f = this.Pb.get(f), k = a.to(), q = a.jc(), r;
          k == Wy.Iv ? (g = Qa(g, "Video "), r = f.Pm.get(c)) : (g = Qa(g, "Audio "), r = f.Om.get(c));
          null != r && (k == Wy.UQ ? (k = 0, q == Xy.Kq ? (k = a.oG() - r.sw, g = Qa(g, "Sent: ")) : q == Xy.gD && (k = a.nG() - r.sw, g = Qa(g, "Received: ")), 0 <= k && b > r.Qh ? (0 != r.Qh ? r.bitRate = 8000 * k / (b - r.Qh) : "Aa" == f.$f && (r.bitRate = 1500), r.Qh = b, r.sw = q == Xy.Kq ? a.oG() : a.nG(), g = Qa(g, r.bitRate.toString(), " Bps")) : (r.bitRate = 1500, g = Qa(g, "Negative bits or time"))) : k == Wy.Iv && (a = a.nX(), 0 == r.Qh && "Aa" == f.$g && (a = 24), 0 <= a && b > r.Qh ? 
          (r.Xy = r.mf, r.mf = a, g = Qa(g, q == Xy.Kq ? "Sent: " : "Received: ", a.toString(), " Fps")) : (r.Xy = r.mf, r.mf = 15, g = Qa(g, "Negative fps or time")), r.Qh = b), g = Qa(g, " Ssrc: ", c), K(this.a, g));
        } else {
          J(this.a, "Received media info for unknown participant with id: " + f);
        }
      }
    }, this);
    this.aT(b);
  }
};
d.aT = function(a) {
  y(this.Pb.ub(), function(b) {
    var c = this.Pb.get(b);
    "za" != c.$f && this.sE(b, c, a, "a");
    "za" != c.$g && this.sE(b, c, a, "v");
  }, this);
};
d.sE = function(a, b, c, e) {
  var f = null;
  "a" == e ? f = b.Om.H() : "v" == e && (f = b.Pm.H());
  var g = !0, k = 0;
  y(f, function(a) {
    "a" == e ? (1500 <= a.bitRate && (g = !1), a.bitRate > k && (k = a.bitRate)) : "v" == e && (24 <= a.mf || 24 <= a.Xy && 15 <= a.mf ? g = !1 : "xa" == b.mv && 0 < a.mf && (g = !1), a.mf > k && (k = a.mf));
  }, this);
  g ? 0 < f.length && ("a" == e && "Aa" == b.$f && 11000 < c - b.Uu ? b.Kk || (b.Kk = !0, this.dispatchEvent(new kF("pb", a))) : "v" == e && "Aa" == b.$g && 11000 < c - b.uq && !b.cn && (b.cn = !0, this.dispatchEvent(new kF("qb", a)))) : ("a" == e && b.Kk ? (b.Kk = !1, this.dispatchEvent(new kF("rb", a))) : "v" == e && b.cn && (b.cn = !1, this.dispatchEvent(new kF("sb", a))), this.A8(e, b, k, c) && this.dispatchEvent(new kF("a" == e ? "ub" : "tb", a)));
};
d.A8 = function(a, b, c, e) {
  return "a" == a && "Ba" == b.$f && 2000 <= c && 11000 < e - b.Uu || "v" == a && "Ba" == b.$g && 11000 < e - b.uq ? !0 : !1;
};
d.z0 = function(a) {
  y(a.Vv, function(a) {
    this.LO(a);
  }, this);
  y(a.LA, function(a) {
    this.yV(a);
  }, this);
};
d.LO = function(a) {
  var b = "" == a.A() ? this.Ff : a.A();
  if (this.Pb.Ma(b)) {
    var c = this.Pb.get(b);
    y(a.wd(), function(e) {
      "a" == a.P() ? (c.Om.Ma(e) || c.Om.set(e, new lF), this.jq.set(e, b)) : "v" == a.P() && (c.Pm.Ma(e) || c.Pm.set(e, new mF), this.jq.set(e, b));
    }, this);
  } else {
    J(this.a, "Attempted to track new stream for unknown participant with id: " + b);
  }
};
d.yV = function(a) {
  var b = "" == a.A() ? this.Ff : a.A();
  if (this.Pb.Ma(b)) {
    var c = this.Pb.get(b);
    y(a.wd(), function(b) {
      "a" == a.P() ? c.Om.remove(b) : "v" == a.P() && c.Pm.remove(b);
      this.jq.remove(b);
    }, this);
  } else {
    J(this.a, "Attempted to forget stream for unknown participant with id: " + b);
  }
};
d.x0 = function(a) {
  var b = "" == a.A() ? this.Ff : a.A();
  if (this.Pb.Ma(b)) {
    var c = this.Pb.get(b);
    "a" == a.N() ? (c.Uu = v(), "Aa" == c.$f && "Ba" == a.getState() && c.Kk && (c.Kk = !1, this.dispatchEvent(new kF("rb", b))), c.$f = a.getState()) : "v" == a.N() && (c.uq = v(), "Aa" == c.$g && "Ba" == a.getState() && c.cn && (c.cn = !1, this.dispatchEvent(new kF("sb", b))), c.$g = a.getState());
  } else {
    J(this.a, "Source state changed for unknown participant with id: " + b);
  }
};
d.s0 = function(a) {
  var b = "" == a.A() ? this.Ff : a.A();
  this.Pb.Ma(b) ? (b = this.Pb.get(b), "v" == a.N() && ("xa" == b.mv && "wa" == a.Kb && (b.uq = v()), b.mv = a.Kb)) : J(this.a, "Source content changed for unknown participant with id: " + b);
};
d.v0 = function(a) {
  this.Pb.set(a.A(), new iF);
  this.B.listen(a.oy(), "B", this.uI);
};
d.uI = function(a) {
  this.KO(a.source);
};
d.w0 = function(a) {
  this.Pb.Ma(a.A()) ? (a = this.Pb.get(a.A()), a.$f = "za", a.$g = "za", a.Om.clear(), a.Pm.clear()) : J(this.a, "Sourceset removed for unknown participant with id: " + a.A());
};
d.u0 = function(a) {
  var b = "" == a.source.A() ? this.Ff : a.source.A();
  this.Pb.Ma(b) ? (b = this.Pb.get(b), "a" == a.source.N() ? b.$f = "za" : "v" == a.source.N() && (b.$g = "za")) : J(this.a, "Source removed from unknown participant  with id: " + b);
};
d.KO = function(a) {
  var b = "" == a.A() ? this.Ff : a.A();
  this.Pb.Ma(b) ? (b = this.Pb.get(b), "a" == a.N() ? (b.$f = a.getState(), b.Uu = v()) : "v" == a.N() && (b.$g = a.getState(), b.uq = v(), b.mv = a.Kb, this.B.listen(a, "x", Aa(this.s0, a))), this.B.listen(a, "z", Aa(this.x0, a))) : J(this.a, "Attempted to track a source associated with an unknown participant with id: " + b);
};
var lF = function() {
  this.bitRate = this.Qh = this.sw = 0;
}, mF = function() {
  this.mf = 0;
  this.Xy = 24;
  this.Qh = 0;
}, iF = function() {
  this.$g = this.$f = "Aa";
  this.mv = "ya";
  this.cn = this.Kk = !1;
  this.Uu = this.uq = 0;
  this.Om = new I;
  this.Pm = new I;
}, kF = function(a, b) {
  F.call(this, a);
  this.za = b;
};
w(kF, F);
var nF = function(a) {
  G.call(this);
  this.wx = this.da = null;
  this.a = zf("realtime.media.detours.DetoursManager");
  this.B = new tk(this);
  this.la(this.B);
  this.ad = fv(a, Rq, jy);
};
w(nF, G);
nF.prototype.connect = function(a, b, c) {
  this.wx = new jF(a, b, c);
  this.la(this.wx);
  this.da = c;
  this.B.listen(this.wx, "pb qb rb sb ub tb".split(" "), this.S_);
};
nF.prototype.S_ = function(a) {
  var b = "" == a.za || a.za == this.da ? "Self" : a.za;
  "pb" == a.type ? (K(this.a, b + " Audio Frozen."), this.it(3325)) : "qb" == a.type ? (K(this.a, b + " Video Frozen."), this.it(3324)) : "rb" == a.type ? (K(this.a, b + " Audio Unfrozen."), this.it(3330)) : "sb" == a.type ? (K(this.a, b + " Video Unfrozen."), this.it(3329)) : "ub" == a.type ? K(this.a, b + " Audio Sent While Muted.") : "tb" == a.type && K(this.a, b + " Video Sent While Muted.");
  this.dispatchEvent(a);
};
nF.prototype.it = function(a) {
  this.ad.then(function(b) {
    b.Ge(a);
  }, null, this);
};
var pF = function(a, b) {
  G.call(this);
  this.tp = new vr;
  this.onConnect = this.tp.provider;
  this.vK = new vr;
  this.onDisconnect = this.vK.provider;
  this.Oz = new vr;
  this.f4 = this.Oz.provider;
  this.Rc = new oF(a, this);
  this.la(this.Rc);
  this.sL = b;
  this.Qd = x(this.sL.Wc, "A ClientConfig was not registered on the Media Api before creating the call.");
  this.m = zf("realtime.media.call.BaseCall");
  this.Jc = new tk(this);
  this.la(this.Jc);
  this.sa = new vr;
  this.$ = this.sa.provider;
  this.da = new vr;
  this.za = this.da.provider;
  this.fA = [];
  this.Oj = this.Qd.xg() + "^" + Ra();
  this.hB = new CB;
  this.XB = new vr;
  this.Tf = this.XB.provider;
  this.WB = new vr;
  this.Sf = this.WB.provider;
  this.bL = new vr;
  this.QO = new Yu;
  this.la(this.QO);
  this.vF = new Yu;
  this.la(this.vF);
  this.rb = new bF(a, b, this.QO.Ou, this.vF.Ou);
  this.la(this.rb);
  this.$w = null;
  (new vr).resolve(this.rb);
  this.Pk = {};
  this.F = 0;
  this.Jc.listen(this.rb, ["u", "qa"], this.dispatchEvent);
  this.Jc.listen(this.rb, "L", this.Rz);
  fv(a, Oq, TE).then(function(a) {
    a.oR(this);
  }, null, this);
  this.hl = [];
  fv(a, Pq, Qu).then(function(a) {
    this.td = a;
    Hb(this.Gx(), function(a, b) {
      this.hl.push(this.td.eb(b, a));
    }, this);
  }, null, this);
};
w(pF, G);
d = pF.prototype;
d.mH = function() {
  return this.Qd.rl();
};
d.cd = function(a) {
  a.wC && (a = a.Yca(this.Qd.Ic()));
  Zh && (a = a.ida(!0));
  var b = this.Qd.ms();
  null != b && (a = a.$ca(b));
  L(this.m, "Starting the media session.");
  this.rb.cd(a);
  this.Oz.resolve(null);
};
d.Gx = function() {
  return {callState:u(this.getState, this), hangoutId:u(this.$.get, this.$), pid:u(this.za.get, this.za), plid:Ad(this.Oj), sessionId:u(this.aj, this)};
};
d.Ix = function() {
  return {callState:Ad(this.getState()), hangoutId:Ad(this.$.get()), pid:Ad(this.za.get()), plid:Ad(this.Oj), sessionId:Ad(this.aj())};
};
d.U = function() {
  L(this.m, "Disposing call.");
  this.disconnect(0);
  x(this.td);
  bb(this.hl);
  y(this.hl, this.td.GA, this.td);
  Hb(this.Ix(), u(function(a, b) {
    this.td.eb(b, a);
  }, this));
  pF.T.U.call(this);
};
d.ec = function(a) {
  a != this.F && (K(this.m, "Call state changed from " + this.F + " to " + a), this.F = a, this.dispatchEvent("wb"));
};
d.aj = function() {
  return this.rb.gg && this.rb.gg.ia();
};
d.getState = function() {
  return this.F;
};
d.gca = function(a, b, c) {
  K(this.m, "triggerConnected() called. HangoutId: " + b + " ParticipantId: " + c);
  this.sa.resolve(b);
  this.da.resolve(c);
  this.WT();
  this.Sf.then(function(a) {
    a = new jE(a, this.rb);
    this.bL.resolve(a);
    this.la(a);
  }, void 0, this);
  a.resolve();
  this.tp.resolve(null);
  this.ec(2);
  this.hB.Ug(this.Oj).p$("jid");
  this.rb.connect(b, c, this.hB);
  this.ly().dP && this.Sf.then(function() {
    this.$w = new nF(this.Rc);
    this.la(this.$w);
    this.$w.connect(this.rb, this.Sf.get(), this.za.get());
  }, void 0, this);
  this.la(new IE(this.rb, this.Qd.Ih(), this.Qd.Dh()));
  K(this.m, "Call connected");
};
d.la = function(a) {
  a = u(G.prototype.la, this, a);
  this.onDisconnect.qc ? a() : this.onDisconnect.then(a, a);
};
d.Rb = function() {
  this.rb.Rb();
};
d.BB = function(a) {
  this.fA = B(a);
  this.rb.Em(this.fA);
  this.Sf.then(function(a) {
    a.BB(this.fA);
  }, void 0, this);
};
d.disconnect = function(a) {
  if (3 == this.getState() || 4 == this.getState()) {
    return K(this.m, "disconnect() skipped, already disconnecting."), this.onDisconnect;
  }
  K(this.m, "disconnect() called. Endcause: " + a);
  var b = 2 == this.getState();
  this.ec(3);
  this.iC(b, a);
  return this.onDisconnect;
};
d.iC = function(a, b) {
  K(this.m, "triggerDisconnected(). Endcause: " + b);
  a = new qF(b);
  this.sa.reject(a);
  this.da.reject(a);
  this.WB.reject(a);
  this.bL.reject(a);
  this.tp.reject(a);
  this.Oz.reject(a);
  Hb(this.Pk, function(a) {
    Sc(a);
  });
  Ob(this.Pk);
  this.mH().yE();
  this.vK.resolve(b);
  this.ec(4);
  this.rb.stop(b);
};
d.ld = function(a) {
  if (3 == this.getState() || 4 == this.getState()) {
    return K(this.m, "addCapture() failed, because we are disconnecting"), !1;
  }
  var b = this.Pk[a.K().getId()];
  if (b && b.vI(a)) {
    return J(this.m, "addCapture() failed, because we already added this capture"), !1;
  }
  b || (b = new gF(this.rb, this), this.Pk[a.K().getId()] = b);
  K(this.m, "addCapture() succeeded. Capture Id:" + a.K().getId());
  var c = b.jd;
  b.ld(a);
  a = b.jd;
  this.Sf.qc && c != a && a != c && (c && this.Sf.get().JL(c.K()), a && this.Sf.get().Pv(a.K()));
  return !0;
};
d.je = function(a) {
  K(this.m, "removeCapture() called. Capture Id:" + a.K().getId());
  var b = this.Pk[a.K().getId()];
  if (b && b.vI(a)) {
    var c = b.jd;
    b.je(a);
    a = b.jd;
    this.Sf.qc && a != c && (c && this.Sf.get().JL(c.K()), a && this.Sf.get().Pv(a.K()));
    return !0;
  }
  return !1;
};
d.Gk = function() {
  this.rb.Gk(!0);
};
d.js = function() {
  return z(Jb(this.Pk), function(a) {
    return a.jd;
  });
};
d.Rz = function(a) {
  a.target == this.rb && ("STOPPED" == a.state ? (K(this.m, "Disconnect received from session. Endcause: " + a.hb), x(null != a.hb), this.disconnect(a.hb)) : "INPROGRESS" == a.state && this.dispatchEvent("vb"));
};
d.ly = function() {
  return this.rb.ly();
};
var rF = function() {
}, qF = function(a) {
  this.hb = a;
}, oF = function(a, b) {
  ay.call(this, a);
  this.Pa = b;
};
w(oF, ay);
var sF = function(a, b, c) {
  pF.call(this, a, b);
  this.Mt = !1;
  this.vy = new vr;
  this.Bf = this.vy.provider;
  this.Nt = new vr;
  this.Bd = this.Nt.provider;
  this.Bd.then(function(a) {
    this.Jc.listen(a, "Q", Aa(this.wO, a));
    this.wO(a);
  }, null, this);
  this.Vw = this.lC = this.fw = this.kA = null;
  a.ho(Oq, !1).then(u(function(a) {
    this.Vw = a;
  }, this));
  c && this.cd(c);
};
w(sF, pF);
var tF = {1:200, 2:201, 3:202, 4:206, 5:207, 6:209, 7:216, 11:223, 17:235, 12:236, 13:237, 14:238, 15:239, 16:240}, uF = {1:0, 2:307, 3:303, 4:217, 5:305, 6:307, 7:307, 8:306, 11:217};
d = sF.prototype;
d.Rb = function() {
  sF.T.Rb.call(this);
  this.Tf.get() && this.Tf.get().Rb();
  this.Bd.get() && this.Bd.get().Rb();
  this.Bf.get() && this.Bf.get().Rb();
};
d.wO = function(a) {
  this.BB(z(a.get(), function(a) {
    return a.A();
  }));
};
d.connect = function(a, b) {
  return this.f4.then(function() {
    K(this.m, "connect() was called");
    if (0 != this.getState()) {
      return J(this.m, "connect() failed. Not in INITIALIZED. State: " + this.getState()), Yd(new rF(0, this.getState()));
    }
    var c = H();
    this.ec(1);
    p(a) ? this.AT(c, a, b) : this.zT(c, a, b);
    return c.promise;
  }, void 0, this);
};
d.zT = function(a, b, c) {
  L(this.m, "Resolving Hangout");
  b.then(function(b) {
    this.NE(a, b, c || null);
  }, function(b) {
    J(this.m, "Hangout resolve failed, reverting to INITIALIZED state");
    this.ec(0);
    a.reject(new vF(306, b));
  }, this);
};
d.AT = function(a, b, c) {
  L(this.m, "Skipping Hangout resolution");
  b = VE(this.Rc, this.Qd, Za(b));
  this.NE(a, b, c || null);
};
d.NE = function(a, b, c) {
  var e = x(b.ls().O());
  L(this.m, "connectToHangout(). HangoutId: " + e);
  1 != this.getState() ? (J(this.m, "connectToHangout() failed, not in CONNECTING state. State: " + this.getState()), a.reject(new vF(302, new rF(1, this.getState()))), Sc(b)) : (this.O0(e, c), this.RD(e, c, a, b, 0));
};
d.RD = function(a, b, c, e, f) {
  a = UE(this.Rc, this.Qd, [a], new lq(ax, [ax.prototype.O], [ax.prototype.L], [ax.prototype.A], [ax.prototype.Sa], nt, [nt.prototype.O], [nt.prototype.L], [nt.prototype.A], [nt.prototype.Sa]), eE, "Ua");
  L(this.m, "Adding participant");
  var g = a.Mn();
  Ga(b || "") || g.Sa(b);
  a.add(g).then(u(this.U3, this, c, e, a, f), u(this.GK, this, c, e, a));
};
d.U3 = function(a, b, c, e, f) {
  if (1 != this.getState()) {
    J(this.m, "add participant succeeded, but we are no longer CONNECTING. State: " + this.getState()), a.reject(new vF(302, new rF(1, this.getState()))), a = new ax, a.L(f[0].O()), a.Sa(f[0].A()), c.remove(a).then(this.Ir, null, this), Sc(b), Sc(c);
  } else {
    K(this.m, "add participant succeeded");
    var g = x(f[0].A());
    10 == f[0].PY() ? (K(this.m, "participant in knocking state"), 30 > e ? (K(this.m, "will attempt again after delay"), ke(1000).then(u(this.RD, this, f[0].O(), f[0].A(), a, b, e + 1))) : (K(this.m, "max knock attempt, failing join"), this.GK(a, b, c, 234))) : (K(this.m, "success adding and not a knock result"), this.hca(a, b, c, g));
  }
};
d.GK = function(a, b, c, e) {
  this.Ir();
  J(this.m, "add participant failed, moving back to INITIALIZED state");
  this.ec(0);
  Sc(b);
  Sc(c);
  a.reject(new vF(this.jW(e), e));
};
d.Gx = function() {
  var a = sF.T.Gx.call(this);
  a.hangout = u(function() {
    return this.Bf.get() && this.Bf.get().na();
  }, this);
  a.participants = u(function() {
    return this.Bd.get() && this.Bd.get().na();
  }, this);
  a.mediaSources = u(function() {
    return this.Tf.get() && this.Tf.get().na();
  }, this);
  return a;
};
d.Ix = function() {
  var a = sF.T.Ix.call(this);
  a.hangout = Ad(this.Bf.get() && this.Bf.get().na());
  a.participants = Ad(this.Bd.get() && this.Bd.get().na());
  a.mediaSources = Ad(this.Tf.get() && this.Tf.get().na());
  return a;
};
d.hca = function(a, b, c, e) {
  var f = x(b.ls().O());
  this.vy.resolve(b);
  this.Nt.resolve(c);
  this.la(b);
  this.la(c);
  this.gca(a, f, e);
  b.start();
  c.start();
};
d.WT = function() {
  ae([this.$, this.za, this.Bd]).then(function() {
    var a = WE(this.Rc, this.Qd, this.$.get());
    this.la(a);
    this.XB.resolve(a);
    a.start();
    a = new hF(this.za.get(), a, this.Bd.get(), z(this.js(), function(a) {
      return a.K();
    }), this.rb);
    this.la(a);
    this.WB.resolve(a);
  }, void 0, this);
};
d.iC = function(a, b) {
  this.kA = b;
  if (a && !this.Mt) {
    K(this.m, "Removing participant on disconnect");
    var c = new ax;
    c.L(this.$.get());
    c.Sa(this.za.get());
    var e = {};
    e.jYdIne = b;
    this.Bd.get().remove(c, e, 2).then(this.Ir, null, this);
  }
  sF.T.iC.call(this, a, b);
  a = new qF(b);
  this.vy.reject(a);
  this.Nt.reject(a);
  this.XB.reject(a);
  null != this.Bf.get() && this.Bf.get().stop();
  null != this.Bd.get() && this.Bd.get().stop();
  null != this.Tf.get() && this.Tf.get().stop();
};
d.O0 = function(a, b) {
  this.fw = rd(Kj(), "beforeunload", u(this.UK, this, a, b));
  this.lC = rd(Kj(), "unload", u(this.UK, this, a, b));
};
d.Ir = function() {
  null != this.fw && td(this.fw);
  null != this.lC && td(this.lC);
};
d.UK = function(a, b) {
  this.Ir();
  var c = this.Qd.ZH(), e = null != this.kA ? this.kA : 63;
  if (null != c) {
    var f = new Wz;
    f.Wp(e);
    var g = new nt;
    g.L(a);
    Ga(b || "") || g.Sa(b);
    f.ra([g]);
    f.setRequestHeader(this.Qd.AW());
    a = new Y;
    a.uB(this.mH().os());
    f.j(a);
    f = f.cb();
    a = this.Vw ? this.Vw.q_() : [];
    a = z(a, function(a) {
      return a.cb();
    }, this);
    if (null != navigator.sendBeacon) {
      var k = new FormData;
      k.append("r", f);
      y(a, function(a) {
        k.append("l", a);
      });
      this.Mt = navigator.sendBeacon(c, k);
    }
    this.Mt || (c = Nc(c, "r", f), c = Nc(c, "l", a), f = Df.Jn(), f.open("GET", c, !1), f.send(null));
    this.Mt = !0;
  }
  this.disconnect(e);
};
d.jW = function(a) {
  var b;
  if (a && a.response instanceof Nz) {
    a = a.response;
    var c = a.getResponseHeader();
    c && (b = 10 == c.Ra() ? tF[a.Jx()] : uF[c.Ra()]);
  } else {
    t(a) && (b = a);
  }
  return l(b) ? b : 302;
};
var vF = function(a, b) {
  this.kO = a;
  this.ix = b;
};
var wF = function(a, b, c, e) {
  this.a = D("mr.mirror.hangouts.HangoutCallService");
  this.Ba = a;
  this.Fb = e;
  this.Ia = new tk(this);
  this.Pa = null;
  this.uw = new Jc;
  this.Zk = new Jc;
  this.aC = !1;
  this.Mu = new Jc;
  this.Ak = this.Ei = null;
  this.VI = this.iL = !1;
  this.IT(b, c);
};
d = wF.prototype;
d.IT = function(a, b) {
  var c = this;
  this.Fb(new Gh("REFRESH_AUTH"));
  a.then(function() {
    return b;
  }).then(function(a) {
    if (!c.VI) {
      c.a.w("Creating call for hangout id: " + a.hangoutId + " resolvedId: " + a.resolvedId + " conferenceMode: " + a.conferenceMode);
      var b = (new Xp).lda(!0).fda(!1);
      void 0 != a.conferenceMode && (b = b.hda(a.conferenceMode));
      ME(c.Ba);
      c.Pa = new sF(c.Ba, c.Ba.get(Sq), b);
      c.Pa.Bd.then(c.bba, null, c);
      c.Pa.Tf.then(c.dba, null, c);
      c.Pa.onConnect.then(c.N_, null, c);
      c.Pa.onDisconnect.then(c.P_, function(a) {
        c.a.l("Error on disconnect: " + a);
      }, c);
      c.uw.resolve(a);
    }
  });
};
d.ME = function(a) {
  var b = this;
  this.a.info("Connecting to hangout");
  setTimeout(function() {
    b.Zk.reject(Error("Timed out before connecting"));
  }, 3E4);
  return this.uw.promise.then(function(c) {
    var e = c.hangoutId;
    c = c.resolvedId;
    b.a.w("Call ready.");
    var f = "", f = b.Ba.get(HE);
    c ? (b.a.w("Already resolved id: " + c), f = Cr(VE(b.Ba, f, c))) : (b.a.w("resolving hangout id: " + e), f = aF(b.Ba, f, b.RT(e)));
    b.Pa.connect(f).jb(function(a) {
      b.nz("Connect error", a);
      if (a.ix) {
        var c = "", e;
        for (e in vp) {
          if (vp[e] == a.kO) {
            c = e + "(" + a.kO + ")";
            break;
          }
        }
        b.a.error("Call connect error startupCode: " + c);
        a = a.ix;
      }
      c = "SESSION_FAILURE";
      a.response && a.response.PX && "chrrp" == a.response.tt && (c = "HANGOUT_INVALID");
      b.Fb(new Gh(c));
      b.Zk.reject(a);
      b.Lu(16);
    });
    return b.Zk.promise.then(function() {
      return b.Pa.za;
    }).then(function(c) {
      b.WO(a, c);
      b.bK(c);
      b.Zaa(b.Pa.Bf.get());
    });
  });
};
d.qca = function(a) {
  var b = this;
  return new Promise(function(c, e) {
    b.Pa.za.then(function(e) {
      b.WO(a, e);
      b.iL || b.bK(e);
      c();
    }, e);
  });
};
d.RT = function(a) {
  a = a.split("@");
  var b = new pA;
  b.aN(!0);
  if (-1 != a[1].indexOf(".")) {
    var c = new Nt;
    c.Dm(a[0]);
    c.Am(a[1]);
    b.r$(c);
  } else {
    c = new ft, c.saa(a[1]), c.QB(a[0]), b.TM(c);
  }
  return b;
};
d.WO = function(a, b) {
  0 < a.getAudioTracks().length && (this.Ei ? this.Ei.jN(a) : (this.Ei = new QE(new Wr(x(b), "1", "a"), a), this.Ei.hO(), this.Pa.ld(this.Ei)));
  this.Ak ? this.Ak.jN(a) : (b = new Wr(x(b), "2", "v", "xa"), b.bO([new Zq(0, 0, 1, 1)]), this.Ak = new QE(b, a), this.Ak.hO(), this.Pa.ld(this.Ak));
};
d.bK = function(a) {
  var b = new Pt;
  b.S$(a);
  a = new Pw;
  a.AN(b);
  a.L(this.Pa.$.get());
  this.Pa.Bf.get().modify(a);
};
d.Zaa = function(a) {
  var b = this;
  this.Ia.listen(a, "Q", function(a) {
    b.Pa.za.then(function(c) {
      b.iL = Array.prototype.some.call(a.target.get(), function(a) {
        return a.zo() && a.zo().bZ() == c;
      });
    });
  });
};
d.bba = function(a) {
  var b = this;
  this.Ia.listen(a, "Q", function(a) {
    b.V3(a);
  });
  this.Ia.listen(a, "S", function(a) {
    b.sK(a);
  });
};
d.V3 = function(a) {
  var b = a.target;
  this.a.w(function() {
    return "Participants updated: " + b.get().filter(function(a) {
      return a.ZG();
    }).map(function(a) {
      return a.Bh();
    }).join(", ");
  });
  !this.aC && 2 > b.get().length && (this.Fb(new Gh("HANGOUT_INACTIVE")), this.Lu(61));
};
d.dba = function(a) {
  var b = this;
  this.Ia.listen(a, "Q", function(a) {
    b.z4(x(b.Pa), a);
  });
  this.Ia.listen(a, "S", function(a) {
    b.sK(a);
  });
};
d.z4 = function(a, b) {
  for (var c = this, e = {}, f = 0;f < b.yb.length;e = {source:e.source}, f++) {
    e.source = b.yb[f], e.source.A() == a.za.get() && e.source.Bl() && e.source.Bl().sl() && a.js().forEach(function(a) {
      return function(b) {
        b.K().getId() == a.source.ya() && (b.cm(), c.Fb(new Gh("STATUS_RESPONSE", {mute:!0})));
      };
    }(e));
  }
};
d.VO = function(a) {
  this.Pa.js().forEach(function(b) {
    "a" == b.K().N() && (a ? b.cm() : b.nca());
  });
};
d.sK = function(a) {
  this.a.error("Failure in collection: " + a.reason);
  this.Zk.reject(a.reason);
  this.Lu(3);
};
d.N_ = function() {
  this.a.info("Call connected");
  this.Fb(new Gh("SESSION_START_SUCCESS"));
  this.Zk.resolve(void 0);
};
d.P_ = function(a) {
  this.Fb(new Gh("SESSION_END"));
  var b = "", c;
  for (c in pp) {
    if (pp[c] == a) {
      b = c + "(" + a + ")";
      break;
    }
  }
  this.a.info("Call ended with endcause: " + b);
  0 != a && 61 != a && 16 != a && this.Fb(new Gh("SESSION_FAILURE"));
};
d.stop = function() {
  this.Lu(0);
  return this.Mu.promise;
};
d.Lu = function(a) {
  var b = this;
  this.a.info("Stopping call with end Cause: " + a);
  this.aC ? this.a.info("Ignore stop, already stopping.") : (this.aC = !0, this.Pa ? this.Pa.disconnect(a).then(function(a) {
    b.a.w("Call disconnected with endCause: " + a);
    b.Mu.resolve(void 0);
  }) : this.Mu.resolve(void 0));
};
d.Qa = function() {
  var a = this;
  this.VI = !0;
  this.Ia.Qa();
  this.Ei && this.Ei.Qa();
  this.Ak && this.Ak.Qa();
  this.uw.reject(Error("Disposed"));
  this.Zk.reject(Error("Disposed"));
  setTimeout(function() {
    a.Mu.reject(Error("Timed out before stopping"));
  }, 1E4);
  this.Pa && this.Pa.Qa();
};
d.nz = function(a, b) {
  b instanceof Error ? this.a.error(a, b) : ta(b) ? this.a.error(function() {
    return a + ": " + JSON.stringify(b);
  }) : va(b) ? this.a.error(a + ": " + JSON.stringify(b)) : this.a.error(a + ": " + b);
};
d.aj = function() {
  return this.Pa ? this.Pa.aj() : null;
};
var xF = function(a, b, c) {
  Dh.call(this, a);
  this.Ba = b;
  this.Hk = c;
  this.a = D("mr.mirror.hangouts.HangoutSession");
  this.Lc = Fg.qs(a.id);
  this.wa = new Jc;
  this.qj = !1;
  this.Ol = !0;
  this.Hd = this.nc = null;
  this.Wk = new Jc;
  this.dd = this.gB = null;
  this.cq();
  this.Tb = null;
};
la(xF, Dh);
d = xF.prototype;
d.start = function(a) {
  var b = this;
  this.a.w("Starting new hangouts mirror session.");
  this.nc = a;
  if (this.Tb) {
    return Promise.reject(Error("Mirroring already started"));
  }
  if (this.Hd) {
    return Promise.reject(Error("Session permanently stopped"));
  }
  this.gB = new Sg("MediaRouter.Hangouts.Session.Launch");
  this.Tb = new wF(this.Ba, this.Hk, this.Wk.promise, u(this.li, this));
  this.Tb.ME(this.nc).then(function() {
    b.a.w("Call connected");
    b.li(new Gh("SESSION_START_SUCCESS"));
    b.gB.end();
    b.gB = null;
    b.dd = new Xg("MediaRouter.Hangouts.Session.Length");
    b.wa.resolve(b);
  }, function(a) {
    b.wa.reject(a);
    b.stop();
  });
  return this.wa.promise;
};
d.A7 = function() {
  var a = this;
  if (!this.Tb || this.Hd) {
    return Promise.resolve();
  }
  this.a.w("Resetting session call.");
  return this.Tb.stop().then(function() {
    if (a.Hd) {
      return Promise.resolve();
    }
    a.qj = !1;
    a.Wk = new Jc;
    a.Tb.Qa();
    a.Tb = new wF(a.Ba, a.Hk, a.Wk.promise, u(a.li, a));
    a.nc.getTracks().forEach(function(a) {
      a.enabled = !0;
    });
    return a.Tb.ME(x(a.nc)).then(function() {
      a.a.w("Reset call connected");
    }, function() {
      a.stop();
    });
  });
};
d.uO = function() {
  return !0;
};
d.XO = function(a) {
  var b = this;
  return new Promise(function(c, e) {
    b.Tb ? b.Tb.qca(a).then(function() {
      b.nc = a;
      c();
    }, e) : e(Error("Mirroring was never started"));
  });
};
d.stop = function() {
  var a = this;
  this.a.w("Stopping hangouts mirror session.");
  this.wa.reject(Error("Session stop requested."));
  this.dd && (this.dd.end(), this.dd = null);
  if (!this.Tb) {
    return Promise.resolve();
  }
  if (this.Hd) {
    return this.Hd;
  }
  this.wa.reject(Error("Stopped"));
  this.Wk.reject(Error("Stopped"));
  var b = function() {
    try {
      a.Lc.Qa();
    } catch (c) {
      a.a.error("Error while disposing message port", c);
    }
    try {
      a.Tb.Qa();
    } catch (c) {
      a.a.error("Error while disposing call service", c);
    }
  };
  return this.Hd = new Promise(function(c, e) {
    setTimeout(function() {
      b();
      e(Error("Timed out before stopping"));
    }, 1E4);
    a.Tb.stop().then(function() {
      b();
      c();
    }).catch(function(a) {
      b();
      e(a);
    });
  });
};
d.cq = function() {
  var a = this;
  this.Lc.onMessage = function(b) {
    if (p(b)) {
      var c = JSON.parse(b), e = c.clientId;
      if (e) {
        "client_connect" == c.type ? a.li({message:{sessionId:"castouts"}, clientId:e, type:"new_session"}) : "v2_message" == c.type && "STOP" == c.message.type && a.li({message:"castouts", clientId:e, type:"remove_session"});
        return;
      }
      b = c;
    }
    if (!b.type) {
      throw Error("Message has no type.");
    }
    switch(b.type) {
      case "AUTH_READY":
        if (void 0 != b.data.conferenceMode && b.data.conferenceMode != a.Ol) {
          a.a.w("received auth ready message with new conference mode");
          a.Ol = b.data.conferenceMode;
          var f = a.qj;
          a.A7().then(function() {
            a.qj = f;
            a.Tb && a.Tb.VO(f);
            a.Wk.resolve(b.data);
          });
        } else {
          a.a.w("received auth ready message"), b.data.conferenceMode = a.Ol, a.Wk.resolve(b.data);
        }
        break;
      case "LOCAL_PRESENT":
        a.a.w("local present message");
        a.li(b);
        break;
      case "MUTE":
        b.data && (a.qj = !!b.data.mute, a.Tb && a.Tb.VO(a.qj));
        break;
      case "STATUS_RESPONSE":
        a.a.w("route status response message");
        b.data && (a.qj = !!b.data.mute);
        break;
      case "STATUS_REQUEST":
        a.a.w("route status request message");
        a.li(new Gh("STATUS_RESPONSE", {routeDescription:a.$a.description, mute:a.qj, local:!a.Ol}));
        break;
      default:
        throw Error("Unknown message type: " + b.type);
    }
  };
};
d.li = function(a) {
  this.a.w(function() {
    return "sending message to mrp: " + JSON.stringify(a);
  });
  this.Lc.sendMessage(a, yF);
};
d.aj = function() {
  return this.Tb ? this.Tb.aj() : null;
};
var yF = {channelType:"mesi"};
var zF = function() {
  Bh.call(this, "hangouts");
  var a = this.Ba = new ay, b = new Iu(a, document);
  a.hi(Fq, b);
  this.vj = this.Xv = this.Hk = this.Rp = null;
};
la(zF, Bh);
d = zF.prototype;
d.pF = function() {
  this.U0();
  Rh(this);
};
d.oa = function() {
  return "HangoutsService";
};
d.getData = function() {
  return [{lastSessionId:this.vj}];
};
d.Xa = function() {
  var a = Oh(this);
  a && a.lastSessionId && (this.vj = a.lastSessionId);
};
d.Mf = function() {
  var a = this;
  return this.vj ? new Promise(function(b, c) {
    setTimeout(c, 5E3);
    a.Hk.then(function() {
      a.vj || c(Error("No session to upload"));
      a.Xv.Mf(a.vj);
      a.vj = null;
      b("");
    });
  }) : Promise.reject(Error("No session to upload"));
};
d.ew = function(a) {
  this.vj = a.aj();
  return Promise.resolve();
};
d.yr = function(a, b) {
  a = new xF(b, this.Ba, x(this.Hk));
  this.Rp = a.li.bind(a);
  return a;
};
d.$t = function() {
  aq(0);
};
d.Wt = function() {
  aq(1);
};
d.Xt = function() {
  $g("MediaRouter.Hangouts.Session.End");
};
d.Yt = function(a) {
  ah("MediaRouter.Hangouts.Start.Failure", a, ch);
};
d.Zt = function() {
  $g("MediaRouter.Hangouts.Stream.End");
};
d.Nf = function(a) {
  this.Rp && this.Rp(a);
};
d.U0 = function() {
  var a = this, b = new cv(new Er, new Gr(this.Nf.bind(this))), b = new DB(b, "hangouts", "v1_today", "", "https://www.googleapis.com"), c = new GE(b);
  c.Pe(39);
  c.yu(158);
  c.setProperty("castouts");
  c.BM("castouts");
  c.CM(chrome.runtime.id + chrome.runtime.getManifest().version);
  c.zm("castouts", !0);
  c.OM(1);
  c.NM("https://hangouts.google.com/hangouts/_/logpref");
  c.PM("https://clients2.google.com/cr/report");
  c.register(this.Ba);
  ME(this.Ba);
  this.Hk = new Promise(function(b, f) {
    a.Xv = a.Ba.get(Sq);
    a.Xv.b9(c).mc().then(b, f);
  });
};
var AF = new zF;
zh("mr.mirror.hangouts.HangoutsService", AF);

