'use strict';var Fg;
m("mr.IssueSeverity", {Oea:"fatal", Xha:"warning", ega:"notification"}, void 0);
m("mr.IssueAction", {Dea:"dismiss", Hfa:"learn_more"}, void 0);
var Gg = function(a, b, c) {
  this.routeId = null;
  this.severity = b;
  this.isBlocking = "fatal" == this.severity ? !0 : !1;
  this.title = a;
  this.message = null;
  this.defaultAction = c;
  this.helpPageId = this.secondaryActions = null;
};
Gg.prototype.N9 = function(a) {
  this.helpPageId = a;
  return this;
};
Gg.prototype.naa = function(a) {
  this.secondaryActions = a;
  return this;
};
Gg.prototype.T9 = function(a) {
  if (!a && "fatal" == this.severity) {
    throw Error("All FATAL issues must be blocking.");
  }
  this.isBlocking = a;
  return this;
};
var Hg = function(a, b) {
  var c = this;
  this.sp = void 0 === b ? null : b;
  this.promise = new Promise(function(b, f) {
    var e = function(a) {
      c.sp = null;
      f(a);
    };
    c.Z6 = e;
    a(function(a) {
      c.sp = null;
      b(a);
    }, e);
  });
};
Hg.prototype.cancel = function(a) {
  this.Z6(a);
  if (this.sp) {
    var b = this.sp;
    this.sp = null;
    setTimeout(function() {
      return b(a);
    }, 0);
  }
};
Hg.prototype.yw = function(a, b) {
  b = void 0 === b ? null : b;
  var c = this;
  return new Hg(function(e, f) {
    c.promise.then(function(b) {
      if (a) {
        try {
          e(a(b));
        } catch (k) {
          f(k);
        }
      } else {
        e(b);
      }
    }, function(a) {
      if (b) {
        try {
          e(b(a));
        } catch (k) {
          f(k);
        }
      } else {
        f(a);
      }
    });
  }, function(a) {
    c.cancel(a);
  });
};
Hg.prototype.then = function(a, b) {
  return this.yw(a, void 0 === b ? null : b);
};
Hg.prototype.catch = function(a) {
  return this.yw(null, a);
};
var Ig = function(a) {
  return new Hg(function(b) {
    b(a);
  });
}, Jg = function(a) {
  return new Hg(function(b, c) {
    c(a);
  });
}, Kg = function(a) {
  return new Hg(function(b, c) {
    a.then(b, c);
  });
}, Lg = function(a, b) {
  var c = !1, e = null;
  return new Hg(function(f, g) {
    a.then(function(a) {
      c || (e = b(a), e.promise.then(f, g));
    }, g);
  }, function(a) {
    e ? e.cancel(a) : c = !0;
  });
};
var Mg = function() {
  return null != Vb && -1 != Vb.indexOf("CrOS");
}, Ng = function() {
  var a = Vb;
  if ("string" != typeof a) {
    return !1;
  }
  a = a.match(/Windows NT \d+.\d+/);
  if (!(a instanceof Array)) {
    return !1;
  }
  a = a[0];
  a = a.match(/\d+.\d+/);
  if (!(a instanceof Array)) {
    return !1;
  }
  a = a[0];
  return 6.2 <= parseFloat(a);
}, Og = function() {
  return Mg() ? "ChromeOS" : lc ? "Windows" : kc ? "Mac" : mc ? "Linux" : "Other";
};
var Pg = "undefined" != typeof chrome && !!chrome.networkingPrivate && !!chrome.networkingPrivate.setWifiTDLSEnabledState && Mg(), Qg = Mg() || lc;
var Rg = function(a, b, c, e) {
  c && (x("offscreen_tab" == a), x(e));
  this.jE = a;
  this.ae = b;
  this.mK = c || null;
  this.gL = e || null;
};
d = Rg.prototype;
d.eJ = function() {
  return "tab" == this.jE;
};
d.$I = function() {
  return "offscreen_tab" == this.jE;
};
d.gC = function(a) {
  return this.eJ() ? this.EO() : this.$I() ? this.bca() : this.$ba(x(a, "Missing desktop capture source id"));
};
d.EO = function() {
  var a = {audio:this.ae.shouldCaptureAudio, video:this.ae.shouldCaptureVideo};
  this.ae.shouldCaptureVideo && (a.videoConstraints = {mandatory:{enableAutoThrottling:!0}}, this.IM(a.videoConstraints.mandatory));
  return a;
};
d.bca = function() {
  x(this.gL, "Missing offscreen capture presentation id");
  var a = this.EO();
  a.presentationId = this.gL;
  return a;
};
d.$ba = function(a) {
  var b = {audio:!1, video:!1};
  this.ae.shouldCaptureVideo && (b.video = {mandatory:{chromeMediaSource:"desktop", chromeMediaSourceId:a}}, this.IM(b.video.mandatory));
  Qg && this.ae.shouldCaptureAudio && (b.audio = {mandatory:{chromeMediaSource:"desktop", chromeMediaSourceId:a}});
  return b;
};
d.IM = function(a) {
  var b = this.ae.minWidth, c = this.ae.minHeight;
  this.ae.senderSideLetterboxing && (c = this.ae.oH(), b = c.width, c = c.height);
  Object.assign(a, {minWidth:b, minHeight:c, maxWidth:this.ae.maxWidth, maxHeight:this.ae.maxHeight, maxFrameRate:this.ae.maxFrameRate});
};
var Sg = function(a) {
  this.ua = a;
  this.ri = Date.now();
};
Sg.prototype.Ox = function(a, b) {
  null != b && (a += "_" + b);
  return a;
};
Sg.prototype.Dm = function(a) {
  this.ua = a;
};
Sg.prototype.end = function(a) {
  Tg(this.Ox(this.ua, a), Date.now() - this.ri);
};
var Tg = function(a, b) {
  0 > b && (Ug.l("Timing analytics event with negative time"), b = 0);
  1E4 < b && (b = 1E4);
  try {
    chrome.metricsPrivate.recordTime(a, b);
  } catch (c) {
    Ug.l("Failed to record time " + b + " in " + a);
  }
}, Ug = D("mr.Timing"), Vg = function(a) {
  Sg.call(this, a);
};
la(Vg, Sg);
Vg.prototype.end = function(a) {
  a = this.Ox(this.ua, a);
  var b = Date.now() - this.ri;
  if (0 > b) {
    Wg.l("Timing analytics event with negative time");
  } else {
    1E4 > b && (b = 1E4);
    18E4 < b && (b = 18E4);
    try {
      chrome.metricsPrivate.recordMediumTime(a, b);
    } catch (c) {
      Wg.l("Failed to record time " + b + " in " + a);
    }
  }
};
var Wg = D("mr.MediumTiming"), Xg = function(a) {
  Sg.call(this, a);
};
la(Xg, Sg);
Xg.prototype.end = function(a) {
  a = this.Ox(this.ua, a);
  var b = Date.now() - this.ri;
  if (0 > b) {
    Yg.l("Timing analytics event with negative time");
  } else {
    18E4 > b && (b = 18E4);
    36E5 < b && (b = 36E5);
    try {
      chrome.metricsPrivate.recordLongTime(a, b);
    } catch (c) {
      Yg.l("Failed to record time " + b + " in " + a);
    }
  }
};
var Yg = D("mr.LongTiming"), Zg = D("mr.Analytics"), $g = function(a) {
  try {
    chrome.metricsPrivate.recordUserAction(a);
  } catch (b) {
    Zg.l("Failed to record event " + a);
  }
}, ah = function(a, b, c) {
  var e, f = 0, g;
  for (g in c) {
    f++, c[g] == b && (e = g);
  }
  if (e) {
    c = {metricName:a, type:"histogram-linear", min:1, max:f, buckets:f + 1};
    try {
      chrome.metricsPrivate.recordValue(c, b);
    } catch (k) {
      Zg.l("Failed to record enum value " + e + " (" + b + ") in " + a, k);
    }
  } else {
    Zg.error("Unknown analytics value, " + b + " for histogram, " + a, Error());
  }
}, bh = function(a, b) {
  try {
    if (0 > b) {
      throw Error("Invalid count for " + a + ": " + b);
    }
    100 < b && Zg.l("Small count for " + a + " exceeded limits: " + b, Error());
    chrome.metricsPrivate.recordSmallCount(a, b);
  } catch (c) {
    Zg.l("Failed to record small count " + a + " (" + b + ")", c);
  }
};
var ch = {eea:0, cea:1, gea:2, dea:3, Jda:4, fea:5, kfa:6, Aha:7, xea:8, iD:9}, dh = function(a, b) {
  a = Error.call(this, a);
  this.message = a.message;
  "stack" in a && (this.stack = a.stack);
  this.reason = 0 <= b && 9 >= b ? b : 9;
};
la(dh, Error);
var eh = function(a) {
  this.Ji = a;
  this.nc = this.jm = null;
  this.a = D("mr.mirror.MirrorMediaStream");
};
d = eh.prototype;
d.vN = function(a) {
  this.jm = a;
};
d.start = function() {
  return this.Ji.eJ() ? this.Bba() : this.Ji.$I() ? this.uba() : this.sba();
};
d.Bba = function() {
  var a = this, b = this.Ji.gC();
  this.a.info("Starting tab capture with constraints " + JSON.stringify(b));
  return new Promise(function(c, e) {
    chrome.tabCapture.capture(b, function(b) {
      b ? (a.IB(b), c(a)) : e(a.bF());
    });
    window.setTimeout(function() {
      e(new dh("chrome.tabCapture.capture failed to call its callback", 2));
    }, 5000);
  });
};
d.D0 = function(a) {
  a && this.a.info(function() {
    return "Track " + JSON.stringify(a.target) + " ended";
  });
  this.stop();
};
d.bF = function() {
  return chrome.runtime.lastError && chrome.runtime.lastError.message ? new dh(chrome.runtime.lastError.message, 7) : new dh("empty_stream", 0);
};
d.sba = function() {
  var a = this;
  return (new Promise(function(a, c) {
    var b = ["screen", "audio"];
    "Linux" == Og() && b.push("window");
    var f = chrome.desktopCapture.chooseDesktopMedia(b, a);
    window.setTimeout(function() {
      chrome.desktopCapture.cancelChooseDesktopMedia(f);
      c(new dh("timeout", 1));
    }, 60000);
  })).then(function(b) {
    if (!b) {
      throw new dh("User cancelled capture dialog", 3);
    }
    var c = a.Ji.gC(b);
    a.a.info(function() {
      return "Starting desktop capture with constraints " + JSON.stringify(c);
    });
    return new Promise(function(a, b) {
      navigator.webkitGetUserMedia(c, a, function(a) {
        var c = 8;
        if ("PermissionDeniedError" == a.name || "NotAllowedError" == a.name) {
          c = 3;
        }
        b(new dh(a.name + " " + a.constraintName + ": " + a.message, c));
      });
    });
  }).then(function(b) {
    if (b) {
      a.IB(b);
    } else {
      throw new dh("empty_stream", 8);
    }
    return a;
  });
};
d.uba = function() {
  var a = this;
  x(!!this.Ji.mK);
  var b = this.Ji.gC();
  this.a.info(function() {
    return "Starting offscreen tab capture with constraints " + JSON.stringify(b);
  });
  return new Promise(function(c, e) {
    chrome.tabCapture.captureOffscreenTab(a.Ji.mK.toString(), b, function(b) {
      b ? (a.IB(b), c(a)) : e(a.bF());
    });
  });
};
d.IB = function(a) {
  var b = this;
  this.nc = a;
  x(a.getAudioTracks().length || a.getVideoTracks().length, "Expecting at least one audio or video track.");
  a.getTracks().forEach(function(a) {
    a.onended = b.D0.bind(b);
  });
};
d.stop = function() {
  this.nc && (this.nc.getTracks().forEach(function(a) {
    a.onended = null;
    a.stop();
  }), this.nc = null, this.jm && this.jm());
};
var fh, gh = {Nfa:0, hea:1, iea:2, zea:3, Aea:4, Tea:5, lfa:6, Mfa:7, Xfa:8, Yfa:9, Pga:10, eha:11, fha:12, oha:13, zha:14}, hh = function(a) {
  void 0 == fh && (ah("MediaRouter.Provider.WakeEvent", a, gh), fh = a);
};
var kh = function(a) {
  return ih(a) || jh(a);
}, lh = function(a) {
  if (!Da(a, "http:") && !Da(a, "https:")) {
    return !1;
  }
  var b = document.createElement("a");
  b.href = a;
  return "http:" != b.protocol && "https:" != b.protocol || -1 != b.hash.indexOf("__testprovider__") ? !1 : -1 == b.hash.indexOf("__castAppId__");
}, mh = ["https://docs.google.com"], nh = function(a) {
  return window.localStorage["debug.allowAllOrigins"] ? null : -1 != a.indexOf("0F5096E8") ? mh : null;
}, ih = function(a) {
  return Da(a, "urn:x-org.chromium.media:source:tab:") || -1 != a.indexOf("0F5096E8");
}, jh = function(a) {
  return "urn:x-org.chromium.media:source:desktop" == a;
};
var oh = function(a) {
  return (new Promise(function(b) {
    chrome.tabs.get(a, b);
  })).then(function(b) {
    if (!b) {
      throw Error("No such tab " + a);
    }
    return b;
  });
};
var ph = function() {
}, uh = function(a) {
  qh.info("Loading module " + a);
  var b = rh.get(a) || null;
  if (b) {
    return Promise.resolve(b);
  }
  b = sh.get(a);
  b || (b = new Jc, sh.set(a, b), th(a, b));
  return b.promise;
}, th = function(a, b) {
  var c = vh.get(a) || null;
  if (!c) {
    b.reject(Error("No corresponding bundle for " + a));
  } else {
    if (!wh.has(c)) {
      var e = xh.get(c);
      e || (qh.info("Loading bundle " + c + " for module " + a), e = yh(c), xh.set(c, e));
      e.catch(function(a) {
        b.reject(a);
      });
    }
  }
}, yh = function(a) {
  var b = new Jc;
  b.promise.then(function() {
    qh.info("Bundle " + a + " loaded");
  }, function(b) {
    qh.error("Failed to load bundle " + a);
    throw b;
  });
  var c = document.createElement("script");
  c.src = chrome.extension.getURL(a);
  c.setAttribute("type", "text/javascript");
  c.async = !0;
  c.onload = function() {
    return b.resolve(void 0);
  };
  c.onerror = function() {
    return b.reject(Error("Failed to load bundle " + a));
  };
  document.head.appendChild(c);
  return b.promise;
}, zh = function(a, b) {
  if (rh.has(a)) {
    throw Error("Duplicate module " + a);
  }
  rh.set(a, b);
  (a = sh.get(a)) && a.resolve(b);
};
ph.prototype.handleEvent = function(a, b) {
  for (var c = 1;c < arguments.length;++c) {
  }
  throw Error("Not implemented");
};
var vh = new Map([["mr.cast.SinkDiscoveryService", "background_script.js"], ["mr.mirror.cast.Service", "mirroring_cast_streaming.js"], ["mr.cloud.discovery.CloudSinkDiscoveryService", "background_script.js"], ["mr.dial.SinkDiscoveryService", "background_script.js"], ["mr.mirror.hangouts.HangoutsService", "mirroring_hangouts.js"], ["mr.ProviderManager", "background_script.js"], ["mr.mirror.webrtc.WebRtcService", "mirroring_webrtc.js"]]), wh = new Set(["background_script.js"]), qh = D("mr.Module"), 
rh = new Map, sh = new Map, xh = new Map;
var Ah = chrome.i18n.getMessage("545449835455981095");
var Bh = function(a, b) {
  this.C8 = a;
  this.xt = b || null;
  this.hf = this.Ha = null;
  this.m = D("mr.mirror.Service." + a);
  this.Tz = u(this.B0, this);
  this.Qo = !1;
};
la(Bh, ph);
d = Bh.prototype;
d.mc = function(a) {
  this.Qo || (this.xt = a, this.Qo = !0, this.pF());
};
d.pF = function() {
};
d.getName = function() {
  return this.C8;
};
d.mq = function(a, b, c, e, f) {
  var g = this;
  this.m.info("Start mirroring on route " + a.id);
  return this.Qo ? Kg(this.xF(b, a.Je.tabId).then(function() {
    return g.nO();
  }).then(function() {
    var a = Ch(b, c, e);
    return (new eh(a)).start();
  }).then(function(b) {
    g.hf = b;
    b.vN(function() {
      g.jm(b);
    });
    return f ? f(a).promise : a;
  }).then(function(a) {
    if (g.Ha) {
      throw new dh("Cannot start multiple sessions");
    }
    g.Ha = g.yr(c, a);
    return g.Ha.start(g.hf.nc);
  }).then(function() {
    ih(b) && !chrome.tabs.onUpdated.hasListener(g.Tz) && chrome.tabs.onUpdated.addListener(g.Tz);
    return g.eL(a, b, c);
  }).then(null, function(a) {
    g.RK(a);
    return g.mh().then(function() {
      throw a;
    });
  })) : Jg(Error("Not initialized"));
};
d.cv = function(a, b, c, e, f, g) {
  this.m.info("Update mirroring on route " + a.id);
  return this.Qo ? Kg(this.xF(b, f).then(this.DU.bind(this, a, b, c, e, g))) : Jg(Error("Not initialized"));
};
d.xF = function(a, b) {
  return ih(a) ? b ? oh(b).then(function(a) {
    if (!a.active) {
      throw new dh("Tab to be mirrored is not active", 7);
    }
  }) : Promise.reject(new dh("BUG: Tab ID is required.")) : Promise.resolve();
};
d.DU = function(a, b, c, e, f) {
  var g = this;
  if (!this.Ha) {
    return Promise.reject(new dh("No session to update streams on", 7));
  }
  if (!this.Ha.uO()) {
    return Promise.reject(new dh("Session does not support updating stream", 7));
  }
  var k = !1;
  return Promise.resolve().then(function() {
    var a = Ch(b, c, e);
    return (new eh(a)).start();
  }).then(function(b) {
    var c = g.hf;
    g.hf = b;
    b.vN(u(g.jm, g, b));
    k = !0;
    c.stop();
    return f ? f(a).promise : a;
  }).then(function(a) {
    if (!g.Ha) {
      throw new dh("Session ended while updating stream");
    }
    g.Ha.haa(a);
    return g.Ha.XO(g.hf.nc);
  }).then(this.eL.bind(this, a, b, c)).then(null, function(a) {
    g.RK(a);
    if (k) {
      return g.mh().then(function() {
        throw a;
      });
    }
    throw a;
  });
};
d.eL = function(a, b, c) {
  var e = this;
  return new Promise(function(f, g) {
    if (e.Ha) {
      if (ih(b)) {
        e.Ha.Jca(a.Je.tabId).then(function() {
          e.Ha.ju();
          e.$t();
          f(e.Ha.$a);
        }, function(a) {
          e.m.error("Failed to obtain initial tab info.", a);
          g(a);
        });
      } else {
        if (lh(b)) {
          var k = "Capturing " + a.mediaSource;
          e.Ha.zB(k, k, null);
          e.Ha.ju();
          e.zA();
        } else {
          e.Ha.zB("Capturing Desktop", "Capturing Desktop", null), e.Ha.ju(), e.Wt();
        }
        e.$S(c, e.hf);
        f(e.Ha.$a);
      }
    } else {
      g(new dh("Session gone before executing post-startup steps", 7));
    }
  });
};
d.RK = function(a) {
  a.reason = null != a.reason ? a.reason : 9;
  this.m.error("Failed to start mirroring: " + a.message + ",  reason = " + a.reason + ": " + a.stack);
  this.Yt(a.reason);
};
d.jm = function(a) {
  this.hf == a && (this.Zt(), this.mh());
};
d.nO = function() {
  var a = this;
  return this.Qo ? this.mh().then(function(b) {
    b && a.Xt();
    return b;
  }) : Promise.reject("Not initialized");
};
d.mh = function() {
  var a = this;
  chrome.tabs.onUpdated.removeListener(this.Tz);
  this.hf && (this.hf.stop(), this.hf = null);
  if (!this.Ha) {
    return Promise.resolve(!1);
  }
  var b = this.Ha;
  this.Ha = null;
  return this.ew(b).catch(function(b) {
    return a.m.error("Error in before-cleanup steps", b);
  }).then(function() {
    return b.stop();
  }).catch(function(b) {
    return a.m.error("Error stopping session", b);
  }).then(function() {
    a.xt.Nz(b.$a.id);
  }).catch(function(b) {
    return a.m.error("Error in ended callbacks", b);
  }).then(function() {
    return !0;
  });
};
d.ew = function() {
  return Promise.resolve();
};
d.B0 = function(a, b, c) {
  hh(14);
  this.Ha && this.Ha.tabId && this.Ha.tabId == a && ("complete" == b.status || b.favIconUrl && "complete" == c.status) && (this.Ha.YO(c), this.xt.CK(this.Ha.$a), this.Ha.ju());
};
var Ch = function(a, b, c) {
  if (ih(a)) {
    return new Rg("tab", b);
  }
  if (jh(a)) {
    return new Rg("desktop", b);
  }
  if (lh(a)) {
    if (!c) {
      throw new dh("Missing offscreen tab presentation id");
    }
    return new Rg("offscreen_tab", b, a, c);
  }
  throw new dh("Source URN does not suggest a known capture type.");
};
d = Bh.prototype;
d.$S = function(a, b) {
  a.shouldCaptureAudio && b.nc && !b.nc.getAudioTracks().length && this.xt.ug().send(new Gg(Ah, "notification", "dismiss"));
};
d.yr = function() {
};
d.$t = function() {
};
d.Wt = function() {
};
d.zA = function() {
};
d.Xt = function() {
};
d.Yt = function() {
};
d.Zt = function() {
};
d.Mf = function() {
  return Promise.reject("Not implemented");
};
var Dh = function(a) {
  this.$a = a;
  this.Qs = !1;
  this.tabId = this.FA = this.iconUrl = null;
};
d = Dh.prototype;
d.zB = function(a, b, c) {
  this.$a.description = a;
  this.Qs || this.$a.offTheRecord ? this.iconUrl = this.FA = null : (this.FA = b, this.iconUrl = c);
};
d.ju = function() {
  this.Qs || this.$a.offTheRecord || this.qM();
};
d.Jca = function(a) {
  this.tabId = a;
  return oh(a).then(this.YO.bind(this));
};
d.YO = function(a) {
  this.Qs = a.incognito;
  this.zB(a.title, Da(a.url, "file://") ? "Local content (Tab)" : Lc(a.url.match(Kc)[3] || null, !0) + " (Tab)", a.favIconUrl);
};
d.haa = function(a) {
  this.$a = a;
};
d.start = function() {
};
d.uO = function() {
  return !1;
};
d.XO = function() {
};
d.stop = function() {
  return Promise.resolve();
};
d.qM = function() {
};
var Fh = function() {
  var a = this;
  this.maxWidth = 1920;
  this.maxHeight = 1080;
  this.minHeight = this.minWidth = 180;
  this.senderSideLetterboxing = !1;
  this.maxFrameRate = 30;
  this.minVideoBitrate = 300;
  this.maxVideoBitrate = 5000;
  this.audioBitrate = 0;
  this.maxLatencyMillis = 800;
  this.animatedLatencyMillis = this.minLatencyMillis = 400;
  this.dscpEnabled = kc || mc || Mg() || Ng();
  this.enableLogging = !0;
  this.useTdls = !1;
  this.shouldCaptureAudio = this.shouldCaptureVideo = !0;
  var b = window.localStorage ? window.localStorage.getItem(Eh) : null;
  if (b) {
    try {
      var c = JSON.parse(String(b));
      if (c instanceof Object) {
        this.aP(c), D("mr.mirror.Settings").l(function() {
          return "Initial mr.mirror.Settings overridden to: " + a.Wu();
        });
      } else {
        throw Error("localStorage[" + Eh + "] does not parse as an Object: " + b);
      }
    } catch (e) {
      throw D("mr.mirror.Settings").error(Eh + ' must be of the form \'{"maxWidth":640, "maxHeight":360}\'.', e), Error("Overrides not parseable.  See ERROR log for details.");
    }
  }
};
d = Fh.prototype;
d.clone = function() {
  var a = new Fh;
  a.aP(this);
  return a;
};
d.Wu = function() {
  return JSON.stringify(this, function(a, b) {
    if (0 == a.length || !a.endsWith("_")) {
      return b;
    }
  });
};
d.aP = function(a) {
  for (var b = ka(Object.keys(a)), c = b.next();!c.done;c = b.next()) {
    c = c.value, c.endsWith("_") || typeof a[c] !== typeof this[c] || (this[c] = a[c]);
  }
};
d.HJ = function() {
  this.fT();
  Object.freeze(this);
};
d.fT = function() {
  var a = screen.width, b = screen.height;
  this.maxHeight * a < this.maxWidth * b ? (a = Math.min(this.maxWidth, a), a -= a % 160, b = 90 * a / 160) : (b = Math.min(this.maxHeight, b), b -= b % 90, a = 160 * b / 90);
  if (a < Math.max(160, this.minWidth) || b < Math.max(90, this.minHeight)) {
    a = Math.max(160, this.minWidth), b = Math.max(90, this.minHeight);
  }
  this.maxWidth = a;
  this.maxHeight = b;
};
d.oH = function() {
  if (this.G2()) {
    return {width:this.minWidth, height:this.minHeight};
  }
  for (var a = this.maxWidth, b = this.maxHeight;0 != b;) {
    var c = a % b, a = b, b = c;
  }
  b = this.maxWidth / a;
  a = this.maxHeight / a;
  if (b < this.minWidth || a < this.minHeight) {
    if (c = Math.max(this.minWidth / b, this.minHeight / a), b *= c, a *= c, b > this.maxWidth || a > this.maxHeight) {
      b = this.maxWidth, a = this.maxHeight;
    }
  }
  b = Math.round(b);
  a = Math.round(a);
  return {width:b, height:a};
};
d.G2 = function() {
  return 0 == this.minHeight || 0 == this.maxHeight ? !1 : Math.floor(100.0 * this.minWidth / this.minHeight) == Math.floor(100.0 * this.maxWidth / this.maxHeight);
};
var Eh = "mr.mirror.Settings.Overrides";
var Gh = function(a, b) {
  this.type = a;
  this.data = b;
}, Hh = function(a) {
  a = JSON.parse(a);
  if (!a.type) {
    throw Error("Invalid message");
  }
  return new Gh(a.type, a.data);
}, Ih = function(a, b, c, e) {
  this.description = a;
  this.settings = b || null;
  this.mediaConstraints = c || null;
  this.presentationUrl = e || null;
};
var Kh = function(a, b) {
  x(l(webkitRTCPeerConnection), "webkitRTCPeerConnection is not available.  Do you need to set flags?");
  this.a = D("cv2.PeerConnection");
  this.v2 = Jh;
  this.I = this.PT(b);
  this.Tw = this.JT(a);
  this.MU = !0;
  this.xM = new Jc;
  this.eB = !1;
  this.Ct = 0;
  this.Po = null;
  this.pJ = this.Fz = 0;
  this.fd = !1;
  this.tK = this.uK = this.Iz = this.DK = this.n3 = n;
};
d = Kh.prototype;
d.sN = function(a) {
  this.Iz = a;
};
d.rN = function(a) {
  this.uK = a;
};
d.qN = function(a) {
  this.tK = a;
};
d.uN = function(a) {
  this.DK = a;
};
d.tN = function(a) {
  this.Tw.onmessage = function(b) {
    a(b.data);
  };
};
d.Ss = function() {
  return this.fd;
};
d.SY = function(a) {
  var b = {};
  b.iceServers = [{url:"stun:stun.l.google.com:19302"}].concat(a);
  return b;
};
d.PT = function(a) {
  var b = this.SY(a);
  a = new webkitRTCPeerConnection(b);
  a.onicecandidate = u(this.Kz, this);
  a.Tpa = u(this.H3, this);
  a.oniceconnectionstatechange = u(this.G3, this);
  this.a.info(function() {
    return "Created webkitRTCPeerConnnection with config: " + JSON.stringify(b);
  });
  return a;
};
d.JT = function(a) {
  return this.I.createDataChannel(a, {reliable:!1});
};
d.n8 = function(a) {
  "string" == typeof a ? this.Tw.send(a) : this.Tw.send(JSON.stringify(a));
};
d.start = function() {
  this.fd || (this.fd = !0, this.Kn());
};
d.stop = function() {
  this.a.info("Stopping peer connection...");
  this.fd && (this.fd = !1, "closed" != this.I.signalingState && this.I.close());
  this.I = null;
};
d.addStream = function(a) {
  this.I.addStream(a);
};
d.removeStream = function(a) {
  this.fd && this.I.removeStream(a);
};
d.Kn = function() {
  var a = this;
  this.a.info("Sending offer to peer.");
  this.Fz = Date.now();
  this.I.createOffer(u(this.dN, this), function(b) {
    a.a.l("Error creating offer.", b);
  }, this.v2);
  this.xM.promise.then(function(b) {
    a.DK(b);
  });
};
d.dN = function(a) {
  var b = this;
  this.a.info(function() {
    return "Setting local description: " + JSON.stringify(a);
  });
  this.I.setLocalDescription(a, function() {
    b.a.info("Local description set successfully");
  }, function(a) {
    b.a.l("Error setting local description.", a);
  });
};
d.zV = function(a) {
  return {type:a.type, sdp:a.sdp};
};
d.setRemoteDescription = function(a) {
  var b = this;
  this.a.w(function() {
    return "<===: " + JSON.stringify(a);
  });
  var c = new RTCSessionDescription(a);
  this.a.info(function() {
    return "Setting remote description: " + JSON.stringify(c);
  });
  this.I.setRemoteDescription(c, function() {
    b.a.info("Remote description set successfully.");
  }, function(a) {
    b.a.l("Error setting remote description.", a);
  });
};
d.Kz = function(a) {
  var b = this;
  a.candidate ? (this.Ct++, this.pJ = Date.now(), 1 == this.Ct ? (x(null == this.Po), this.Po = ie(function() {
    b.a.info("ICE candidate gathering timed out.");
    b.Po = null;
    b.TA();
  }, 5E3)) : this.eB && this.a.l("Received ICE candidate after resolving session description.")) : (this.a.info("End of ICE candidates."), Tg("MediaRouter.WebRtc.IceCandidateGathering.Duration.Reported", Date.now() - this.Fz), this.TA(), 0 < this.Ct && Tg("MediaRouter.WebRtc.IceCandidateGathering.Duration.Real", this.pJ - this.Fz));
};
d.H3 = function() {
  "completed" == this.I.iceGatheringState && this.TA();
};
d.TA = function() {
  je(this.Po);
  this.Po = null;
  this.eB || (this.a.info("Resolving sesion description after gathering " + this.Ct + " ICE candidates."), this.xM.resolve(this.zV(this.I.localDescription)), this.eB = !0);
};
d.G3 = function(a) {
  var b = this;
  if (this.I) {
    var c = this.I.iceConnectionState;
    this.a.info("New ICE connection state: " + c + ".");
    "connected" == c ? this.Iz("iceconnected") : "completed" == c ? this.Iz("icecompleted") : "failed" == c ? (this.a.l(function() {
      return "Ice connection failed: " + JSON.stringify(a);
    }), this.uK("icefailed")) : "closed" == c ? this.tK("iceclosed") : "disconnected" == c && (this.a.l("Ice connection state is bad."), this.MU && this.Ss() ? (this.a.info("Restarting ICE."), this.I.createOffer(u(this.dN, this), function(a) {
      b.a.l("Error creating new offer.", a);
    }, Lh)) : this.n3());
  }
};
var Jh = {mandatory:{OfferToReceiveAudio:!0, OfferToReceiveVideo:!0}}, Lh = {mandatory:{IceRestart:!0, OfferToReceiveAudio:!0, OfferToReceiveVideo:!0}};
n.oO = window.localStorage;
var Mh = 0, Oh = function(a) {
  return (a = window.localStorage.getItem(Nh(a, !1))) ? JSON.parse(a) : null;
}, Ph = function(a) {
  return (a = window.localStorage.getItem(Nh(a, !0))) ? JSON.parse(a) : null;
}, Rh = function(a) {
  if (Qh.has(a.oa())) {
    throw Error("Duplicate instance name " + a.oa());
  }
  Qh.set(a.oa(), a);
  a.Xa();
}, Sh = null, Th = D("mr.PersistentDataManager"), Qh = new Map, Nh = function(a, b) {
  return "mr." + (b ? "persistent." : "temp.") + a.oa();
}, Uh = function(a) {
  return !!window.localStorage.getItem("mrInstanceId") && window.localStorage.getItem("mrInstanceId") !== a;
}, Xh = function() {
  Th.info("onSuspend");
  Vh("version", chrome.runtime.getManifest().version);
  Sh && Vh("mrInstanceId", Sh);
  Qh.forEach(Wh);
}, Wh = function(a) {
  var b = a.getData();
  b && void 0 != b[0] && Vh(Nh(a, !1), JSON.stringify(b[0]));
  b && void 0 != b[1] && Vh(Nh(a, !0), JSON.stringify(b[1]));
}, Vh = function(a, b) {
  var c;
  c = window.localStorage.getItem(a);
  c = void 0 != c ? b.length - c.length : a.length + b.length;
  5200000 <= Mh + c && (Th.l("Unable to write " + c + " bytes"), Yh());
  5200000 <= Mh + c ? Th.error("Unable to write " + c + " bytes after clearing temporary") : (window.localStorage.setItem(a, b), Mh += c);
}, Yh = function() {
  for (var a = ka(Object.keys(n.oO)), b = a.next();!b.done;b = a.next()) {
    b = b.value, b.startsWith("mr.temp.") && (Mh -= b.length + window.localStorage.getItem(b).length, delete window.localStorage[b]);
  }
  Th.info("removeTemporary_: " + Mh + " bytes used");
};
var Zh = C("Firefox"), $h = Zb() || C("iPod"), ai = C("iPad"), bi = C("Android") && !(Yb() || C("Firefox") || C("Opera") || C("Silk")), ci = Yb(), di = C("Safari") && !(Yb() || C("Coast") || C("Opera") || C("Edge") || C("Silk") || C("Android")) && !(Zb() || C("iPad") || C("iPod"));
var ei = function(a) {
  this.Iba = a;
  this.em = 1000 * Math.floor(1e6 * Math.random());
};
d = ei.prototype;
d.OU = function() {
  Rh(this);
};
d.us = function() {
  var a = this.em++;
  0 == a && (a = this.em++);
  return a;
};
d.oa = function() {
  return "IdGenerator." + this.Iba;
};
d.getData = function() {
  return [this.em];
};
d.Xa = function() {
  var a = Oh(this);
  a && (this.em = a);
};
var fi = function(a) {
  return z(a, function(a) {
    a = a.toString(16);
    return 1 < a.length ? a : "0" + a;
  }).join("");
}, gi = function(a) {
  for (var b = [], c = 0, e = 0;e < a.length;e++) {
    var f = a.charCodeAt(e);
    128 > f ? b[c++] = f : (2048 > f ? b[c++] = f >> 6 | 192 : (55296 == (f & 64512) && e + 1 < a.length && 56320 == (a.charCodeAt(e + 1) & 64512) ? (f = 65536 + ((f & 1023) << 10) + (a.charCodeAt(++e) & 1023), b[c++] = f >> 18 | 240, b[c++] = f >> 12 & 63 | 128) : b[c++] = f >> 12 | 224, b[c++] = f >> 6 & 63 | 128), b[c++] = f & 63 | 128);
  }
  return b;
};
chrome.cast.VERSION = [1, 2];
m("chrome.cast.VERSION", chrome.cast.VERSION, void 0);
chrome.cast.Sca = !0;
m("chrome.cast.usingPresentationApi", chrome.cast.Sca, void 0);
chrome.cast.Error = function(a, b, c) {
  this.code = a;
  this.description = b || null;
  this.details = c || null;
};
m("chrome.cast.Error", chrome.cast.Error, void 0);
chrome.cast.QQ = function(a) {
  this.platform = a;
  this.packageId = this.url = null;
};
m("chrome.cast.SenderApplication", chrome.cast.QQ, void 0);
chrome.cast.Image = function(a) {
  this.url = a;
  this.width = this.height = null;
};
m("chrome.cast.Image", chrome.cast.Image, void 0);
chrome.cast.Volume = function(a, b) {
  this.level = l(a) ? a : null;
  this.muted = l(b) ? b : null;
};
m("chrome.cast.Volume", chrome.cast.Volume, void 0);
var hi = function(a, b, c, e, f) {
  this.id = a;
  this.friendlyName = b;
  this.iconType = void 0 === c ? "generic" : c;
  this.description = void 0 === e ? null : e;
  this.domain = void 0 === f ? null : f;
};
var ii = function(a, b) {
  this.input = a;
  this.domain = b;
};
var ji = function(a, b) {
  this.fh = a;
  this.kca = b;
}, ki = new ji("https://www.googleapis.com/clouddevices/v1", "AIzaSyAOZM8ZYeov685QMjXT3sC7XNizfrTEKjA"), li = new ji("https://www.googleapis.com/calendar/v3", ""), mi = new ji("https://www.googleapis.com/hangouts/v1", ""), ni = new ji("https://networktraversal.googleapis.com/v1alpha", "AIzaSyAOZM8ZYeov685QMjXT3sC7XNizfrTEKjA");
var oi = function(a, b) {
  this.email = a;
  this.imageUrl = null != b ? b : null;
}, pi = function(a) {
  this.type = a;
}, qi = function(a, b, c) {
  this.type = "__cloud_webrtc_session_message__";
  this.sessionDescription = a;
  this.user = null != b ? b : null;
  this.flungUrl = null != c ? c : null;
};
la(qi, pi);
var ri = function(a, b, c) {
  this.name = a;
  this.parameters = b;
  this.minimalRole = null != c ? c : "user";
}, si = {_settings:{type:"string"}, _presentationRequest:{type:"string"}, _optMediaConstraints:{type:"string"}, _webrtcMessage:{type:"string"}, _user:{type:"string"}}, ti = new ri("_knockingStartWebrtcSession", si, "viewer"), ui = new ri("_startWebrtcSession", si), vi = new ri("_stopSession", {}, "viewer");
var wi = function(a, b) {
  for (var c = [], e = 1;e < arguments.length;++e) {
    c[e - 1] = arguments[e];
  }
  for (var e = a, c = ka(c), f = c.next();!f.done;f = c.next()) {
    if (void 0 == e || "object" != typeof e) {
      return;
    }
    e = e[f.value];
  }
  return e;
};
var xi = function(a) {
  return Promise.all(a.map(function(a) {
    return a.then(function(a) {
      return {as:!0, value:a};
    }, function(a) {
      return {as:!1, reason:a};
    });
  }));
};
var yi = function() {
  this.pc = -1;
};
var zi = {SC:{1E3:{other:"0K"}, 1E4:{other:"00K"}, 1E5:{other:"000K"}, 1E6:{other:"0M"}, 1E7:{other:"00M"}, 1E8:{other:"000M"}, 1E9:{other:"0B"}, 1E10:{other:"00B"}, 1E11:{other:"000B"}, 1E12:{other:"0T"}, 1E13:{other:"00T"}, 1E14:{other:"000T"}}, MP:{1E3:{other:"0 thousand"}, 1E4:{other:"00 thousand"}, 1E5:{other:"000 thousand"}, 1E6:{other:"0 million"}, 1E7:{other:"00 million"}, 1E8:{other:"000 million"}, 1E9:{other:"0 billion"}, 1E10:{other:"00 billion"}, 1E11:{other:"000 billion"}, 1E12:{other:"0 trillion"}, 
1E13:{other:"00 trillion"}, 1E14:{other:"000 trillion"}}}, Ai = zi, Ai = zi;
var Ci = function(a, b) {
  var c = ["0"];
  b = Bi[b][0] & 7;
  if (0 < b) {
    c.push(".");
    for (var e = 0;e < b;e++) {
      c.push("0");
    }
  }
  return a.replace(/0.00/g, c.join(""));
}, Bi = {AED:[2, "dh", "\u062f.\u0625.", "DH"], ALL:[0, "Lek", "Lek"], AUD:[2, "$", "AU$"], BDT:[2, "\u09f3", "Tk"], BGN:[2, "lev", "lev"], BRL:[2, "R$", "R$"], CAD:[2, "$", "C$"], CDF:[2, "FrCD", "CDF"], CHF:[2, "CHF", "CHF"], CLP:[0, "$", "CL$"], CNY:[2, "\u00a5", "RMB\u00a5"], COP:[32, "$", "COL$"], CRC:[0, "\u20a1", "CR\u20a1"], CZK:[50, "K\u010d", "K\u010d"], DKK:[50, "kr.", "kr."], DOP:[2, "RD$", "RD$"], EGP:[2, "\u00a3", "LE"], ETB:[2, "Birr", "Birr"], EUR:[2, "\u20ac", "\u20ac"], GBP:[2, 
"\u00a3", "GB\u00a3"], HKD:[2, "$", "HK$"], HRK:[2, "kn", "kn"], HUF:[34, "Ft", "Ft"], IDR:[0, "Rp", "Rp"], ILS:[34, "\u20aa", "IL\u20aa"], INR:[2, "\u20b9", "Rs"], IRR:[0, "Rial", "IRR"], ISK:[0, "kr", "kr"], JMD:[2, "$", "JA$"], JPY:[0, "\u00a5", "JP\u00a5"], KRW:[0, "\u20a9", "KR\u20a9"], LKR:[2, "Rs", "SLRs"], LTL:[2, "Lt", "Lt"], MNT:[0, "\u20ae", "MN\u20ae"], MVR:[2, "Rf", "MVR"], MXN:[2, "$", "Mex$"], MYR:[2, "RM", "RM"], NOK:[50, "kr", "NOkr"], PAB:[2, "B/.", "B/."], PEN:[2, "S/.", "S/."], 
PHP:[2, "\u20b1", "PHP"], PKR:[0, "Rs", "PKRs."], PLN:[50, "z\u0142", "z\u0142"], RON:[2, "RON", "RON"], RSD:[0, "din", "RSD"], RUB:[50, "\u20bd", "RUB"], SAR:[2, "Rial", "Rial"], SEK:[50, "kr", "kr"], SGD:[2, "$", "S$"], THB:[2, "\u0e3f", "THB"], TRY:[2, "TL", "YTL"], TWD:[2, "NT$", "NT$"], TZS:[0, "TSh", "TSh"], UAH:[2, "\u0433\u0440\u043d.", "UAH"], USD:[2, "$", "US$"], UYU:[2, "$", "$U"], VND:[48, "\u20ab", "VN\u20ab"], YER:[0, "Rial", "Rial"], ZAR:[2, "R", "ZAR"]};
var Di = {VC:".", zv:",", $C:"%", Jv:"0", qQ:"+", hQ:"-", YC:"E", aD:"\u2030", Bv:"\u221e", mQ:"NaN", UC:"#,##0.###", MQ:"#E0", pQ:"#,##0%", NP:"\u00a4#,##0.00", QP:"USD"}, Ei = Di, Ei = Di;
var Fi = function(a) {
  return 1 == a % 10 && 11 != a % 100 ? "one" : 2 == a % 10 && 12 != a % 100 ? "two" : 3 == a % 10 && 13 != a % 100 ? "few" : "other";
}, Gi = Fi, Gi = Fi;
var Hi = function(a, b) {
  if (void 0 === b) {
    b = a + "";
    var c = b.indexOf(".");
    b = Math.min(-1 == c ? 0 : b.length - c - 1, 3);
  }
  return 1 == (a | 0) && 0 == b ? "one" : "other";
}, Ii = Hi, Ii = Hi;
var Ji = function(a, b) {
  this.width = a;
  this.height = b;
};
d = Ji.prototype;
d.clone = function() {
  return new Ji(this.width, this.height);
};
d.toString = function() {
  return "(" + this.width + " x " + this.height + ")";
};
d.RR = function() {
  return this.width * this.height;
};
d.Bb = function() {
  return !this.RR();
};
d.ceil = function() {
  this.width = Math.ceil(this.width);
  this.height = Math.ceil(this.height);
  return this;
};
d.floor = function() {
  this.width = Math.floor(this.width);
  this.height = Math.floor(this.height);
  return this;
};
d.round = function() {
  this.width = Math.round(this.width);
  this.height = Math.round(this.height);
  return this;
};
d.scale = function(a, b) {
  b = t(b) ? b : a;
  this.width *= a;
  this.height *= b;
  return this;
};
var Ki = function(a) {
  this.fm = 0;
  this.Yl = a || 100;
  this.ag = [];
};
d = Ki.prototype;
d.add = function(a) {
  var b = this.ag[this.fm];
  this.ag[this.fm] = a;
  this.fm = (this.fm + 1) % this.Yl;
  return b;
};
d.get = function(a) {
  a = this.iK(a);
  return this.ag[a];
};
d.set = function(a, b) {
  a = this.iK(a);
  this.ag[a] = b;
};
d.V = function() {
  return this.ag.length;
};
d.Bb = function() {
  return 0 == this.ag.length;
};
d.clear = function() {
  this.fm = this.ag.length = 0;
};
d.H = function() {
  return this.GY(this.V());
};
d.GY = function(a) {
  var b = this.V(), c = [];
  for (a = this.V() - a;a < b;a++) {
    c.push(this.get(a));
  }
  return c;
};
d.ub = function() {
  for (var a = [], b = this.V(), c = 0;c < b;c++) {
    a[c] = c;
  }
  return a;
};
d.Ma = function(a) {
  return a < this.V();
};
d.$k = function(a) {
  for (var b = this.V(), c = 0;c < b;c++) {
    if (this.get(c) == a) {
      return !0;
    }
  }
  return !1;
};
d.iK = function(a) {
  if (a >= this.ag.length) {
    throw Error("Out of bounds exception");
  }
  return this.ag.length < this.Yl ? a : (this.fm + Number(a)) % this.Yl;
};
var Li = function() {
  this.pc = 64;
  this.fa = [];
  this.pw = [];
  this.fR = [];
  this.Jt = [];
  this.Jt[0] = 128;
  for (var a = 1;a < this.pc;++a) {
    this.Jt[a] = 0;
  }
  this.Zu = this.Ml = 0;
  this.reset();
};
w(Li, yi);
Li.prototype.reset = function() {
  this.fa[0] = 1732584193;
  this.fa[1] = 4023233417;
  this.fa[2] = 2562383102;
  this.fa[3] = 271733878;
  this.fa[4] = 3285377520;
  this.Zu = this.Ml = 0;
};
Li.prototype.ph = function(a, b) {
  b || (b = 0);
  var c = this.fR;
  if (p(a)) {
    for (var e = 0;16 > e;e++) {
      c[e] = a.charCodeAt(b) << 24 | a.charCodeAt(b + 1) << 16 | a.charCodeAt(b + 2) << 8 | a.charCodeAt(b + 3), b += 4;
    }
  } else {
    for (e = 0;16 > e;e++) {
      c[e] = a[b] << 24 | a[b + 1] << 16 | a[b + 2] << 8 | a[b + 3], b += 4;
    }
  }
  for (e = 16;80 > e;e++) {
    var f = c[e - 3] ^ c[e - 8] ^ c[e - 14] ^ c[e - 16];
    c[e] = (f << 1 | f >>> 31) & 4294967295;
  }
  a = this.fa[0];
  b = this.fa[1];
  for (var g = this.fa[2], k = this.fa[3], q = this.fa[4], r, e = 0;80 > e;e++) {
    40 > e ? 20 > e ? (f = k ^ b & (g ^ k), r = 1518500249) : (f = b ^ g ^ k, r = 1859775393) : 60 > e ? (f = b & g | k & (b | g), r = 2400959708) : (f = b ^ g ^ k, r = 3395469782), f = (a << 5 | a >>> 27) + f + q + r + c[e] & 4294967295, q = k, k = g, g = (b << 30 | b >>> 2) & 4294967295, b = a, a = f;
  }
  this.fa[0] = this.fa[0] + a & 4294967295;
  this.fa[1] = this.fa[1] + b & 4294967295;
  this.fa[2] = this.fa[2] + g & 4294967295;
  this.fa[3] = this.fa[3] + k & 4294967295;
  this.fa[4] = this.fa[4] + q & 4294967295;
};
Li.prototype.update = function(a, b) {
  if (null != a) {
    l(b) || (b = a.length);
    for (var c = b - this.pc, e = 0, f = this.pw, g = this.Ml;e < b;) {
      if (0 == g) {
        for (;e <= c;) {
          this.ph(a, e), e += this.pc;
        }
      }
      if (p(a)) {
        for (;e < b;) {
          if (f[g] = a.charCodeAt(e), ++g, ++e, g == this.pc) {
            this.ph(f);
            g = 0;
            break;
          }
        }
      } else {
        for (;e < b;) {
          if (f[g] = a[e], ++g, ++e, g == this.pc) {
            this.ph(f);
            g = 0;
            break;
          }
        }
      }
    }
    this.Ml = g;
    this.Zu += b;
  }
};
Li.prototype.digest = function() {
  var a = [], b = 8 * this.Zu;
  56 > this.Ml ? this.update(this.Jt, 56 - this.Ml) : this.update(this.Jt, this.pc - (this.Ml - 56));
  for (var c = this.pc - 1;56 <= c;c--) {
    this.pw[c] = b & 255, b /= 256;
  }
  this.ph(this.pw);
  for (c = b = 0;5 > c;c++) {
    for (var e = 24;0 <= e;e -= 8) {
      a[b] = this.fa[c] >> e & 255, ++b;
    }
  }
  return a;
};
var Mi = {ACCEPTED:0, wea:1, TIMEOUT:2}, Ni = {SUCCESS:0, WP:1}, Oi = {dR:0, DQ:1, aia:2, gfa:3, ffa:4, Tfa:5, TIMEOUT:6, Mga:7}, Pi = {dfa:0, vha:1}, Qi = {vga:0, Jfa:1, Rha:2, Zea:3}, Ri = function(a) {
  ah("MediaRouter.Cloud.Knock.Result", a, Mi);
}, Si = function(a) {
  ah("MediaRouter.Cloud.Session.Start", a, Ni);
}, Ti = function(a) {
  ah("MediaRouter.Cloud.Session.Type", a, Pi);
}, Ui = function(a) {
  ah("MediaRouter.Cloud.Device.UserRole", a, Qi);
};
var Vi = function(a) {
  this.Ib = a;
  this.id = x(a.id);
  this.a = D("mr.cloud.devices.CloudDevice");
};
d = Vi.prototype;
d.isAvailable = function() {
  if (this.getState().appStatus) {
    var a = this.m1(), b = this.g1(), c = this.vE(864E5);
    this.a.w("Device id: " + this.id + ", availability: GCM connected " + a + ", app Available: " + b + ", checked in: " + c);
    return a && b && c;
  }
  a = this.vE(9E5);
  this.a.info("Availability for legacy receiver app: " + a);
  return a;
};
d.vE = function(a) {
  var b = this.SX();
  return !!(b && b > Date.now() - a);
};
d.g1 = function() {
  return "available" == this.getState().appStatus;
};
d.m1 = function() {
  return "online" == this.Ib.connectionStatus;
};
d.SX = function() {
  return this.Ib.lastUpdateTimeMs ? Number(this.Ib.lastUpdateTimeMs) : null;
};
d.Bh = function() {
  return this.getState().settings.receiverName;
};
d.getId = function() {
  return this.id;
};
d.getState = function() {
  return this.Ib.state._cloudCast;
};
d.t1 = function() {
  return this.Ib.invitations ? 0 != this.Ib.invitations.length : !1;
};
var Wi = function(a, b, c, e, f, g) {
  this.iJ = a;
  this.Fd = b;
  this.vh = e || null;
  this.Vh = c || null;
  this.Ve = f || null;
  this.ak = g || null;
};
d = Wi.prototype;
d.Bh = function() {
  var a = "";
  this.Ve ? a = this.Ve : this.Vh && (a = this.Vh);
  return x(a, "Missing Hangout display name forHangout id: " + this.getId());
};
d.getId = function() {
  return this.iJ + "@" + this.Fd;
};
d.getService = function() {
  return this.Fd;
};
d.Ch = function() {
  return this.vh;
};
d.merge = function(a) {
  !this.ak && a.ak && (this.ak = a.ak);
  !this.Ve && a.Ve && (this.Ve = a.Ve);
  this.Ve && a.Ve && this.ak && (this.Ve = a.Ve);
  x(this.Vh == a.Vh);
  x(this.vh == a.vh);
};
var Xi = function(a, b, c) {
  this.state = a;
  this.type = null != b ? b : null;
  this.results = null != c ? c : null;
}, Yi = function(a) {
  this.tb = a;
};
d = Yi.prototype;
d.r8 = function(a, b, c) {
  var e = this;
  return this.rM(ti, a, b, c, 35000).then(function(a) {
    return e.nI(a);
  });
};
d.u8 = function(a, b, c) {
  var e = this;
  return this.rM(ui, a, b, c, 23000).then(function(a) {
    var b = a.state;
    return "done" == b ? (a = e.$K(a), new Xi(b, a.type, new qi(a.sessionDescription))) : new Xi(b);
  });
};
d.x8 = function(a) {
  return this.Nf(a, vi, {});
};
d.rM = function(a, b, c, e, f) {
  var g;
  g = c.presentationUrl ? new qi(x(c.description), null, c.presentationUrl) : new qi(x(c.description));
  g = {_webrtcMessage:JSON.stringify(g)};
  c.settings && (g._settings = c.settings.Wu());
  c.mediaConstraints && (g._optMediaConstraints = JSON.stringify(c.mediaConstraints));
  e && (g._user = JSON.stringify(e));
  return this.Nf(b, a, g, f);
};
d.nI = function(a) {
  var b = this, c = a.state;
  switch(c) {
    case "done":
      return Promise.resolve(this.b5(a));
    case "queued":
    case "inProgress":
      return this.Wca(a).then(function(a) {
        return b.nI(a);
      });
    default:
      return Promise.resolve(new Xi(c));
  }
};
d.Wca = function(a) {
  var b = this;
  return new Promise(function(c) {
    var e = setInterval(function() {
      var f = x(a.id);
      b.iV(f).then(function(a) {
        "queued" != a.state && "inProgress" != a.state && (clearInterval(e), c(a));
      });
    }, 2000);
  });
};
d.b5 = function(a) {
  a = this.$K(a);
  return "__cloud_webrtc_session_message__" == a.type ? new Xi("done", "knocking_cloud_webrtc_session_message", new qi(a.sessionDescription)) : new Xi("done", a.type);
};
d.Nf = function(a, b, c, e) {
  a = {deviceId:a, name:"_cloudCast." + b.name, parameters:c, expirationTimeoutMs:e || 10000};
  b = {};
  e && (b.responseAwaitMs = Math.min(e + 5000, 25000));
  e = this.tb.Wi(ki.fh, ["commands"], b);
  return this.tb.jh(e, "POST", a);
};
d.$K = function(a) {
  return a.results && a.results.results ? JSON.parse(a.results.results) : null;
};
d.iV = function(a) {
  a = this.tb.Wi(ki.fh, ["commands", a]);
  return this.tb.jh(a, "GET");
};
Yi.$inject = ["gapiService"];
var Zi = function(a, b, c, e, f) {
  for (var g = [], k = 4;k < arguments.length;++k) {
    g[k - 4] = arguments[k];
  }
  var q = this;
  this.ml = a;
  this.ua = b;
  this.bm = c;
  this.Ia = e;
  this.U1 = g;
  this.Jl = !1;
  this.Cg = function(a) {
    for (var b = [], c = 0;c < arguments.length;++c) {
      b[c - 0] = arguments[c];
    }
    return q.qU.apply(q, [].concat(ma(b)));
  };
};
d = Zi.prototype;
d.yR = function() {
  Rh(this);
};
d.xU = function() {
  this.Ia.addListener.apply(this.Ia, [].concat([this.Cg], ma(this.U1)));
};
d.addListener = function() {
  this.Jl || (this.Jl = !0, this.xU());
};
d.removeListener = function() {
  this.Jl && (this.Ia.removeListener(this.Cg), this.Jl = !1);
};
d.jv = function(a) {
  for (var b = 0;b < arguments.length;++b) {
  }
  return !0;
};
d.qU = function(a) {
  for (var b = [], c = 0;c < arguments.length;++c) {
    b[c - 0] = arguments[c];
  }
  var e = this;
  hh(this.ml);
  if (!this.jv.apply(this, [].concat(ma(b)))) {
    return !1;
  }
  uh(this.bm).then(function(a) {
    return a.handleEvent.apply(a, [].concat([e.Ia], ma(b)));
  });
  return this.Xw();
};
d.rj = function() {
  return this.Jl;
};
d.oa = function() {
  return "mr.EventListener." + this.ua;
};
d.getData = function() {
  return [this.Jl];
};
d.Xa = function() {
  Oh(this) && this.addListener();
};
d.Xw = function() {
};
var $i = function(a) {
  this.tb = a;
  this.ol = this.Ul = this.wj = null;
  this.Us = this.Rs = !1;
  this.a = D("mr.cloud.devices.CloudDevicesService");
  Rh(this);
};
d = $i.prototype;
d.getDevice = function(a) {
  a = this.tb.Wi(ki.fh, ["devices", a]);
  return this.tb.jh(a, "GET").then(function(a) {
    return new Vi(a);
  });
};
d.Q1 = function() {
  return this.BJ({descriptionSubstring:"Chrome Streaming Receiver"});
};
d.BJ = function(a) {
  var b = this, c = this.tb.Wi(ki.fh, ["devices"], a);
  return this.tb.jh(c, "GET").then(function(c) {
    var e = (c.devices || []).filter(function(a) {
      return null != a.commandDefs && null != a.commandDefs._cloudCast;
    }).map(function(a) {
      return new Vi(a);
    });
    if (c = c.nextPageToken) {
      var g = Qb(a);
      g.token = c;
      return b.BJ(g).then(function(a) {
        return e.concat(a);
      });
    }
    return e;
  });
};
d.oa = function() {
  return "CloudDevicesService";
};
d.getData = function() {
  return [new aj(this.wj, this.ol, this.Ul)];
};
d.Xa = function() {
  var a = Oh(this);
  a && (this.wj = a.M1, this.ol = a.gcmRegistrationId, this.Ul = a.K1);
};
d.U6 = function() {
  var a = this;
  return new Promise(function(b, c) {
    a.Rs ? c(Error("Registering...")) : (a.Rs = !0, a.ol && a.Ul && a.Ul + 864E5 >= Date.now() ? (a.Rs = !1, b(a.ol)) : chrome.gcm.register(["919648714761"], function(e) {
      a.Rs = !1;
      e ? (a.a.w("Got GCM ID: " + e), a.ol = e, a.Ul = Date.now(), a.wj = null, b(e)) : (a.a.l("Error: " + chrome.runtime.lastError.message), a.ol = null, a.Ul = null, a.wj = null, c(Error(chrome.runtime.lastError.message)));
    }));
  });
};
d.fba = function() {
  return !this.wj || this.wj + 864E5 < Date.now();
};
d.subscribe = function(a) {
  var b = this;
  if (this.Us) {
    return Promise.resolve();
  }
  this.Us = !0;
  if (!a || !this.fba()) {
    return Promise.resolve();
  }
  a = {filters:["myDevices"], gcmRegistrationId:a, gcmSenderId:"919648714761", expirationTimeMs:864E5};
  var c = this.tb.Wi(ki.fh, ["subscriptions", "subscribe"], {});
  return this.tb.jh(c, "POST", a).then(function() {
    b.a.w("Subscribed on: " + Date.now());
    b.wj = Date.now();
    b.Us = !1;
    return Promise.resolve();
  }, function(a) {
    b.Us = !1;
    throw a;
  });
};
var aj = function(a, b, c) {
  this.M1 = a;
  this.gcmRegistrationId = b;
  this.K1 = c;
};
var bj = function() {
  this.Vg = !1;
  this.an = null;
  this.Wo = !1;
  this.a = D("mr.cloud.identity.IdentityService");
  Rh(this);
  this.S1();
  this.NN();
};
d = bj.prototype;
d.getAuthToken = function() {
  return chrome.identity ? new Promise(function(a, b) {
    chrome.identity.getAuthToken({interactive:!1}, function(c) {
      chrome.runtime.lastError ? b(Error("Unable to get user auth token: " + chrome.runtime.lastError.message)) : null == c ? b(Error("User is not logged in (no token found)")) : a(c);
    });
  }) : Promise.reject(Error("chrome.identity permission required for auth."));
};
d.dV = function(a) {
  return new Promise(function(b) {
    chrome.identity.removeCachedAuthToken({token:a}, function() {
      b();
    });
  });
};
d.NN = function() {
  var a = this;
  this.getAuthToken().then(function(b) {
    chrome.identity.getProfileUserInfo(function(c) {
      a.Vg = !!c.email || !!c.id;
      a.an = c.email || null;
      b && !a.Vg && (a.Wo = !0);
    });
  }, function(b) {
    a.a.w("Unable to set sign in and email.", b);
  });
};
d.S1 = function() {
  var a = this;
  chrome.identity.onSignInChanged.addListener(function(b, c) {
    hh(6);
    a.Vg = c;
    a.a.info("Signed in change: " + a.Vg);
    a.Vg ? a.NN() : (a.an = null, a.Wo = !1);
  });
};
d.O6 = function() {
  var a = this;
  return this.getAuthToken().then(function(b) {
    var c = window.gapi;
    if (!c) {
      return a.a.error("gapi not loaded."), !1;
    }
    a.a.info("Setting gapi auth token");
    c.auth.setToken({access_token:b});
    return !0;
  });
};
d.oa = function() {
  return "IdentityService";
};
d.getData = function() {
  return [null, {signedIn:this.Vg, userEmail:this.an, kioskAuth:this.Wo}];
};
d.Xa = function() {
  var a = Ph(this);
  a && (a.signedIn && (this.Vg = a.signedIn), a.userEmail && (this.an = a.userEmail), a.kioskAuth && (this.Wo = a.kioskAuth));
};
var cj = function() {
  var a = this;
  this.a = D("mr.cloud.settings.SettingsService");
  this.Hz = null;
  chrome.settingsPrivate.onPrefsChanged.addListener(function(b) {
    hh(13);
    if (a.Hz) {
      b = ka(b);
      for (var c = b.next();!c.done;c = b.next()) {
        if (c = c.value, "media_router.cloudservices.enabled" == c.key) {
          a.Hz.call(null, c.value);
          break;
        }
      }
    }
  });
};
d = cj.prototype;
d.B$ = function(a) {
  this.Hz = a;
};
d.ica = function() {
  var a = this.a;
  chrome.storage.sync.set({"mr.cloud.cloudEnabled":!0}, function() {
    chrome.runtime.lastError && a.l("Error setting cloud setting: " + JSON.stringify(chrome.runtime.lastError));
  });
};
d.yW = function() {
  var a = this;
  return this.wG().catch(function() {
    return a.wG().catch(function(b) {
      a.a.l("Error retrieving cloud on setting.", b);
      return !1;
    });
  });
};
d.wG = function() {
  return this.YG("mr.cloud.cloudEnabled").then(function(a) {
    return !!a["mr.cloud.cloudEnabled"];
  });
};
d.YG = function(a) {
  return new Promise(function(b, c) {
    chrome.storage.sync.get(a, function(a) {
      chrome.runtime.lastError ? c(chrome.runtime.lastError) : b(a);
    });
  });
};
d.wW = function() {
  var a = this;
  return this.vG().catch(function() {
    return a.vG().catch(function(b) {
      a.a.l("Error retrieving cloud enabled setting.", b);
      return !1;
    });
  });
};
d.vG = function() {
  return this.ZY("media_router.cloudservices.enabled").then(function(a) {
    x("media_router.cloudservices.enabled" == a.key);
    x(a.type == chrome.settingsPrivate.PrefType.BOOLEAN);
    return !!a.value;
  });
};
d.ZY = function(a) {
  return new Promise(function(b, c) {
    chrome.settingsPrivate.getPref(a, function(a) {
      chrome.runtime.lastError ? c(chrome.runtime.lastError) : b(a);
    });
  });
};
d.A$ = function() {
  var a = this.a;
  chrome.storage.sync.set({"mr.cloud.notifiedHangouts":!0}, function() {
    chrome.runtime.lastError && a.l("Error setting notified Hangout privacy.", chrome.runtime.lastError);
  });
};
d.LY = function() {
  var a = this;
  return this.qH().catch(function() {
    return a.qH().catch(function(b) {
      a.a.l("Error retrieving hangouts notified setting.", b);
      return !1;
    });
  });
};
d.qH = function() {
  return this.YG("mr.cloud.notifiedHangouts").then(function(a) {
    return !!a["mr.cloud.notifiedHangouts"];
  });
};
var dj = function() {
  this.xe = [];
  this.df = [];
};
d = dj.prototype;
d.n2 = function() {
  0 == this.xe.length && (this.xe = this.df, this.xe.reverse(), this.df = []);
};
d.enqueue = function(a) {
  this.df.push(a);
};
d.uh = function() {
  this.n2();
  return this.xe.pop();
};
d.V = function() {
  return this.xe.length + this.df.length;
};
d.Bb = function() {
  return 0 == this.xe.length && 0 == this.df.length;
};
d.clear = function() {
  this.xe = [];
  this.df = [];
};
d.contains = function(a) {
  return pb(this.xe, a) || pb(this.df, a);
};
d.remove = function(a) {
  var b;
  b = this.xe;
  var c = gb(b, a);
  0 <= c ? (tb(b, c), b = !0) : b = !1;
  return b || ub(this.df, a);
};
d.H = function() {
  for (var a = [], b = this.xe.length - 1;0 <= b;--b) {
    a.push(this.xe[b]);
  }
  for (var c = this.df.length, b = 0;b < c;++b) {
    a.push(this.df[b]);
  }
  return a;
};
var ej = function() {
  Zi.call(this, 5, "cloud.GcmEventListener", "mr.cloud.discovery.CloudSinkDiscoveryService", chrome.gcm.onMessage);
  this.a = D("mr.CloudGcmEventListener");
};
la(ej, Zi);
ej.prototype.jv = function(a) {
  a = wi(a, "data", "notification");
  if (!a) {
    return this.a.error("Notification json not found"), !1;
  }
  try {
    var b = JSON.parse(a);
    return !!b && Array.isArray(b.events) && 0 < b.events.length;
  } catch (c) {
    return this.a.error("Invalid json: " + a), !1;
  }
};
var gj = function() {
  fj || (fj = new ej);
  return fj;
}, fj = null;
var hj = function(a, b, c) {
  this.Ro = b || Ei.QP;
  this.cU = c || 0;
  this.nt = 40;
  this.Ie = 1;
  this.nk = 0;
  this.Cj = 3;
  this.vt = this.Gg = 0;
  this.dO = this.hP = !1;
  this.Ap = this.Qj = "";
  this.Wh = "-";
  this.dm = "";
  this.ce = 1;
  this.Gj = !1;
  this.lj = [];
  this.hv = this.eF = !1;
  this.Gn = 0;
  this.WD = null;
  "number" == typeof a ? this.QR(a) : this.Ik(a);
};
d = hj.prototype;
d.m$ = function(a) {
  if (0 < this.nk && 0 < a) {
    throw Error("Can't combine significant digits and minimum fraction digits");
  }
  this.Gg = a;
  return this;
};
d.h$ = function(a) {
  this.Cj = a;
  return this;
};
d.waa = function(a) {
  if (0 < this.Gg && 0 <= a) {
    throw Error("Can't combine significant digits and minimum fraction digits");
  }
  this.nk = a;
  return this;
};
d.Ik = function(a) {
  a.replace(/ /g, "\u00a0");
  var b = [0];
  this.Qj = this.Kt(a, b);
  var c = b[0];
  this.H5(a, b);
  c = b[0] - c;
  this.Ap = this.Kt(a, b);
  b[0] < a.length && ";" == a.charAt(b[0]) ? (b[0]++, 1 != this.ce && (this.Gj = !0), this.Wh = this.Kt(a, b), b[0] += c, this.dm = this.Kt(a, b)) : (this.Wh = this.Qj + this.Wh, this.dm += this.Ap);
};
d.QR = function(a) {
  switch(a) {
    case 1:
      this.Ik(Ei.UC);
      break;
    case 2:
      this.Ik(Ei.MQ);
      break;
    case 3:
      this.Ik(Ei.pQ);
      break;
    case 4:
      this.Ik(Ci(Ei.NP, this.Ro));
      break;
    case 5:
      this.KD(1);
      break;
    case 6:
      this.KD(2);
      break;
    default:
      throw Error("Unsupported pattern type.");
  }
};
d.KD = function(a) {
  this.Gn = a;
  this.Ik(Ei.UC);
  this.m$(0);
  this.h$(2);
  this.waa(2);
};
d.parse = function(a, b) {
  b = b || [0];
  if (0 != this.Gn) {
    throw Error("Parsing of compact numbers is unimplemented");
  }
  var c;
  a = a.replace(/ /g, "\u00a0");
  var e = a.indexOf(this.Qj, b[0]) == b[0], f = a.indexOf(this.Wh, b[0]) == b[0];
  e && f && (this.Qj.length > this.Wh.length ? f = !1 : this.Qj.length < this.Wh.length && (e = !1));
  e ? b[0] += this.Qj.length : f && (b[0] += this.Wh.length);
  a.indexOf(Ei.Bv, b[0]) == b[0] ? (b[0] += Ei.Bv.length, c = Infinity) : c = this.r5(a, b);
  if (e) {
    if (a.indexOf(this.Ap, b[0]) != b[0]) {
      return NaN;
    }
    b[0] += this.Ap.length;
  } else {
    if (f) {
      if (a.indexOf(this.dm, b[0]) != b[0]) {
        return NaN;
      }
      b[0] += this.dm.length;
    }
  }
  return f ? -c : c;
};
d.r5 = function(a, b) {
  var c = !1, e = !1, f = !1, g = 1, k = Ei.VC, q = Ei.zv, r = Ei.YC;
  if (0 != this.Gn) {
    throw Error("Parsing of compact style numbers is not implemented");
  }
  for (var A = "";b[0] < a.length;b[0]++) {
    var E = a.charAt(b[0]), aa = this.KG(E);
    if (0 <= aa && 9 >= aa) {
      A += aa, f = !0;
    } else {
      if (E == k.charAt(0)) {
        if (c || e) {
          break;
        }
        A += ".";
        c = !0;
      } else {
        if (E == q.charAt(0) && ("\u00a0" != q.charAt(0) || b[0] + 1 < a.length && 0 <= this.KG(a.charAt(b[0] + 1)))) {
          if (c || e) {
            break;
          }
        } else {
          if (E == r.charAt(0)) {
            if (e) {
              break;
            }
            A += "E";
            e = !0;
          } else {
            if ("+" == E || "-" == E) {
              A += E;
            } else {
              if (1 == this.ce && E == Ei.$C.charAt(0)) {
                if (1 != g) {
                  break;
                }
                g = 100;
                if (f) {
                  b[0]++;
                  break;
                }
              } else {
                if (1 == this.ce && E == Ei.aD.charAt(0)) {
                  if (1 != g) {
                    break;
                  }
                  g = 1000;
                  if (f) {
                    b[0]++;
                    break;
                  }
                } else {
                  break;
                }
              }
            }
          }
        }
      }
    }
  }
  1 != this.ce && (g = this.ce);
  return parseFloat(A) / g;
};
d.format = function(a) {
  if (isNaN(a)) {
    return Ei.mQ;
  }
  var b = [], c = this.l_(null === this.WD ? a : this.WD, a);
  a /= Math.pow(10, c.cx);
  b.push(c.prefix);
  var e = 0.0 > a || 0.0 == a && 0.0 > 1 / a;
  b.push(e ? this.Wh : this.Qj);
  isFinite(a) ? (a = a * (e ? -1 : 1) * this.ce, this.hv ? this.Lba(a, b) : this.cC(a, this.Ie, b)) : b.push(Ei.Bv);
  b.push(e ? this.dm : this.Ap);
  b.push(c.sO);
  return b.join("");
};
d.ZL = function(a) {
  var b = Math.pow(10, this.Cj), c = 0 >= this.nk ? Math.round(a * b) : Math.round(this.T7(a * b, this.nk, this.Cj));
  isFinite(c) ? (a = Math.floor(c / b), b = Math.floor(c - a * b)) : b = 0;
  return {NI:a, DV:b};
};
d.cC = function(a, b, c) {
  if (this.Gg > this.Cj) {
    throw Error("Min value must be less than max value");
  }
  c || (c = []);
  a = this.ZL(a);
  var e = Math.pow(10, this.Cj), f = a.NI, g = a.DV, k = 0 == f ? 0 : this.Ps(f) + 1, q = 0 < this.Gg || 0 < g || this.dO && k < this.nk;
  a = this.Gg;
  q && (a = this.dO && 0 < this.nk ? this.nk - k : this.Gg);
  for (var r = "", k = f;1E20 < k;) {
    r = "0" + r, k = Math.round(k / 10);
  }
  var r = k + r, A = Ei.VC, k = Ei.Jv.charCodeAt(0), E = r.length, aa = 0;
  if (0 < f || 0 < b) {
    for (f = E;f < b;f++) {
      c.push(String.fromCharCode(k));
    }
    if (2 <= this.lj.length) {
      for (b = 1;b < this.lj.length;b++) {
        aa += this.lj[b];
      }
    }
    b = E - aa;
    if (0 < b) {
      for (var f = this.lj, aa = E = 0, ba, nb = Ei.zv, zd = r.length, Oc = 0;Oc < zd;Oc++) {
        if (c.push(String.fromCharCode(k + 1 * Number(r.charAt(Oc)))), 1 < zd - Oc) {
          if (ba = f[aa], Oc < b) {
            var LA = b - Oc;
            (1 === ba || 0 < ba && 1 === LA % ba) && c.push(nb);
          } else {
            aa < f.length && (Oc === b ? aa += 1 : ba === Oc - b - E + 1 && (c.push(nb), E += ba, aa += 1));
          }
        }
      }
    } else {
      b = r;
      r = this.lj;
      f = Ei.zv;
      ba = b.length;
      nb = [];
      for (E = r.length - 1;0 <= E && 0 < ba;E--) {
        aa = r[E];
        for (zd = 0;zd < aa && 0 <= ba - zd - 1;zd++) {
          nb.push(String.fromCharCode(k + 1 * Number(b.charAt(ba - zd - 1))));
        }
        ba -= aa;
        0 < ba && nb.push(f);
      }
      c.push.apply(c, nb.reverse());
    }
  } else {
    q || c.push(String.fromCharCode(k));
  }
  (this.eF || q) && c.push(A);
  e = "" + (g + e);
  for (g = e.length;"0" == e.charAt(g - 1) && g > a + 1;) {
    g--;
  }
  for (f = 1;f < g;f++) {
    c.push(String.fromCharCode(k + 1 * Number(e.charAt(f))));
  }
};
d.qD = function(a, b) {
  b.push(Ei.YC);
  0 > a ? (a = -a, b.push(Ei.hQ)) : this.hP && b.push(Ei.qQ);
  a = "" + a;
  for (var c = Ei.Jv, e = a.length;e < this.vt;e++) {
    b.push(c);
  }
  b.push(a);
};
d.gY = function(a, b) {
  var c = Math.pow(10, b);
  if (isFinite(c) && 0 !== c) {
    return a / c;
  }
  c = Math.pow(10, Math.floor(b / 2));
  a = a / c / c;
  1 == b % 2 && (a = 0 < b ? a / 10 : 10 * a);
  return a;
};
d.Lba = function(a, b) {
  if (0.0 == a) {
    this.cC(a, this.Ie, b), this.qD(0, b);
  } else {
    var c;
    c = Math.log(a) / Math.log(10);
    x(!l(void 0) || !1);
    c = Math.floor(c + 2e-15);
    a = this.gY(a, c);
    var e = this.Ie;
    if (1 < this.nt && this.nt > this.Ie) {
      for (;0 != c % this.nt;) {
        a *= 10, c--;
      }
      e = 1;
    } else {
      1 > this.Ie ? (c++, a /= 10) : (c -= this.Ie - 1, a *= Math.pow(10, this.Ie - 1));
    }
    this.cC(a, e, b);
    this.qD(c, b);
  }
};
d.KG = function(a) {
  a = a.charCodeAt(0);
  if (48 <= a && 58 > a) {
    return a - 48;
  }
  var b = Ei.Jv.charCodeAt(0);
  return b <= a && a < b + 10 ? a - b : -1;
};
d.Kt = function(a, b) {
  for (var c = "", e = !1, f = a.length;b[0] < f;b[0]++) {
    var g = a.charAt(b[0]);
    if ("'" == g) {
      b[0] + 1 < f && "'" == a.charAt(b[0] + 1) ? (b[0]++, c += "'") : e = !e;
    } else {
      if (e) {
        c += g;
      } else {
        switch(g) {
          case "#":
          case "0":
          case ",":
          case ".":
          case ";":
            return c;
          case "\u00a4":
            if (b[0] + 1 < f && "\u00a4" == a.charAt(b[0] + 1)) {
              b[0]++, c += this.Ro;
            } else {
              switch(this.cU) {
                case 0:
                  c += Bi[this.Ro][1];
                  break;
                case 2:
                  var g = this.Ro, k = Bi[g], c = c + (g == k[1] ? g : g + " " + k[1]);
                  break;
                case 1:
                  c += Bi[this.Ro][2];
              }
            }
            break;
          case "%":
            if (!this.Gj && 1 != this.ce) {
              throw Error("Too many percent/permill");
            }
            if (this.Gj && 100 != this.ce) {
              throw Error("Inconsistent use of percent/permill characters");
            }
            this.ce = 100;
            this.Gj = !1;
            c += Ei.$C;
            break;
          case "\u2030":
            if (!this.Gj && 1 != this.ce) {
              throw Error("Too many percent/permill");
            }
            if (this.Gj && 1000 != this.ce) {
              throw Error("Inconsistent use of percent/permill characters");
            }
            this.ce = 1000;
            this.Gj = !1;
            c += Ei.aD;
            break;
          default:
            c += g;
        }
      }
    }
  }
  return c;
};
d.H5 = function(a, b) {
  for (var c = -1, e = 0, f = 0, g = 0, k = -1, q = a.length, r = !0;b[0] < q && r;b[0]++) {
    switch(a.charAt(b[0])) {
      case "#":
        0 < f ? g++ : e++;
        0 <= k && 0 > c && k++;
        break;
      case "0":
        if (0 < g) {
          throw Error('Unexpected "0" in pattern "' + a + '"');
        }
        f++;
        0 <= k && 0 > c && k++;
        break;
      case ",":
        0 < k && this.lj.push(k);
        k = 0;
        break;
      case ".":
        if (0 <= c) {
          throw Error('Multiple decimal separators in pattern "' + a + '"');
        }
        c = e + f + g;
        break;
      case "E":
        if (this.hv) {
          throw Error('Multiple exponential symbols in pattern "' + a + '"');
        }
        this.hv = !0;
        this.vt = 0;
        b[0] + 1 < q && "+" == a.charAt(b[0] + 1) && (b[0]++, this.hP = !0);
        for (;b[0] + 1 < q && "0" == a.charAt(b[0] + 1);) {
          b[0]++, this.vt++;
        }
        if (1 > e + f || 1 > this.vt) {
          throw Error('Malformed exponential pattern "' + a + '"');
        }
        r = !1;
        break;
      default:
        b[0]--, r = !1;
    }
  }
  0 == f && 0 < e && 0 <= c && (f = c, 0 == f && f++, g = e - f, e = f - 1, f = 1);
  if (0 > c && 0 < g || 0 <= c && (c < e || c > e + f) || 0 == k) {
    throw Error('Malformed pattern "' + a + '"');
  }
  a = e + f + g;
  this.Cj = 0 <= c ? a - c : 0;
  0 <= c && (this.Gg = e + f - c, 0 > this.Gg && (this.Gg = 0));
  this.Ie = (0 <= c ? c : a) - e;
  this.hv && (this.nt = e + this.Ie, 0 == this.Cj && 0 == this.Ie && (this.Ie = 1));
  this.lj.push(Math.max(0, k));
  this.eF = 0 == c || c == a;
};
var ij = {prefix:"", sO:"", cx:0};
hj.prototype.aI = function(a, b) {
  var c = 1 == this.Gn ? Ai.SC : Ai.MP;
  null == c && (c = Ai.SC);
  if (3 > a) {
    return ij;
  }
  a = Math.min(14, a);
  var e = c[Math.pow(10, a)];
  for (--a;!e && 3 <= a;) {
    e = c[Math.pow(10, a)], a--;
  }
  if (!e) {
    return ij;
  }
  b = e[b];
  return b && "0" != b ? (b = /([^0]*)(0+)(.*)/.exec(b)) ? {prefix:b[1], sO:b[3], cx:a + 1 - (b[2].length - 1)} : ij : ij;
};
hj.prototype.l_ = function(a, b) {
  if (0 == this.Gn) {
    return ij;
  }
  a = Math.abs(a);
  b = this.aI(1 >= a ? 0 : this.Ps(a), "other").cx;
  return this.aI(b + this.Ps(this.ZL(a / Math.pow(10, b)).NI), "other");
};
hj.prototype.Ps = function(a) {
  if (!isFinite(a)) {
    return 0 < a ? a : 0;
  }
  for (var b = 0;1 <= (a /= 10);) {
    b++;
  }
  return b;
};
hj.prototype.T7 = function(a, b, c) {
  if (!a) {
    return a;
  }
  b = b - this.Ps(a) - 1;
  if (b < -c) {
    return c = Math.pow(10, c), Math.round(a / c) * c;
  }
  c = Math.pow(10, b);
  return Math.round(a * c) / c;
};
var jj = !fc && !dc || dc && 9 <= Number(zc) || fc && yc("1.9.1");
dc && yc("9");
var kj = function(a, b) {
  if ("undefined" != typeof HTMLScriptElement && "undefined" != typeof Element) {
    var c = a && (a instanceof HTMLScriptElement || !(a instanceof Element)), e;
    e = va(a) ? a.constructor.displayName || a.constructor.name || Object.prototype.toString.call(a) : void 0 === a ? "undefined" : null === a ? "null" : typeof a;
    x(c, "Argument is not a HTMLScriptElement (or a non-Element mock); got: %s", e);
  }
  a.src = Ze(b);
};
var lj = function(a) {
  this.Wl = [];
  this.eA = [];
  this.Dz = new hj(1);
  this.t5(a);
}, mj = /'([{}#].*?)'/g, nj = /''/g;
d = lj.prototype;
d.format = function(a) {
  return this.Zr(a, !1);
};
d.Zr = function(a, b) {
  if (0 == this.eA.length) {
    return "";
  }
  var c = [];
  this.vx(this.eA, a, b, c);
  a = c.join("");
  for (b || x(-1 == a.search("#"), "Not all # were replaced.");0 < this.Wl.length;) {
    a = a.replace(this.qw(this.Wl), this.Wl.pop());
  }
  return a;
};
d.vx = function(a, b, c, e) {
  for (var f = 0;f < a.length;f++) {
    switch(a[f].type) {
      case 4:
        e.push(a[f].value);
        break;
      case 3:
        var g = a[f].value;
        this.CV(g, b, e);
        break;
      case 2:
        g = a[f].value;
        this.BV(g, b, c, e);
        break;
      case 0:
        g = a[f].value;
        this.RF(g, b, Ii, c, e);
        break;
      case 1:
        g = a[f].value;
        this.RF(g, b, Gi, c, e);
        break;
      default:
        Xa("Unrecognized block type: " + a[f].type);
    }
  }
};
d.CV = function(a, b, c) {
  b = b[a];
  l(b) ? (this.Wl.push(b), c.push(this.qw(this.Wl))) : c.push("Undefined parameter - " + a);
};
d.BV = function(a, b, c, e) {
  var f = a.Vq;
  l(b[f]) ? (f = a[b[f]], l(f) || (f = a.other, bb(f, "Invalid option or missing other option for select block.")), this.vx(f, b, c, e)) : e.push("Undefined parameter - " + f);
};
d.RF = function(a, b, c, e, f) {
  var g = a.Vq, k = a.MD, q = +b[g];
  isNaN(q) ? f.push("Undefined or invalid parameter - " + g) : (k = q - k, g = a[b[g]], l(g) || (x(0 <= k, "Argument index smaller than offset."), c = this.Dz.xY ? c(k, this.Dz.xY()) : c(k), Za(c, "Invalid plural key."), g = a[c], l(g) || (g = a.other), bb(g, "Invalid option or missing other option for plural block.")), a = [], this.vx(g, b, e, a), b = a.join(""), Za(b, "Empty block in plural."), e ? f.push(b) : (e = this.Dz.format(k), f.push(b.replace(/#/g, e))));
};
d.t5 = function(a) {
  a && (a = this.$0(a), this.eA = this.Lt(a));
};
d.$0 = function(a) {
  var b = this.Wl, c = u(this.qw, this);
  a = a.replace(nj, function() {
    b.push("'");
    return c(b);
  });
  return a = a.replace(mj, function(a, f) {
    b.push(f);
    return c(b);
  });
};
d.Rr = function(a) {
  var b = 0, c = [], e = [], f = /[{}]/g;
  f.lastIndex = 0;
  for (var g;g = f.exec(a);) {
    var k = g.index;
    "}" == g[0] ? (g = c.pop(), x(l(g) && "{" == g, "No matching { for }."), 0 == c.length && (g = {type:1}, g.value = a.substring(b, k), e.push(g), b = k + 1)) : (0 == c.length && (b = a.substring(b, k), "" != b && e.push({type:0, value:b}), b = k + 1), c.push("{"));
  }
  x(0 == c.length, "There are mismatched { or } in the pattern.");
  b = a.substring(b);
  "" != b && e.push({type:0, value:b});
  return e;
};
var oj = /^\s*(\w+)\s*,\s*plural\s*,(?:\s*offset:(\d+))?/, pj = /^\s*(\w+)\s*,\s*selectordinal\s*,/, qj = /^\s*(\w+)\s*,\s*select\s*,/;
d = lj.prototype;
d.P4 = function(a) {
  return oj.test(a) ? 0 : pj.test(a) ? 1 : qj.test(a) ? 2 : /^\s*\w+\s*/.test(a) ? 3 : 5;
};
d.Lt = function(a) {
  var b = [];
  a = this.Rr(a);
  for (var c = 0;c < a.length;c++) {
    var e = {};
    if (0 == a[c].type) {
      e.type = 4, e.value = a[c].value;
    } else {
      if (1 == a[c].type) {
        switch(this.P4(a[c].value)) {
          case 2:
            e.type = 2;
            e.value = this.z5(a[c].value);
            break;
          case 0:
            e.type = 0;
            e.value = this.u5(a[c].value);
            break;
          case 1:
            e.type = 1;
            e.value = this.s5(a[c].value);
            break;
          case 3:
            e.type = 3;
            e.value = a[c].value;
            break;
          default:
            Xa("Unknown block type for pattern: " + a[c].value);
        }
      } else {
        Xa("Unknown part of the pattern.");
      }
    }
    b.push(e);
  }
  return b;
};
d.z5 = function(a) {
  var b = "";
  a = a.replace(qj, function(a, c) {
    b = c;
    return "";
  });
  var c = {};
  c.Vq = b;
  a = this.Rr(a);
  for (var e = 0;e < a.length;) {
    var f = a[e].value;
    Za(f, "Missing select key element.");
    e++;
    x(e < a.length, "Missing or invalid select value element.");
    if (1 == a[e].type) {
      var g = this.Lt(a[e].value);
    } else {
      Xa("Expected block type.");
    }
    c[f.replace(/\s/g, "")] = g;
    e++;
  }
  bb(c.other, "Missing other key in select statement.");
  return c;
};
d.u5 = function(a) {
  var b = "", c = 0;
  a = a.replace(oj, function(a, e, f) {
    b = e;
    f && (c = parseInt(f, 10));
    return "";
  });
  var e = {};
  e.Vq = b;
  e.MD = c;
  a = this.Rr(a);
  for (var f = 0;f < a.length;) {
    var g = a[f].value;
    Za(g, "Missing plural key element.");
    f++;
    x(f < a.length, "Missing or invalid plural value element.");
    if (1 == a[f].type) {
      var k = this.Lt(a[f].value);
    } else {
      Xa("Expected block type.");
    }
    e[g.replace(/\s*(?:=)?(\w+)\s*/, "$1")] = k;
    f++;
  }
  bb(e.other, "Missing other key in plural statement.");
  return e;
};
d.s5 = function(a) {
  var b = "";
  a = a.replace(pj, function(a, c) {
    b = c;
    return "";
  });
  var c = {};
  c.Vq = b;
  c.MD = 0;
  a = this.Rr(a);
  for (var e = 0;e < a.length;) {
    var f = a[e].value;
    Za(f, "Missing ordinal key element.");
    e++;
    x(e < a.length, "Missing or invalid ordinal value element.");
    if (1 == a[e].type) {
      var g = this.Lt(a[e].value);
    } else {
      Xa("Expected block type.");
    }
    c[f.replace(/\s*(?:=)?(\w+)\s*/, "$1")] = g;
    e++;
  }
  bb(c.other, "Missing other key in selectordinal statement.");
  return c;
};
d.qw = function(a) {
  x(0 < a.length, "Literal array is empty.");
  return "\ufddf_" + (a.length - 1).toString(10) + "_";
};
var rj = chrome.i18n.getMessage("1522140683318860351"), sj = chrome.i18n.getMessage("4246483347873264186"), tj = chrome.i18n.getMessage("5991427458288444010"), uj = chrome.i18n.getMessage("6063910461797960050"), vj = chrome.i18n.getMessage("7735695102441495789"), wj = chrome.i18n.getMessage("4575332923598659024"), xj = chrome.i18n.getMessage("2297080986956220930"), yj = new lj(xj), zj = function(a, b) {
  return yj.format({ORGANIZER:a, PARTICIPANTS:b});
};
var Aj = null, Bj = null, Cj = null, Dj = fc || gc && !di || cc || !di && !dc && "function" == typeof h.atob, Fj = function(a, b) {
  x(ta(a), "encodeByteArray takes an array as a parameter");
  Ej();
  b = b ? Cj : Aj;
  for (var c = [], e = 0;e < a.length;e += 3) {
    var f = a[e], g = e + 1 < a.length, k = g ? a[e + 1] : 0, q = e + 2 < a.length, r = q ? a[e + 2] : 0, A = f >> 2, f = (f & 3) << 4 | k >> 4, k = (k & 15) << 2 | r >> 6, r = r & 63;
    q || (r = 64, g || (k = 64));
    c.push(b[A], b[f], b[k], b[r]);
  }
  return c.join("");
}, Hj = function(a, b) {
  if (Dj && !b) {
    return h.atob(a);
  }
  var c = "";
  Gj(a, function(a) {
    c += String.fromCharCode(a);
  });
  return c;
}, Gj = function(a, b) {
  function c(b) {
    for (;e < a.length;) {
      var c = a.charAt(e++), f = Bj[c];
      if (null != f) {
        return f;
      }
      if (!Ga(c)) {
        throw Error("Unknown base64 encoding at char: " + c);
      }
    }
    return b;
  }
  Ej();
  for (var e = 0;;) {
    var f = c(-1), g = c(0), k = c(64), q = c(64);
    if (64 === q && -1 === f) {
      break;
    }
    b(f << 2 | g >> 4);
    64 != k && (b(g << 4 & 240 | k >> 2), 64 != q && b(k << 6 & 192 | q));
  }
}, Ej = function() {
  if (!Aj) {
    Aj = {};
    Bj = {};
    Cj = {};
    for (var a = 0;65 > a;a++) {
      Aj[a] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=".charAt(a), Bj[Aj[a]] = a, Cj[a] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_.".charAt(a), 62 <= a && (Bj["ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_.".charAt(a)] = a);
    }
  }
};
var Ij = {cellpadding:"cellPadding", cellspacing:"cellSpacing", colspan:"colSpan", frameborder:"frameBorder", height:"height", maxlength:"maxLength", nonce:"nonce", role:"role", rowspan:"rowSpan", type:"type", usemap:"useMap", valign:"vAlign", width:"width"}, Jj = function(a) {
  a = a.document;
  a = "CSS1Compat" == a.compatMode ? a.documentElement : a.body;
  return new Ji(a.clientWidth, a.clientHeight);
}, Kj = function(a) {
  return a ? a.parentWindow || a.defaultView : window;
}, Mj = function(a, b, c, e) {
  function f(c) {
    c && b.appendChild(p(c) ? a.createTextNode(c) : c);
  }
  for (;e < c.length;e++) {
    var g = c[e];
    !ta(g) || va(g) && 0 < g.nodeType ? f(g) : y(Lj(g) ? B(g) : g, f);
  }
}, Nj = function(a) {
  x(a, "Node cannot be null or undefined.");
  return 9 == a.nodeType ? a : a.ownerDocument || a.document;
}, Oj = function(a, b) {
  x(null != a, "goog.dom.setTextContent expects a non-null value for node");
  if ("textContent" in a) {
    a.textContent = b;
  } else {
    if (3 == a.nodeType) {
      a.data = b;
    } else {
      if (a.firstChild && 3 == a.firstChild.nodeType) {
        for (;a.lastChild != a.firstChild;) {
          a.removeChild(a.lastChild);
        }
        a.firstChild.data = b;
      } else {
        for (var c;c = a.firstChild;) {
          a.removeChild(c);
        }
        c = Nj(a);
        a.appendChild(c.createTextNode(String(b)));
      }
    }
  }
}, Lj = function(a) {
  if (a && "number" == typeof a.length) {
    if (va(a)) {
      return "function" == typeof a.item || "string" == typeof a.item;
    }
    if (ua(a)) {
      return "function" == typeof a.item;
    }
  }
  return !1;
}, Pj = function(a) {
  this.Un = a || h.document || document;
};
d = Pj.prototype;
d.getElementsByTagName = function(a, b) {
  return (b || this.Un).getElementsByTagName(String(a));
};
d.setProperties = function(a, b) {
  Hb(b, function(b, e) {
    "style" == e ? a.style.cssText = b : "class" == e ? a.className = b : "for" == e ? a.htmlFor = b : Ij.hasOwnProperty(e) ? a.setAttribute(Ij[e], b) : Da(e, "aria-") || Da(e, "data-") ? a.setAttribute(e, b) : a[e] = b;
  });
};
d.createElement = function(a) {
  return this.Un.createElement(String(a));
};
d.createTextNode = function(a) {
  return this.Un.createTextNode(String(a));
};
d.getWindow = function() {
  var a = this.Un;
  return a.parentWindow || a.defaultView;
};
d.appendChild = function(a, b) {
  a.appendChild(b);
};
d.append = function(a, b) {
  Mj(Nj(a), a, arguments, 1);
};
d.canHaveChildren = function(a) {
  if (1 != a.nodeType) {
    return !1;
  }
  switch(a.tagName) {
    case "APPLET":
    case "AREA":
    case "BASE":
    case "BR":
    case "COL":
    case "COMMAND":
    case "EMBED":
    case "FRAME":
    case "HR":
    case "IMG":
    case "INPUT":
    case "IFRAME":
    case "ISINDEX":
    case "KEYGEN":
    case "LINK":
    case "NOFRAMES":
    case "NOSCRIPT":
    case "META":
    case "OBJECT":
    case "PARAM":
    case "SCRIPT":
    case "SOURCE":
    case "STYLE":
    case "TRACK":
    case "WBR":
      return !1;
  }
  return !0;
};
d.removeNode = function(a) {
  return a && a.parentNode ? a.parentNode.removeChild(a) : null;
};
d.getChildren = function(a) {
  return jj && void 0 != a.children ? a.children : ib(a.childNodes, function(a) {
    return 1 == a.nodeType;
  });
};
d.isElement = function(a) {
  return va(a) && 1 == a.nodeType;
};
d.contains = function(a, b) {
  if (!a || !b) {
    return !1;
  }
  if (a.contains && 1 == b.nodeType) {
    return a == b || a.contains(b);
  }
  if ("undefined" != typeof a.compareDocumentPosition) {
    return a == b || !!(a.compareDocumentPosition(b) & 16);
  }
  for (;b && a != b;) {
    b = b.parentNode;
  }
  return b == a;
};
var Qj = function(a, b) {
  this.vh = this.Vf = this.Rg = "";
  this.Ja = null;
  this.Xi = this.Jg = "";
  this.Zd = this.u1 = !1;
  var c;
  a instanceof Qj ? (this.Zd = l(b) ? b : a.Zd, this.Au(a.Rg), this.PB(a.Io()), this.Am(a.Ch()), this.Fm(a.Wa()), this.ni(a.vd()), this.Gm(a.Lg.clone()), this.su(a.Xi)) : a && (c = String(a).match(Kc)) ? (this.Zd = !!b, this.Au(c[1] || "", !0), this.PB(c[2] || "", !0), this.Am(c[3] || "", !0), this.Fm(c[4]), this.ni(c[5] || "", !0), this.Gm(c[6] || "", !0), this.su(c[7] || "", !0)) : (this.Zd = !!b, this.Lg = new Rj(null, null, this.Zd));
};
d = Qj.prototype;
d.toString = function() {
  var a = [], b = this.Rg;
  b && a.push(Sj(b, Tj, !0), ":");
  var c = this.Ch();
  if (c || "file" == b) {
    a.push("//"), (b = this.Io()) && a.push(Sj(b, Tj, !0), "@"), a.push(encodeURIComponent(String(c)).replace(/%25([0-9a-fA-F]{2})/g, "%$1")), c = this.Wa(), null != c && a.push(":", String(c));
  }
  if (c = this.vd()) {
    this.Js() && "/" != c.charAt(0) && a.push("/"), a.push(Sj(c, "/" == c.charAt(0) ? Uj : Vj, !0));
  }
  (c = this.fX()) && a.push("?", c);
  (c = this.Xi) && a.push("#", Sj(c, Wj));
  return a.join("");
};
d.resolve = function(a) {
  var b = this.clone(), c = a.K0();
  c ? b.Au(a.Rg) : c = a.L0();
  c ? b.PB(a.Io()) : c = a.Js();
  c ? b.Am(a.Ch()) : c = a.CI();
  var e = a.vd();
  if (c) {
    b.Fm(a.Wa());
  } else {
    if (c = a.BI()) {
      if ("/" != e.charAt(0)) {
        if (this.Js() && !this.BI()) {
          e = "/" + e;
        } else {
          var f = b.vd().lastIndexOf("/");
          -1 != f && (e = b.vd().substr(0, f + 1) + e);
        }
      }
      f = e;
      if (".." == f || "." == f) {
        e = "";
      } else {
        if (-1 != f.indexOf("./") || -1 != f.indexOf("/.")) {
          for (var e = Da(f, "/"), f = f.split("/"), g = [], k = 0;k < f.length;) {
            var q = f[k++];
            "." == q ? e && k == f.length && g.push("") : ".." == q ? ((1 < g.length || 1 == g.length && "" != g[0]) && g.pop(), e && k == f.length && g.push("")) : (g.push(q), e = !0);
          }
          e = g.join("/");
        } else {
          e = f;
        }
      }
    }
  }
  c ? b.ni(e) : c = a.J0();
  c ? b.Gm(a.Lg.clone()) : c = a.F0();
  c && b.su(a.Xi);
  return b;
};
d.clone = function() {
  return new Qj(this);
};
d.Au = function(a, b) {
  this.Ui();
  if (this.Rg = b ? Xj(a, !0) : a) {
    this.Rg = this.Rg.replace(/:$/, "");
  }
  return this;
};
d.K0 = function() {
  return !!this.Rg;
};
d.Io = function() {
  return this.Vf;
};
d.PB = function(a, b) {
  this.Ui();
  this.Vf = b ? Xj(a) : a;
  return this;
};
d.L0 = function() {
  return !!this.Vf;
};
d.Ch = function() {
  return this.vh;
};
d.Am = function(a, b) {
  this.Ui();
  this.vh = b ? Xj(a, !0) : a;
  return this;
};
d.Js = function() {
  return !!this.vh;
};
d.Wa = function() {
  return this.Ja;
};
d.Fm = function(a) {
  this.Ui();
  if (a) {
    a = Number(a);
    if (isNaN(a) || 0 > a) {
      throw Error("Bad port number " + a);
    }
    this.Ja = a;
  } else {
    this.Ja = null;
  }
  return this;
};
d.CI = function() {
  return null != this.Ja;
};
d.vd = function() {
  return this.Jg;
};
d.ni = function(a, b) {
  this.Ui();
  this.Jg = b ? Xj(a, !0) : a;
  return this;
};
d.BI = function() {
  return !!this.Jg;
};
d.J0 = function() {
  return "" !== this.Lg.toString();
};
d.Gm = function(a, b) {
  this.Ui();
  a instanceof Rj ? (this.Lg = a, this.Lg.wB(this.Zd)) : (b || (a = Sj(a, Yj)), this.Lg = new Rj(a, null, this.Zd));
  return this;
};
d.fX = function() {
  return this.Lg.toString();
};
d.su = function(a, b) {
  this.Ui();
  this.Xi = b ? Xj(a) : a;
  return this;
};
d.F0 = function() {
  return !!this.Xi;
};
d.Ui = function() {
  if (this.u1) {
    throw Error("Tried to modify a read-only Uri");
  }
};
d.wB = function(a) {
  this.Zd = a;
  this.Lg && this.Lg.wB(a);
  return this;
};
var Xj = function(a, b) {
  return a ? b ? decodeURI(a.replace(/%25/g, "%2525")) : decodeURIComponent(a) : "";
}, Sj = function(a, b, c) {
  return p(a) ? (a = encodeURI(a).replace(b, Zj), c && (a = a.replace(/%25([0-9a-fA-F]{2})/g, "%$1")), a) : null;
}, Zj = function(a) {
  a = a.charCodeAt(0);
  return "%" + (a >> 4 & 15).toString(16) + (a & 15).toString(16);
}, Tj = /[#\/\?@]/g, Vj = /[\#\?:]/g, Uj = /[\#\?]/g, Yj = /[\#\?@]/g, Wj = /#/g, Rj = function(a, b, c) {
  this.Va = this.xb = null;
  this.xh = a || null;
  this.Zd = !!c;
};
Rj.prototype.og = function() {
  if (!this.xb && (this.xb = new I, this.Va = 0, this.xh)) {
    var a = this;
    Mc(this.xh, function(b, c) {
      a.add(decodeURIComponent(b.replace(/\+/g, " ")), c);
    });
  }
};
var ak = function(a, b, c) {
  b = ve(a);
  if ("undefined" == typeof b) {
    throw Error("Keys are undefined");
  }
  c = new Rj(null, null, c);
  a = ue(a);
  for (var e = 0;e < b.length;e++) {
    var f = b[e], g = a[e];
    sa(g) ? c.ZN(f, g) : c.add(f, g);
  }
  return c;
};
d = Rj.prototype;
d.V = function() {
  this.og();
  return this.Va;
};
d.add = function(a, b) {
  this.og();
  this.Nl();
  a = this.yl(a);
  var c = this.xb.get(a);
  c || this.xb.set(a, c = []);
  c.push(b);
  this.Va = Ya(this.Va) + 1;
  return this;
};
d.remove = function(a) {
  this.og();
  a = this.yl(a);
  return this.xb.Ma(a) ? (this.Nl(), this.Va = Ya(this.Va) - this.xb.get(a).length, this.xb.remove(a)) : !1;
};
d.clear = function() {
  this.Nl();
  this.xb = null;
  this.Va = 0;
};
d.Bb = function() {
  this.og();
  return 0 == this.Va;
};
d.Ma = function(a) {
  this.og();
  a = this.yl(a);
  return this.xb.Ma(a);
};
d.$k = function(a) {
  var b = this.H();
  return pb(b, a);
};
d.ub = function() {
  this.og();
  for (var a = this.xb.H(), b = this.xb.ub(), c = [], e = 0;e < b.length;e++) {
    for (var f = a[e], g = 0;g < f.length;g++) {
      c.push(b[e]);
    }
  }
  return c;
};
d.H = function(a) {
  this.og();
  var b = [];
  if (p(a)) {
    this.Ma(a) && (b = xb(b, this.xb.get(this.yl(a))));
  } else {
    a = this.xb.H();
    for (var c = 0;c < a.length;c++) {
      b = xb(b, a[c]);
    }
  }
  return b;
};
d.set = function(a, b) {
  this.og();
  this.Nl();
  a = this.yl(a);
  this.Ma(a) && (this.Va = Ya(this.Va) - this.xb.get(a).length);
  this.xb.set(a, [b]);
  this.Va = Ya(this.Va) + 1;
  return this;
};
d.get = function(a, b) {
  a = a ? this.H(a) : [];
  return 0 < a.length ? String(a[0]) : b;
};
d.ZN = function(a, b) {
  this.remove(a);
  0 < b.length && (this.Nl(), this.xb.set(this.yl(a), B(b)), this.Va = Ya(this.Va) + b.length);
};
d.toString = function() {
  if (this.xh) {
    return this.xh;
  }
  if (!this.xb) {
    return "";
  }
  for (var a = [], b = this.xb.ub(), c = 0;c < b.length;c++) {
    for (var e = b[c], f = encodeURIComponent(String(e)), e = this.H(e), g = 0;g < e.length;g++) {
      var k = f;
      "" !== e[g] && (k += "=" + encodeURIComponent(String(e[g])));
      a.push(k);
    }
  }
  return this.xh = a.join("&");
};
d.Nl = function() {
  this.xh = null;
};
d.clone = function() {
  var a = new Rj;
  a.xh = this.xh;
  this.xb && (a.xb = this.xb.clone(), a.Va = this.Va);
  return a;
};
d.yl = function(a) {
  a = String(a);
  this.Zd && (a = a.toLowerCase());
  return a;
};
d.wB = function(a) {
  a && !this.Zd && (this.og(), this.Nl(), this.xb.forEach(function(a, c) {
    var b = c.toLowerCase();
    c != b && (this.remove(c), this.ZN(b, a));
  }, this));
  this.Zd = a;
};
d.extend = function(a) {
  for (var b = 0;b < arguments.length;b++) {
    xe(arguments[b], function(a, b) {
      this.add(b, a);
    }, this);
  }
};
var bk = function(a) {
  return (a = a.exec(Vb)) ? a[1] : "";
}, ck = function() {
  if (Zh) {
    return bk(/Firefox\/([0-9.]+)/);
  }
  if (dc || ec || cc) {
    return wc;
  }
  if (ci) {
    return bk(/Chrome\/([0-9.]+)/);
  }
  if (di && !(Zb() || C("iPad") || C("iPod"))) {
    return bk(/Version\/([0-9.]+)/);
  }
  if ($h || ai) {
    var a = /Version\/(\S+).*Mobile\/(\S+)/.exec(Vb);
    if (a) {
      return a[1] + "." + a[2];
    }
  } else {
    if (bi) {
      return (a = bk(/Android\s+([0-9.]+)/)) ? a : bk(/Version\/([0-9.]+)/);
    }
  }
  return "";
}();
var dk = function(a, b) {
  this.tb = a;
  this.xd = b;
  this.a = D("mr.cloud.calendar.CalendarService");
};
d = dk.prototype;
d.uV = function() {
  var a = this, b = x(this.xd.an, "No user email to use as calendar id to query for events.");
  return this.EW(b, 9E5).then(function(b) {
    a.a.info(a.XF(b.length) + " events discovered before filtering.");
    return a.GX(b);
  }, function(b) {
    a.a.l("Error getting Hangouts from calendar.", b);
    return [];
  });
};
d.XF = function(a) {
  return 20 < a ? "20+" : a.toString();
};
d.EW = function(a, b) {
  var c = this, e = Date.now();
  return this.fW(a, new Date(e), new Date(e + b)).then(function(a) {
    return a.filter(c.s1);
  });
};
d.s1 = function(a) {
  return !(!a.start || !a.end || a.start.date || a.end.date || !a.start.dateTime || !a.end.dateTime);
};
d.fW = function(a, b, c) {
  a = this.tb.Wi(li.fh, ["calendars", a, "events"], {timeMin:b.toJSON(), timeMax:c.toJSON(), singleEvents:!0});
  this.a.w("Retrieving Hangouts from Calendar: " + a);
  return this.tb.jh(a, "GET").then(function(a) {
    return a.items ? a.items : [];
  });
};
d.GX = function(a) {
  var b = this;
  a = a.reduce(function(a, e) {
    if (e.hangoutLink) {
      var c = new Qj(e.hangoutLink), g = b.j5(c.vd());
      if (2 == g.length) {
        var c = g[0], g = g[1], k, q;
        -1 != c.indexOf(".") && (k = g, q = c);
        a.push(new Wi(g, c, k, q, e.summary));
      } else {
        b.a.l("Invalid hangout link from calendar event: " + e.hangoutLink);
      }
    }
    return a;
  }, []);
  this.a.info(this.XF(a.length) + " events discovered with Hangout links.");
  return a;
};
d.j5 = function(a) {
  return a.substring(12).split("/");
};
var ek = function(a) {
  this.tb = a;
  this.a = D("mr.cloud.mesi.MesiService");
};
ek.prototype.rV = function() {
  var a = mi.fh, a = a.replace("v1", "v1_today"), a = this.tb.Wi(a, ["hangouts", "search"]);
  this.a.info("Retrieving Hangouts from MESI: " + a);
  return this.tb.jh(a, "POST", fk).then(function(a) {
    var b = [];
    a.result && (b = a.result.map(function(a) {
      var b = a.hangout, c, e;
      b.external_key ? (c = b.external_key.value.replace(/@.*/, ""), e = Za(b.external_key.service)) : b.sharing_url && (e = b.sharing_url.split("/"), x(5 == e.length), x("hangouts.google.com" == e[2]), c = e[4], e = e[3]);
      c = x(c);
      e = x(e);
      var q = b.meeting_room_name, r;
      b.meeting_domain ? (r = b.meeting_domain, q && (c = q, e = r)) : "BUSINESS" == b.type && b.company_title && (r = b.company_title.toLowerCase());
      var A = zj("", 0);
      if ((a = a.participant) && 0 < a.length) {
        var E = a[0].display_name;
        a = a.reduce(function(a, b) {
          a.add(b.user_id);
          "ORGANIZER" == b.role && (E = b.display_name);
          return a;
        }, new Set);
        A = zj(x(E), a.size);
      }
      return new Wi(c, e, q, r, A, b.hangout_id);
    }));
    return b;
  });
};
var fk = {request_header:{client_version:{client_id:"39"}}, search_sources:["0"]};
var hk = function() {
  this.yA = Ra();
  this.Wj = new gk(null, null);
  this.Vj = new gk(null, null);
  this.sx = [];
  this.Zs = this.Qk = 0;
  Rh(this);
};
d = hk.prototype;
d.pl = function(a) {
  a = a.toLowerCase();
  var b = new Li;
  b.update(a);
  b.update(this.yA);
  return "r" + Fj(b.digest(), !0);
};
d.gZ = function() {
  return this.Wj.model ? this.Wj : this.Vj.model ? this.Vj : new gk(null, null);
};
d.oa = function() {
  return "SinkUtils";
};
d.getData = function() {
  return [{recentLaunchedDevice:this.Wj, recentDiscoveredDevice:this.Vj}, {receiverIdToken:this.yA, fixedIpList:this.sx.join(","), castControlPort:this.Qk, lastCloudSinkCheckTimeMillis:this.Zs}];
};
d.Xa = function() {
  var a = Oh(this);
  a && (this.Wj = a.recentLaunchedDevice || new gk(null, null), this.Vj = a.recentDiscoveredDevice || new gk(null, null));
  if (a = Ph(this)) {
    this.yA = a.receiverIdToken || Ra(), this.sx = a.fixedIpList && a.fixedIpList.split(",") || [], this.Qk = a.castControlPort || 0, this.Zs = a.lastCloudSinkCheckTimeMillis || 0;
  }
};
pa(hk);
var gk = function(a, b) {
  this.model = a;
  this.ip = b;
};
var ik = function(a, b, c, e, f, g, k, q) {
  this.Yi = null;
  this.BE = !1;
  this.AE = H();
  this.Ac = [];
  this.Od = a ? encodeURIComponent(String(a)) : null;
  this.bs = null;
  !e && b && (this.bs = b);
  this.MR = c || null;
  this.Yq = !e;
  this.Mr = null != f ? f : null;
  this.hm = g || null;
  this.yC = !!k;
  this.TF = q || null;
  e ? (x(this.Od, "Unauthed requests must have an API key"), x(!this.hm, "Unauthed requests should not have an OAuth token"), x(!this.yC, "Unauthed requests should not use v2 Auth headers")) : this.hm ? (x(!this.Od, "OAuth'd requests should not have an API key"), x(!this.bs, "OAuth'd requests should not have an Gaia session index"), x(!this.yC, "OAuth'd requests should not use v2 Auth headers")) : (x(this.Od, "first party auth requests must have an API key"), x(this.bs, "first party auth requests must have a session ID"));
};
w(ik, Rc);
var jk;
var kk = Ne("https://apis.google.com/js/client.js");
kk instanceof Me && kk.constructor === Me && kk.OQ === Le ? jk = kk.bC : (Xa("expected object of type Const, got '" + kk + "'"), jk = "type_error:Const");
var lk = new Ye;
lk.rA = jk;
d = ik.prototype;
d.init = function() {
  var a = u(function(a) {
    this.Yi = a;
    var b = oa("client.request", a), c = oa("auth", a);
    b && c ? this.lI() : a.load("client", u(this.lI, this));
  }, this), b = this.KF("gapi");
  b ? a(b.gapi) : this.Y1(a);
  return this.AE.promise;
};
d.KF = function(a) {
  for (var b = window, c = oa(a, b);!c && b != window.top && this.IS(b.parent, a);) {
    b = b.parent, c = oa(a, b);
  }
  return c ? b : null;
};
d.IS = function(a, b) {
  try {
    return !!a && null != a.location.href && ac(a, b);
  } catch (c) {
    return !1;
  }
};
d.Y1 = function(a) {
  var b = this.KF("gapi_onload");
  if (b) {
    var c = b.gapi_onload;
    b.gapi_onload = function() {
      c();
      a(b.gapi);
    };
  } else {
    window.gapi_onload = function() {
      a(window.gapi);
    };
    var e = document.createElement("script");
    kj(e, lk);
    this.TF && Oj(e, ef(this.TF));
    document.getElementsByTagName("head")[0].appendChild(e);
  }
};
d.vl = function() {
  return x(this.Yi, "Missing gapi instance!");
};
d.lI = function() {
  for (var a = 0;a < this.Ac.length;a++) {
    this.Ac[a].pb.resolve(this.uM(this.Ac[a].u7));
  }
  this.BE = !0;
  this.AE.resolve(this.vl());
};
d.sendRequest = function(a) {
  if (this.BE) {
    return this.uM(a);
  }
  var b = H();
  this.Ac.push({u7:a, pb:b});
  return b.promise;
};
d.uM = function(a) {
  var b, c, e, f = oa("config.get", this.vl());
  this.Yq || (b = f("googleapis.config/auth/useFirstPartyAuth"), c = f("googleapis.config/auth/useOriginToken"));
  null != this.Mr && (e = f("client/cors"));
  try {
    var g = oa("config.update", this.vl());
    this.Yq || (g("googleapis.config/auth/useFirstPartyAuth", !1), g("googleapis.config/auth/useOriginToken", !1));
    null != this.Mr && g("client/cors", this.Mr);
    var k = oa("client.request", this.vl()), q = this.VV();
    a.headers && Ub(q, a.headers);
    var r = {headers:q, root:this.MR, path:a.path, method:a.method, body:a.body}, A = a.params || {};
    this.Od && !this.hm ? Ub(A, {key:this.Od}) : this.hm && Ub(A, {key:null});
    Nb(A) || (r.params = A);
    var E = Xd(k(r));
    a.callback && E.then(function(b) {
      a.callback.apply(null, [b.result, b]);
    }, function(b) {
      a.callback.apply(null, [b.result, b]);
    });
    return E;
  } finally {
    g = oa("config.update", this.vl()), this.Yq || (g("googleapis.config/auth/useFirstPartyAuth", b), g("googleapis.config/auth/useOriginToken", c)), null != this.Mr && g("client/cors", e);
  }
};
d.VV = function() {
  if (this.Yq) {
    if (this.hm) {
      return {Authorization:"Bearer " + this.hm};
    }
    var a = oa("auth.getAuthHeaderValueForFirstParty", this.vl());
    return {Authorization:this.yC ? a([]) : a(), "X-Goog-AuthUser":this.bs};
  }
  return {};
};
var mk = function(a, b, c, e, f, g, k) {
  var q = hk.W().pl(a);
  this.bb = new hi(q, b, g, k, f);
  this.deviceId = a;
  this.Nba = c;
  this.model = e;
};
mk.prototype.tO = function(a) {
  return pb(this.Nba, a);
};
var nk = function(a, b, c, e, f) {
  mk.call(this, a, b, ["cloud"], "Chrome Streaming Receiver", e);
  this.Kv = c;
  this.isAvailable = f;
};
la(nk, mk);
var ok = function(a) {
  var b = a.getService();
  a.Ch() && (b = a.Ch());
  var c;
  a.Vh && a.Bh() != a.Vh && (c = x(a.Vh));
  mk.call(this, a.getId(), a.Bh(), ["mesi"], "Hangout", x(b), "hangout", c);
  this.UA = a.ak || "";
};
la(ok, mk);
var pk = function(a) {
  this.xd = a;
};
d = pk.prototype;
d.Wi = function(a, b, c) {
  var e = "";
  b.forEach(function(a) {
    e += "/" + encodeURIComponent(a);
  });
  a = new Qj(a + e);
  c && (c = ak(c), a.Gm(c));
  return a;
};
d.jh = function(a, b, c) {
  var e = this;
  return this.xd.getAuthToken().then(function(f) {
    var g = e.WV(f);
    return e.ES(g, a, b, c).catch(function(g) {
      if ("INVALID_ACCESS_ERROR" == g) {
        return e.eV(f, a, b, c);
      }
      throw g;
    });
  });
};
d.eV = function(a, b, c, e) {
  var f = this;
  return this.xd.dV(a).then(function() {
    return f.jh(b, c, e);
  });
};
d.ES = function(a, b, c, e) {
  var f = this;
  return new Promise(function(g, k) {
    a.sendRequest(f.AV(b, c, function(a) {
      a && !a.error ? g(a) : f.n1(a) ? k("INVALID_ACCESS_ERROR") : k(f.f5(a));
    }, e));
  });
};
d.n1 = function(a) {
  return !!a && 401 == a.error.code;
};
d.WV = function(a) {
  a = new ik(void 0, void 0, void 0, !1, !1, a);
  a.init();
  return a;
};
d.f5 = function(a) {
  return a && a.error ? a.error.errors ? a.error.errors[0] : a : Error(a);
};
d.AV = function(a, b, c, e) {
  a = {callback:c, method:b, path:a.toString()};
  e && (a.body = e);
  return a;
};
var qk = function(a, b, c, e) {
  this.sg = a;
  this.xd = b;
  this.xq = c;
  this.Qb = e;
};
d = qk.prototype;
d.c0 = function(a, b, c) {
  var e = this;
  return this.m8(a, b, c).then(function(a) {
    return e.L_(a, b.id);
  });
};
d.T_ = function(a) {
  var b = this;
  return this.xq.DW().then(function(c) {
    b.Qb.Dd(new Gh("TURN_CREDENTIALS", {credentials:c}), a.id);
  });
};
d.m8 = function(a, b, c) {
  b = c.deviceId;
  var e = this.xd.an, e = e ? new oi(e) : void 0;
  a = a.data;
  switch(c.Kv) {
    case "owner":
      Ui(0);
      break;
    case "manager":
      Ui(1);
      break;
    case "user":
      Ui(2);
      break;
    case "viewer":
      Ui(3);
  }
  return "viewer" == c.Kv ? this.sg.r8(b, a, e) : this.sg.u8(b, a, e);
};
d.L_ = function(a, b) {
  if ("done" != a.state) {
    return Promise.reject(Error("Offer not executed by receiver. State: " + a.state));
  }
  switch(a.type) {
    case "__cloud_webrtc_session_message__":
      a = new Gh("ANSWER", a.results.sessionDescription);
      this.Qb.Dd(a, b);
      break;
    case "knocking_cloud_webrtc_session_message":
      Ri(0);
      a = new Gh("KNOCK_ANSWER", a.results.sessionDescription);
      this.Qb.Dd(a, b);
      break;
    case "knock_denied":
      Ri(1);
      this.mI(sj, b);
      break;
    case "knock_timeout":
      Ri(2);
      this.mI(tj, b);
      break;
    default:
      return Promise.reject(Error("Invalid message type: " + a.type));
  }
  return Promise.resolve();
};
d.mI = function(a, b) {
  a = new Gg(a, "warning", "dismiss");
  a.T9(!0);
  this.Qb.ug().send(a);
  this.Qb.Dd(new Gh("STOP"), b);
};
var rk = function(a, b) {
  this.xd = a;
  this.Qb = b;
};
rk.prototype.Z_ = function(a, b, c) {
  var e = this, f, g;
  switch(a.type) {
    case "REFRESH_AUTH":
      return f = c.deviceId, g = c.UA, this.xd.O6().then(function() {
        e.Qb.Dd(new Gh("AUTH_READY", {hangoutId:f, resolvedId:g}), b.id);
      });
    case "LOCAL_PRESENT":
      return f = c.deviceId, g = c.UA, this.Qb.Dd(new Gh("AUTH_READY", {hangoutId:f, resolvedId:g, conferenceMode:!a.data.local}), b.id), Promise.resolve();
    case "STATUS_REQUEST":
      return this.Qb.Dd(a, b.id), Promise.resolve();
    case "STATUS_RESPONSE":
      return this.Qb.Dd(a, b.id, !0), a.data.routeDescription || this.Qb.Dd(a, b.id), Promise.resolve();
    case "HANGOUT_INACTIVE":
      return this.Qb.wk(b, 4, new Gg(vj, "warning", "dismiss"));
    case "HANGOUT_INVALID":
      return this.Qb.wk(b, 3, new Gg(wj, "warning", "dismiss"));
    default:
      return Promise.reject(Error("Unknown type: " + a.type));
  }
};
var sk = function(a, b, c) {
  this.Vk = a;
  this.Mo = b;
  this.Qb = c;
};
sk.prototype.f6 = function(a, b, c, e) {
  var f = this;
  return new Promise(function(g) {
    switch(a) {
      case "cloud":
      case "mesi":
        break;
      default:
        throw Error("Unrecognized channel type");
    }
    if (!b.type) {
      throw Error("Message has no type");
    }
    switch(b.type) {
      case "STOP":
        g(f.Qb.wk(x(c), 1, null));
        return;
      case "SESSION_START_SUCCESS":
        Si(0);
        break;
      case "SESSION_END":
        break;
      case "SESSION_FAILURE":
        Si(1);
        g(f.Qb.wk(x(c), 2, new Gg(rj, "warning", "dismiss")));
        return;
      case "__webrtc_stats__":
        break;
      case "PRESENTATION_CONNECTION_MESSAGE":
        f.Qb.Dd(b.data, c.id, !0);
        break;
      case "OFFER":
        x("cloud" == a);
        g(f.Vk.c0(b, x(c), x(e)));
        return;
      case "GET_TURN_CREDENTIALS":
        x("cloud" == a);
        g(f.Vk.T_(x(c)));
        return;
      case "REFRESH_AUTH":
      case "LOCAL_PRESENT":
      case "MUTE":
      case "STATUS_REQUEST":
      case "STATUS_RESPONSE":
      case "HANGOUT_INACTIVE":
      case "HANGOUT_INVALID":
        x("mesi" == a);
        g(f.Mo.Z_(b, x(c), x(e)));
        return;
      case "new_session":
        f.Qb.Dd(b, x(c).id, !0);
        break;
      case "remove_session":
        f.Qb.Dd(b, x(c).id, !0);
        f.Qb.terminateRoute(x(c).id);
        break;
      default:
        throw Error("Unknown type: " + b.type);
    }
    g();
  });
};
var tk = function(a) {
  Rc.call(this);
  this.B = a;
  this.Da = {};
};
w(tk, Rc);
var uk = [];
d = tk.prototype;
d.listen = function(a, b, c, e) {
  return this.EJ(a, b, c, e);
};
d.T1 = function(a, b, c, e, f) {
  return this.EJ(a, b, c, e, f);
};
d.EJ = function(a, b, c, e, f) {
  sa(b) || (b && (uk[0] = b.toString()), b = uk);
  for (var g = 0;g < b.length;g++) {
    var k = jd(a, b[g], c || this.handleEvent, e || !1, f || this.B || this);
    if (!k) {
      break;
    }
    this.Da[k.key] = k;
  }
  return this;
};
d.hp = function(a, b, c, e) {
  return this.CJ(a, b, c, e);
};
d.CJ = function(a, b, c, e, f) {
  if (sa(b)) {
    for (var g = 0;g < b.length;g++) {
      this.CJ(a, b[g], c, e, f);
    }
  } else {
    a = rd(a, b, c || this.handleEvent, e, f || this.B || this);
    if (!a) {
      return this;
    }
    this.Da[a.key] = a;
  }
  return this;
};
d.Fc = function(a, b, c, e, f) {
  if (sa(b)) {
    for (var g = 0;g < b.length;g++) {
      this.Fc(a, b[g], c, e, f);
    }
  } else {
    c = c || this.handleEvent, f = f || this.B || this, c = kd(c), e = !!e, b = bd(a) ? a.ro(b, c, e, f) : a ? (a = nd(a)) ? a.ro(b, c, e, f) : null : null, b && (td(b), delete this.Da[b.key]);
  }
  return this;
};
d.removeAll = function() {
  Hb(this.Da, function(a, b) {
    this.Da.hasOwnProperty(b) && td(a);
  }, this);
  this.Da = {};
};
d.U = function() {
  tk.T.U.call(this);
  this.removeAll();
};
d.handleEvent = function() {
  throw Error("EventHandler.handleEvent not implemented");
};
var vk = function(a, b, c) {
  this.Gca = a;
  this.ed = b;
  this.Pc = new Map;
  this.Eu = new Map;
  this.Tl = null;
  this.H2 = c;
};
d = vk.prototype;
d.Xd = function() {
  this.LS() && (this.Tl = Date.now(), this.$n());
  return Array.from(this.Pc.values());
};
d.sn = function(a) {
  this.Pc.set(a.bb.id, a);
};
d.Zj = function(a) {
  return this.Pc.delete(a);
};
d.Y = function(a) {
  return this.Pc.get(a) || null;
};
d.LS = function() {
  var a = this.Tl + this.H2;
  return null == this.Tl || a < Date.now();
};
d.$n = function() {
  var a = this;
  return this.Gca().then(function(b) {
    a.Fca(b);
  });
};
d.Fca = function(a) {
  var b = new Map(this.Pc), c = new Map, e = new Map, f = [], g = [];
  a.forEach(function(a) {
    var k = a.bb.id;
    c.set(k, a);
    e.set(k, a.deviceId);
    b.has(k) ? b.has(k) && JSON.stringify(b.get(k)) != JSON.stringify(a) && g.push(a.bb) : f.push(a.bb);
    b.delete(k);
  });
  a = [].concat(ma(b.values())).map(function(a) {
    return a.bb;
  });
  this.Eu.clear();
  this.Eu = e;
  this.Pc.clear();
  this.Pc = c;
  this.HS(f, g, a);
};
d.HS = function(a, b, c) {
  0 < a.length && this.ed.Sz(a);
  0 < b.length && this.ed.ee(b);
  0 < c.length && this.ed.Le(c);
};
d.b = function() {
  for (var a = {}, b = ka(this.Pc.entries()), c = b.next();!c.done;c = b.next()) {
    var e = ka(c.value), c = e.next().value, e = e.next().value;
    a[c] = e;
  }
  b = {};
  c = ka(this.Eu.entries());
  for (e = c.next();!e.done;e = c.next()) {
    var f = ka(e.value), e = f.next().value, f = f.next().value;
    b[e] = f;
  }
  return new wk(a, b, this.Tl);
};
d.GJ = function(a) {
  for (var b in a.sinks) {
    var c = a.sinks[b], e = null;
    "Hangout" == c.model ? (e = c.deviceId.split("@"), x(2 == e.length), e = new ok(new Wi(e[0], e[1], c.bb.description, c.bb.domain, c.bb.friendlyName, c.UA))) : "Chrome Streaming Receiver" == c.model && (e = new nk(c.deviceId, c.bb.friendlyName, c.Kv, c.bb.domain, c.isAvailable));
    this.Pc.set(b, e);
  }
  for (b in a.FE) {
    this.Eu.set(b, a.FE[b]);
  }
  a.lJ && (this.Tl = a.lJ);
};
d.xB = function(a) {
  this.Tl = a;
};
var wk = function(a, b, c) {
  this.sinks = a;
  this.FE = b;
  this.lJ = c;
};
var xk = function(a) {
  this.ax = a;
  this.a = D("mr.cloud.messaging.GcmMessageHandler");
};
xk.prototype.onMessage = function(a) {
  var b = this;
  a = JSON.parse(a.data.notification);
  var c = hk.W();
  a.events.forEach(function(a) {
    if (a.deviceId) {
      var e = c.pl(a.deviceId);
      switch(a.type) {
        case "deviceCreated":
          b.v3(a, e);
          break;
        case "deviceUpdated":
          b.A3(a, e);
          break;
        case "deviceDeleted":
          b.x3(e);
          break;
        default:
          b.a.w(function() {
            return "[unhandled event] " + JSON.stringify(a);
          });
      }
    } else {
      b.a.error("Device ID not provided");
    }
  });
};
xk.prototype.v3 = function(a, b) {
  var c = wi(a, "statePatch", "_cloudCast", "settings", "receiverName");
  "string" != typeof c ? this.a.error("Receiver name not a string: " + c) : (a = new nk(a.deviceId, c, "owner", "default", !0), this.ax.u3({sinkId:b, cloudSink:a}));
};
xk.prototype.A3 = function(a, b) {
  a = wi(a, "statePatch", "_cloudCast", "appStatus");
  "string" != typeof a ? this.a.error("App status not a string: " + a) : this.ax.z3({sinkId:b, isAvailable:"available" == a});
};
xk.prototype.x3 = function(a) {
  this.ax.w3({sinkId:a});
};
var yk = function(a, b) {
  this.Iw = a;
  this.ed = b;
  this.se = new vk(this.$n.bind(this), b, 2E4);
  this.UF = new xk(this);
  gj().addListener();
  Rh(this);
  zh("mr.cloud.discovery.CloudSinkDiscoveryService", this);
};
la(yk, ph);
d = yk.prototype;
d.Xd = function() {
  var a = this;
  this.Iw.U6().then(function(b) {
    a.Iw.subscribe(b);
  }, function() {
  });
  return this.se.Xd().filter(function(a) {
    return a.isAvailable;
  });
};
d.Y = function(a) {
  return this.se.Y(a);
};
d.handleEvent = function(a, b) {
  for (var c = [], e = 1;e < arguments.length;++e) {
    c[e - 1] = arguments[e];
  }
  if (a == chrome.gcm.onMessage) {
    this.UF.onMessage.apply(this.UF, [].concat(ma(c)));
  } else {
    throw Error("Unhandled event: expected chrome.gcm.onMessage");
  }
};
d.$n = function() {
  return this.Iw.Q1().then(function(a) {
    return a.map(function(a) {
      $g("MediaRouter.Cloud.CloudReceiver.Sink.Discovered");
      var b = a.isAvailable() && !a.t1();
      return new nk(a.getId(), a.Bh(), a.Ib.personalizedInfo.maxRole, "default", b);
    });
  });
};
d.oa = function() {
  return "CloudSinkDiscoveryService";
};
d.getData = function() {
  return [{cache:this.se.b()}];
};
d.Xa = function() {
  var a = Oh(this);
  a && this.se.GJ(a.cache);
};
d.u3 = function(a) {
  a = a.Zja;
  this.se.sn(a);
  this.se.xB(Date.now());
  this.ed.Sz([a.bb]);
};
d.z3 = function(a) {
  var b = this.se.Y(a.sinkId);
  b && (b.isAvailable = a.isAvailable, this.se.xB(Date.now()), this.ed.ee([b.bb]));
};
d.w3 = function(a) {
  if (a = this.se.Y(a.sinkId)) {
    this.se.Zj(a.bb.id), this.se.xB(Date.now()), this.ed.Le([a.bb]);
  }
};
var Bk = function(a, b, c) {
  if (!zk) {
    xf();
    var e = wf;
    e.vu(uf);
    e.sR(Ak);
    zk = !0;
  }
  this.DS = a;
  this.B2 = b;
  this.Il = new vk(this.$n.bind(this), c, 2E4);
  this.lp = new Map;
  Rh(this);
}, Ak = function(a) {
  Fc({m:a.h2, level:Ic(a.xj.value), time:a.Yba, message:a.getMessage(), pg:a.nx});
};
Bk.prototype.sD = function(a, b) {
  a = new Wi(a, b, a, b);
  this.lp.set(a.getId(), a);
  return a;
};
Bk.prototype.addManualHangout = Bk.prototype.sD;
Bk.prototype.i7 = function(a, b) {
  a = this.pz(new Wi(a, b, a, b));
  x(this.IL(a));
};
Bk.prototype.removeManualHangout = Bk.prototype.i7;
d = Bk.prototype;
d.Xd = function() {
  return this.Il.Xd();
};
d.Y = function(a) {
  return this.Il.Y(a);
};
d.$n = function() {
  var a = this;
  this.a.info("Fetching hangouts");
  return xi([this.B2.rV(), this.DS.uV()]).then(function(b) {
    var c = Array.from(a.lp.values());
    b.forEach(function(b) {
      b.as ? c = c.concat(b.value) : a.a.error("Error discovering Hangouts", b.reason);
    });
    var e = c.reduce(function(a, b) {
      var c = a[b.getId()];
      c ? c.merge(b) : c = b;
      a[c.getId()] = c;
      return a;
    }, {});
    return Object.keys(e).map(function(b) {
      b = e[b];
      $g("MediaRouter.Cloud.Hangout.Sink.Discovered");
      return a.pz(b);
    });
  });
};
d.pz = function(a) {
  return new ok(a);
};
d.vR = function(a) {
  a = this.sD(a.input, a.domain);
  a = this.pz(a);
  this.Il.sn(a);
  return a.bb;
};
d.IL = function(a) {
  return this.lp.delete(a.deviceId) ? (this.Il.Zj(a.bb.id), !0) : !1;
};
d.oa = function() {
  return "HangoutSinkDiscoveryService";
};
d.getData = function() {
  for (var a = {}, b = ka(this.lp.entries()), c = b.next();!c.done;c = b.next()) {
    var e = ka(c.value), c = e.next().value, e = e.next().value;
    a[c] = e;
  }
  return [{cache:this.Il.b(), manualHangouts:a}];
};
d.Xa = function() {
  var a = Oh(this);
  if (a) {
    this.Il.GJ(a.cache);
    for (var b in a.manualHangouts) {
      var c = a.manualHangouts[b];
      this.lp.set(b, new Wi(c.iJ, c.Fd, c.Vh, c.vh, c.Ve, c.ak));
    }
  }
};
d.a = D("mr.cloud.discovery.HangoutSinkDiscoveryService");
var zk = !1;
var Ck = function(a) {
  this.a = D("mr.cloud.CredentialService");
  this.tb = a;
};
Ck.prototype.DW = function() {
  var a = this, b = new Jc, c = ni.fh + "/iceconfig?key=" + ni.kca;
  this.a.info("Requesting TURN credentials from " + c);
  var e = Jf(c, function() {
    return a.H4(e, b);
  }, "POST", void 0, {"Content-Type":"application/json"});
  return b.promise;
};
Ck.prototype.H4 = function(a, b) {
  a.$d() ? (this.a.info("Got TURN credentials: " + a.Dl()), b.resolve(this.D3(a.vZ()))) : b.resolve(this.E3(null));
};
Ck.prototype.D3 = function(a) {
  try {
    ab(a);
    var b = [];
    bb(a.iceServers).forEach(function(a) {
      bb(a.urls).forEach(function(c) {
        0 == c.indexOf("turn:") && b.push({url:Za(c), credential:Za(a.credential), username:Za(a.username)});
      });
    });
    return b;
  } catch (c) {
    return this.a.error("Error parsing TURN credentials.", c), [];
  }
};
Ck.prototype.E3 = function(a) {
  this.a.error("XHR failed fetching TURN credentials.", a);
  return [];
};
var Dk = function() {
  this.xq = this.Qe = this.$l = this.Mo = this.Vk = this.sg = this.wy = this.tw = this.wz = this.Jw = this.Hw = this.tb = this.dw = null;
};
d = Dk.prototype;
d.po = function() {
  null == this.dw && (this.dw = new bj);
  return this.dw;
};
d.oo = function() {
  null == this.tb && (this.tb = new pk(this.po()));
  return this.tb;
};
d.vW = function() {
  null == this.Hw && (this.Hw = new $i(this.oo()));
  return this.Hw;
};
d.zW = function(a) {
  null == this.Jw && (this.Jw = new yk(this.vW(), a));
  return this.Jw;
};
d.uY = function() {
  null == this.wz && (this.wz = new ek(this.oo()));
  return this.wz;
};
d.gW = function() {
  null == this.tw && (this.tw = new dk(this.oo(), this.po()));
  return this.tw;
};
d.FX = function(a) {
  null == this.wy && (this.wy = new Bk(this.gW(), this.uY(), a));
  return this.wy;
};
d.PG = function() {
  null == this.sg && (this.sg = new Yi(this.oo()));
  return this.sg;
};
d.xW = function(a) {
  null == this.Vk && (this.Vk = new qk(this.PG(), this.po(), this.i_(), a));
  return this.Vk;
};
d.yX = function(a) {
  null == this.Mo && (this.Mo = new rk(this.po(), a));
  return this.Mo;
};
d.wY = function(a) {
  null == this.$l && (this.$l = new sk(this.xW(a), this.yX(a), a));
  return this.$l;
};
d.LZ = function() {
  null == this.Qe && (this.Qe = new cj);
  return this.Qe;
};
d.i_ = function() {
  null == this.xq && (this.xq = new Ck(this.oo()));
  return this.xq;
};
pa(Dk);

