'use strict';var yo = {TAB:0, WC:1, oQ:2}, zo = function(a) {
  ah("MediaRouter.CastStreaming.Start.Success", a, yo);
};
var Ao = D("mr.mirror.cast.LogUploader"), Co = function(a, b, c) {
  Bo("raw_events.log.gz", a, b, c);
  return b ? "https://crash-staging.corp.google.com/samples?stbtiq=" + b : "";
}, Bo = function(a, b, c, e) {
  if (0 == b.size) {
    Ao.info("Trying to upload an empty file to Crash"), e && e(null);
  } else {
    var f = new FormData;
    f.append("prod", "Cast");
    f.append("ver", chrome.runtime.getManifest().version);
    f.append(a, b);
    c && f.append("comments", c);
    Jf("https://clients2.google.com/cr/staging_report", function(a) {
      a = a.target;
      var b = null;
      a.$d() ? (b = a.Dl(), Ao.info("Upload to Crash succeeded: " + b)) : Ao.info("Upload to Crash failed. HTTP status: " + a.Ra());
      e && e(b);
    }, "POST", f, void 0, 3E4);
  }
};
var Do = function() {
  this.Xo = 0;
  Rh(this);
}, Fo = function() {
  Eo || (Eo = new Do);
  return Eo;
};
Do.prototype.Y9 = function(a) {
  this.Xo = a;
};
Do.prototype.eba = function() {
  var a = {fraction:1}, b = a.autoSubmitTimeLimitMillis, c = Date.now();
  return this.Xo && b && c - this.Xo < b ? !1 : Math.random() < a.fraction;
};
var Ho = function(a, b, c, e) {
  var f = new Go;
  f.extVersion = chrome.runtime.getManifest().version;
  f.extChannel = "internal";
  f.minBitrate = c.minVideoBitrate;
  f.maxBitrate = c.maxVideoBitrate;
  f.resolution = c.maxWidth + "x" + c.maxHeight;
  f.minResolution = c.minWidth + "x" + c.minHeight;
  if (f.minResolution == f.resolution) {
    f.resolutionChangePolicy = "fixed";
  } else {
    if (c.senderSideLetterboxing) {
      var g = c.oH();
      f.minResolution += " (altered to: " + g.width + "x" + g.height + ")";
      f.resolutionChangePolicy = "fixed-aspect-ratio";
    } else {
      f.resolutionChangePolicy = "variable";
    }
  }
  f.maxFrameRate = c.maxFrameRate;
  f.minLatency = c.minLatencyMillis;
  f.maxLatency = c.maxLatencyMillis;
  f.animatedLatency = c.animatedLatencyMillis;
  f.useDscp = c.dscpEnabled;
  f.useTdls = c.useTdls;
  null != b && (f.receiverVersion = b);
  null != a && (f.receiverProductName = a);
  e.length && (f.receiverStatusData = e);
  return f;
}, Jo = function(a, b, c, e, f) {
  Io.info("getRawEvents");
  return new Promise(function(g, k) {
    var q = function(b) {
      Io.info("Got receiver version: " + b);
      b = JSON.stringify(Ho(c, b, e, f));
      chrome.cast.streaming.rtpStream.getRawEvents(a, b, g);
    };
    "Chromecast" == c ? Sf(b).then(q, k) : q(null);
  });
}, Ko = function(a, b, c, e) {
  Io.info("getStats");
  return new Promise(function(f, g) {
    var k = function(b) {
      Io.info("Got receiver version: " + b);
      var g = Ho(c, b, e, []);
      chrome.cast.streaming.rtpStream.getStats(a, function(a) {
        var b = {tags:g};
        Ub(b, a);
        f(b);
      });
    };
    "Chromecast" == c ? Sf(b).then(k, g) : k(null);
  });
};
Do.prototype.oa = function() {
  return "mirror.cast.LogUtils";
};
Do.prototype.getData = function() {
  return [void 0, {lastAutoSubmitMillis:this.Xo}];
};
Do.prototype.Xa = function() {
  var a = Ph(this);
  this.Xo = a && a.lastAutoSubmitMillis || 0;
};
var Eo = null, Io = D("mr.mirror.cast.LogUtils"), Go = function() {
  this.ext = "MR";
  this.senderProductName = "Google Chrome";
  this.senderVersion = ck;
  this.senderPlatform = jc;
  this.senderUserAgent = Vb || "";
};
var Lo = function(a) {
  return a && a.getAudioTracks() && 0 < a.getAudioTracks().length ? a.getAudioTracks()[0] : null;
}, Mo = function(a) {
  return a && a.getVideoTracks() && 0 < a.getVideoTracks().length ? a.getVideoTracks()[0] : null;
};
var No = D("mr.NetworkUtils"), Oo = function(a, b) {
  return Pg ? new Promise(function(c, e) {
    chrome.networkingPrivate.setWifiTDLSEnabledState(a, b, function(a) {
      chrome.runtime.lastError ? (No.l("Unable to set TDLS state: state = " + b + ", error = " + chrome.runtime.lastError.message), e("Unable to set TDLS state to " + b + ".")) : (No.info("TDLS state changed: state = " + b + ", status = " + a), c(a));
    });
  }) : Promise.reject("TDLS feature not enabled.");
};
var Po = {tga:"OFFER", Ida:"ANSWER", Lga:"PRESENTATION", Xea:"GET_STATUS", uha:"STATUS_RESPONSE", Wea:"GET_CAPABILITIES", bea:"CAPABILITIES_RESPONSE"};
var Qo = function(a, b) {
  this.sessionId = a;
  this.seqNum = b;
  this.type = "PRESENTATION";
};
var Ro = function() {
  this.capabilities = this.status = this.bf = this.error = this.result = this.type = this.seqNum = this.sessionId = null;
}, Uo = function(a) {
  var b;
  try {
    if ("string" !== typeof a) {
      throw SyntaxError("Cannot parse non-string as JSON");
    }
    var c;
    So(JSON.parse(a), function(a) {
      c = To(a);
    }, function() {
      throw Error("non-Object result from JSON parse");
    });
    return c;
  } catch (e) {
    b = e instanceof SyntaxError ? "JSON parse error: " + e.message : "Type coercion error: " + e.message;
  }
  "string" == typeof a ? a = "a string: " + a : a instanceof ArrayBuffer ? (a = new Uint8Array(a), a = "an ArrayBuffer whose base64 is " + btoa(String.fromCharCode.apply(null, a))) : a = "of invalid data type " + typeof a;
  throw Error(b + ". Input was " + a);
}, To = function(a) {
  var b = new Ro;
  null != a.sessionId && (b.sessionId = String(a.sessionId));
  Vo(a.seqNum, function(a) {
    b.seqNum = a;
  }, function() {
    throw Error('"seqNum" must be a number');
  });
  if ("type" in a) {
    for (var c = String(a.type).toUpperCase(), e = ka(Object.keys(Po)), f = e.next();!f.done;f = e.next()) {
      if (Po[f.value] == c) {
        b.type = c;
        break;
      }
    }
    if (!b.type) {
      throw Error('not a known message "type"');
    }
  }
  "result" in a && (b.result = String(a.result));
  So(a.error, function(a) {
    b.error = Wo(a);
  }, function() {
    throw Error('"error" must be an Object');
  });
  So(a.answer, function(a) {
    b.bf = Xo(a);
  }, function() {
    throw Error('"answer" must be an Object');
  });
  So(a.status, function(a) {
    b.status = Yo(a);
  }, function() {
    throw Error('"status" must be an Object');
  });
  "capabilities" in a || !("mediaCaps" in a || "keySystems" in a) || (a.capabilities = {}, "mediaCaps" in a && (a.capabilities.mediaCaps = a.mediaCaps), "keySystems" in a && (a.capabilities.keySystems = a.keySystems));
  So(a.capabilities, function(a) {
    b.capabilities = Zo(a);
  }, function() {
    throw Error('"capabilities" must be an Object');
  });
  return b;
}, So = function(a, b, c) {
  void 0 !== a && (a instanceof Object ? b(a) : c());
}, Vo = function(a, b, c) {
  void 0 !== a && ("number" !== typeof a ? c() : b(a));
}, $o = function(a, b, c) {
  void 0 !== a && (a instanceof Array && a.every(function(a) {
    return "number" === typeof a;
  }) ? b(a) : c());
}, ap = function(a, b, c) {
  void 0 !== a && (a instanceof Array ? b(a.map(function(a) {
    return String(a);
  })) : c());
}, bp = function() {
  this.jC = null;
  this.oM = [];
  this.lq = [];
  this.SS = this.tL = this.$P = null;
}, Xo = function(a) {
  var b = new bp;
  Vo(a.udpPort, function(a) {
    b.jC = a;
  }, function() {
    throw Error('"answer.udpPort" must be a number');
  });
  $o(a.sendIndexes, function(a) {
    b.oM = a;
  }, function() {
    throw Error('"answer.sendIndexes" must be an array of numbers');
  });
  $o(a.ssrcs, function(a) {
    b.lq = a;
  }, function() {
    throw Error('"answer.ssrcs" must be an array of numbers');
  });
  "IV" in a && (b.$P = String(a.IV));
  "receiverGetStatus" in a && (b.tL = "true" == String(a.receiverGetStatus).toLowerCase());
  "castMode" in a && (b.SS = String(a.castMode));
  return b;
}, cp = function() {
  this.details = this.description = this.code = null;
}, Wo = function(a) {
  var b = new cp;
  Vo(a.code, function(a) {
    b.code = a;
  }, function() {
    throw Error('"error.code" must be a number');
  });
  "description" in a && (b.description = String(a.description));
  So(a.details, function(a) {
    b.details = a;
  }, function() {
    throw Error('"error.details" must be an Object');
  });
  return b;
}, dp = function() {
  this.DC = this.CC = null;
}, Yo = function(a) {
  var b = new dp;
  Vo(a.wifiSnr, function(a) {
    b.CC = a;
  }, function() {
    throw Error('"status.wifiSnr" must be a number');
  });
  $o(a.wifiSpeed, function(a) {
    b.DC = a;
  }, function() {
    throw Error('"status.wifiSpeed" must be an array of numbers');
  });
  return b;
}, ep = function() {
  this.H1 = this.u2 = null;
}, Zo = function(a) {
  var b = new ep;
  ap(a.mediaCaps, function(a) {
    b.u2 = a;
  }, function() {
    throw Error('"capabilities.mediaCaps" must be an array');
  });
  if ("keySystems" in a) {
    a = a.keySystems;
    if (!(a instanceof Array)) {
      throw Error('"capabilities.keySystems" must be an array');
    }
    b.H1 = a.map(function(a) {
      var b;
      So(a, function(a) {
        b = fp(a);
      }, function() {
        throw Error('"capabilities.keySystems" entries must be *Objects');
      });
      return b;
    });
  }
  return b;
}, gp = function() {
  this.wU = this.P5 = this.O5 = this.N5 = this.Uca = this.SR = this.h8 = this.rT = this.initDataTypes = this.G1 = null;
}, fp = function(a) {
  var b = new gp;
  "keySystemName" in a && (b.G1 = String(a.keySystemName));
  ap(a.initDataTypes, function(a) {
    b.initDataTypes = a;
  }, function() {
    throw Error('"capabilities.initDataTypes" must be an array');
  });
  ap(a.codecs, function(a) {
    b.rT = a;
  }, function() {
    throw Error('"capabilities.codecs" must be an array');
  });
  ap(a.secureCodecs, function(a) {
    b.h8 = a;
  }, function() {
    throw Error('"capabilities.secureCodecs" must be an array');
  });
  ap(a.audioRobustness, function(a) {
    b.SR = a;
  }, function() {
    throw Error('"capabilities.audioRobustness" must be an array');
  });
  ap(a.videoRobustness, function(a) {
    b.Uca = a;
  }, function() {
    throw Error('"capabilities.videoRobustness" must be an array');
  });
  "persistentLicenseSessionSupport" in a && (b.N5 = String(a.persistentLicenseSessionSupport));
  "persistentReleaseMessageSessionSupport" in a && (b.O5 = String(a.persistentReleaseMessageSessionSupport));
  "persistentStateSupport" in a && (b.P5 = String(a.persistentStateSupport));
  "distinctiveIdentifierSupport" in a && (b.wU = String(a.distinctiveIdentifierSupport));
  return b;
};
var hp = function(a, b) {
  this.address = a;
  this.port = b;
}, ip = function(a, b, c) {
  Dh.call(this, b);
  this.a = D("mr.mirror.cast.Session");
  this.Fa = a;
  this.Lc = Fg.qs(b.id);
  this.C = b.Je.sessionId;
  this.he = new hp(b.Je.eO, 2344);
  this.Vt = b.Je.fO;
  this.Tc = null;
  this.Gi = !1;
  this.gc = null;
  this.Bk = !1;
  this.vi = 0;
  this.wa = this.vn = this.wn = null;
  this.Y5 = ["H264", "VP8"];
  this.Ey = new Map;
  this.SD = null;
  this.dM = u(this.v4, this);
  this.cM = u(this.u4, this);
  this.Bo = null;
  this.Ep = new Ki(30);
  this.uL = !1;
  this.ti = c || null;
  this.cB = new ei("mirror.cast.SeqNumGenerator");
  this.dd = this.Ef = null;
  this.Cz = 0;
};
la(ip, Dh);
d = ip.prototype;
d.start = function(a) {
  var b = this, c = Lo(a);
  a = Mo(a);
  this.Ef = new Sg("MediaRouter.CastStreaming.Session.Launch");
  this.wa = new Jc;
  this.T0();
  this.Fa.useTdls && Oo(this.he.address, !0).then(function(a) {
    "Connected" != a && (b.Fa.useTdls = !1);
  }, function() {
    b.Fa.useTdls = !1;
  });
  chrome.cast.streaming.session.create(c, a, function(a, c, g) {
    b.Tc = a;
    b.gc = c;
    b.vi = Ya(g);
    b.Lc.onMessage = u(b.Gt, b);
    b.Cz = 0;
    b.bB({type:"OFFER", sessionId:b.getId(), seqNum:b.cB.us(), offer:b.Kn()});
  });
  return this.wa.promise;
};
d.stop = function() {
  this.dd && (this.dd.end(), this.dd = null);
  this.a.info("Stopping " + this.getId());
  null !== this.Tc && (chrome.cast.streaming.rtpStream.stop(this.Tc), chrome.cast.streaming.rtpStream.destroy(this.Tc), this.Tc = null, this.Gi = !1);
  null !== this.gc && (chrome.cast.streaming.rtpStream.stop(this.gc), chrome.cast.streaming.rtpStream.destroy(this.gc), this.gc = null, this.Bk = !1);
  this.vi && (chrome.cast.streaming.udpTransport.destroy(this.vi), this.vi = 0);
  this.Fa.useTdls && Oo(this.he.address, !1);
  this.wa && (this.wa.resolve(this), this.wa = null);
  chrome.cast.streaming.rtpStream.onStarted.removeListener(this.dM);
  chrome.cast.streaming.rtpStream.onError.removeListener(this.cM);
  null !== this.Bo && (window.clearTimeout(this.Bo), this.Bo = null);
  this.wn = this.vn = null;
  if (this.ti && this.ti.onSessionStop) {
    this.ti.onSessionStop(this.he);
  }
  this.Lc.Qa();
  return Promise.resolve();
};
d.g$ = function(a) {
  this.Gi && chrome.cast.streaming.rtpStream.toggleLogging(Ya(this.Tc), a);
  this.Bk && chrome.cast.streaming.rtpStream.toggleLogging(Ya(this.gc), a);
};
d.getLogs = function() {
  var a = this;
  if (!this.Gi && !this.Bk) {
    return Promise.reject(Error("No streams has been started yet."));
  }
  var b = [];
  if (this.Gi) {
    var c = Jo(Ya(this.Tc), this.he.address, this.Vt, this.Fa, this.Ep.H());
    b.push(c);
  }
  this.Bk && (c = Jo(Ya(this.gc), this.he.address, this.Vt, this.Fa, this.Ep.H()), b.push(c));
  return Promise.all(b).then(function(b) {
    b = new Blob(b, {type:"application/gzip"});
    a.a.info("Events blob size: " + b.size);
    return b;
  });
};
d.getStats = function() {
  var a = [];
  if (this.Gi) {
    var b = Ko(Ya(this.Tc), this.he.address, this.Vt, this.Fa);
    a.push(b);
  }
  this.Bk && (b = Ko(Ya(this.gc), this.he.address, this.Vt, this.Fa), a.push(b));
  this.Ep.V() && a.push(Promise.resolve({receiverStatusData:this.Ep.H()}));
  return Promise.all(a).then(function(a) {
    var b = {};
    a.forEach(function(a) {
      Ub(b, a);
    });
    return b;
  });
};
d.HT = function() {
  var a = chrome.cast.streaming.rtpStream.getSupportedParams(Ya(this.Tc))[0];
  a.payload.channels = 2;
  a.payload.maxBitrate = this.Fa.audioBitrate;
  a.payload.maxFrameRate = 100;
  a.payload.maxLatency = this.Fa.maxLatencyMillis;
  a.payload.minLatency = this.Fa.minLatencyMillis;
  a.payload.animatedLatency = this.Fa.animatedLatencyMillis;
  a.payload.ssrc = jp(1, 5e5);
  a.payload.clockRate = 48000;
  a.payload.feedbackSsrc = 2;
  a.payload.payloadType = 127;
  a.payload.aesKey = Za(this.wn);
  a.payload.aesIvMask = Za(this.vn);
  return a;
};
d.YT = function() {
  var a = this, b = [];
  if (null === this.gc) {
    return b;
  }
  var c = chrome.cast.streaming.rtpStream.getSupportedParams(Ya(this.gc));
  this.Y5.forEach(function(e) {
    var f = c.find(function(a) {
      return a.payload.codecName.toLowerCase() == e.toLowerCase();
    });
    f && (f.payload.maxFrameRate = a.Fa.maxFrameRate, f.payload.minBitrate = a.Fa.minVideoBitrate, f.payload.maxBitrate = a.Fa.maxVideoBitrate, f.payload.maxLatency = a.Fa.maxLatencyMillis, f.payload.minLatency = a.Fa.minLatencyMillis, f.payload.animatedLatency = a.Fa.animatedLatencyMillis, f.payload.aesKey = Za(a.wn), f.payload.aesIvMask = Za(a.vn), f.payload.ssrc = jp(500001, 1E6), f.payload.feedbackSsrc = 12, f.payload.payloadType = 96, b.push(f));
  });
  return b;
};
d.Kn = function() {
  var a = this, b = 0, c = [];
  if (this.Tc) {
    var e = this.HT();
    this.SD = e;
    e = {index:b, type:"audio_source", codecName:e.payload.codecName.toLowerCase(), rtpProfile:"cast", rtpPayloadType:e.payload.payloadType, ssrc:e.payload.ssrc, targetDelay:this.Fa.animatedLatencyMillis, aesKey:e.payload.aesKey, aesIvMask:e.payload.aesIvMask, bitRate:0 < e.payload.maxBitrate ? 1000 * e.payload.maxBitrate : 60 * e.payload.maxFrameRate + e.payload.clockRate * e.payload.channels, sampleRate:e.payload.clockRate, timeBase:"1/" + e.payload.clockRate, channels:e.payload.channels, rtpExtensions:["adaptive_playout_delay"]};
    this.Fa.enableLogging && Ub(e, {receiverRtcpEventLog:!0});
    this.Fa.dscpEnabled && Ub(e, {receiverRtcpDscp:46});
    c.push(e);
    b++;
  }
  this.YT().forEach(function(e) {
    var f = {index:b, type:"video_source", codecName:e.payload.codecName.toLowerCase(), rtpProfile:"cast", rtpPayloadType:e.payload.payloadType, ssrc:e.payload.ssrc, targetDelay:a.Fa.animatedLatencyMillis, aesKey:e.payload.aesKey, aesIvMask:e.payload.aesIvMask, maxFrameRate:Math.round(1000 * e.payload.maxFrameRate) + "/1000", timeBase:"1/90000", maxBitRate:e.payload.maxBitrate, resolutions:[{width:a.Fa.maxWidth, height:a.Fa.maxHeight}], rtpExtensions:["adaptive_playout_delay"]};
    a.Fa.enableLogging && Ub(f, {receiverRtcpEventLog:!0});
    a.Fa.dscpEnabled && Ub(f, {receiverRtcpDscp:46});
    c.push(f);
    a.Ey.set(b, e);
    b++;
  });
  return {supportedStreams:c};
};
d.v4 = function(a) {
  a == this.Tc ? this.Gi = !0 : a == this.gc && (this.Bk = !0);
  this.Gi && (null === this.gc || this.Bk) && (this.g$(this.Fa.enableLogging), this.wa && (this.wa.resolve(this), this.wa = null));
  this.dd = new Xg("MediaRouter.CastStreaming.Session.Length");
};
d.u4 = function(a, b) {
  if (a == this.Tc) {
    this.a.l("Audio stream error " + b);
  } else {
    if (a == this.gc) {
      this.a.l("Video stream error " + b);
    } else {
      this.a.l("Error for stream " + a + ": " + b);
      return;
    }
  }
  this.wa && (this.wa.reject(Error("Error for stream " + a + ": " + b)), this.wa = null);
  this.stop();
};
d.Aba = function(a, b) {
  var c = this;
  this.a.w(function() {
    return "Starting streaming ... " + JSON.stringify({udpTransportId:c.vi, receiverIpEndPoint:c.he, "audio ID":c.Tc, "video ID":c.gc, "audio params":a, "video params":b});
  });
  if (ua(chrome.cast.streaming.udpTransport.setOptions)) {
    var e = {};
    this.Fa.dscpEnabled && (this.a.info("Enable DSCP in sender."), e.DSCP = !0);
    chrome.cast.streaming.udpTransport.setOptions(this.vi, e);
  }
  chrome.cast.streaming.udpTransport.setDestination(this.vi, {address:this.he.address, port:this.he.port});
  chrome.cast.streaming.rtpStream.onStarted.addListener(this.dM);
  chrome.cast.streaming.rtpStream.onError.addListener(this.cM);
  a && chrome.cast.streaming.rtpStream.start(Ya(this.Tc), a);
  b && chrome.cast.streaming.rtpStream.start(Ya(this.gc), b);
};
d.Gt = function(a) {
  var b = this;
  if ("urn:x-cast:com.google.cast.webrtc" == a.namespace_) {
    var c, e = null;
    try {
      c = Uo(a.data);
    } catch (k) {
      c = new Ro, e = k.message;
    }
    if ("ANSWER" == c.type) {
      if ("ok" == c.result && c.bf) {
        c.bf.jC && (this.he.port = c.bf.jC);
        this.uL = !!c.bf.tL;
        if (this.ti) {
          this.ti.onAnswer(this.he);
        }
        this.Ef && (this.Ef.end(), this.Ef = null);
        this.a.info("Starting streaming");
        var f = this.SD, g = null;
        c.bf.oM.forEach(function(a) {
          f && 0 == a ? c.bf.lq[a] && (f.payload.feedbackSsrc = c.bf.lq[a]) : b.Ey.has(a) && (g ? b.a.l("Receiver selected multiple video stream") : (g = b.Ey.get(a), c.bf.lq[a] && (g.payload.feedbackSsrc = c.bf.lq[a])));
        });
        null !== this.gc && null === g && (this.a.l("Receiver is capable of video, but did not specify a video stream index in the ANSWER message."), chrome.cast.streaming.rtpStream.destroy(this.gc), this.gc = null);
        if (f || g) {
          this.BH(), this.Aba(f, g), this.wa && (this.wa.resolve(this), this.wa = null);
        }
      } else {
        this.wa && (this.wa.reject(Error("Non-OK answer received: " + JSON.stringify(c))), this.wa = null), this.stop();
      }
    } else {
      "STATUS_RESPONSE" == c.type && c.status ? (a = {}, null != c.status.CC && (a.wifiSnr = c.status.CC), null != c.status.DC && (a.wifiSpeed = c.status.DC.pop()), e = {}, e[(new Date).toISOString()] = a, this.Ep.add(e)) : (e || (e = "Ignoring message: " + JSON.stringify(c)), 10 > this.Cz ? this.a.l(e) : this.a.w(e), ++this.Cz);
    }
  }
};
d.T0 = function() {
  x(!this.vn);
  x(!this.wn);
  this.vn = fi(window.crypto.getRandomValues(new Uint8Array(16)));
  this.wn = fi(window.crypto.getRandomValues(new Uint8Array(16)));
};
var jp = function(a, b) {
  x(a < b, "Expect low < upper");
  return Math.floor(Math.random() * (b - a)) + a;
};
d = ip.prototype;
d.qM = function() {
  this.bB(this.aZ());
};
d.bB = function(a) {
  x(null != a, "Expect non-null message");
  this.Lc.sendMessage(a, {namespace:"urn:x-cast:com.google.cast.webrtc"});
};
d.BH = function() {
  this.Bo = null;
  this.vi && this.uL && (this.bB({type:"GET_STATUS", sessionId:this.getId(), seqNum:this.cB.us(), get_status:["wifiSnr", "wifiSpeed"]}), this.Bo = window.setTimeout(u(this.BH, this), 12E4));
};
d.aZ = function() {
  var a = new Qo(this.C, this.cB.us());
  a.title = this.FA || void 0;
  a.icons = this.iconUrl && !this.Qs ? [new chrome.cast.Image(this.iconUrl)] : [];
  return a;
};
d.getId = function() {
  return this.C;
};
var kp = function() {
  Bh.call(this, "cast_streaming");
  this.ti = null;
};
la(kp, Bh);
d = kp.prototype;
d.getName = function() {
  return "cast_streaming";
};
d.yr = function(a, b) {
  return new ip(a, b, this.ti);
};
d.$t = function() {
  zo(0);
};
d.Wt = function() {
  zo(1);
};
d.zA = function() {
  zo(2);
};
d.Xt = function() {
  $g("MediaRouter.CastStreaming.Session.End");
};
d.Yt = function(a) {
  ah("MediaRouter.CastStreaming.Start.Failure", a, ch);
};
d.Zt = function() {
  $g("MediaRouter.CastStreaming.Stream.End");
};
d.ew = function(a) {
  var b = this, c = a.getLogs().then(function(a) {
    return a;
  }, function(a) {
    b.m.l("Get cast streaming logs failed.", a);
  });
  a = a.getStats().then(function(a) {
    return a;
  }, function(a) {
    b.m.l("Get cast streaming stats failed.", a);
  });
  var e = new Promise(function(a) {
    chrome.metricsPrivate.getIsCrashReportingEnabled(a);
  });
  return Promise.all([c, a, e]).then(function(a) {
    var c = ka(a);
    a = c.next().value;
    var e = c.next().value, c = c.next().value;
    if (a) {
      var f = new FileReader;
      f.onloadend = function() {
        Vh("mr.temp.mirror.cast.Service.mirrorLogs", f.result);
      };
      f.readAsBinaryString(a);
    }
    e && (window.localStorage["e2eTestService.castStreamingMirrorStats"] = JSON.stringify(e));
    c && (a && Fo().eba() ? Co(a, void 0, b.f3.bind(b)) : e && Bo("stats.json", new Blob([JSON.stringify(e)], {type:"application/json"}), void 0, void 0));
  });
};
d.f3 = function(a) {
  a && (Fo().Y9(Date.now()), window.localStorage["e2eTestService.castStreamingMirrorLogId"] = a);
};
d.Mf = function(a) {
  var b = this;
  this.m.info("Received message to upload logs for " + a);
  return this.Ha ? this.Ha.getLogs().then(function(b) {
    return Co(b, a);
  }, function(c) {
    b.m.l("Get cast streaming logs failed.", c);
    return b.UJ(a);
  }) : Promise.resolve(this.UJ(a));
};
d.UJ = function(a) {
  var b = window.localStorage["mr.temp.mirror.cast.Service.mirrorLogs"];
  if (!b) {
    return "";
  }
  window.localStorage.removeItem("mr.temp.mirror.cast.Service.mirrorLogs");
  this.m.info("Uploading saved logs for feedback.");
  for (var c = new Uint8Array(b.length), e = 0;e < c.length;e++) {
    c[e] = b.charCodeAt(e);
  }
  return Co(new Blob([c], {type:"application/gzip"}), a);
};
d.Kaa = function(a) {
  this.ti = a;
};
var lp = new kp;
zh("mr.mirror.cast.Service", lp);

