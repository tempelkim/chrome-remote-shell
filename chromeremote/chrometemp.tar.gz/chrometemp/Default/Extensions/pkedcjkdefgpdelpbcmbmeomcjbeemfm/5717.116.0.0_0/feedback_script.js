'use strict';var Tf = function(a) {
  this.RE = "number" == typeof a ? 0 < a ? 1 : 0 > a ? -1 : null : null == a ? null : a ? -1 : 1;
};
Tf.prototype.UU = function(a, b) {
  var c = 0, e = 0, f = !1;
  a = Fe(a, b).split(Je);
  for (b = 0;b < a.length;b++) {
    var g = a[b];
    He.test(Fe(g, void 0)) ? (c++, e++) : Ie.test(g) ? f = !0 : Ge.test(Fe(g, void 0)) ? e++ : Ke.test(g) && (f = !0);
  }
  return 0 == e ? f ? 1 : 0 : 0.40 < c / e ? -1 : 1;
};
Tf.prototype.pU = function(a, b) {
  return this.I1(this.UU(a, b));
};
Tf.prototype.I1 = function(a) {
  return -1 == (0 == a ? this.RE : a) ? "rtl" : "ltr";
};
Tf.prototype.mark = function() {
  switch(this.RE) {
    case 1:
      return "\u200e";
    case -1:
      return "\u200f";
    default:
      return "";
  }
};
if ("undefined" != typeof angular) {
  var Uf = angular.module("chrome_18n", []);
  chrome.runtime && chrome.runtime.getManifest && chrome.runtime.getManifest().default_locale && Uf.directive("angularMessage", function() {
    return {restrict:"E", replace:!0, controller:["$scope", function(a) {
      var b = this;
      this.hw = this.Tn = null;
      a.dirForText = function(a) {
        b.Tn || (b.Tn = chrome.i18n.getMessage("@@bidi_dir") || "ltr");
        b.hw || (b.hw = new Tf("rtl" == b.Tn));
        return b.hw.pU(a || "");
      };
    }], compile:function(a, b) {
      b = b.key;
      var c = null, e = document.createElement("amr");
      b && !b.match(/^\d+$/) && (b = chrome.i18n.getMessage(b), null == b && e.setAttribute("id", "missing"));
      if (b) {
        var f = chrome.i18n.getMessage(b + "_ph"), c = [];
        if (null != f) {
          for (c = f.split("\ue000"), f = 0;f < c.length;++f) {
            c[f] = c[f].replace(/^{{(.*)}}$/, '<amrp dir="{{dirForText($1)}}">{{$1}}</amrp>');
          }
        }
        c = chrome.i18n.getMessage(b, c);
      } else {
        e.setAttribute("r", "nokey");
      }
      c ? e.innerHTML = c : (e.setAttribute("tl", "false"), e.innerHTML = a.html());
      a.replaceWith(e);
    }};
  });
}
;var Vf = /^[\w+/]+[=]{0,2}$/;
var Wf = function(a, b, c) {
  a.timeOfStartCall = (new Date).getTime();
  var e = c || h, f = e.document, g;
  g = (g = (g = (e || h).document.querySelector("script[nonce]")) && g.getAttribute("nonce")) && Vf.test(g) ? g : void 0;
  g && (a.nonce = g);
  if ("help" == a.flow) {
    var k = oa("document.location.href", e);
    !a.helpCenterContext && k && (a.helpCenterContext = k.substring(0, 1200));
    k = !0;
    if (b && JSON && JSON.stringify) {
      var q = JSON.stringify(b);
      (k = 1200 >= q.length) && (a.psdJson = q);
    }
    k || (b = {invalidPsd:!0});
  }
  b = [a, b, c];
  e.GOOGLE_FEEDBACK_START_ARGUMENTS = b;
  c = a.serverUri || "//www.google.com/tools/feedback";
  if (k = e.GOOGLE_FEEDBACK_START) {
    k.apply(e, b);
  } else {
    var e = c + "/load.js?", r;
    for (r in a) {
      b = a[r], null != b && !va(b) && (e += encodeURIComponent(r) + "=" + encodeURIComponent(b) + "&");
    }
    a = f.createElement("script");
    g && a.setAttribute("nonce", g);
    a.src = e;
    f.body.appendChild(a);
  }
};
m("userfeedback.api.startFeedback", Wf, void 0);
var Xf = function() {
  this.jF = this.mE = this.receiverVersion = this.modelName = this.aK = this.Qr = this.jt = "";
};
var Yf = chrome.i18n.getMessage("4163185390680253103"), Zf = chrome.i18n.getMessage("492097680647953484"), $f = chrome.i18n.getMessage("2575016469622936324"), ag = chrome.i18n.getMessage("128276876460319075"), bg = chrome.i18n.getMessage("3326722026796849289"), cg = chrome.i18n.getMessage("1018984561488520517"), dg = chrome.i18n.getMessage("8205999658352447129"), eg = chrome.i18n.getMessage("5723583529370342957"), fg = chrome.i18n.getMessage("1550904064710828958"), gg = chrome.i18n.getMessage("5014364904504073524"), 
hg = chrome.i18n.getMessage("2194670894476780934"), ig = chrome.i18n.getMessage("6614468912728530636"), jg = chrome.i18n.getMessage("5910595154486533449"), kg = chrome.i18n.getMessage("5363086287710390513"), lg = chrome.i18n.getMessage("244647017322945605"), mg = chrome.i18n.getMessage("5375576275991472719"), og = chrome.i18n.getMessage("4592127349908255218"), pg = chrome.i18n.getMessage("843316808366399491"), qg = chrome.i18n.getMessage("5699813974548050528"), rg = chrome.i18n.getMessage("8515148417333877999"), 
sg = chrome.i18n.getMessage("1636686747687494376"), tg = chrome.i18n.getMessage("4148300086676792937"), ug = chrome.i18n.getMessage("3219866268410307919"), vg = chrome.i18n.getMessage("9211708838274008657"), wg = chrome.i18n.getMessage("8706273405040403641"), xg = chrome.i18n.getMessage("4756056595565370923"), yg = chrome.i18n.getMessage("7876724262035435114"), zg = chrome.i18n.getMessage("5485620192329479690"), Ag = chrome.i18n.getMessage("6963873398546068901"), Bg = chrome.i18n.getMessage("3567591856726172993"), 
Cg = chrome.i18n.getMessage("3239956785410157548");
var Dg = function(a, b) {
  var c = this;
  this.lF = b;
  this.u = a;
  this.u.top = a;
  this.GF = [];
  this.NC = !1;
  this.fe = new Xf;
  this.cba();
  this.Waa();
  this.Xaa();
  this.Yaa();
  this.$aa();
  this.hV = Ra();
  this.u.userEmail = "";
  chrome.identity.getProfileUserInfo(function(a) {
    c.u.userEmail = a.email;
    c.Pp();
  });
  this.u.yourAnswerText = Cg;
  this.u.language = chrome.i18n && chrome.i18n.getUILanguage ? chrome.i18n.getUILanguage() : chrome.runtime.getManifest().default_locale;
  this.u.requestLogsInProgress = !1;
};
d = Dg.prototype;
d.Waa = function() {
  this.GF = [{value:"Bug", desc:Yf}, {value:"FeatureRequest", desc:Zf}, {value:"MirroringQuality", desc:$f}, {value:"Discovery", desc:ag}, {value:"Other", desc:bg}];
  this.u.feedbackTypes = this.GF;
};
d.hC = function(a) {
  for (var b = [], c = 1;c < arguments.length;c++) {
    b.push(new Eg(c, arguments[c]));
  }
  b.push(new Eg(0, arguments[0]));
  return b;
};
d.cba = function() {
  this.u.videoSmoothnessRatings = this.hC(hg, cg, dg, eg, fg, gg);
  this.u.videoQualityRatings = this.hC(hg, ig, jg, kg, lg, mg);
  this.u.audioQualityRatings = this.hC(hg, og, pg, qg, rg, sg);
};
d.Xaa = function() {
  this.u.includeFineLogs = !0;
  this.u.feedbackType = "Bug";
  this.u.sendFeedback = this.q8.bind(this);
  this.u.cancel = this.NS.bind(this);
  this.u.attachLogsClick = this.PD.bind(this);
  this.u.viewLogs = this.Vca.bind(this);
};
d.Yaa = function() {
  this.u.$watchGroup("videoSmoothness videoQuality audioQuality feedbackDescription comments feedbackType".split(" "), this.dT.bind(this));
  this.u.sufficientFeedback = !1;
};
d.$aa = function() {
  this.u.$watch("attachLogs", this.PD.bind(this));
  this.u.attachLogs = !0;
};
d.NS = function() {
  this.u.feedbackDescription && !confirm(tg) || window.close();
};
d.dT = function() {
  var a = this.u.feedbackType;
  this.u.sufficientFeedback = "MirroringQuality" == a ? this.u.videoSmoothness || this.u.videoQuality || this.u.audioQuality || this.u.comments : "Discovery" == a ? this.u.visibleInSetup || this.u.comments : !!this.u.feedbackDescription;
};
d.q8 = function() {
  if (this.u.sufficientFeedback) {
    var a = this.u.feedbackType, b = "";
    "MirroringQuality" == a ? (this.u.videoSmoothness && (b += "\nVideo Smoothness: " + this.u.videoSmoothness), this.u.videoQuality && (b += "\nVideo Quality: " + this.u.videoQuality), this.u.audioQuality && (b += "\nAudio: " + this.u.audioQuality), this.u.projectedContentUrl && (b += "\nProjected Content/URL: " + this.u.projectedContentUrl), this.u.comments && (b += "\nComments: " + this.u.comments)) : "Discovery" == a ? (this.u.visibleInSetup && (b += "\nChromecast Visible in Setup: " + this.u.visibleInSetup), 
    this.u.hasNetworkSoftware && (b += "\nUsing VPN/proxy/firewall/NAS Software: " + this.u.hasNetworkSoftware), this.u.networkDescription && (b += "\nNetwork Description: " + this.u.networkDescription), this.u.comments && (b += "\nComments: " + this.u.comments)) : b = this.u.feedbackDescription;
    this.p8("Type: " + a + "\n\n" + b);
  }
};
d.p8 = function(a) {
  this.u.sendDialogText = ug;
  this.u.okButton = Bg;
  this.u.feedbackSent = !1;
  this.lF.show({locals:{Rla:this.u.feedbackSent, Tra:this.u.sendDialogText, T2:this.u.okButton}, scope:this.u, preserveScope:!0, bindToController:!0, template:'<md-dialog id="feedback-confirmation"><md-dialog-content><div id="send-feedback-text">{{sendDialogText}}</div><md-dialog-actions><md-button class="md-raised md-primary"ng-disabled="!feedbackSent" ng-click="closeWindow()">{{okButton}}</md-button></md-dialog-actions></md-dialog-content></md-dialog>', controller:this.yv});
  this.mM(a, Date.now());
};
d.mM = function(a, b) {
  var c = Date.now();
  !this.u.requestLogsInProgress || 5000 < c - b ? this.CU(a) : setTimeout(this.mM.bind(this), 1000, a, b);
};
d.CU = function(a) {
  var b = this, c = 0, e = function(a, c, e) {
    e ? a(!0) : (b.u.sendDialogText = xg, b.Pp(), c(Error("Failed to send")));
  };
  (new Ce(function() {
    c++;
    return new Promise(function(c, g) {
      var f = b.u.userEmail, q = b.fe;
      c = e.bind(null, c, g);
      g = chrome.runtime.getManifest();
      Wf({productId:85561, bucket:"Canary", flow:"submit", serverUri:"https://www.google.com/tools/feedback", allowNonLoggedInFeedback:!0, locale:g.default_locale, enableAnonymousFeedback:!f, report:{description:a}, callback:c}, {version:g.version, description:g.description, user_email:f || "NA", logs:q.jt || "NA", external_logs:q.Qr || "NA", device_model:q.modelName || "NA", receiver_version:q.receiverVersion || "NA", dash_report_url:q.aK || "NA", cast_device_counts:q.mE, dial_device_counts:q.jF});
    });
  }, 10000, 4)).pu(2).start().then(function() {
    b.u.sendDialogText = wg;
    b.u.feedbackSent = !0;
    b.Pp();
  }, function() {
    b.u.sendDialogText = vg;
    b.u.feedbackSent = !0;
    b.Pp();
  });
};
d.PD = function() {
  var a = this;
  this.fe = new Xf;
  this.u.attachLogs && (this.u.requestLogsInProgress = !0, chrome.runtime.sendMessage(new Nf(this.hV, "retrieve_log_data"), function(b) {
    a.u.requestLogsInProgress = !1;
    a.fe.jt = b.logs || "no extension";
    b.castStreamingLogs && (a.fe.aK = b.castStreamingLogs);
    b.castDeviceCounts && (a.fe.mE = b.castDeviceCounts);
    b.dialDeviceCounts && (a.fe.jF = b.dialDeviceCounts);
    if (b = b.device) {
      if (b.model && (a.fe.modelName = b.model), b.version && (a.fe.receiverVersion = b.version), !a.NC) {
        var c = Ra();
        a.NC = !0;
        a.fe.Qr = Qf(b.ip, c, a.m4.bind(a));
      }
    }
  }));
};
d.Vca = function() {
  this.u.logsHeader = yg;
  this.u.sendLogs = zg;
  this.u.fineLogsWarning = Ag;
  this.u.okButton = Bg;
  this.lF.show({locals:{Cia:this.u.attachLogs, jt:this.fe.jt, ina:this.u.includeFineLogs, doa:this.u.logsHeader, Vra:this.u.sendLogs, Tla:this.u.fineLogsWarning, T2:this.u.okButton}, scope:this.u, preserveScope:!0, bindToController:!0, clickOutsideToClose:!0, template:'<md-dialog><md-dialog-content id="logs-dialog"><div class="subheading">{{logsHeader}}</div><div ng-show="includeFineLogs && attachLogs"id="feedback-fine-log-warning" class="informative">{{fineLogsWarning}}</div><pre>{{logs}}</pre><div class="send-logs"><md-checkbox type="checkbox" ng-model="attachLogs"ng-change="attachLogsClick()"><span>{{sendLogs}}</span></md-checkbox></div><md-dialog-actions><md-button class="md-raised md-primary"ng-click="closeDialog()">{{okButton}}</md-button></md-dialog-actions></md-dialog-content></md-dialog>', 
  controller:this.yv});
};
d.m4 = function(a, b) {
  this.NC = !1;
  this.fe.Qr = "error" == a ? "" : b;
  this.u.attachLogs || (this.fe.Qr = "");
  this.Pp();
};
d.Pp = function() {
  this.u.$$phase || this.u.$apply();
};
d.yv = function(a, b) {
  a.closeWindow = function() {
    window.close();
  };
  a.closeDialog = function() {
    b.hide();
  };
};
Dg.prototype.yv.$inject = ["$scope", "$mdDialog"];
var Eg = function(a, b) {
  this.id = a;
  this.desc = b;
  this.text = 0 == a ? b : a + " (" + b + ")";
};
angular.module("feedbackApp", "chrome_18n material.components.button material.components.checkbox material.components.dialog material.components.input material.components.radioButton".split(" ")).controller("FeedbackCtrl", ["$scope", "$mdDialog", Dg]);
m("ng.safehtml.googSceHelper.isGoogHtmlType", function(a) {
  return a && a.Ll ? !0 : !1;
}, void 0);
m("ng.safehtml.googSceHelper.isCOMPILED", function() {
  return !0;
}, void 0);
m("ng.safehtml.googSceHelper.unwrapAny", function(a) {
  if (a instanceof Ye) {
    return Ze(a);
  }
  if (a instanceof af) {
    return bf(a);
  }
  if (a instanceof Ve) {
    return We(a);
  }
  if (a instanceof Se) {
    return Te(a);
  }
  if (a instanceof Pe) {
    return Qe(a);
  }
  throw Error();
}, void 0);
m("ng.safehtml.googSceHelper.unwrapGivenContext", function(a, b) {
  if ("html" == a) {
    return bf(b);
  }
  if ("resourceUrl" == a || "templateUrl" == a) {
    return Ze(b);
  }
  if ("url" == a) {
    return b instanceof Ye ? Ze(b) : We(b);
  }
  if ("css" == a) {
    return Te(b);
  }
  if ("js" == a) {
    return Qe(b);
  }
  throw Error();
}, void 0);

