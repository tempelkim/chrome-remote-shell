'use strict';window.navigator.userAgent.match(/Chrome\/([0-9]+)/);
var Ek = function(a, b) {
  this.type = a;
  this.entryPoint = b;
};
m("castApp.frontEnd.ExtensionMessage", Ek, void 0);
var Fk = function(a) {
  return "urn:x-cast:com.google.cast." + a;
}, Gk = Fk("tp.connection"), Hk = Fk("receiver"), Ik = Fk("media"), Jk = Fk("webrtc"), Kk = Fk("broadcast"), Lk = Sb({Eha:Gk, Fha:Fk("tp.heartbeat"), Sga:Hk, MEDIA:Ik, Ofa:Fk("media.universalRemote.optIn"), Zha:Jk, Uda:Kk});
var Mk = function(a) {
  return "available" == a || "available_rescan" == a;
};
var Nk = function(a, b) {
  this.xc = this.lg = this.ng = this.Ja = this.qa = null;
  this.be = new hi(hk.W().pl(b), a);
  this.Sc = {};
  this.Uq = {};
  this.Rm = !1;
};
d = Nk.prototype;
d.Fh = function() {
  return this.be;
};
d.ul = function() {
  return this.be.friendlyName;
};
d.n$ = function(a) {
  this.xc = a;
  return this;
};
d.getId = function() {
  return this.be.id;
};
d.tu = function(a) {
  this.be.id = a;
  return this;
};
d.UN = function(a) {
  this.Rm = a;
  return this;
};
d.update = function(a) {
  if (this.getId() != a.getId()) {
    return !1;
  }
  var b = !1;
  this.be.friendlyName != a.be.friendlyName && (this.be.friendlyName = a.be.friendlyName, b = !0);
  this.ng != a.ng && (this.ng = a.ng, b = !0);
  this.lg != a.lg && (this.lg = a.lg, b = !0);
  this.qa != a.qa && (this.qa = a.qa, b = !0);
  this.Ja != a.Ja && (this.Ja = a.Ja, b = !0);
  return b;
};
d.S9 = function(a) {
  this.qa = a;
  return this;
};
d.Wa = function() {
  return this.Ja;
};
d.Fm = function(a) {
  this.Ja = a;
  return this;
};
d.r9 = function(a) {
  this.ng = a;
  return this;
};
d.q9 = function(a) {
  this.lg = a;
  return this;
};
d.ye = function(a) {
  return this.Sc[a] || "unknown";
};
d.NV = function(a) {
  return this.Uq[a] || null;
};
d.Vp = function(a, b) {
  this.Sc[a] = b;
  this.Uq[a] = Date.now();
  return this;
};
d.BO = function() {
  return "name = " + this.be.friendlyName + (this.qa ? ", ip = " + this.qa : "") + (this.xc ? ", model = " + this.xc : "") + ", apps = " + JSON.stringify(this.Sc);
};
var Ok = function(a) {
  var b = new Nk(a.be.friendlyName, "");
  b.be.id = a.be.id;
  b.qa = a.qa;
  b.Ja = a.Ja;
  b.ng = a.ng;
  b.lg = a.lg;
  b.xc = a.xc;
  b.Sc = a.Sc;
  b.Uq = a.Uq;
  b.Rm = a.Rm;
  return b;
};
var Pk = function(a, b, c, e, f, g) {
  a = hk.W().pl(a);
  this.Se = new hi(a, b, this.PH(e));
  this.xc = c || null;
  this.pd = e || null;
  this.qa = f || null;
  this.Ja = g || null;
  this.Sc = {};
  this.il = !1;
}, Qk = function(a) {
  if (!a.xc || !a.qa) {
    return null;
  }
  var b = new Pk(a.Fh().id, a.Fh().friendlyName, a.xc, void 0, a.qa, hk.W().Qk || 8009);
  b.Se.id = a.Fh().id;
  b.rB(!0);
  return b;
};
d = Pk.prototype;
d.vca = function(a) {
  (a = this.update(a.ul(), a.qa, a.Wa(), a.pd)) && this.rB(!1);
  return a;
};
d.update = function(a, b, c, e) {
  var f = !1;
  this.Se.friendlyName != a && (this.Se.friendlyName = a, f = !0);
  null != b && this.qa != b && (this.qa = b, f = !0);
  null != c && this.Ja != c && (this.Ja = c, f = !0);
  null != e && this.pd != e && (this.pd = e, f = !0);
  return f;
};
d.Fh = function() {
  return this.Se;
};
d.ul = function() {
  return this.Se.friendlyName;
};
d.PH = function(a) {
  return a & 1 ? "cast" : a & 32 ? "cast_audio_group" : "cast_audio";
};
d.X8 = function(a) {
  this.pd = a;
  this.Se.iconType = this.PH(this.pd);
};
d.getId = function() {
  return this.Se.id;
};
var Rk = function(a) {
  var b = new Pk("", a.friendlyName, a.modelName, a.capabilities, a.ip, a.port);
  b.Se.id = a.id;
  b.rB(a.discoveredByDial);
  b.Sc = a.appStatusMap;
  for (var c in b.Sc) {
    "unavailable" == b.Sc[c] && (b.Sc[c] = "unavailable_rescan");
  }
  return b;
};
d = Pk.prototype;
d.Wa = function() {
  return this.Ja;
};
d.ye = function(a) {
  return this.Sc[a] || "unknown";
};
d.Vp = function(a, b) {
  this.Sc[a] = b;
};
d.BO = function() {
  return "name = " + this.Se.friendlyName + (this.qa ? ", ip = " + this.qa : "") + (this.xc ? ", model = " + this.xc : "") + ", capabilities = " + this.pd + ", apps = " + JSON.stringify(this.Sc);
};
d.rB = function(a) {
  this.il = a;
};
var Sk = {Gfa:0, xfa:1}, Tk = {Uha:0, DQ:1, Tga:2}, Uk = {DIAL:0, Kfa:1, Lfa:2, yea:3}, Vk = {lga:0, TIMEOUT:1, FAILED:2}, Wk = {iD:0, Mda:1, pea:2, Uea:3, jea:4, Wfa:5}, Xk = {WP:0, SUCCESS:1}, Yk = function(a) {
  ah("MediaRouter.Cast.Session.Ended", a, Tk);
}, Zk = function(a) {
  ah("MediaRouter.Cast.Channel.ConnectResult", a, Xk);
}, $k = function(a) {
  ah("MediaRouter.Cast.Discovery.Type", a, Uk);
}, al = function(a) {
  ah("MediaRouter.Cast.Session.Fail", a, Vk);
};
var bl = {serviceType:"_googlecast._tcp.local"}, cl = null, dl = function() {
  cl || (cl = new Zi(7, "CastMdnsEventListener", "mr.cast.SinkDiscoveryService", chrome.mdns.onServiceList, bl));
  return cl;
}, el = null, fl = function() {
  el || (el = Mg() ? new Zi(9, "CastNetworkListChangedEventListener", "mr.cast.SinkDiscoveryService", chrome.networkingPrivate.onNetworkListChanged) : new Zi(8, "CastNetworksChangedEventListener", "mr.cast.SinkDiscoveryService", chrome.networkingPrivate.onNetworksChanged));
  return el;
};
var gl = function(a, b) {
  this.ed = b;
  this.lE = a;
  this.lE.Y = this.Y.bind(this);
  this.Oc = new I;
  this.Mm = new I;
  this.ai = new I;
  this.sz = null;
  this.Yo = this.Xh = "";
  this.dl = null;
  this.By = this.No = !1;
  this.dF = [];
  this.a = D("mr.cast.SinkDiscoveryService");
  this.Jr = new Set;
  this.kf = {Mk:0, Sl:0};
  this.Lm = this.bt = 0;
};
la(gl, ph);
d = gl.prototype;
d.init = function() {
  Rh(this);
  this.No && (this.DJ(), this.aG());
  zh("mr.cast.SinkDiscoveryService", this);
};
d.DJ = function() {
  this.a.info("Start listening to network changes");
  fl().addListener();
};
d.start = function() {
  var a = Date.now(), b = dl();
  if (b.rj()) {
    x(l(this.sz));
    if (6E4 > a - this.sz) {
      return;
    }
    this.a.info("Forcing mdns discovery");
    this.xV();
  } else {
    this.a.info("Adding mdns listener"), b.addListener();
  }
  this.sz = a;
};
d.xV = function() {
  chrome.mdns.forceDiscovery(n);
  var a = dl();
  a.removeListener();
  a.addListener();
};
d.handleEvent = function(a, b) {
  for (var c = [], e = 1;e < arguments.length;++e) {
    c[e - 1] = arguments[e];
  }
  if (a == chrome.mdns.onServiceList) {
    this.yL.apply(this, [].concat(ma(c)));
  } else {
    if (a == chrome.networkingPrivate.onNetworksChanged || a == chrome.networkingPrivate.onNetworkListChanged) {
      this.aG();
    } else {
      throw Error("Unhandled event");
    }
  }
};
d.UT = function(a) {
  if (-1 == a.serviceName.indexOf("._googlecast.")) {
    return null;
  }
  var b = {};
  a.serviceData.forEach(function(a) {
    0 == a.search(/[a-z]{2}=.+/) && (b[a.substring(0, 2)] = a.substring(3));
  });
  var c = b.id;
  if (!c) {
    return this.a.l("Missing ID"), null;
  }
  hk.W().pl(c);
  var e = Number(a.serviceHostPort.substring(a.serviceHostPort.indexOf(":") + 1));
  if (isNaN(e) || 0 > e || 65535 < e) {
    return this.a.l("Missing or invalid port"), null;
  }
  var f = b.fn;
  if (!f || !a.ipAddress) {
    return this.a.l("Missing friendly name or IP address"), null;
  }
  var g = Number(b.ca);
  return new Pk(c, f, b.md || "", isNaN(g) ? 0 : g, a.ipAddress, e);
};
d.refresh = function() {
  this.a.w("Executing forceDiscovery.");
  chrome.mdns.forceDiscovery(n);
};
d.yL = function(a) {
  var b = this;
  this.a.info("Registering " + a.length + " devices");
  0 != this.Lm && (clearTimeout(this.Lm), this.Lm = 0);
  a = this.VT(a).map(function(a) {
    return b.Bw(a, !0);
  });
  xi(a).then(function() {
    b.kf = {Mk:b.ny(), Sl:b.QX()};
    b.p2();
  });
};
d.p2 = function() {
  var a = this;
  0 != this.Lm || 36E5 > Date.now() - this.bt || (this.Lm = setTimeout(function() {
    return a.AU();
  }, 5E3));
};
d.AU = function() {
  var a = this.kf;
  bh("MediaRouter.Cast.Discovery.KnownDevicesCount", a.Sl);
  bh("MediaRouter.Cast.Discovery.ConnectedDevicesCount", a.Mk);
  this.bt = Date.now();
  this.Lm = 0;
};
d.QX = function() {
  var a = this, b = this.Jr.size;
  oe(this.hj(), function(c) {
    a.Jr.has(c.getId()) || b++;
  });
  return b;
};
d.S6 = function(a) {
  this.yL(a);
  this.dF = a;
};
d.Bw = function(a, b) {
  var c = this;
  if (this.ai.Ma(a.getId())) {
    return Promise.resolve();
  }
  this.ai.set(a.getId(), a);
  return this.Fn(a).then(function(e) {
    e ? (e = c.Oc.get(a.getId()), b && (e ? e.il && $k(3) : $k(1)), c.sn(a)) : (c.a.info("Inaccessible sink: " + a.getId()), c.Zj(a.getId()));
    c.ai.remove(a.getId());
  });
};
d.i1 = function(a) {
  return void 0 != this.dF.find(function(b) {
    return b.ipAddress == a.ipAddress;
  });
};
d.VT = function(a) {
  var b = this, c = [];
  this.Jr.clear();
  a.forEach(function(a) {
    if (!b.i1(a) && (a = b.UT(a))) {
      var e = a.getId();
      b.Jr.add(e);
      if (b.ai.Ma(e)) {
        var g = b.ai.get(e);
        if (g.qa == a.qa && g.Wa() == a.Wa()) {
          b.a.info("Sink has pending connection " + e);
          return;
        }
        b.a.l("Pending sink changed ip " + e);
        b.ai.remove(e);
      }
      (e = b.Oc.get(e)) ? e.vca(a) && b.ed.Ad(e) : c.push(a);
    }
  });
  return c;
};
d.oF = function(a) {
  var b = this.Oc.get(a.getId()), c = null, e = a.qa, f = a.Wa();
  null != e && null != f && (c = this.Mm.get(e + ":" + f));
  if (b && !c) {
    var g = a.qa, k = a.Wa();
    g && k && this.Mm.remove(g + ":" + k);
  }
  c && !b && this.Oc.remove(c.getId());
  this.Oc.set(a.getId(), a);
  null != e && null != f && this.Mm.set(e + ":" + f, a);
};
d.sn = function(a) {
  this.a.info("Adding sink " + a.getId());
  this.oF(a);
  this.No || (this.No = !0, this.DJ());
  this.ed.Kj(a);
  hk.W().Vj = new gk(a.xc, a.qa);
};
d.Gz = function(a) {
  this.a.info("Channel error for sink " + a);
  this.Zj(a);
};
d.Zj = function(a) {
  var b = this.Oc.get(a);
  if (b) {
    this.a.info("Removing sink " + a);
    this.Oc.remove(a);
    a = b.qa;
    var c = b.Wa();
    null != a && null != c && this.Mm.remove(a + ":" + c);
    this.ed.Ht(b);
  }
};
d.c7 = function() {
  var a = this.Oc.H();
  this.Oc.clear();
  this.Mm.clear();
  a.forEach(this.ed.Ht, this.ed);
};
d.Fn = function(a) {
  this.a.w("Checking access to " + a.getId());
  return this.lE.Yk(a).then(function(b) {
    if (a.il) {
      var c = 4;
      b.audioOnly || (c |= 1);
      a.X8(c);
    }
    return !0;
  }, function() {
    return !1;
  });
};
d.St = function() {
  var a = this;
  this.a.info("Pruning inactive sinks.");
  oe(this.hj(), function(b) {
    a.ai.set(b.getId(), b);
    a.Fn(b).then(function(c) {
      c || a.Zj(b.getId());
      a.ai.remove(b.getId());
    });
  });
};
d.Y = function(a) {
  return this.Oc.get(a, null);
};
d.OZ = function(a, b) {
  return this.Mm.get(a + ":" + b);
};
d.PZ = function(a) {
  var b = [];
  oe(this.hj(), function(c) {
    Mk(c.ye(a)) && b.push(c);
  });
  return b;
};
d.hj = function() {
  return this.Oc.sy();
};
d.ny = function() {
  return this.Oc.V();
};
d.Ad = function(a) {
  x(null != this.Y(a.getId()));
  this.ed.Ad(a);
};
d.Xd = function() {
  return this.Oc.H();
};
d.oa = function() {
  return "cast.SinkDiscoveryService";
};
d.getData = function() {
  var a = this, b = {};
  oe(this.Oc.$G(), function(c) {
    var e;
    e = a.Oc.get(c);
    e = {id:e.getId(), ip:e.qa, port:e.Wa(), friendlyName:e.ul(), modelName:e.xc, capabilities:e.pd, discoveredByDial:e.il, appStatusMap:e.Sc};
    b[c] = e;
  });
  return [new hl(b, this.Yo, this.kf), new il(this.No, this.bt)];
};
d.Xa = function() {
  var a = Oh(this);
  a && 3 == a.version && (this.Yo = a.networkIds, this.kf = a.deviceCounts, this.V0(a.sinkMap));
  if (a = Ph(this)) {
    this.No = a.hasSavedSinks, this.bt = a.lastSinkCountMetricRecordTime || 0;
  }
};
d.V0 = function(a) {
  this.By = 0 < Object.keys(a).length;
  for (var b in a) {
    var c = Rk(a[b]);
    this.Y(c.getId()) || this.oF(c);
  }
  this.St();
};
d.b2 = function(a) {
  this.By = 0 < Object.keys(a).length;
  for (var b in a) {
    var c = Rk(a[b]);
    this.Y(c.getId()) || this.Bw(c, !1);
  }
};
d.aG = function() {
  var a = this;
  this.a.info("Fetching networks state");
  this.dl && Wh(this.dl);
  chrome.networkingPrivate.getNetworks({networkType:"All", visible:!0, configured:!0}, function(b) {
    for (var c = [], e = 0;e < b.length;e++) {
      "Connected" == b[e].ConnectionState && c.push(b[e].GUID);
    }
    a.sca(c.sort().join(","));
  });
};
d.sca = function(a) {
  this.a.info(function() {
    return "Update current network " + jl(a);
  });
  a != this.Xh && (this.dl && (Qh.delete(this.dl.oa()), this.dl = null), a ? (this.Yo && a != this.Yo ? this.c7() : this.St(), this.Yo = this.Xh = a, this.dl = new kl(this, this.Xh)) : this.Xh = "");
};
var jl = function(a) {
  for (var b = 0, c = 0;c < a.length;c++) {
    b += a.charCodeAt(c);
  }
  return b;
}, hl = function(a, b, c) {
  this.sinkMap = a;
  this.networkIds = b;
  this.deviceCounts = c;
  this.version = 3;
}, il = function(a, b) {
  this.hasSavedSinks = a;
  this.lastSinkCountMetricRecordTime = b;
}, kl = function(a, b) {
  this.Fd = a;
  this.Xh = b;
  Rh(this);
};
kl.prototype.oa = function() {
  return "cast.NetworkSink." + this.Xh;
};
kl.prototype.getData = function() {
  var a = this, b = null, c = this.Fd.getData();
  c && (this.Fd.By || 0 < this.Fd.ny()) && (b = c[0]);
  this.Fd.a.info(function() {
    return "Saving sink data for network " + jl(a.Xh);
  });
  return [null, b];
};
kl.prototype.Xa = function() {
  var a = this;
  this.Fd.a.info(function() {
    return "Restoring sink data for network " + jl(a.Xh);
  });
  var b = Ph(this);
  b && 3 == b.version && this.Fd.b2(b.sinkMap);
};
var ll = {STOP_MEDIA:"STOP", MEDIA_SET_VOLUME:"SET_VOLUME", MEDIA_GET_STATUS:"GET_STATUS"};
var ml = function() {
  this.type = "GET_STATUS";
  this.requestId = 0;
};
var nl = function(a, b, c) {
  this.type = "APPLICATION_BROADCAST";
  this.requestId = 0;
  this.appIds = a;
  this.namespace = b;
  this.message = c;
};
var ol = function(a) {
  this.type = "LAUNCH";
  this.requestId = 0;
  this.appId = a;
  this.language = null;
};
var pl = function(a) {
  this.type = "STOP";
  this.requestId = 0;
  this.sessionId = a || null;
};
var ql = function(a, b) {
  this.requestId = a;
  this.Zba = b;
  this.zO = null;
};
ql.prototype.Jz = function() {
};
var rl = function() {
  this.Yb = new I;
};
rl.prototype.yD = function(a) {
  var b = this;
  this.Yb.set(a.requestId, a);
  a.zO = setTimeout(function() {
    return b.D4(a);
  }, a.Zba);
};
rl.prototype.Ip = function(a) {
  var b = this.Yb.get(a);
  if (!b) {
    return null;
  }
  clearTimeout(b.zO);
  this.Yb.remove(a);
  return b;
};
rl.prototype.Kh = function(a) {
  return this.Yb.get(a, null);
};
rl.prototype.D4 = function(a) {
  this.Yb.remove(a.requestId);
  a.Jz();
};
var sl = function(a, b) {
  this.Vc = a;
  this.Ed = b;
  this.Pj = new rl;
  this.RL = new ei("cast.RequestIdGenerator");
};
d = sl.prototype;
d.init = function() {
  this.RL.OU();
};
d.zD = function(a, b, c) {
  var e = this.RL.us();
  a.requestId = e;
  a = new Jc;
  b = new tl(e, a, t(b) && 0 < b ? b : 6E5, c);
  this.Pj.yD(b);
  return b;
};
d.IA = function(a) {
  this.Pj.Ip(a.requestId);
};
d.Ip = function(a) {
  return this.Pj.Ip(a);
};
d.sendRequest = function(a, b, c, e, f, g) {
  var k = this;
  if (!Lk.hasOwnProperty(c)) {
    return Promise.reject(Error("Custom namespace is not supported"));
  }
  var q = this.zD(a, l(e) ? e : 3000, f), r = q.pb;
  this.Vc.ku(b, c, a, f || this.Ed, g).then(null, function() {
    k.IA(q);
    r.reject(ul);
  });
  return r.promise;
};
d.sendMessage = function(a, b, c, e, f, g) {
  var k = this, q = this.zD(a, l(e) ? e : 3000, f), r = q.pb;
  this.Vc.ku(b, c, a, f || this.Ed, g).then(function() {
    k.IA(q);
    r.resolve(!0);
  }, function() {
    k.IA(q);
    r.reject(ul);
  });
  return r.promise;
};
d.x7 = function(a, b) {
  var c = new ol(a.appId);
  c.language = a.language ? a.language : chrome.i18n.getUILanguage ? chrome.i18n.getUILanguage() : chrome.runtime.getManifest().default_locale;
  return this.sendRequest(c, b, Hk, a.requestSessionTimeout);
};
d.y7 = function(a, b) {
  return this.sendRequest(new pl(a), b, Hk);
};
d.k8 = function(a, b) {
  return this.sendMessage(a, b, Kk);
};
var vl = Error("Timeout"), ul = Error("Failed to send message"), tl = function(a, b, c, e) {
  ql.call(this, a, c);
  this.pb = b;
  this.sourceId = e;
};
la(tl, ql);
tl.prototype.Jz = function() {
  this.pb.reject(vl);
};
var wl = function(a, b) {
  this.type = "cast_app";
  this.originId = window["castApp.eventPage.Message.OriginID"] || void 0;
  this.subtype = a;
  this.devices = b;
  this.logRecord = this.deviceJustSetUp = void 0;
};
m("castApp.eventPage.Message", wl, void 0);
var xl = function(a, b, c) {
  this.ipAddress = a;
  this.appId = b;
  this.sessionId = c;
};
wl.DeviceData = xl;
wl.DeviceJustSetUp = function(a, b, c, e) {
  this.ipAddress = a;
  this.name = b;
  this.udn = c;
  this.modelName = e;
};
wl.DeviceCapabilities = function() {
};
wl.LogRecord = function(a, b, c, e) {
  this.levelValue = a;
  this.msg = b;
  this.loggerName = c;
  this.time = e;
};
var yl = function(a, b) {
  this.Cc = a;
  this.qd = b;
  this.gl = new I;
  this.fl = new Ae;
  this.rJ = 0;
  this.D2 = new I("serviceCheck", this.l0.bind(this), "startDeviceMonitor", this.y0.bind(this), "releaseDeviceMonitor", this.f0.bind(this), "deviceJustSetUp", this.O_.bind(this), "logRecord", this.V_.bind(this));
  chrome.runtime.onMessage.addListener(this.$_.bind(this));
  chrome.runtime.onMessageExternal.addListener(this.R_.bind(this));
  this.Nf("serviceReady");
};
d = yl.prototype;
d.a = D("castApp.eventPage.Service");
d.iQ = 3E4;
d.r0 = function() {
  if (this.rE()) {
    var a = new Ae;
    oe(this.Cc.hj(), function(b) {
      var c = b.qa;
      a.add(c);
      this.gl.Ma(c) || this.qd.sendRequest(new ml, b, Hk);
    }.bind(this));
    var b = !1;
    this.gl.ub().forEach(function(c) {
      a.contains(c) || (this.gl.remove(c), b = !0);
    }.bind(this));
    b && this.mw();
  }
};
d.J_ = function(a, b) {
  if (this.rE() && Lk.hasOwnProperty(b.namespace_) && (a = a.qa) && (b = JSON.parse(b.data), "RECEIVER_STATUS" === b.type)) {
    var c = b.status && b.status.applications && b.status.applications[0], e = b = null;
    c && (c.appId && (b = c.appId), c.sessionId && (e = c.sessionId));
    c = this.gl.get(a);
    this.gl.set(a, new xl(a, b, e));
    c && c.appId === b || this.mw();
  }
};
d.rE = function() {
  if (0 === this.fl.V()) {
    return !1;
  }
  var a = v();
  a - this.rJ > this.iQ && (this.rJ = a, chrome.tabs.query({url:["chrome://cast/*", "chrome-extension://" + chrome.runtime.id + "/cast_setup/*"]}, function(a) {
    0 === a.length ? (this.a.info("No tabs found. Clearing device monitor clients."), this.fl.clear()) : this.a.info(function() {
      return "Tab check found active tabs: " + a.map(function(a) {
        return a.id;
      });
    });
  }.bind(this)));
  a = this.fl.V();
  this.a.info("Monitor client count: " + a);
  return 0 < a;
};
d.$_ = function(a, b, c) {
  if ("object" !== typeof a || "cast_app" !== a.type) {
    return !1;
  }
  var e = this.D2.get(a.subtype);
  if (!e) {
    return !1;
  }
  if (!a.originId) {
    return Xa("Missing origin ID in the incoming message."), !1;
  }
  try {
    var f = e(a, b, c);
    f && c(f);
  } catch (g) {
    this.a.error("Error while handling request", g);
  }
  return !1;
};
d.Nf = function(a, b) {
  var c = new wl(a, b);
  this.a.w(function() {
    return "Sending message: " + JSON.stringify(c);
  });
  chrome.runtime.sendMessage(c);
};
d.l0 = function() {
  this.Nf("serviceReady");
};
d.y0 = function(a) {
  this.fl.contains(x(a.originId)) ? this.a.info("Client: " + a.originId + "already registered, dispatching current device list.") : (this.a.info("Registering monitor client: " + a.originId), this.fl.add(x(a.originId)));
  this.mw();
  this.N6();
};
d.f0 = function(a) {
  this.a.info("Unregistering monitor client: " + a.originId);
  this.fl.remove(x(a.originId));
};
d.O_ = function(a) {
  a = x(a.deviceJustSetUp);
  var b = a.udn.replace(/-/g, "").toLowerCase(), c;
  a.capabilities && (c = (a.capabilities.audioOutSupported ? 4 : 0) | (a.capabilities.videoOutSupported ? 1 : 0));
  c = new Pk(b, a.name, a.modelName, c, a.ipAddress, hk.W().Qk || 8009);
  this.Cc.Bw(c, !0);
};
d.V_ = function(a) {
  a = x(a.logRecord);
  Fc({level:Ic(a.levelValue), m:a.loggerName, time:a.time, message:a.msg});
};
d.mw = function() {
  var a = this.gl.H();
  this.Nf("devices", a);
};
d.N6 = function() {
  this.Cc.refresh();
  this.Cc.Xd().forEach(function(a) {
    this.qd.sendRequest(new ml, a, Hk);
  }.bind(this));
};
d.R_ = function(a, b, c) {
  switch(a.type) {
    case "handshake":
      c(new Ek("handshake"));
      break;
    case "launch":
      b = b.tab && t(b.tab.id) ? b.tab.id : null, null === b || "setup" !== a.entryPoint && "offers" !== a.entryPoint && "devices" !== a.entryPoint || chrome.tabs.update(b, {url:"chrome://cast#" + a.entryPoint});
  }
};
chrome.cast.Xf = {CUSTOM_CONTROLLER_SCOPED:"custom_controller_scoped", TAB_AND_ORIGIN_SCOPED:"tab_and_origin_scoped", ORIGIN_SCOPED:"origin_scoped", PAGE_SCOPED:"page_scoped"};
m("chrome.cast.AutoJoinPolicy", chrome.cast.Xf, void 0);
chrome.cast.Hq = {CREATE_SESSION:"create_session", CAST_THIS_TAB:"cast_this_tab"};
m("chrome.cast.DefaultActionPolicy", chrome.cast.Hq, void 0);
chrome.cast.dh = {VIDEO_OUT:"video_out", AUDIO_OUT:"audio_out", VIDEO_IN:"video_in", AUDIO_IN:"audio_in", MULTIZONE_GROUP:"multizone_group"};
m("chrome.cast.Capability", chrome.cast.dh, void 0);
chrome.cast.Yf = {CANCEL:"cancel", TIMEOUT:"timeout", API_NOT_INITIALIZED:"api_not_initialized", INVALID_PARAMETER:"invalid_parameter", EXTENSION_NOT_COMPATIBLE:"extension_not_compatible", EXTENSION_MISSING:"extension_missing", RECEIVER_UNAVAILABLE:"receiver_unavailable", SESSION_ERROR:"session_error", CHANNEL_ERROR:"channel_error", LOAD_MEDIA_FAILED:"load_media_failed"};
m("chrome.cast.ErrorCode", chrome.cast.Yf, void 0);
chrome.cast.EQ = {AVAILABLE:"available", UNAVAILABLE:"unavailable"};
m("chrome.cast.ReceiverAvailability", chrome.cast.EQ, void 0);
chrome.cast.RQ = {CHROME:"chrome", IOS:"ios", ANDROID:"android"};
m("chrome.cast.SenderPlatform", chrome.cast.RQ, void 0);
chrome.cast.Jq = {CAST:"cast", DIAL:"dial", HANGOUT:"hangout", CUSTOM:"custom"};
m("chrome.cast.ReceiverType", chrome.cast.Jq, void 0);
chrome.cast.RP = {RUNNING:"running", STOPPED:"stopped", ERROR:"error"};
m("chrome.cast.DialAppState", chrome.cast.RP, void 0);
chrome.cast.qn = {CAST:"cast", STOP:"stop"};
m("chrome.cast.ReceiverAction", chrome.cast.qn, void 0);
chrome.cast.eD = {CONNECTED:"connected", DISCONNECTED:"disconnected", STOPPED:"stopped"};
m("chrome.cast.SessionStatus", chrome.cast.eD, void 0);
chrome.cast.JP = function(a, b, c, e, f) {
  this.sessionRequest = a;
  this.sessionListener = b;
  this.receiverListener = c;
  this.autoJoinPolicy = e || chrome.cast.Xf.TAB_AND_ORIGIN_SCOPED;
  this.defaultActionPolicy = f || chrome.cast.Hq.CREATE_SESSION;
  this.customDialLaunchCallback = null;
  this.invisibleSender = !1;
  this.additionalSessionRequests = [];
};
m("chrome.cast.ApiConfig", chrome.cast.JP, void 0);
chrome.cast.TP = function(a, b) {
  this.appName = a;
  this.launchParameter = b || null;
};
m("chrome.cast.DialRequest", chrome.cast.TP, void 0);
chrome.cast.XC = function(a, b, c) {
  this.receiver = a;
  this.appState = b;
  this.extraData = c || null;
};
m("chrome.cast.DialLaunchData", chrome.cast.XC, void 0);
chrome.cast.SP = function(a, b) {
  this.doLaunch = a;
  this.launchParameter = b || null;
};
m("chrome.cast.DialLaunchResponse", chrome.cast.SP, void 0);
chrome.cast.dD = function(a, b, c) {
  this.appId = a;
  this.capabilities = sa(b) ? b : [chrome.cast.dh.VIDEO_OUT, chrome.cast.dh.AUDIO_OUT];
  this.requestSessionTimeout = c || chrome.cast.timeout.requestSession;
  this.dialRequest = this.language = null;
};
m("chrome.cast.SessionRequest", chrome.cast.dD, void 0);
chrome.cast.Ev = function(a, b, c, e) {
  this.label = a;
  a = b;
  Oa.test(a) && (-1 != a.indexOf("&") && (a = a.replace(Ia, "&amp;")), -1 != a.indexOf("<") && (a = a.replace(Ja, "&lt;")), -1 != a.indexOf(">") && (a = a.replace(Ka, "&gt;")), -1 != a.indexOf('"') && (a = a.replace(La, "&quot;")), -1 != a.indexOf("'") && (a = a.replace(Ma, "&#39;")), -1 != a.indexOf("\x00") && (a = a.replace(Na, "&#0;")));
  this.friendlyName = a;
  this.capabilities = c || [];
  this.volume = e || null;
  this.receiverType = chrome.cast.Jq.CAST;
  this.displayStatus = this.isActiveInput = null;
};
m("chrome.cast.Receiver", chrome.cast.Ev, void 0);
chrome.cast.FQ = function(a, b) {
  this.statusText = a;
  this.appImages = b;
  this.showStop = null;
};
m("chrome.cast.ReceiverDisplayStatus", chrome.cast.FQ, void 0);
chrome.cast.hD = function() {
  this.requestSession = 60000;
  this.sendCustomMessage = this.setReceiverVolume = this.stopSession = this.leaveSession = 3000;
};
m("chrome.cast.Timeout", chrome.cast.hD, void 0);
chrome.cast.timeout = new chrome.cast.hD;
m("chrome.cast.timeout", chrome.cast.timeout, void 0);
chrome.cast.IP = "auto-join";
chrome.cast.bD = "cast-session_";
chrome.cast.media.pn = {PAUSE:"pause", SEEK:"seek", STREAM_VOLUME:"stream_volume", STREAM_MUTE:"stream_mute"};
m("chrome.cast.media.MediaCommand", chrome.cast.media.pn, void 0);
chrome.cast.media.re = {GENERIC:0, MOVIE:1, TV_SHOW:2, MUSIC_TRACK:3, PHOTO:4};
m("chrome.cast.media.MetadataType", chrome.cast.media.re, void 0);
chrome.cast.media.Iq = {IDLE:"IDLE", PLAYING:"PLAYING", PAUSED:"PAUSED", BUFFERING:"BUFFERING"};
m("chrome.cast.media.PlayerState", chrome.cast.media.Iq, void 0);
chrome.cast.media.Fv = {OFF:"REPEAT_OFF", ALL:"REPEAT_ALL", SINGLE:"REPEAT_SINGLE", ALL_AND_SHUFFLE:"REPEAT_ALL_AND_SHUFFLE"};
m("chrome.cast.media.RepeatMode", chrome.cast.media.Fv, void 0);
chrome.cast.media.GQ = {PLAYBACK_START:"PLAYBACK_START", PLAYBACK_PAUSE:"PLAYBACK_PAUSE"};
m("chrome.cast.media.ResumeState", chrome.cast.media.GQ, void 0);
chrome.cast.media.fD = {BUFFERED:"BUFFERED", LIVE:"LIVE", OTHER:"OTHER"};
m("chrome.cast.media.StreamType", chrome.cast.media.fD, void 0);
chrome.cast.media.aQ = {CANCELLED:"CANCELLED", INTERRUPTED:"INTERRUPTED", FINISHED:"FINISHED", ERROR:"ERROR"};
m("chrome.cast.media.IdleReason", chrome.cast.media.aQ, void 0);
chrome.cast.media.bR = {TEXT:"TEXT", AUDIO:"AUDIO", VIDEO:"VIDEO"};
m("chrome.cast.media.TrackType", chrome.cast.media.bR, void 0);
chrome.cast.media.ZQ = {SUBTITLES:"SUBTITLES", CAPTIONS:"CAPTIONS", DESCRIPTIONS:"DESCRIPTIONS", CHAPTERS:"CHAPTERS", METADATA:"METADATA"};
m("chrome.cast.media.TextTrackType", chrome.cast.media.ZQ, void 0);
chrome.cast.media.VQ = {NONE:"NONE", OUTLINE:"OUTLINE", DROP_SHADOW:"DROP_SHADOW", RAISED:"RAISED", DEPRESSED:"DEPRESSED"};
m("chrome.cast.media.TextTrackEdgeType", chrome.cast.media.VQ, void 0);
chrome.cast.media.$Q = {NONE:"NONE", NORMAL:"NORMAL", ROUNDED_CORNERS:"ROUNDED_CORNERS"};
m("chrome.cast.media.TextTrackWindowType", chrome.cast.media.$Q, void 0);
chrome.cast.media.WQ = {SANS_SERIF:"SANS_SERIF", MONOSPACED_SANS_SERIF:"MONOSPACED_SANS_SERIF", SERIF:"SERIF", MONOSPACED_SERIF:"MONOSPACED_SERIF", CASUAL:"CASUAL", CURSIVE:"CURSIVE", SMALL_CAPITALS:"SMALL_CAPITALS"};
m("chrome.cast.media.TextTrackFontGenericFamily", chrome.cast.media.WQ, void 0);
chrome.cast.media.XQ = {NORMAL:"NORMAL", BOLD:"BOLD", BOLD_ITALIC:"BOLD_ITALIC", ITALIC:"ITALIC"};
m("chrome.cast.media.TextTrackFontStyle", chrome.cast.media.XQ, void 0);
chrome.cast.media.YP = function() {
  this.customData = null;
};
m("chrome.cast.media.GetStatusRequest", chrome.cast.media.YP, void 0);
chrome.cast.media.rQ = function() {
  this.customData = null;
};
m("chrome.cast.media.PauseRequest", chrome.cast.media.rQ, void 0);
chrome.cast.media.tQ = function() {
  this.customData = null;
};
m("chrome.cast.media.PlayRequest", chrome.cast.media.tQ, void 0);
chrome.cast.media.PQ = function() {
  this.customData = this.resumeState = this.currentTime = null;
};
m("chrome.cast.media.SeekRequest", chrome.cast.media.PQ, void 0);
chrome.cast.media.SQ = function() {
  this.customData = null;
};
m("chrome.cast.media.StopRequest", chrome.cast.media.SQ, void 0);
chrome.cast.media.eR = function(a) {
  this.volume = a;
  this.customData = null;
};
m("chrome.cast.media.VolumeRequest", chrome.cast.media.eR, void 0);
chrome.cast.media.dQ = function(a) {
  this.type = "LOAD";
  this.requestId = 0;
  this.sessionId = null;
  this.media = a;
  this.activeTrackIds = null;
  this.autoplay = !0;
  this.customData = this.currentTime = null;
};
m("chrome.cast.media.LoadRequest", chrome.cast.media.dQ, void 0);
chrome.cast.media.Rga = function(a) {
  this.type = "PRECACHE";
  this.requestId = 0;
  this.data = a;
};
chrome.cast.media.VP = function(a, b) {
  this.requestId = 0;
  this.activeTrackIds = a || null;
  this.textTrackStyle = b || null;
};
m("chrome.cast.media.EditTracksInfoRequest", chrome.cast.media.VP, void 0);
chrome.cast.media.XP = function() {
  this.metadataType = this.type = chrome.cast.media.re.GENERIC;
  this.releaseDate = this.releaseYear = this.images = this.subtitle = this.title = null;
};
m("chrome.cast.media.GenericMediaMetadata", chrome.cast.media.XP, void 0);
chrome.cast.media.kQ = function() {
  this.metadataType = this.type = chrome.cast.media.re.MOVIE;
  this.releaseDate = this.releaseYear = this.images = this.subtitle = this.studio = this.title = null;
};
m("chrome.cast.media.MovieMediaMetadata", chrome.cast.media.kQ, void 0);
chrome.cast.media.cR = function() {
  this.metadataType = this.type = chrome.cast.media.re.TV_SHOW;
  this.originalAirdate = this.releaseYear = this.images = this.episode = this.episodeNumber = this.season = this.seasonNumber = this.episodeTitle = this.title = this.seriesTitle = null;
};
m("chrome.cast.media.TvShowMediaMetadata", chrome.cast.media.cR, void 0);
chrome.cast.media.lQ = function() {
  this.metadataType = this.type = chrome.cast.media.re.MUSIC_TRACK;
  this.releaseDate = this.releaseYear = this.images = this.discNumber = this.trackNumber = this.artistName = this.songName = this.composer = this.artist = this.albumArtist = this.title = this.albumName = null;
};
m("chrome.cast.media.MusicTrackMediaMetadata", chrome.cast.media.lQ, void 0);
chrome.cast.media.sQ = function() {
  this.metadataType = this.type = chrome.cast.media.re.PHOTO;
  this.creationDateTime = this.height = this.width = this.longitude = this.latitude = this.images = this.location = this.artist = this.title = null;
};
m("chrome.cast.media.PhotoMediaMetadata", chrome.cast.media.sQ, void 0);
chrome.cast.media.jQ = function(a, b) {
  this.contentId = a;
  this.streamType = chrome.cast.media.fD.BUFFERED;
  this.contentType = b;
  this.customData = this.textTrackStyle = this.tracks = this.duration = this.metadata = null;
};
m("chrome.cast.media.MediaInfo", chrome.cast.media.jQ, void 0);
chrome.cast.media.vQ = function(a) {
  this.itemId = null;
  this.media = a;
  this.autoplay = !0;
  this.startTime = 0;
  this.playbackDuration = null;
  this.preloadTime = 0;
  this.customData = this.activeTrackIds = null;
};
m("chrome.cast.media.QueueItem", chrome.cast.media.vQ, void 0);
chrome.cast.media.PP = "CC1AD845";
m("chrome.cast.media.DEFAULT_MEDIA_RECEIVER_APP_ID", chrome.cast.media.PP, void 0);
chrome.cast.media.timeout = {};
m("chrome.cast.media.timeout", chrome.cast.media.timeout, void 0);
chrome.cast.media.timeout.load = 0;
chrome.cast.media.timeout.load = chrome.cast.media.timeout.load;
chrome.cast.media.timeout.Ra = 0;
chrome.cast.media.timeout.getStatus = chrome.cast.media.timeout.Ra;
chrome.cast.media.timeout.play = 0;
chrome.cast.media.timeout.play = chrome.cast.media.timeout.play;
chrome.cast.media.timeout.pause = 0;
chrome.cast.media.timeout.pause = chrome.cast.media.timeout.pause;
chrome.cast.media.timeout.seek = 0;
chrome.cast.media.timeout.seek = chrome.cast.media.timeout.seek;
chrome.cast.media.timeout.stop = 0;
chrome.cast.media.timeout.stop = chrome.cast.media.timeout.stop;
chrome.cast.media.timeout.Im = 0;
chrome.cast.media.timeout.setVolume = chrome.cast.media.timeout.Im;
chrome.cast.media.timeout.fx = 0;
chrome.cast.media.timeout.editTracksInfo = chrome.cast.media.timeout.fx;
chrome.cast.media.timeout.q6 = 0;
chrome.cast.media.timeout.queue = chrome.cast.media.timeout.q6;
chrome.cast.media.aR = function(a, b) {
  this.trackId = a;
  this.trackContentType = this.trackContentId = null;
  this.type = b;
  this.customData = this.subtype = this.language = this.name = null;
};
m("chrome.cast.media.Track", chrome.cast.media.aR, void 0);
chrome.cast.media.YQ = function() {
  this.customData = this.fontStyle = this.fontGenericFamily = this.fontFamily = this.fontScale = this.windowRoundedCornerRadius = this.windowColor = this.windowType = this.edgeColor = this.edgeType = this.backgroundColor = this.foregroundColor = null;
};
m("chrome.cast.media.TextTrackStyle", chrome.cast.media.YQ, void 0);
chrome.cast.media.xQ = function(a) {
  this.type = "QUEUE_LOAD";
  this.sessionId = this.requestId = null;
  this.items = a;
  this.startIndex = 0;
  this.repeatMode = chrome.cast.media.Fv.OFF;
  this.customData = null;
};
m("chrome.cast.media.QueueLoadRequest", chrome.cast.media.xQ, void 0);
chrome.cast.media.uQ = function(a) {
  this.type = "QUEUE_INSERT";
  this.sessionId = this.requestId = null;
  this.items = a;
  this.customData = this.insertBefore = null;
};
m("chrome.cast.media.QueueInsertItemsRequest", chrome.cast.media.uQ, void 0);
chrome.cast.media.BQ = function(a) {
  this.type = "QUEUE_UPDATE";
  this.sessionId = this.requestId = null;
  this.items = a;
  this.customData = null;
};
m("chrome.cast.media.QueueUpdateItemsRequest", chrome.cast.media.BQ, void 0);
chrome.cast.media.wQ = function() {
  this.type = "QUEUE_UPDATE";
  this.customData = this.jump = this.currentItemId = this.sessionId = this.requestId = null;
};
m("chrome.cast.media.QueueJumpRequest", chrome.cast.media.wQ, void 0);
chrome.cast.media.AQ = function() {
  this.type = "QUEUE_UPDATE";
  this.customData = this.repeatMode = this.sessionId = this.requestId = null;
};
m("chrome.cast.media.QueueSetPropertiesRequest", chrome.cast.media.AQ, void 0);
chrome.cast.media.yQ = function(a) {
  this.type = "QUEUE_REMOVE";
  this.sessionId = this.requestId = null;
  this.itemIds = a;
  this.customData = null;
};
m("chrome.cast.media.QueueRemoveItemsRequest", chrome.cast.media.yQ, void 0);
chrome.cast.media.zQ = function(a) {
  this.type = "QUEUE_REORDER";
  this.sessionId = this.requestId = null;
  this.itemIds = a;
  this.customData = this.insertBefore = null;
};
m("chrome.cast.media.QueueReorderItemsRequest", chrome.cast.media.zQ, void 0);
chrome.cast.media.v = function(a, b) {
  this.sessionId = a;
  this.mediaSessionId = b;
  this.media = null;
  this.playbackRate = 1.0;
  this.playerState = chrome.cast.media.Iq.IDLE;
  this.currentTime = 0.0;
  this.jJ = -1;
  this.supportedMediaCommands = [];
  this.volume = new chrome.cast.Volume;
  this.items = this.preloadedItemId = this.loadingItemId = this.currentItemId = this.customData = this.activeTrackIds = this.idleReason = null;
  this.repeatMode = chrome.cast.media.Fv.OFF;
};
m("chrome.cast.media.Media", chrome.cast.media.v, void 0);
chrome.cast.media.v.prototype.Ra = function() {
};
chrome.cast.media.v.prototype.getStatus = chrome.cast.media.v.prototype.Ra;
chrome.cast.media.v.prototype.play = function() {
  x(zl);
};
chrome.cast.media.v.prototype.play = chrome.cast.media.v.prototype.play;
chrome.cast.media.v.prototype.U5 = function() {
};
chrome.cast.media.v.prototype.playWithContext = chrome.cast.media.v.prototype.U5;
chrome.cast.media.v.prototype.pause = function() {
  x(zl);
};
chrome.cast.media.v.prototype.pause = chrome.cast.media.v.prototype.pause;
chrome.cast.media.v.prototype.M5 = function() {
};
chrome.cast.media.v.prototype.pauseWithContext = chrome.cast.media.v.prototype.M5;
chrome.cast.media.v.prototype.seek = function() {
};
chrome.cast.media.v.prototype.seek = chrome.cast.media.v.prototype.seek;
chrome.cast.media.v.prototype.stop = function() {
};
chrome.cast.media.v.prototype.stop = chrome.cast.media.v.prototype.stop;
chrome.cast.media.v.prototype.Im = function() {
};
chrome.cast.media.v.prototype.setVolume = chrome.cast.media.v.prototype.Im;
chrome.cast.media.v.prototype.fx = function() {
};
chrome.cast.media.v.prototype.editTracksInfo = chrome.cast.media.v.prototype.fx;
chrome.cast.media.v.prototype.t6 = function() {
};
chrome.cast.media.v.prototype.queueInsertItems = chrome.cast.media.v.prototype.t6;
chrome.cast.media.v.prototype.r6 = function() {
};
chrome.cast.media.v.prototype.queueAppendItem = chrome.cast.media.v.prototype.r6;
chrome.cast.media.v.prototype.D6 = function() {
};
chrome.cast.media.v.prototype.queueUpdateItems = chrome.cast.media.v.prototype.D6;
chrome.cast.media.v.prototype.y6 = function() {
};
chrome.cast.media.v.prototype.queuePrev = chrome.cast.media.v.prototype.y6;
chrome.cast.media.v.prototype.x6 = function() {
};
chrome.cast.media.v.prototype.queueNext = chrome.cast.media.v.prototype.x6;
chrome.cast.media.v.prototype.u6 = function(a) {
  this.Rx(a);
};
chrome.cast.media.v.prototype.queueJumpToItem = chrome.cast.media.v.prototype.u6;
chrome.cast.media.v.prototype.C6 = function() {
};
chrome.cast.media.v.prototype.queueSetRepeatMode = chrome.cast.media.v.prototype.C6;
chrome.cast.media.v.prototype.A6 = function() {
};
chrome.cast.media.v.prototype.queueRemoveItems = chrome.cast.media.v.prototype.A6;
chrome.cast.media.v.prototype.z6 = function(a) {
  this.Rx(a);
};
chrome.cast.media.v.prototype.queueRemoveItem = chrome.cast.media.v.prototype.z6;
chrome.cast.media.v.prototype.B6 = function() {
};
chrome.cast.media.v.prototype.queueReorderItems = chrome.cast.media.v.prototype.B6;
chrome.cast.media.v.prototype.w6 = function(a, b, c, e) {
  a = this.Rx(a);
  0 > a || (0 > b ? e && e(new chrome.cast.Error(chrome.cast.Yf.INVALID_PARAMETER)) : a == b && c && c());
};
chrome.cast.media.v.prototype.queueMoveItemToNewIndex = chrome.cast.media.v.prototype.w6;
chrome.cast.media.v.prototype.Pba = function(a) {
  return -1 < this.supportedMediaCommands.indexOf(a);
};
chrome.cast.media.v.prototype.supportsCommand = chrome.cast.media.v.prototype.Pba;
chrome.cast.media.v.prototype.hX = function() {
  if (this.playerState == chrome.cast.media.Iq.PLAYING && 0 <= this.jJ) {
    var a = this.currentTime + (Date.now() - this.jJ) / 1000 * this.playbackRate;
    this.media && null != this.media.duration && a > this.media.duration && (a = this.media.duration);
    0 > a && (a = 0);
    return a;
  }
  return this.currentTime;
};
chrome.cast.media.v.prototype.getEstimatedTime = chrome.cast.media.v.prototype.hX;
chrome.cast.media.v.prototype.Sv = function() {
  x(zl);
};
chrome.cast.media.v.prototype.addUpdateListener = chrome.cast.media.v.prototype.Sv;
chrome.cast.media.v.prototype.Tv = function() {
};
chrome.cast.media.v.prototype.addUpdateListenerWithContext = chrome.cast.media.v.prototype.Tv;
chrome.cast.media.v.prototype.JA = function() {
  x(zl);
};
chrome.cast.media.v.prototype.removeUpdateListener = chrome.cast.media.v.prototype.JA;
chrome.cast.media.v.prototype.KA = function() {
};
chrome.cast.media.v.prototype.removeUpdateListenerWithContext = chrome.cast.media.v.prototype.KA;
chrome.cast.media.v.prototype.Rx = function(a) {
  return lb(this.items, function(b) {
    return b.itemId == a;
  });
};
var Al = function(a, b, c) {
  this.sessionId = a;
  this.namespaceName = b;
  this.message = c;
};
var Bl = function(a) {
  this.qd = a;
  this.a = D("mr.cast.ReceiverStatusQuerier");
};
Bl.prototype.xba = function(a) {
  var b = this;
  return (new Ce(u(this.p6, this, a), 3500, 5)).pu(2).start().then(null, function(c) {
    b.a.info("Failed to get receiver status from " + a.getId());
    throw c;
  });
};
Bl.prototype.p6 = function(a) {
  this.a.info("Query receiver status: " + a.getId());
  return this.qd.sendRequest(new ml, a, Hk);
};
var zl = null;
var Cl = function(a, b) {
  this.type = "SET_VOLUME";
  this.requestId = 0;
  this.volume = a;
  this.expectedVolume = b || null;
};
chrome.cast.D = function(a, b, c, e, f) {
  this.sessionId = a;
  this.appId = b;
  this.displayName = c;
  this.statusText = null;
  this.appImages = e;
  this.receiver = f;
  this.senderApps = [];
  this.namespaces = [];
  this.media = [];
  this.status = chrome.cast.eD.CONNECTED;
  this.transportId = "";
};
m("chrome.cast.Session", chrome.cast.D, void 0);
chrome.cast.D.prototype.Y$ = function(a, b, c) {
  this.EN(x(zl), a, b, c);
};
chrome.cast.D.prototype.setReceiverVolumeLevel = chrome.cast.D.prototype.Y$;
chrome.cast.D.prototype.EN = function(a, b, c, e) {
  b = new Cl(new chrome.cast.Volume(b, null), this.receiver.volume);
  a.setReceiverVolume(this.sessionId, b, c, e);
};
chrome.cast.D.prototype.setReceiverVolumeLevelWithContext = chrome.cast.D.prototype.EN;
chrome.cast.D.prototype.X$ = function(a, b, c) {
  this.DN(x(zl), a, b, c);
};
chrome.cast.D.prototype.setReceiverMuted = chrome.cast.D.prototype.X$;
chrome.cast.D.prototype.DN = function(a, b, c, e) {
  a = new Cl(new chrome.cast.Volume(null, b), this.receiver.volume);
  zl.setReceiverVolume(this.sessionId, a, c, e);
};
chrome.cast.D.prototype.setReceiverMutedWithContext = chrome.cast.D.prototype.DN;
chrome.cast.D.prototype.leave = function(a, b) {
  zl.leaveSession(this.sessionId, a, b);
};
chrome.cast.D.prototype.leave = chrome.cast.D.prototype.leave;
chrome.cast.D.prototype.stop = function() {
  x(zl);
};
chrome.cast.D.prototype.stop = chrome.cast.D.prototype.stop;
chrome.cast.D.prototype.Hba = function() {
};
chrome.cast.D.prototype.stopWithContext = chrome.cast.D.prototype.Hba;
chrome.cast.D.prototype.sendMessage = function() {
  x(zl);
};
chrome.cast.D.prototype.sendMessage = chrome.cast.D.prototype.sendMessage;
chrome.cast.D.prototype.t8 = function() {
};
chrome.cast.D.prototype.sendMessageWithContext = chrome.cast.D.prototype.t8;
chrome.cast.D.prototype.Sv = function() {
  x(zl);
};
chrome.cast.D.prototype.addUpdateListener = chrome.cast.D.prototype.Sv;
chrome.cast.D.prototype.Tv = function() {
};
chrome.cast.D.prototype.addUpdateListenerWithContext = chrome.cast.D.prototype.Tv;
chrome.cast.D.prototype.JA = function() {
  x(zl);
};
chrome.cast.D.prototype.removeUpdateListener = chrome.cast.D.prototype.JA;
chrome.cast.D.prototype.KA = function() {
};
chrome.cast.D.prototype.removeUpdateListenerWithContext = chrome.cast.D.prototype.KA;
chrome.cast.D.prototype.wR = function() {
  x(zl);
};
chrome.cast.D.prototype.addMessageListener = chrome.cast.D.prototype.wR;
chrome.cast.D.prototype.xR = function() {
};
chrome.cast.D.prototype.addMessageListenerWithContext = chrome.cast.D.prototype.xR;
chrome.cast.D.prototype.tD = function(a) {
  this.uD(x(zl), a);
};
chrome.cast.D.prototype.addMediaListener = chrome.cast.D.prototype.tD;
chrome.cast.D.prototype.uD = function(a, b) {
  a.tD(this.sessionId, b);
};
chrome.cast.D.prototype.addMediaListenerWithContext = chrome.cast.D.prototype.uD;
chrome.cast.D.prototype.KL = function(a) {
  this.LL(x(zl), a);
};
chrome.cast.D.prototype.removeMediaListener = chrome.cast.D.prototype.KL;
chrome.cast.D.prototype.LL = function(a, b) {
  a.KL(this.sessionId, b);
};
chrome.cast.D.prototype.removeMediaListenerWithContext = chrome.cast.D.prototype.LL;
chrome.cast.D.prototype.l7 = function() {
  x(zl);
};
chrome.cast.D.prototype.removeMessageListener = chrome.cast.D.prototype.l7;
chrome.cast.D.prototype.m7 = function() {
};
chrome.cast.D.prototype.removeMessageListenerWithContext = chrome.cast.D.prototype.m7;
chrome.cast.D.prototype.Z1 = function(a) {
  a.sessionId = this.sessionId;
};
chrome.cast.D.prototype.loadMedia = chrome.cast.D.prototype.Z1;
chrome.cast.D.prototype.v6 = function(a) {
  a.sessionId = this.sessionId;
};
chrome.cast.D.prototype.queueLoad = chrome.cast.D.prototype.v6;
var Fl = function(a, b) {
  if (!b.applications || 1 != b.applications.length) {
    return null;
  }
  var c = b.applications[0];
  a = Dl(a);
  a = new chrome.cast.D(c.sessionId, c.appId, c.displayName, c.appImages, a);
  a.senderApps = c.senderApps;
  a.namespaces = c.namespaces || [];
  a.transportId = c.transportId;
  a.statusText = c.statusText;
  if (!a.sessionId || !(a.namespaces && 0 != a.namespaces.length || El(a))) {
    return null;
  }
  a.receiver.volume = b.volume;
  "boolean" == typeof b.isActiveInput && (a.receiver.isActiveInput = b.isActiveInput);
  return a;
}, Gl = function(a) {
  var b = [];
  if (!a) {
    return b;
  }
  a & 1 && b.push(chrome.cast.dh.VIDEO_OUT);
  a & 2 && b.push(chrome.cast.dh.VIDEO_IN);
  a & 4 && b.push(chrome.cast.dh.AUDIO_OUT);
  a & 8 && b.push(chrome.cast.dh.AUDIO_IN);
  a & 32 && b.push(chrome.cast.dh.MULTIZONE_GROUP);
  return b;
}, Dl = function(a) {
  return new chrome.cast.Ev(a.getId(), a.ul(), Gl(a.pd));
}, Hl = function(a, b) {
  if (a.statusText != b.statusText) {
    return !0;
  }
  var c = a.namespaces || [], e = b.namespaces || [];
  if (c.length != e.length) {
    return !0;
  }
  for (var f = {index:0};f.index < c.length;f = {index:f.index}, f.index++) {
    if (!e.some(function(a) {
      return function(b) {
        return b.name == c[a.index].name;
      };
    }(f))) {
      return !0;
    }
  }
  return a.receiver.volume.level !== b.receiver.volume.level || a.receiver.volume.muted !== b.receiver.volume.muted ? !0 : !1;
}, Il = function(a) {
  sa(a) ? a.forEach(Il) : va(a) && Object.keys(a).forEach(function(b) {
    null === a[b] ? delete a[b] : (va(a[b]) || sa(a[b])) && Il(a[b]);
  });
}, Jl = function(a, b) {
  return a.namespaces.some(function(a) {
    return a.name == b;
  });
}, Kl = ["MultizoneLeader", "MultizoneFollower"], El = function(a) {
  return null !== a && "MultizoneLeader" == a.appId;
}, Ll = function(a) {
  return "E8C28D3C" == a || "00000000-0000-0000-0000-000000000000" == a;
};
var Ml = function(a) {
  this.qd = a;
  this.a = D("mr.cast.SessionLauncher");
};
Ml.prototype.gz = function(a, b) {
  ah("MediaRouter.Cast.Session.Type", 0, Sk);
  return this.qd.x7(a, b).then(this.U_.bind(this, b), function(a) {
    a && vl == a ? al(1) : al(0);
    throw a;
  });
};
Ml.prototype.U_ = function(a, b) {
  this.a.w("Got launch result from " + a.getId());
  if ("LAUNCH_ERROR" == b.type) {
    throw al(2), Error(b.reason);
  }
  a = Fl(a, b.status);
  this.a.info("Launched session: " + a.sessionId);
  return a;
};
var Nl = function(a, b, c, e) {
  this.type = a;
  this.message = b;
  this.sequenceNumber = l(c) ? c : -1;
  this.timeoutMillis = e || 0;
  this.clientId = "";
};
var Ol = function(a, b) {
  this.bi = a;
  this.Jb = b;
  this.FJ = [];
  this.Pj = new rl;
};
d = Ol.prototype;
d.gy = function(a) {
  return (a = this.Jb.Zc(a)) ? a.routeId : null;
};
d.listen = function(a, b) {
  this.FJ[a] = b;
};
d.$b = function(a, b, c) {
  Pl.w("Sending to " + b);
  Pl.w(JSON.stringify(c));
  c.clientId = b;
  this.bi.sU(a, c);
};
d.mi = function(a, b) {
  var c = this, e = this.Jb.Zc(a);
  e && e.Ky ? this.$b(e.routeId, a, b) : this.connect(a).then(function(e) {
    e ? (e = c.gy(a)) ? c.$b(e, a, b) : Pl.l("No route for " + a) : Pl.l("No connected client " + a);
  }, null);
};
d.tp = function(a) {
  Pl.w("App " + a);
  var b = this.Jb.Zc(a);
  b ? (b.Ky = !0, (a = this.Pj.Ip(b.routeId)) && a.pb.resolve(!0)) : Pl.l("Client not found " + a);
};
d.X2 = function(a) {
  Pl.w("Received: " + a);
  a = JSON.parse(a);
  var b = a.clientId;
  "client_connect" == a.type ? this.tp(b) : this.gy(b) ? (b = this.FJ[a.type]) && b(a) : Pl.l("No route for " + b);
};
d.connect = function(a) {
  if (this.h1(a)) {
    return Promise.resolve(!0);
  }
  var b = this.gy(a);
  if (!b) {
    return Pl.l("No route for client " + a), Promise.resolve(!1);
  }
  if (a = this.Pj.Kh(b)) {
    return a.pb.promise;
  }
  a = new Jc;
  this.Pj.yD(new Ql(b, a));
  return a.promise;
};
d.h1 = function(a) {
  a = this.Jb.Zc(a);
  return null != a && a.Ky;
};
var Pl = D("mr.cast.ApiMessenger"), Ql = function(a, b) {
  ql.call(this, a, 3E4);
  this.pb = b;
};
la(Ql, ql);
Ql.prototype.Jz = function() {
  this.pb.resolve(!1);
};
var Rl = function(a, b, c, e, f, g, k, q, r, A) {
  this.Zv = a;
  this.Rd = b || null;
  this.Zq = c || null;
  this.Er = e || null;
  this.et = l(f) ? f : null;
  this.$v = g || null;
  this.kF = k || null;
  this.Gy = q || !1;
  this.ow = r || null;
  this.nw = A || null;
}, Sl = function(a, b) {
  return (a = a.match(b + "=([^/]*)")) ? a[1] : null;
}, Ul = function(a) {
  a = a.match(/__castAppId__=([^/]*)/g);
  return null == a ? [] : ib(z(a, function(a) {
    a = Sl(a, "__castAppId__");
    if (!a) {
      return null;
    }
    a = a.match(Tl);
    if (!a || 0 == a.length) {
      return null;
    }
    var b = [];
    3 == a.length && a[2] && (b = a[2].split(","));
    return {appId:a[1], capabilities:b};
  }), function(a) {
    return null != a;
  });
}, Vl = function(a) {
  return Sl(a, "__castClientId__");
};
d = Rl.prototype;
d.eo = function() {
  return z(this.Zv, function(a) {
    return a.appId;
  });
};
d.eG = function() {
  return this.$v;
};
d.rc = function() {
  return this.Rd;
};
d.Ax = function() {
  return this.Zq ? this.Zq : chrome.cast.Xf.TAB_AND_ORIGIN_SCOPED;
};
d.IW = function() {
  return this.Er ? this.Er : chrome.cast.Hq.CREATE_SESSION;
};
d.TX = function() {
  return null == this.et ? chrome.cast.timeout.requestSession : this.et;
};
d.toString = function() {
  var a = new Qj;
  a.Au("https");
  a.Am("google.com");
  a.ni("/cast");
  var b = [];
  y(this.Zv, function(a) {
    var c = "__castAppId__=" + a.appId;
    a.capabilities && 0 < a.capabilities.length && (c = c + "(" + a.capabilities.join(","), c += ")");
    b.push(c);
  });
  this.Rd && b.push("__castClientId__=" + this.Rd);
  this.Zq && b.push("__castAutoJoinPolicy__=" + this.Zq);
  this.Er && b.push("__castDefaultActionPolicy__=" + this.Er);
  null != this.et && b.push("__castLaunchTimeout__=" + this.et);
  this.$v && b.push("__dialAppName__=" + this.$v);
  this.kF && b.push("__dialPostData__=" + this.kF);
  this.Gy && b.push("__castInvisibleSender__=true");
  this.ow && (b.push("__castBroadcastNamespace__=" + this.ow), b.push("__castBroadcastId__=" + Math.random()));
  this.nw && b.push("__castBroadcastMessage__=" + encodeURIComponent(JSON.stringify(this.nw)));
  a.su(b.join("/"));
  return a.toString();
};
d.A1 = function(a) {
  var b = this.eo(), c = Wl(a);
  return jb(b, function(a) {
    return pb(c, a);
  });
};
var Xl = function(a) {
  a = new Qj(a);
  if ("https" != a.Rg || "google.com" != a.Ch() || "/cast" != a.vd()) {
    return null;
  }
  var b = a.Xi;
  a = Ul(b);
  if (!a || 0 == a.length) {
    return null;
  }
  var c = Vl(b), e = Sl(b, "__castAutoJoinPolicy__"), f = Sl(b, "__castDefaultActionPolicy__"), g;
  g = Sl(b, "__castLaunchTimeout__");
  null == g ? g = null : (g = Number(g), g = !isNaN(g) && 0 <= g ? g : null);
  var k = Sl(b, "__dialAppName__"), q = Sl(b, "__dialPostData__"), r = Sl(b, "__castInvisibleSender__"), r = null === r ? null : "true" == r, A = Sl(b, "__castBroadcastNamespace__"), b = (b = Sl(b, "__castBroadcastMessage__")) ? JSON.parse(decodeURIComponent(b)) : null;
  return new Rl(a, c, e, f, g, k, q, r, A, b);
}, Wl = function(a) {
  return (a = Xl(a)) ? a.eo() : null;
}, Yl = function(a) {
  return (a = Xl(a)) ? a.rc() : null;
}, Tl = /(^\w+)(?:\(([\w,\ ]*)\))?$/;
var Zl = function(a, b, c, e, f, g) {
  this.Og = a;
  this.ea = b;
  this.Jb = c;
  this.va = e;
  this.Vc = f;
  this.bi = g;
  this.Pd = new Ol(g, c);
  this.H6 = new Bl(this.Og);
  this.F8 = new Ml(this.Og);
};
d = Zl.prototype;
d.init = function() {
  this.Jb.init();
  this.Pd.listen("v2_message", this.G4.bind(this));
  this.Pd.listen("app_message", this.c3.bind(this));
  this.Pd.listen("leave_session", this.J3.bind(this));
};
d.Ke = function(a, b) {
  this.Pd.X2(b);
};
d.pM = function(a, b, c) {
  var e = this;
  this.va.uG(a).slice().forEach(function(a) {
    a != c && e.$A(a, b);
  });
};
d.$A = function(a, b) {
  b.clientId = a;
  this.Pd.mi(a, b);
};
d.tM = function(a, b, c) {
  b = {receiver:Dl(b), action:c};
  this.$A(a, new Nl("receiver_action", b));
};
d.G4 = function(a) {
  var b = a.message, c = b.sessionId;
  if (c) {
    var e = this.va.ky(c);
    if (e) {
      if (c = this.va.QH(c)) {
        if (c = this.ea.Y(c)) {
          switch(b.type) {
            case "STOP":
              this.Z2(a, c);
              break;
            case "LOAD":
            case "PAUSE":
            case "PLAY":
            case "SEEK":
            case "STOP_MEDIA":
            case "MEDIA_SET_VOLUME":
            case "MEDIA_GET_STATUS":
            case "EDIT_TRACKS_INFO":
            case "QUEUE_LOAD":
            case "QUEUE_INSERT":
            case "QUEUE_UPDATE":
            case "QUEUE_REMOVE":
            case "QUEUE_REORDER":
            case "PRECACHE":
              this.W2(a, c, e);
              break;
            case "SET_VOLUME":
              this.Y2(a, c);
              break;
            default:
              $l.l("Unknown request");
          }
        } else {
          this.wm(a, chrome.cast.Yf.INVALID_PARAMETER, "No receiver");
        }
      } else {
        this.wm(a, chrome.cast.Yf.INVALID_PARAMETER, "No sink ID");
      }
    } else {
      this.wm(a, chrome.cast.Yf.INVALID_PARAMETER, "Unknown session ID");
    }
  } else {
    this.wm(a, chrome.cast.Yf.INVALID_PARAMETER, "No session ID");
  }
};
d.wm = function(a, b, c) {
  b = new chrome.cast.Error(b, c);
  this.ZA(a, b);
};
d.ZA = function(a, b) {
  this.Pd.mi(a.clientId, new Nl("error", b, a.sequenceNumber));
};
d.Z2 = function(a, b) {
  var c = this, e = a.message;
  $g("MediaRouter.Cast.Session.End");
  var f = e.sessionId, g = this.va.Ee(f);
  g && (g.Ts = !0);
  g = function() {
    c.qm(f, a);
  };
  this.Og.sendRequest(e, b, Hk, a.timeoutMillis, Za(a.clientId)).then(g, g);
};
d.W2 = function(a, b, c) {
  var e = this, f = a.message, g = f.type;
  g in ll && (f.type = ll[g]);
  this.Og.sendRequest(f, b, Ik, a.timeoutMillis, a.clientId, c.transportId).then(function(b) {
    e.nL(c, b);
    e.Pd.mi(a.clientId, new Nl("v2_message", b, a.sequenceNumber));
  }, function(b) {
    e.ZA(a, b);
  });
};
d.Y2 = function(a, b) {
  var c = this, e = a.message;
  delete e.sessionId;
  this.Og.sendRequest(e, b, Hk, a.timeoutMillis, a.clientId).then(function() {
    c.Pd.mi(a.clientId, new Nl("v2_message", null, a.sequenceNumber));
  }, function(b) {
    c.ZA(a, b);
  });
};
d.c3 = function(a) {
  var b = this, c = a.message, e = c.sessionId;
  if (e) {
    var f = this.va.QH(e);
    f ? (f = this.ea.Y(f)) ? (e = this.va.ky(e), mb(e.namespaces, function(a) {
      return a.name == c.namespaceName;
    }) ? this.Vc.ku(f, c.namespaceName, c.message, a.clientId, e.transportId).then(function() {
      b.Pd.mi(a.clientId, new Nl("app_message", null, a.sequenceNumber));
    }, function() {
      b.wm(a, chrome.cast.Yf.CHANNEL_ERROR, "Channel to receiver not available");
    }) : this.wm(a, chrome.cast.Yf.INVALID_PARAMETER, "Invalid namespace")) : $l.l("No receiver from sinkId") : $l.l("No sinkId from sessionId");
  } else {
    $l.l("No sessionId");
  }
};
d.Ht = function(a) {
  (a = this.va.Co(a)) && a.session && this.qm(a.session.sessionId);
};
d.J3 = function(a) {
  var b = this;
  $l.info("Leave session");
  var c = this.va.Ee(a.message);
  if (c) {
    var e = a.clientId, f = this.Jb.Zc(e);
    if (f) {
      var g = [], k = [], q = f.tabId, r = f.origin, A = f.autoJoinPolicy;
      c.eg.forEach(function(a) {
        var c = b.Jb.Zc(a);
        A == chrome.cast.Xf.TAB_AND_ORIGIN_SCOPED && q == c.tabId && r == c.origin || A == chrome.cast.Xf.ORIGIN_SCOPED && r == c.origin ? (c.YI = !0, g.push(a)) : k.push(a);
      });
      this.Pd.mi(e, new Nl("leave_session", null, a.sequenceNumber));
      g.forEach(function(a) {
        (a = b.Jb.Zc(a)) && b.bi.Yj(a.routeId, !0, !0);
      });
      c.eg = k;
    } else {
      $l.l("No client record");
    }
  } else {
    $l.l("No session");
  }
};
d.pL = function(a, b) {
  Jl(a, Ik) && this.Og.sendRequest(new ml, b, Ik, void 0, void 0, a.transportId).catch(n);
};
d.qL = function(a, b) {
  var c = this, e = a.getId();
  $l.info("Query status for " + e);
  this.H6.xba(a).then(function(f) {
    c.LK(e, f);
    b && (f = c.va.xs(e)) && c.pL(f, a);
  }, n);
};
d.o4 = function(a, b) {
  Lk.hasOwnProperty(b.namespace_) ? this.l4(a, b) : this.k4(a, b);
};
d.D1 = function(a) {
  if ("*" == a.destinationId) {
    return !0;
  }
  a = a.destinationId;
  if (a == this.Vc.KH() || null != this.Jb.Zc(a)) {
    return !0;
  }
  $l.info("Invalid destination " + a);
  return !1;
};
d.l4 = function(a, b) {
  var c = this;
  $l.w(function() {
    return "Cast message: " + JSON.stringify(b);
  });
  if (this.D1(b)) {
    if (b.namespace_ == Jk) {
      (a = this.va.Co(a)) && a.le.forEach(function(a) {
        c.bi.rU(a, b);
      });
    } else {
      var e = JSON.parse(b.data), f = this.d0(e), f = f ? f.sourceId : void 0;
      switch(e.type) {
        case "RECEIVER_STATUS":
          this.LK(a, e);
          break;
        case "MEDIA_STATUS":
          this.n4(a, b, f);
      }
    }
  } else {
    this.Vc.DE(a, b.destinationId, b.sourceId, !1);
  }
};
d.d0 = function(a) {
  var b = this.Og.Ip(a.requestId);
  if (!b) {
    return null;
  }
  var c = b.pb;
  switch(a.type) {
    case "LAUNCH_ERROR":
    case "INVALID_REQUEST":
    case "LOAD_CANCELLED":
    case "LOAD_FAILED":
    case "INVALID_PLAYER_STATE":
      delete a.requestId;
      c.reject(new chrome.cast.Error(chrome.cast.Yf.SESSION_ERROR, a.reason || a.type, a));
      break;
    default:
      c.resolve(a);
  }
  return b;
};
d.k4 = function(a, b) {
  var c = this;
  $l.w(function() {
    return "App message: " + JSON.stringify(b);
  });
  if (a = this.va.xs(a)) {
    var e;
    e = "*" == b.destinationId ? this.va.uG(a.sessionId) : [b.destinationId];
    var f = new Al(a.sessionId, b.namespace_, b.data);
    e.forEach(function(a) {
      c.Pd.mi(a, new Nl("app_message", f));
    });
  } else {
    $l.l("No session for incoming app message");
  }
};
var am = function(a, b) {
  a.forEach(function(a) {
    a.sessionId = b;
    var c = a.supportedMediaCommands, f = [];
    c & 1 && f.push(chrome.cast.media.pn.PAUSE);
    c & 2 && f.push(chrome.cast.media.pn.SEEK);
    c & 4 && f.push(chrome.cast.media.pn.STREAM_VOLUME);
    c & 8 && f.push(chrome.cast.media.pn.STREAM_MUTE);
    a.supportedMediaCommands = f;
  });
  return a;
};
d = Zl.prototype;
d.nL = function(a, b) {
  a = a.sessionId;
  b.sessionId = a;
  this.va.uaa(a, am(b.status, a));
};
d.T3 = function(a, b, c) {
  this.Pd.mi(c, new Nl("new_session", a));
  this.pL(a, b);
};
d.NL = function(a) {
  if (a = this.va.xs(a)) {
    a = a.sessionId;
    var b = this.va.Ee(a);
    b && b.Ts || this.qm(a);
  }
};
d.qm = function(a, b) {
  var c = this;
  b && this.$A(b.clientId, b);
  (b = this.va.Ee(a)) && b.le.slice().forEach(function(a) {
    c.bi.Yj(a, !0);
  });
  this.va.qm(a);
};
d.LK = function(a, b) {
  $l.w("Receiver status for " + a);
  var c = b.status;
  if (c) {
    if (b = this.ea.Y(a)) {
      var c = Fl(b, c), e = this.va.Co(a);
      e ? c ? c.sessionId == e.session.sessionId ? this.q0(e, c) : (this.sI(a), this.bi.af(null, b, null, c)) : this.sI(a) : c && this.bi.af(null, b, null, c);
    } else {
      $g("MediaRouter.Cast.Error.Sink.Missing.From.Discovery.Service"), $l.l("Got message from receiver " + a + ", but sink is no longer available.");
    }
  }
};
d.q0 = function(a, b) {
  x(a.session.sessionId == b.sessionId);
  var c = a.session;
  Hl(c, b) && ($l.w("Updating session " + b.sessionId), c.statusText = b.statusText, c.namespaces = b.namespaces, c.receiver.volume = b.receiver.volume, this.bi.Eca(a), this.pM(c.sessionId, new Nl("update_session", c)));
};
d.sI = function(a) {
  this.NL(a);
  Yk(1);
};
d.n4 = function(a, b, c) {
  if (a = this.va.xs(a)) {
    if (b = JSON.parse(b.data)) {
      this.nL(a, b), this.pM(b.sessionId, new Nl("v2_message", b), c);
    }
  }
};
d.eT = function(a, b) {
  var c = Gl(b.pd);
  return (b = mb(a.Zv, function(a) {
    return kb(a.capabilities, function(a) {
      return pb(c, a);
    });
  })) ? b.appId : a.eo()[0];
};
d.gz = function(a, b) {
  var c = Xl(a);
  if (!c) {
    return Promise.reject(Error("Invalid source " + a));
  }
  a = this.eT(c, b);
  var e = new Sg("MediaRouter.Cast.Session.Launch");
  return this.F8.gz(new chrome.cast.dD(a, void 0, c.TX()), b).then(function(a) {
    e.end("Success");
    return a;
  }, function(a) {
    e.end("Failure");
    throw a;
  });
};
var $l = D("mr.cast.ApiHandler");
var bm = D("mr.RuntimeErrorUtils"), cm = function() {
  chrome.runtime.lastError && bm.w(chrome.runtime.lastError.message || "unknown runtime error");
};
var dm = function() {
  this.iA = new I;
  this.jA = new I;
  this.xp = new I;
};
d = dm.prototype;
d.Yk = function(a, b) {
  b = void 0 === b ? !1 : b;
  var c = this, e = a.getId(), f = a.qa + ":" + a.Wa(), g = this.iA.get(e);
  if (g) {
    if (this.xp.get(e) == f) {
      return em.w("Using pending creation to " + e), g;
    }
    em.info("Device " + e + " IP changed from " + this.xp.get(a.getId()) + " to " + f);
    this.gR(a);
  }
  a = this.yU(a, b ? 15E3 : 1E4).then(function(a) {
    c.Dw(e);
    Zk(1);
    return a;
  }, function(a) {
    f == c.xp.get(e) && c.Dw(e);
    Zk(0);
    return Promise.reject(a);
  });
  this.iA.set(e, a);
  this.xp.set(e, f);
  return a;
};
d.gR = function(a) {
  a = a.getId();
  em.w("Aborting connection to device " + a);
  var b = this.jA.get(a);
  b && b.abort();
  this.Dw(a);
};
d.Dw = function(a) {
  this.iA.remove(a);
  this.jA.remove(a);
  this.xp.remove(a);
};
d.yU = function(a, b) {
  var c = this, e = new Ce(function() {
    return c.I4(a, b);
  }, 1000, 3);
  this.jA.set(a.getId(), e);
  return e.pu(1.5).start().then(null, function(b) {
    em.info("Failed to create channel to " + a.getId());
    return Promise.reject(b);
  });
};
d.I4 = function(a, b) {
  var c = fm++;
  em.info("Connecting to (id " + c + ") " + a.getId());
  var e = new Sg("MediaRouter.Cast.Mdns.Channel.Open");
  return this.J4(a, b).then(function(a) {
    em.info(function() {
      return "Channel opened (id " + c + "): " + JSON.stringify(a);
    });
    e.end("Success");
    return a;
  }, function(a) {
    em.info("Channel did not open (id " + c + ").");
    e.end("Failure");
    return Promise.reject(a);
  });
};
d.J4 = function(a, b) {
  var c = {ipAddress:a.qa, port:a.Wa(), auth:"ssl_verified", timeout:10000, livenessTimeout:b, pingInterval:5000, capabilities:0};
  em.info(function() {
    return "Opening channel to " + JSON.stringify(c);
  });
  var e = new Jc;
  chrome.cast.channel.open(c, function(a) {
    cm();
    "open" == a.readyState ? e.resolve(a) : (chrome.cast.channel.close(a, function() {
      chrome.runtime.lastError || em.w("Channel close success");
    }), e.reject(Error(a.errorState)));
  });
  return e.promise;
};
var em = D("mr.cast.ChannelFactory"), fm = 0;
var gm = function(a, b, c, e) {
  return {namespace_:a, data:p(b) ? b : JSON.stringify(b), sourceId:c, destinationId:e};
};
var hm = function(a) {
  this.type = "CLOSE";
  this.reasonCode = a;
};
var jm = function(a) {
  this.type = "CONNECT";
  this.origin = {};
  this.userAgent = Vb;
  var b = this.userAgent.indexOf("(") + 1, b = this.userAgent.substr(b, this.userAgent.indexOf(")", b) - 1 - b + 1);
  this.senderInfo = {sdkType:2, version:chrome.runtime.getManifest().version, browserVersion:ck, platform:im(), systemVersion:b, connectionType:1};
  this.connType = a ? 0 : 2;
}, im = function() {
  switch(Og()) {
    case "ChromeOS":
      return 5;
    case "Windows":
      return 3;
    case "Mac":
      return 4;
    case "Linux":
      return 6;
  }
  return 0;
};
var km = function() {
  this.ah = new I;
};
d = km.prototype;
d.init = function() {
  Rh(this);
};
d.Xz = function(a, b, c, e) {
  if (!this.EI(a, b, c)) {
    var f = gm(Gk, new jm(e), b, c);
    chrome.cast.channel.send(a, f, cm);
    this.ah.set(this.Qy(a, b, c), e);
  }
};
d.qT = function(a, b, c, e) {
  this.EI(a, b, c) && (this.OL(a, b, c), b = gm(Gk, new hm(e ? 5 : 0), b, c), chrome.cast.channel.send(a, b, cm));
};
d.OL = function(a, b, c) {
  this.ah.remove(this.Qy(a, b, c));
};
d.p7 = function(a) {
  var b = this;
  this.ah.ub().forEach(function(c) {
    c.split("#")[0] == a.channelId.toString() && b.ah.remove(c);
  });
};
d.P2 = function(a, b) {
  var c = this;
  this.ah.forEach(function(e, f) {
    var g = f.split("#");
    g[0] == a.channelId.toString() && (c.Xz(b, g[1], g[2], e), c.ah.remove(f));
  });
};
d.SU = function(a, b, c) {
  this.Xz(a, b, c, 0 == c.indexOf("receiver-0"));
};
d.EI = function(a, b, c) {
  return this.ah.Ma(this.Qy(a, b, c));
};
d.Qy = function(a, b, c) {
  return [a.channelId, b, c].join("#");
};
d.oa = function() {
  return "cast.VirtualConnectionManager";
};
d.getData = function() {
  var a = this.ah.b();
  return [new lm(a)];
};
d.Xa = function() {
  var a = Oh(this);
  if (a) {
    for (var b in a.oP) {
      this.ah.set(b, a.oP[b]);
    }
  }
};
pa(km);
var lm = function(a) {
  this.oP = a;
};
var mm = function(a, b) {
  this.Aw = b;
  this.Ed = a;
  this.gi = new I;
  this.lh = new I;
  this.yk = km.W();
  this.VS = new dm;
  this.Y = null;
};
d = mm.prototype;
d.init = function() {
  chrome.cast.channel.onMessage.addListener(this.k3.bind(this));
  chrome.cast.channel.onError.addListener(this.i3.bind(this));
  this.yk.init();
  Rh(this);
};
d.KH = function() {
  return this.Ed;
};
d.ku = function(a, b, c, e, f) {
  var g = this, k = e || this.Ed, q = f || "receiver-0";
  return this.Yk(a).then(function(a) {
    return g.y8(a, b, c, k, q);
  });
};
d.K4 = function(a, b, c, e) {
  var f = this;
  return this.Yk(a).then(function(a) {
    return f.yk.Xz(a, b, c, e);
  });
};
d.DE = function(a, b, c, e) {
  (a = this.gi.get(a)) && this.yk.qT(a, b, c, e);
};
d.k3 = function(a, b) {
  hh(2);
  var c = this.lh.get(a.channelId);
  if (c) {
    var e = this.Y(c);
    if (e) {
      if (Lk.hasOwnProperty(b.namespace_)) {
        c = JSON.parse(b.data);
        if ("CLOSE" == c.type) {
          this.yk.OL(a, b.destinationId, b.sourceId);
          return;
        }
        nm.info("Got message " + (c.type || c.responseType) + " from " + e.getId());
      } else {
        nm.info("Got message in " + b.namespace_ + " from " + e.getId());
      }
      this.Aw.j3(e, b);
    } else {
      nm.l("Receiver " + c + " not found.");
    }
  } else {
    nm.l("This message is from unknown receiver.");
  }
};
d.EE = function(a) {
  chrome.cast.channel.close(a, function() {
    chrome.runtime.lastError || nm.w("Channel close success");
  });
  var b = this.lh.get(a.channelId);
  b && (this.lh.remove(a.channelId), this.gi.remove(b));
};
d.i3 = function(a, b) {
  hh(1);
  nm.l(function() {
    return "Channel error: " + JSON.stringify(a) + (b ? ", " + JSON.stringify(b) : "");
  });
  b && this.rR(b.errorState, b);
  this.CE(a);
};
d.rR = function(a, b) {
  switch(a) {
    case "unknown":
      a = 0;
      break;
    case "authentication_error":
      a = 1;
      break;
    case "connect_error":
      a = 2;
      break;
    default:
      return;
  }
  if (b) {
    if (-8192 <= b.nssErrorCode && -7192 > b.nssErrorCode || 2 == b.challengeReplyErrorType || 8 == b.challengeReplyErrorType || 9 == b.challengeReplyErrorType || 11 == b.challengeReplyErrorType || -200 >= b.netReturnValue && -300 < b.netReturnValue || 30 == b.eventType || 31 == b.eventType || 32 == b.eventType) {
      a = 3;
    }
    if (26 == b.eventType || -201 == b.netReturnValue || -8181 == b.nssErrorCode || -8162 == b.nssErrorCode || -8161 == b.nssErrorCode) {
      a = 4;
    }
    -138 == b.netReturnValue && (a = 5);
    if (-8182 == b.nssErrorCode || 10 == b.eventType || 12 == b.eventType) {
      a = 1;
    }
  }
  nm.l("Channel error code: " + a);
  ah("MediaRouter.Cast.Channel.Error", a, Wk);
};
d.CE = function(a) {
  var b = this, c = this.lh.get(a.channelId);
  this.EE(a);
  if (c) {
    var e = this.Y(c);
    e && this.Yk(e, !0).then(function(c) {
      nm.info("Re-connected to receiver: " + e.getId());
      b.yk.P2(a, c);
      b.Aw.l3(e);
    }, function() {
      nm.info("Failed to re-connect to receiver: " + e.getId());
      b.yk.p7(a);
      b.Aw.Gz(e, a.errorState);
    });
  }
};
d.Yk = function(a, b) {
  b = void 0 === b ? !1 : b;
  var c = this, e = a.getId(), f = this.gi.get(e);
  return f && "open" == f.readyState ? Promise.resolve(f) : this.VS.Yk(a, b).then(function(a) {
    if (c.lh.Ma(a.channelId)) {
      return a;
    }
    c.gi.get(e) && (nm.l("Duplicate channel to a receiver " + e), c.EE(c.gi.get(e)));
    nm.info("Connected to: " + e);
    c.gi.set(e, a);
    c.lh.set(a.channelId, e);
    return a;
  }, null);
};
d.y8 = function(a, b, c, e, f) {
  var g = this;
  this.yk.SU(a, e, f);
  Il(c);
  var k = gm(b, c, e, f);
  nm.info("Channel is sending message");
  nm.w(function() {
    return "....message was: " + JSON.stringify(k);
  });
  return new Promise(function(b, c) {
    cm();
    chrome.cast.channel.send(a, k, function(a) {
      a.errorState ? (c(Error("Failed to send message")), g.CE(a)) : b(!0);
    });
  });
};
d.oa = function() {
  return "cast.ChannelService";
};
d.getData = function() {
  return [new om(this.gi.b(), this.lh.b())];
};
d.Xa = function() {
  var a = Oh(this);
  a && (this.gi.addAll(a.G6), this.lh.addAll(a.WS));
};
var nm = D("mr.cast.ChannelService"), om = function(a, b) {
  this.G6 = a;
  this.WS = b;
};
var pm = function() {
  this.requestId = 0;
  this.type = "GET_APP_AVAILABILITY";
  this.appId = [];
};
var qm = function(a, b) {
  this.Og = a;
  this.ea = b;
  this.Yb = new Ae;
  this.zc = new I;
};
d = qm.prototype;
d.init = function() {
  Rh(this);
};
d.BA = function(a) {
  var b = this.zc.get(a);
  b ? b.DA++ : this.zc.set(a, {DA:1});
  this.g8();
};
d.mC = function(a) {
  var b = this.zc.get(a);
  b && (b.DA--, 0 < b.DA || (oe(this.ea.hj(), function(b) {
    switch(b.ye(a)) {
      case "available":
        b.Vp(a, "available_rescan");
        break;
      case "unavailable":
        b.Vp(a, "unavailable_rescan");
    }
  }), this.zc.remove(a)));
};
d.g8 = function() {
  this.a.info("Scanning sinks for app availability");
  oe(this.ea.hj(), this.Qp, this);
};
d.Qp = function(a) {
  var b = this;
  oe(this.zc.$G(), function(c) {
    var e;
    a: {
      switch(a.ye(c)) {
        case "unknown":
        case "available_rescan":
        case "unavailable_rescan":
          e = !0;
          break a;
      }
      e = !1;
    }
    if (e) {
      var f = a.getId() + ":" + c;
      b.Yb.contains(f) || (b.Yb.add(f), e = function() {
        b.Yb.remove(f);
      }, (new Ce(b.ZS.bind(b, a, c), 5500, 3)).pu(2).start().then(b.RO.bind(b, a, c), function() {
        b.a.error("Failed to get app availability response for " + a.getId() + ", appId " + c + " after 3 attempts.");
        b.RO(a, c, "unknown");
      }).then(e, e));
    }
  });
};
d.RO = function(a, b, c) {
  c != a.ye(b) && (this.a.info(b + " on " + a.getId() + " is " + c), a.Vp(b, c), this.ea.Ad(a));
};
d.ZS = function(a, b) {
  var c = this, e = new pm;
  e.appId = [b];
  var f = new Sg("MediaRouter.Cast.App.Availability");
  return this.Og.sendRequest(e, a, Hk, 5000).then(function(a) {
    f.end("Success");
    c.a.w(function() {
      return "App availability response " + JSON.stringify(a);
    });
    for (var b in a.availability) {
      if ("APP_AVAILABLE" == a.availability[b]) {
        return "available";
      }
      if ("APP_UNAVAILABLE" == a.availability[b]) {
        return "unavailable";
      }
    }
    return "unknown";
  }, function(e) {
    f.end("Failure");
    c.a.error("checkAppAvailability_ failed for " + a.getId() + ", appId " + b);
    throw e;
  });
};
d.oa = function() {
  return "cast.AppDiscoveryService";
};
d.getData = function() {
  return [new rm(this.zc.b())];
};
d.Xa = function() {
  var a = Oh(this);
  a && this.zc.addAll(a.X6);
};
d.a = D("mr.cast.AppDiscoveryService");
var rm = function(a) {
  this.X6 = a;
};
var sm = function(a, b, c) {
  var e;
  e = Error.call(this);
  this.message = e.message;
  "stack" in e && (this.stack = e.stack);
  this.name = "RouteRequestError";
  this.message = b || "";
  if (c) {
    this.stack = c;
  } else {
    if (Error.captureStackTrace) {
      Error.captureStackTrace(this, sm);
    } else {
      if (b = Error().stack) {
        this.stack = b;
      }
    }
  }
  this.errorCode = a;
};
la(sm, Error);
var tm = function(a, b) {
  this.sinks = a;
  this.origins = b || null;
}, um = new tm([]);
var vm = function() {
}, wm = function(a) {
  if (!Da(a, "urn:x-org.chromium:media:route:")) {
    return null;
  }
  var b = a.substring(31);
  if (!b) {
    return null;
  }
  b = Ua(b, "/", 2);
  if (3 != b.length) {
    return null;
  }
  var c = Ua(b[1], "-", 1);
  if (2 != c.length) {
    return null;
  }
  var e = new vm;
  e.Gra = a;
  e.hL = b[0];
  e.Mqa = c[0];
  e.isa = c[1];
  e.oi = b[2];
  return e;
};
vm.prototype.K = function() {
  return this.oi;
};
var xm = function(a, b, c, e, f, g) {
  this.id = a;
  this.sinkId = b;
  this.mediaSource = c;
  this.isLocal = e;
  this.description = f;
  this.iconUrl = g;
  this.allowStop = !0;
  this.customControllerPath = null;
  this.forDisplay = !0;
  this.offTheRecord = !1;
  this.cl = e;
  this.isOffscreenPresentation = !1;
}, ym = function(a, b, c, e, f, g, k) {
  return new xm("urn:x-org.chromium:media:route:" + a + "/" + b + "-" + c + "/" + e, c, e, f, g, k);
};
var zm = function(a, b, c, e) {
  return ym(c, "cast", b.getId(), a, e, "", null);
};
var Am = function(a, b, c, e, f, g) {
  this.routeId = a;
  this.clientId = b;
  this.appIds = c;
  this.autoJoinPolicy = e;
  this.origin = f;
  this.tabId = g;
  this.YI = this.Ky = !1;
}, Bm = function() {
  this.Db = [];
};
d = Bm.prototype;
d.init = function() {
  Rh(this);
};
d.V = function() {
  return this.Db.length;
};
d.Zc = function(a) {
  return mb(this.Db, function(b) {
    return b.clientId == a;
  });
};
d.Jh = function(a) {
  return mb(this.Db, function(b) {
    return b.routeId == a;
  });
};
d.Nv = function(a, b, c, e, f, g) {
  x(null == this.Zc(b));
  a = new Am(a, b, c, e, f, g);
  this.Db.push(a);
  return a;
};
d.HA = function(a) {
  this.Db = ib(this.Db, function(b) {
    return b.clientId != a;
  });
};
d.oa = function() {
  return "cast.ClientRecords";
};
d.getData = function() {
  return [new Cm(this.Db)];
};
d.Xa = function() {
  var a = Oh(this);
  a && (this.Db = a.au);
};
var Cm = function(a) {
  this.au = a;
};
var Dm = function(a) {
  this.ea = a;
}, Em = function(a) {
  var b = [];
  a.forEach(function(a) {
    var c = "Receiver-" + a.replace(/\./g, "_"), f = hk.W().Qk || 8009;
    b.push({serviceName:c + "._googlecast._tcp.local", serviceHostPort:c + ":" + f, ipAddress:a, serviceData:["id=mdns:" + c, "ve=02", "ca=5", "st=1", "fn=" + c, "md=Chromecast"]});
  });
  return b;
};
Dm.prototype.init = function() {
  var a = Em(hk.W().sx);
  this.ea.S6(a);
};
var Fm = chrome.i18n.getMessage("4528089202128275824");
chrome.i18n.getMessage("2810417817914017289");
chrome.i18n.getMessage("3413021810593924462");
chrome.i18n.getMessage("7603034707785674700");
chrome.i18n.getMessage("8009014317872238527");
chrome.i18n.getMessage("8636962961150071298");
chrome.i18n.getMessage("1802762746589457177");
var Gm = function(a, b) {
  this.eg = [];
  this.le = [];
  this.sinkId = a;
  this.session = b;
  this.ft = this.gp = null;
  this.offTheRecord = this.Ts = !1;
};
d = Gm.prototype;
d.Nv = function(a) {
  if (pb(this.eg, a)) {
    return !1;
  }
  this.eg.push(a);
  return !0;
};
d.HA = function(a) {
  return ub(this.eg, a);
};
d.af = function(a) {
  if (pb(this.le, a)) {
    return !1;
  }
  this.le.push(a);
  return !0;
};
d.Yj = function(a) {
  return ub(this.le, a);
};
d.D_ = function(a, b) {
  El(a) ? (this.ft = a, this.gp = b) : El(this.session) && (this.ft = this.session, this.gp = this.sinkId, this.session = a, this.sinkId = b);
  return this;
};
var Hm = function() {
  this.a = D("mr.cast.SessionRecords");
  this.Db = [];
};
d = Hm.prototype;
d.init = function() {
  Rh(this);
};
d.AD = function(a, b) {
  this.a.info("Adding new session: " + b + ", " + a.sessionId);
  var c = this.Ee(a.sessionId);
  if (c) {
    return c.D_(a, b);
  }
  a = new Gm(b, a);
  this.Db.push(a);
  return a;
};
d.qm = function(a) {
  this.a.info("Removing session " + a);
  this.Db = ib(this.Db, function(b) {
    return b.session.sessionId != a;
  });
};
d.uG = function(a) {
  return (a = this.Ee(a)) ? a.eg : [];
};
d.xs = function(a) {
  return (a = this.Co(a)) ? a.session : null;
};
d.Zc = function(a) {
  return mb(this.Db, function(b) {
    return pb(b.eg, a);
  });
};
d.Jh = function(a) {
  return mb(this.Db, function(b) {
    return pb(b.le, a);
  });
};
d.hZ = function(a) {
  return mb(this.Db, function(b) {
    return null != mb(b.le, function(b) {
      return wm(b).hL == a;
    });
  });
};
d.Co = function(a) {
  return mb(this.Db, function(b) {
    return b.sinkId == a || b.gp == a;
  });
};
d.Ee = function(a) {
  return mb(this.Db, function(b) {
    return b.session.sessionId == a;
  });
};
d.QH = function(a) {
  return (a = this.Ee(a)) ? a.sinkId : null;
};
d.ky = function(a) {
  return (a = this.Ee(a)) ? a.session : null;
};
d.uaa = function(a, b) {
  var c = this.ky(a);
  c && (a = ib(b, function(a) {
    return a.playerState != chrome.cast.media.Iq.IDLE;
  }), a.forEach(function(a) {
    if (!a.media) {
      var b = mb(c.media, function(b) {
        return b.mediaSessionId == a.mediaSessionId;
      });
      b && (a.media = b.media);
    }
  }), c.media = a);
};
d.m6 = function(a) {
  for (var b = 0;b < this.Db.length;b++) {
    this.Db[b].HA(a);
  }
};
d.oa = function() {
  return "cast.SessionRecords";
};
d.getData = function() {
  return [new Im(this.Db)];
};
d.Xa = function() {
  var a = Oh(this);
  if (a) {
    for (var b = 0;b < a.au.length;b++) {
      var c = a.au[b], e = new Gm(c.sinkId, c.session);
      e.eg = c.eg;
      e.le = c.le;
      e.Ts = c.Ts;
      e.ft = c.ft;
      e.gp = c.gp;
      this.Db.push(e);
    }
  }
};
var Im = function(a) {
  this.au = a;
};
var Jm = function(a) {
  this.Ed = "sender-" + Ra();
  this.xa = new I;
  this.uj = null;
  Rh(this);
  this.o = a;
  this.Jb = new Bm;
  this.va = new Hm;
  this.Vc = new mm(this.Ed, this);
  this.ea = new gl(this.Vc, this);
  this.eU = new Dm(this.ea);
  this.qd = new sl(this.Vc, this.Ed);
  this.nd = new qm(this.qd, this.ea);
  this.Nd = new Zl(this.qd, this.ea, this.Jb, this.va, this.Vc, this);
  this.kE = new yl(this.ea, this.qd);
  this.tba = this.ea.start.bind(this.ea);
};
d = Jm.prototype;
d.getName = function() {
  return "cast";
};
d.mc = function() {
  this.qd.init();
  this.va.init();
  this.Nd.init();
  this.Vc.init();
  this.ea.init();
  this.eU.init();
  this.nd.init();
  this.o.CA(this.tba);
};
d.vf = function() {
  return this.xa.H();
};
d.zh = function(a) {
  var b = this;
  if (this.TI(a)) {
    return new tm([]);
  }
  var c = new Ae;
  this.fo(a).forEach(function(a) {
    b.ea.PZ(a).map(function(a) {
      return a.Fh();
    }).forEach(function(a) {
      c.add(a);
    });
  });
  return new tm(c.H(), nh(a));
};
d.startObservingMediaSinks = function(a) {
  var b = this, c = this.iG(a);
  c ? (this.a.info("Received broadcast request " + a), oe(this.ea.hj(), function(a) {
    b.qd.k8(c, a).catch(function(a) {
      b.a.error("Broadcast failed " + a.message);
    });
  })) : (this.fo(a).forEach(function(a) {
    b.nd.BA(a);
  }), this.o.My() && this.ea.start());
};
d.stopObservingMediaSinks = function(a) {
  var b = this;
  this.TI(a) || this.fo(a).forEach(function(a) {
    b.nd.mC(a);
  });
};
d.startObservingMediaRoutes = function() {
};
d.stopObservingMediaRoutes = function() {
};
d.Y = function(a) {
  return (a = this.ea.Y(a)) ? a.Fh() : null;
};
d.o8 = function(a) {
  var b = new Gg(Fm, "warning", "dismiss");
  b.routeId = a;
  this.o.ug().send(b);
};
d.oI = function(a, b) {
  this.a.error("Error launching.", b);
  this.Yj(a.id, !1, !0, "error");
  this.o8(a.id);
};
d.Ti = function(a, b, c, e, f, g, k) {
  var q = this;
  hk.W().Wj = new gk(b.xc, b.qa);
  var r = zm(a, b, c, !0);
  r.forDisplay = !1;
  r.offTheRecord = e;
  this.xa.set(r.id, r);
  this.o.Jj(this, r);
  this.o.Lf(this.oa(), !0);
  (e = Xl(a)) && e.rc() && this.nD(e, r.id, g, k);
  kh(a) || lh(a) ? (r.Je = {tabId:k, sessionId:"", eO:b.qa || "", fO:b.xc || ""}, lh(a) && (r.isOffscreenPresentation = !0), this.o.mq(this, r, c, function(e) {
    return Kg(q.AJ(a, b, c, f, g, k, e));
  }).promise.then(function() {
    q.nN(r);
  }, function(a) {
    q.oI(r, a);
  })) : this.AJ(a, b, c, f, g, k, r).then(null, function(a) {
    q.oI(r, a);
  });
  return Promise.resolve(r);
};
d.AJ = function(a, b, c, e, f, g, k) {
  var q = this;
  return this.Nd.gz(this.oA(a, b, e), b).then(function(e) {
    q.af(a, b, c, e, f, g, k);
    return k;
  });
};
d.createRoute = function(a, b, c, e, f, g, k) {
  var q = this, r = this.ea.Y(b);
  if (!r) {
    return Jg(Error("No sink with ID " + b));
  }
  var A = Vl(a);
  if (A) {
    setTimeout(function() {
      q.Nd.tM(Za(A), ab(r), chrome.cast.qn.CAST);
    }, 0);
    var E = function() {
      return q.Ti(a, r, c, e, f, g, k);
    }, aa = this.Jb.Zc(A);
    if (aa) {
      return Kg(this.terminateRoute(aa.routeId).then(E, E));
    }
    if (g && k && (b = this.TE(a, g, k, e, f, b))) {
      return b;
    }
  }
  return Kg(this.Ti(a, r, c, e, f, g, k));
};
d.sU = function(a, b) {
  this.o.Ke(this, a, b);
};
d.rU = function(a, b) {
  var c = this.xa.get(a);
  c && c.cl && this.o.Et(this, a, b);
};
d.Yj = function(a, b, c, e) {
  c = void 0 === c ? !1 : c;
  e = void 0 === e ? "closed" : e;
  this.a.info("Remove route " + a);
  var f = this.Jb.Jh(a);
  if (f) {
    b = b || f.YI;
    var g = f.clientId;
    this.a.info("Remove client " + g);
    this.va.m6(g);
    this.Jb.HA(g);
  }
  if (g = this.va.Jh(a)) {
    g.Yj(a), this.KJ(g.le);
  }
  var k = this.xa.get(a);
  if (k) {
    if (k.cl && g && (this.Vc.DE(k.sinkId, f ? f.clientId : this.Ed, g.session.transportId, b), k.forDisplay && f && (this.uj = {Tk:f, yM:g})), this.xa.remove(a), this.o.Ig(this, k), this.vf().some(function(a) {
      return a.isLocal;
    }) || this.o.Lf(this.oa(), !1), c) {
      this.o.onPresentationConnectionClosed(a, e, "Remove route");
    } else {
      this.o.onPresentationConnectionStateChanged(a, "terminated");
    }
  }
};
d.Eca = function(a) {
  var b = this;
  a.le.forEach(function(c) {
    if (c = b.xa.get(c)) {
      var e = a.session;
      c.Je && c.forDisplay ? b.nN(c) : (c.description = e.statusText || e.displayName, b.o.Yh(b, c));
    }
  });
};
d.yca = function(a) {
  var b = this;
  jb(a, function(a) {
    a = b.xa.get(a, null);
    if (!a || !a.mediaSource) {
      return !1;
    }
    var c = Xl(a.mediaSource), c = c ? c.Gy : !1;
    return a.isLocal && !c;
  }) && y(a, function(a) {
    if (a = b.xa.get(a, null)) {
      a.isLocal = !0;
    }
  });
};
d.KJ = function(a) {
  var b = this, c = [], e = [], f = null;
  a.forEach(function(a) {
    if (a = b.xa.get(a)) {
      a.forDisplay = !1;
      var g = Xl(a.mediaSource);
      g && mb(g.eo(), Ll) || (a.cl ? (g = g ? g.Ax() : null, f || g == chrome.cast.Xf.CUSTOM_CONTROLLER_SCOPED || (c.push(a), f = a.sinkId)) : f && f != a.sinkId ? c.push(a) : e.push(a));
    }
  });
  y(0 < c.length ? c : e, function(a) {
    a.forDisplay = !0;
  });
};
d.nD = function(a, b, c, e) {
  var f = a.rc();
  f && !this.Jb.Zc(f) && (this.a.info("Add client " + f), this.Jb.Nv(b, f, a.eo(), a.Ax(), c || null, l(e) ? e : null));
};
d.nN = function(a) {
  var b = this.va.Jh(a.id);
  b && (b = b.session, b.statusText = a.description || b.statusText);
};
d.af = function(a, b, c, e, f, g, k) {
  var q = this.va.Co(b.getId());
  q || (q = this.va.AD(e, b.getId()));
  var r = null != a;
  if (!r && Ll(e.appId)) {
    return null;
  }
  var A;
  null == a ? (A = new Rl([{appId:e.appId, capabilities:e.capabilities}]), a = A.toString()) : A = Xl(a);
  var E = k;
  if (E) {
    if (!this.xa.get(E.id)) {
      return this.a.l("Route " + E.id + " not added"), E;
    }
  } else {
    E = zm(a, b, c || e.sessionId, r), this.xa.set(E.id, E);
  }
  c = E.id;
  this.a.info("Add route " + c);
  a = null;
  A && (a = A.rc(), this.nD(A, c, f, g));
  q.af(c);
  E.cl && this.Vc.K4(b, a || this.Ed, e.transportId, !(A && A.Gy));
  q.offTheRecord = E.offTheRecord;
  f = q.le;
  this.yca(f);
  this.KJ(f);
  f = E;
  g = e.sessionId;
  A = e.appId;
  ("0F5096E8" == A || "85CDB22F" == A) && g && f.Je && (f.Je.sessionId = g);
  !Jl(e, Ik) || null !== e && pb(Kl, e.appId) || (f.customControllerPath = "cast_route_details.html?" + ["sessionId=" + g, "appId=" + A].join("&"));
  f.description = e.statusText || e.displayName;
  k ? this.o.Yh(this, E) : (this.o.Jj(this, E), E.isLocal && this.o.Lf(this.oa(), !0));
  a && q.Nv(a) && this.Nd.T3(e, b, a);
  return E;
};
d.terminateRoute = function(a) {
  var b = this, c = this.xa.get(a);
  if (!c) {
    return Promise.reject(new sm(3, "Route in Cast provider not found for routeId  " + a));
  }
  var e = this.va.Jh(a);
  if (!e) {
    return this.Yj(a, !0), Promise.resolve();
  }
  var f = e.session.sessionId, g = this.ea.Y(c.sinkId);
  if (!g) {
    return this.Nd.qm(f), Promise.resolve();
  }
  (a = this.Jb.Jh(a)) && this.Nd.tM(a.clientId, g, chrome.cast.qn.STOP);
  Yk(0);
  return new Promise(function(a) {
    var c = function() {
      b.Nd.NL(g.getId());
      a();
    };
    b.qd.y7(f, g).then(c, c);
  });
};
d.sV = function(a) {
  var b = this, c = null;
  pe(this.xa.sy(), function(e) {
    if (!e.cl) {
      return !1;
    }
    var f = b.ea.Y(e.sinkId);
    if (!f || !a.A1(b.oA(e.mediaSource, f))) {
      return !1;
    }
    c = e;
    return !0;
  });
  if (!c || !c.mediaSource) {
    return null;
  }
  var e = Yl(c.mediaSource);
  if (!e) {
    return null;
  }
  var f = this.Jb.Zc(e);
  return f ? (e = this.va.Zc(e)) ? {Tk:f, yM:e} : null : null;
};
d.TR = function(a, b, c) {
  var e = this.sV(a);
  if (!e) {
    if (!this.uj || this.uj.Tk.origin != b || this.uj.Tk.tabId != c) {
      return null;
    }
    e = this.uj;
  }
  switch(a.Ax()) {
    case chrome.cast.Xf.PAGE_SCOPED:
      return null;
    case chrome.cast.Xf.ORIGIN_SCOPED:
      if (b != e.Tk.origin) {
        return null;
      }
      break;
    case chrome.cast.Xf.TAB_AND_ORIGIN_SCOPED:
      if (b != e.Tk.origin || c != e.Tk.tabId) {
        return null;
      }
  }
  return this.va.Ee(e.yM.session.sessionId);
};
d.TE = function(a, b, c, e, f, g) {
  var k = this, q = null;
  pe(this.xa.sy(), function(a) {
    var b = a.Je;
    return b && null != b.tabId && b.tabId == c && ih(a.mediaSource) ? (q = a, !0) : !1;
  });
  if (!q) {
    return null;
  }
  var r = function() {
    return k.createRoute(a, g || q.sinkId, "", e, f, b, null == c ? void 0 : c);
  };
  return Kg(this.terminateRoute(q.id).then(r, r));
};
d.connectRouteByRouteId = function(a, b, c, e, f) {
  if (!Xl(a)) {
    return Jg(Error("Unsupported presentation URL"));
  }
  b = wm(b);
  b = this.va.Ee(b.hL);
  if (!b) {
    return Jg(Error("No matching route"));
  }
  var g = this.ea.Y(b.sinkId);
  return g ? (a = this.af(a, g, c, b.session, e, f)) ? Ig(a) : Jg(Error("Failed to create route")) : Jg(Error("No sink"));
};
d.joinRoute = function(a, b, c, e, f, g) {
  var k = Xl(a);
  if (!k) {
    return Jg(Error("Unsupported presentation URL"));
  }
  var q;
  if (b == chrome.cast.IP) {
    if (q = this.TR(k, f, g), !q && k.IW() != chrome.cast.Hq.CAST_THIS_TAB && (e = this.TE(a, f, g, c, e))) {
      return e;
    }
  } else {
    q = 0 == b.indexOf(chrome.cast.bD) ? this.va.Ee(b.substr(chrome.cast.bD.length)) : this.va.hZ(b);
  }
  if (!q) {
    return Jg(Error("No matching route"));
  }
  if (q.offTheRecord != c) {
    return Jg(Error("Off the record mismatch"));
  }
  e = this.ea.Y(q.sinkId);
  if (!e) {
    return Jg(Error("No sink"));
  }
  a = this.af(a, e, b, q.session, f, g);
  a.offTheRecord = c;
  return Ig(a);
};
d.detachRoute = function(a) {
  this.Yj(a, !1, !0);
};
d.cj = function(a) {
  var b = new Fh, c = this.ea.Y(a);
  if (!c) {
    return null;
  }
  c = c.pd;
  c & 1 || (b.shouldCaptureVideo = !1);
  c & 4 || (b.shouldCaptureAudio = !1);
  b.shouldCaptureAudio && !b.shouldCaptureVideo && (b.minLatencyMillis = b.maxLatencyMillis, b.animatedLatencyMillis = b.maxLatencyMillis);
  b.senderSideLetterboxing = !0;
  b.HJ();
  this.a.info(function() {
    return "Settings for " + a + ": " + b.Wu();
  });
  return b.shouldCaptureAudio || b.shouldCaptureVideo ? b : null;
};
d.bj = function() {
  return "cast_streaming";
};
d.sendRouteMessage = function(a, b, c) {
  var e = this;
  if (!c) {
    return this.Nd.Ke(a, b), Promise.resolve();
  }
  var f = this.va.Jh(a);
  if (!f) {
    return Promise.reject(Error("Not managing the route " + a));
  }
  var g = this.ea.Y(f.sinkId);
  if (!g) {
    return Promise.reject(Error("Sink no longer accessible"));
  }
  var k = (a = this.Jb.Jh(a)) ? a.clientId : this.Ed;
  return new Promise(function(a) {
    e.Vc.ku(g, c.namespace, b, k, f.session.transportId).then(a, a);
  });
};
d.Ok = function(a, b) {
  var c = this.ea.Y(b);
  if (!c) {
    return !1;
  }
  a = this.oA(a, c);
  return (a = Wl(a)) && 0 != a.length ? jb(a, function(a) {
    return Mk(c.ye(a));
  }) : !1;
};
d.Ii = function(a, b) {
  var c = this.fo(a);
  return c && 0 != c.length ? b && b.mediaSource ? (a = Wl(b.mediaSource), jb(a, function(a) {
    return pb(c, a);
  })) : !0 : !1;
};
d.oA = function(a, b, c) {
  return kh(a) || lh(a) ? (a = {appId:0 == (b.pd & 1) ? "85CDB22F" : "0F5096E8", capabilities:Gl(b.pd)}, (new Rl([a], void 0, void 0, void 0, c)).toString()) : a;
};
d.fo = function(a) {
  var b = [];
  if (kh(a) || lh(a)) {
    var c = Og();
    jh(a) && "ChromeOS" != c && "Windows" != c || b.push("85CDB22F");
    b.push("0F5096E8");
  } else {
    (a = Wl(a)) && (b = xb(b, a));
  }
  return b;
};
d.TI = function(a) {
  return null != this.iG(a);
};
d.iG = function(a) {
  var b = Xl(a);
  if (!b) {
    return null;
  }
  a = this.fo(a);
  var c = b.ow || "", b = b.nw;
  return c && b ? new nl(a, c, JSON.stringify(b)) : null;
};
d.Gz = function(a) {
  this.ea.Gz(a.getId());
  Yk(2);
};
d.l3 = function(a) {
  this.Nd.qL(a, !0);
};
d.j3 = function(a, b) {
  this.kE.J_(a, b);
  this.Nd.o4(a.getId(), b);
};
d.Kj = function(a) {
  this.o.onSinkAvailabilityUpdated(this, 1);
  this.Ad(a);
  this.Nd.qL(a);
};
d.Ht = function(a) {
  if (0 == this.ea.ny()) {
    this.o.onSinkAvailabilityUpdated(this, 0);
  }
  this.Nd.Ht(a.getId());
  this.tI();
};
d.Ad = function(a) {
  this.nd.Qp(a);
  this.tI();
};
d.tI = function() {
  this.kE.r0();
  this.o.ee();
};
d.oa = function() {
  return "cast.Provider";
};
d.getData = function() {
  return [new Km(this.Ed, this.xa.b(), this.uj)];
};
d.Xa = function() {
  var a = Oh(this);
  a && (this.Ed = a.wM, this.xa.addAll(a.routes), this.uj = a.L1);
};
d.searchSinks = function() {
  return null;
};
d.a = D("mr.CastProvider");
var Km = function(a, b, c) {
  this.wM = a;
  this.routes = b;
  this.L1 = c;
};
var Lm = function() {
  if (!dc) {
    return !1;
  }
  try {
    return new ActiveXObject("MSXML2.DOMDocument"), !0;
  } catch (a) {
    return !1;
  }
};
dc && Lm();
var Mm = function(a, b) {
  Rc.call(this);
  this.$J = a || 0;
  this.Aj = b || 10;
  if (this.$J > this.Aj) {
    throw Error("[goog.structs.Pool] Min can not be greater than max");
  }
  this.ic = new dj;
  this.Mh = new Ae;
  this.Yw = 0;
  this.Sy = null;
  this.Qq();
};
w(Mm, Rc);
d = Mm.prototype;
d.getObject = function() {
  var a = v();
  if (!(null != this.Sy && a - this.Sy < this.Yw)) {
    var b = this.h7();
    b && (this.Sy = a, this.Mh.add(b));
    return b;
  }
};
d.Xj = function(a) {
  return this.Mh.remove(a) ? (this.Ov(a), !0) : !1;
};
d.h7 = function() {
  for (var a;0 < this.OG() && (a = this.ic.uh(), !this.Ez(a));) {
    this.Qq();
  }
  !a && this.V() < this.Aj && (a = this.jg());
  return a;
};
d.Ov = function(a) {
  this.Mh.remove(a);
  this.Ez(a) && this.V() < this.Aj ? this.ic.enqueue(a) : this.Si(a);
};
d.Qq = function() {
  for (var a = this.ic;this.V() < this.$J;) {
    a.enqueue(this.jg());
  }
  for (;this.V() > this.Aj && 0 < this.OG();) {
    this.Si(a.uh());
  }
};
d.jg = function() {
  return {};
};
d.Si = function(a) {
  if ("function" == typeof a.Qa) {
    a.Qa();
  } else {
    for (var b in a) {
      a[b] = null;
    }
  }
};
d.Ez = function(a) {
  return "function" == typeof a.KS ? a.KS() : !0;
};
d.contains = function(a) {
  return this.ic.contains(a) || this.Mh.contains(a);
};
d.V = function() {
  return this.ic.V() + this.Mh.V();
};
d.LX = function() {
  return this.Mh.V();
};
d.OG = function() {
  return this.ic.V();
};
d.Bb = function() {
  return this.ic.Bb() && this.Mh.Bb();
};
d.U = function() {
  Mm.T.U.call(this);
  if (0 < this.LX()) {
    throw Error("[goog.structs.Pool] Objects not released");
  }
  delete this.Mh;
  for (var a = this.ic;!a.Bb();) {
    this.Si(a.uh());
  }
  delete this.ic;
};
var Nm = function(a, b) {
  this.Df = a;
  this.Kd = b;
};
Nm.prototype.getKey = function() {
  return this.Df;
};
Nm.prototype.vc = function() {
  return this.Kd;
};
Nm.prototype.clone = function() {
  return new Nm(this.Df, this.Kd);
};
var Om = function(a) {
  this.de = [];
  a && this.Z0(a);
};
d = Om.prototype;
d.insert = function(a, b) {
  var c = this.de;
  c.push(new Nm(a, b));
  this.O2(c.length - 1);
};
d.Z0 = function(a) {
  var b;
  if (a instanceof Om) {
    if (b = a.ub(), a = a.H(), 0 >= this.V()) {
      for (var c = this.de, e = 0;e < b.length;e++) {
        c.push(new Nm(b[e], a[e]));
      }
      return;
    }
  } else {
    b = Kb(a), a = Jb(a);
  }
  for (e = 0;e < b.length;e++) {
    this.insert(b[e], a[e]);
  }
};
d.remove = function() {
  var a = this.de, b = a.length, c = a[0];
  if (!(0 >= b)) {
    return 1 == b ? qb(a) : (a[0] = a.pop(), this.N2(0)), c.vc();
  }
};
d.N2 = function(a) {
  for (var b = this.de, c = b.length, e = b[a];a < c >> 1;) {
    var f = this.UX(a), g = this.DZ(a), f = g < c && b[g].getKey() < b[f].getKey() ? g : f;
    if (b[f].getKey() > e.getKey()) {
      break;
    }
    b[a] = b[f];
    a = f;
  }
  b[a] = e;
};
d.O2 = function(a) {
  for (var b = this.de, c = b[a];0 < a;) {
    var e = this.OY(a);
    if (b[e].getKey() > c.getKey()) {
      b[a] = b[e], a = e;
    } else {
      break;
    }
  }
  b[a] = c;
};
d.UX = function(a) {
  return 2 * a + 1;
};
d.DZ = function(a) {
  return 2 * a + 2;
};
d.OY = function(a) {
  return a - 1 >> 1;
};
d.H = function() {
  for (var a = this.de, b = [], c = a.length, e = 0;e < c;e++) {
    b.push(a[e].vc());
  }
  return b;
};
d.ub = function() {
  for (var a = this.de, b = [], c = a.length, e = 0;e < c;e++) {
    b.push(a[e].getKey());
  }
  return b;
};
d.$k = function(a) {
  return jb(this.de, function(b) {
    return b.vc() == a;
  });
};
d.Ma = function(a) {
  return jb(this.de, function(b) {
    return b.getKey() == a;
  });
};
d.clone = function() {
  return new Om(this);
};
d.V = function() {
  return this.de.length;
};
d.Bb = function() {
  return 0 == this.de.length;
};
d.clear = function() {
  qb(this.de);
};
var Pm = function() {
  Om.call(this);
};
w(Pm, Om);
Pm.prototype.enqueue = function(a, b) {
  this.insert(a, b);
};
Pm.prototype.uh = function() {
  return this.remove();
};
var Qm = function(a, b) {
  this.gF = void 0;
  this.du = new Pm;
  Mm.call(this, a, b);
};
w(Qm, Mm);
d = Qm.prototype;
d.getObject = function(a, b) {
  if (!a) {
    return (a = Qm.T.getObject.call(this)) && this.Yw && (this.gF = h.setTimeout(u(this.Is, this), this.Yw)), a;
  }
  this.du.enqueue(l(b) ? b : 100, a);
  this.Is();
};
d.Is = function() {
  for (var a = this.du;0 < a.V();) {
    var b = this.getObject();
    if (b) {
      a.uh().apply(this, [b]);
    } else {
      break;
    }
  }
};
d.Ov = function(a) {
  Qm.T.Ov.call(this, a);
  this.Is();
};
d.Qq = function() {
  Qm.T.Qq.call(this);
  this.Is();
};
d.U = function() {
  Qm.T.U.call(this);
  h.clearTimeout(this.gF);
  this.du.clear();
  this.du = null;
};
var Rm = function(a, b, c, e) {
  this.oj = a;
  this.bh = !!e;
  Qm.call(this, b, c);
};
w(Rm, Qm);
Rm.prototype.jg = function() {
  var a = new Ff, b = this.oj;
  b && b.forEach(function(b, e) {
    a.headers.set(e, b);
  });
  this.bh && a.RB(!0);
  return a;
};
Rm.prototype.Ez = function(a) {
  return !a.isDisposed() && !a.Cf();
};
var Sm = function(a, b, c, e, f, g) {
  G.call(this);
  this.Fg = l(a) ? a : 1;
  this.Yg = l(f) ? Math.max(0, f) : 0;
  this.bh = !!g;
  this.mn = new Rm(b, c, e, g);
  this.Ac = new I;
  this.Ia = new tk(this);
};
w(Sm, G);
var Tm = "ready complete success error abort timeout".split(" ");
d = Sm.prototype;
d.Bu = function(a) {
  this.Yg = Math.max(0, a);
};
d.send = function(a, b, c, e, f, g, k, q, r, A) {
  if (this.Ac.get(a)) {
    throw Error("[goog.net.XhrManager] ID in use");
  }
  b = new Um(b, u(this.Q_, this, a), c, e, f, k, l(q) ? q : this.Fg, r, l(A) ? A : this.bh);
  this.Ac.set(a, b);
  a = u(this.G_, this, a);
  this.mn.getObject(a, g);
  return b;
};
d.abort = function(a, b) {
  var c = this.Ac.get(a);
  if (c) {
    var e = c.uv;
    c.H8(!0);
    b && (e && (this.PL(e, c.MC), rd(e, "ready", function() {
      this.mn.Xj(e);
    }, !1, this)), this.Ac.remove(a));
    e && e.abort();
  }
};
d.G_ = function(a, b) {
  var c = this.Ac.get(a);
  c && !c.uv ? (this.GR(b, c.MC), b.Bu(this.Yg), b.KN(c.rm), b.RB(c.bh), c.uv = b, this.dispatchEvent(new Vm("ready", this, a, b)), this.XL(a, b), c.jD && b.abort()) : this.mn.Xj(b);
};
d.Q_ = function(a, b) {
  var c = b.target;
  switch(b.type) {
    case "ready":
      this.XL(a, c);
      break;
    case "complete":
      return this.M_(a, c, b);
    case "success":
      this.A0(a, c);
      break;
    case "timeout":
    case "error":
      this.Ko(a, c);
      break;
    case "abort":
      this.E_(a, c);
  }
  return null;
};
d.XL = function(a, b) {
  var c = this.Ac.get(a);
  !c || c.JE || c.Ay() ? (c && (this.PL(b, c.MC), this.Ac.remove(a)), this.mn.Xj(b)) : (c.Q0(), b.send(c.getUrl(), c.F2, c.Kb, c.ps()));
};
d.M_ = function(a, b, c) {
  var e = this.Ac.get(a);
  if (7 == b.Oh || b.$d() || e.Ay()) {
    if (this.dispatchEvent(new Vm("complete", this, a, b)), e && (e.g9(!0), e.IE)) {
      return e.IE.call(b, c);
    }
  }
  return null;
};
d.E_ = function(a, b) {
  this.dispatchEvent(new Vm("abort", this, a, b));
};
d.A0 = function(a, b) {
  this.dispatchEvent(new Vm("success", this, a, b));
};
d.Ko = function(a, b) {
  this.Ac.get(a).Ay() && this.dispatchEvent(new Vm("error", this, a, b));
};
d.PL = function(a, b, c) {
  this.Ia.Fc(a, c || Tm, b);
};
d.GR = function(a, b, c) {
  this.Ia.listen(a, c || Tm, b);
};
d.U = function() {
  Sm.T.U.call(this);
  this.mn.Qa();
  this.mn = null;
  this.Ia.Qa();
  this.Ia = null;
  this.Ac.clear();
  this.Ac = null;
};
var Vm = function(a, b, c, e) {
  F.call(this, a, b);
  this.id = c;
  this.uv = e;
};
w(Vm, F);
var Um = function(a, b, c, e, f, g, k, q, r) {
  this.gv = a;
  this.F2 = c || "GET";
  this.Kb = e;
  this.oj = f || null;
  this.Fg = l(k) ? k : 1;
  this.QD = 0;
  this.jD = this.JE = !1;
  this.MC = b;
  this.IE = g;
  this.rm = q || "";
  this.bh = !!r;
  this.uv = null;
};
d = Um.prototype;
d.getUrl = function() {
  return this.gv;
};
d.ps = function() {
  return this.oj;
};
d.ss = function() {
  return this.Fg;
};
d.Q0 = function() {
  this.QD++;
};
d.Ay = function() {
  return this.QD > this.Fg;
};
d.g9 = function(a) {
  this.JE = a;
};
d.H8 = function(a) {
  this.jD = a;
};
var Wm = function() {
  this.name = "unknown";
  this.state = "error";
  this.c1 = null;
  this.allowStop = !0;
  this.Pg = null;
  this.extraData = {};
}, Xm = function(a, b) {
  this.GP = a;
  this.Zf = b;
  this.d8 = !!b && "running" == b.state;
}, $m = function(a, b, c) {
  void 0 === b && (Ym || (Ym = new Sm(3, null, 1, 10, 2000)), b = Ym);
  void 0 === c && (Zm || (Zm = new Sm(0, null, 1, 10, 15000)), c = Zm);
  x(!!a.ng, "Receiver must have a DIAL app URL set.");
  this.Se = a;
  this.ln = b;
  this.nn = [];
  this.HP = c;
  this.a = D("mr.dial.Client");
};
d = $m.prototype;
d.abort = function() {
  var a = this;
  this.nn.forEach(function(b) {
    a.ln.abort(b, !0);
    a.HP.abort(b, !0);
  });
};
d.launchApp = function(a, b) {
  var c = new Jc, e = (++an).toString();
  this.nn.push(e);
  this.HP.send(e, this.zx(a), "POST", b, null, 0, this.MF("launchApp", "POST", e, c));
  return c.promise;
};
d.mO = function(a) {
  var b = new Jc, c = (++an).toString();
  this.nn.push(c);
  this.ln.send(c, this.zx(a), "DELETE", null, null, 0, this.MF("stopApp", "DELETE", c, b), 0);
  return b.promise;
};
d.yx = function(a) {
  var b = this;
  return new Promise(function(c) {
    var e = (++an).toString();
    b.nn.push(e);
    b.ln.send(e, b.zx(a), "GET", null, null, 0, u(b.C3, b, e, c));
  });
};
d.C3 = function(a, b, c) {
  ub(this.nn, a);
  a = c.target;
  De(this.a, "GetAppInfo", "GET", a, !0);
  if (a.$d()) {
    if (c = a.IH()) {
      var e = c.getElementsByTagName("service");
      if (e && 1 == e.length) {
        c = new Wm;
        for (var f = 0, g = e[0].childNodes.length;f < g;f++) {
          var k = e[0].childNodes[f];
          if ("state" == k.nodeName) {
            a: {
              switch(k.textContent) {
                case "running":
                  k = "running";
                  break a;
                case "stopped":
                  k = "stopped";
                  break a;
                default:
                  k = "error";
              }
            }
            c.state = k;
          } else {
            "name" == k.nodeName ? c.name = k.textContent : "link" == k.nodeName ? c.Pg = k.getAttribute("href") : "options" == k.nodeName ? c.allowStop = "false" != k.getAttribute("allowStop") : c.extraData[k.nodeName] = k.innerHTML;
          }
        }
        if ("unknown" == c.name) {
          this.a.info("GET response missing name value"), b(new Xm(a, null));
        } else {
          if ("error" == c.state) {
            this.a.info("GET response missing state value"), b(new Xm(a, null));
          } else {
            if ((e = /installable=(.+)/.exec(c.state)) && e[1]) {
              c.state = "installable", c.c1 = e[1];
            } else {
              if ("running" != c.state && "stopped" != c.state) {
                this.a.info("GET response has invalid state value");
                b(new Xm(a, null));
                return;
              }
            }
            b(new Xm(a, c));
          }
        }
      } else {
        this.a.info("Invalid GET response (invalid service)"), b(new Xm(a, null));
      }
    } else {
      this.a.info("Empty response"), b(new Xm(a, null));
    }
  } else {
    this.a.info("Request to " + a.rs() + " failed"), b(new Xm(a, null));
  }
};
d.zx = function(a) {
  var b = this.Se.ng;
  "/" != b.charAt(b.length - 1) && (b += "/");
  return b + a;
};
d.MF = function(a, b, c, e) {
  var f = this;
  return function(g) {
    ub(f.nn, c);
    g = g.target;
    De(f.a, a, b, g, !0);
    g.$d() ? e.resolve(void 0) : e.reject(Error(cf(g.Oh)));
  };
};
var Ym = null, Zm = null, an = 999;
var bn = function(a, b, c) {
  this.appName = b;
  this.launchParameter = void 0 === c ? "" : c;
}, dn = function(a) {
  if (a.startsWith("urn:dial-multiscreen-org:dial:application:")) {
    var b = a.indexOf("?"), c = a.substring(42, 0 < b ? b : void 0);
    a = c && 0 < c.length ? new bn(a, c, 0 < b ? a.substring(b + 1) : void 0) : null;
  } else {
    a = cn(a);
  }
  return a;
}, cn = function(a) {
  var b = (new Qj(a)).Xi;
  if (!b) {
    return null;
  }
  var c = en.exec(b), c = c ? c[1] : null;
  if (!c) {
    return null;
  }
  c = decodeURIComponent(c);
  if (b = (b = fn.exec(b)) ? b[1] : void 0) {
    try {
      b = Hj(b);
    } catch (e) {
      return gn.l("Invalid base64 encoded postData:" + b), null;
    }
  }
  return new bn(a, c, b);
}, gn = D("mr.dial.MediaSource"), en = /__dialAppName__=([A-Za-z0-9-._~!$&'()*+,;=%]+)/, fn = /__dialPostData__=([A-Za-z0-9]+={0,2})/;
var hn = function(a, b) {
  this.$a = a;
  this.appName = b;
};
var jn = function(a) {
  this.Cd = new Map;
  this.Lv = a;
};
d = jn.prototype;
d.init = function() {
  Rh(this);
};
d.clear = function() {
  this.Cd.clear();
};
d.add = function(a) {
  this.lG(a.$a.id) || (this.Cd.set(a.$a.id, a), this.Lv.U2(a));
};
d.lG = function(a) {
  return this.Cd.get(a) || null;
};
d.mG = function(a) {
  for (var b = ka(this.Cd), c = b.next();!c.done;c = b.next()) {
    if (c = ka(c.value), c.next(), c = c.next().value, c.$a.sinkId == a) {
      return c;
    }
  }
  return null;
};
d.d7 = function(a) {
  if (a = this.mG(a)) {
    this.Cd.delete(a.$a.id), this.Lv.nK(a);
  }
};
d.GL = function(a) {
  var b = this.Cd.get(a);
  b && (this.Cd.delete(a), this.Lv.nK(b));
};
d.vf = function() {
  return Array.from(this.Cd.values(), function(a) {
    return a.$a;
  });
};
d.KV = function() {
  return Array.from(this.Cd.values());
};
d.oa = function() {
  return "dial.ActivityRecords";
};
d.getData = function() {
  return [Array.from(this.Cd)];
};
d.Xa = function() {
  var a = Oh(this);
  a && (this.Cd = new Map(a));
};
var kn = {Jea:0, dha:1, jga:2, Iea:3}, ln = {ERROR:0, Bga:1, EMPTY:2}, mn = function(a) {
  ah("MediaRouter.Dial.Create.Route", a, kn);
}, nn = function(a) {
  ah("MediaRouter.Dial.Device.Description.Failure", a, ln);
};
var on = /^([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})$/, pn = [4278190080, 4293918720, 4294901760], qn = [167772160, 2886729728, 3232235520], rn = function(a) {
  var b = document.createElement("a");
  b.href = a;
  return b;
};
var sn = function() {
  this.configId = this.modelName = this.deviceType = this.expireTimeMillis = this.fetchTimeMillis = this.appUrl = this.ipAddress = this.friendlyName = this.deviceLabel = this.uniqueId = null;
};
sn.prototype.mP = function() {
  var a;
  if (this.deviceLabel) {
    if (this.uniqueId) {
      if (this.friendlyName) {
        if (this.ipAddress) {
          if (this.appUrl) {
            if (this.fetchTimeMillis) {
              if (this.expireTimeMillis) {
                a = this.ipAddress;
                var b = rn(this.appUrl);
                a = "http:" == b.protocol && b.hostname == a ? null : "Invalid appUrl";
              } else {
                a = "Missing expireTimeMillis";
              }
            } else {
              a = "Missing fetchTimeMillis";
            }
          } else {
            a = "Missing appUrl";
          }
        } else {
          a = "Missing ipAddress";
        }
      } else {
        a = "Missing friendlyName";
      }
    } else {
      a = "Missing uniqueId";
    }
  } else {
    a = "Missing deviceLabel";
  }
  return a;
};
sn.prototype.toString = function() {
  return JSON.stringify(this, function(a, b) {
    return p(b) && 0 == b.indexOf("uuid:") ? "***" : b;
  });
};
var tn = function(a) {
  var b = new sn;
  b.uniqueId = a.uniqueId;
  b.deviceLabel = a.deviceLabel;
  b.friendlyName = a.friendlyName;
  b.ipAddress = a.ipAddress;
  b.appUrl = a.appUrl;
  b.fetchTimeMillis = a.fetchTimeMillis;
  b.expireTimeMillis = a.expireTimeMillis;
  b.deviceType = a.deviceType;
  b.modelName = a.modelName;
  b.configId = a.configId;
  return b;
}, wn = function(a) {
  this.Dn = new Map;
  this.Yb = new Map;
  this.hA = new Map;
  var b;
  (b = a) || (un || (un = new Sm(3, null, 1, 10, 2000)), b = un);
  this.ln = b;
  a || (vn || (vn = new Sm(2, null, 1, 10, 3000)), a = vn);
  this.iR = a;
  this.a = D("mr.dial.DeviceDescriptionService");
  Rh(this);
};
d = wn.prototype;
d.oa = function() {
  return "mr.dial.DeviceDescriptionService";
};
d.getData = function() {
  return [Array.from(this.Dn)];
};
d.Xa = function() {
  var a = Oh(this);
  if (a) {
    for (var a = ka(a), b = a.next();!b.done;b = a.next()) {
      var c = ka(b.value), b = c.next().value, c = c.next().value;
      null != tn(c).mP() ? this.a.error("Dropping invalid description " + b + " loaded from storage.") : this.Dn.set(b, tn(c));
    }
  }
};
d.SW = function(a) {
  var b = this.YS(a);
  return b ? ($g("MediaRouter.Dial.Device.Description.Cached"), Promise.resolve(b)) : this.jV(a);
};
d.hR = function(a) {
  var b = this.Yb.get(a);
  b && (this.ln.abort(a, !0), b.pb.reject(Error("Aborted")));
};
d.YS = function(a) {
  var b = this.Dn.get(a.deviceLabel);
  return b ? b.configId != a.configId || Date.now() >= b.expireTimeMillis ? (this.a.w("Removing invalid entry " + b.toString()), this.Dn.delete(a.deviceLabel), null) : b : null;
};
d.jV = function(a) {
  var b = this;
  if (!xn(a.deviceDescriptionUrl)) {
    return Promise.reject(Error("Invalid device description URL: " + a.deviceDescriptionUrl));
  }
  var c = this.Yb.get(a.deviceLabel);
  if (c) {
    if (c.deviceDescriptionUrl == a.deviceDescriptionUrl) {
      return c.pb.promise;
    }
    this.hR(a.deviceLabel);
  }
  var e = new Jc, c = {deviceDescriptionUrl:a.deviceDescriptionUrl, pb:e};
  this.Yb.set(a.deviceLabel, c);
  this.ln.send(a.deviceLabel, a.deviceDescriptionUrl, "GET", null, null, 0, function(c) {
    b.Yb.delete(a.deviceLabel);
    (c = b.d6(a, c)) ? e.resolve(c) : e.reject(Error("Failed to get device description"));
  });
  return e.promise;
};
d.d6 = function(a, b) {
  b = b.target;
  De(this.a, "fetchDeviceDescription", "GET", b);
  if (!b.$d()) {
    return this.a.info("Request to " + b.rs() + " failed"), nn(0), null;
  }
  var c = b.IH();
  if (!c) {
    return this.a.info("Invalid or empty response"), nn(2), null;
  }
  b = this.e5(b, a, c);
  if (!b) {
    return nn(1), this.a.info("Invalid device description"), null;
  }
  this.a.info("Got device description for " + b.deviceLabel);
  this.a.w("... device description was: " + b.toString());
  null != b.configId && (this.a.w("Caching device description for " + b.deviceLabel), this.Dn.set(a.deviceLabel, b));
  return b;
};
d.e5 = function(a, b, c) {
  var e = new sn;
  e.fetchTimeMillis = Date.now();
  e.expireTimeMillis = e.fetchTimeMillis + 18E5;
  e.deviceLabel = b.deviceLabel;
  e.configId = b.configId;
  e.appUrl = a.getResponseHeader("Application-URL") || null;
  a = rn(b.deviceDescriptionUrl);
  e.ipAddress = a.hostname;
  e.deviceType = yn(c, "deviceType");
  e.modelName = yn(c, "modelName");
  e.friendlyName = yn(c, "friendlyName");
  e.uniqueId = yn(c, "UDN");
  !e.friendlyName && e.modelName && (e.friendlyName = e.modelName, e.uniqueId && (e.friendlyName += "[" + e.uniqueId.slice(-4) + "]"), this.a.l("Fixed device description: created friendlyName from modelName."));
  a = e.mP();
  this.a.w(function() {
    return "Device description: " + zn(c);
  });
  return a ? (this.a.l(function() {
    return "Device description failed to validate: " + e;
  }, a), null) : e;
};
var yn = function(a, b) {
  return (a = a.getElementsByTagName(b)) && 0 != a.length ? a[0].textContent : null;
}, zn = function(a) {
  var b = function(a) {
    for (var b = 0, c = a.length;b < c;b++) {
      a[b].textContent = "***";
    }
  };
  b(a.getElementsByTagName("UDN"));
  b(a.getElementsByTagName("serialNumber"));
  return (new XMLSerializer).serializeToString(a);
};
wn.prototype.Fn = function(a) {
  var b = this, c = this.hA.get(a);
  if (c) {
    return c.promise;
  }
  c = new Jc;
  this.hA.set(a, c);
  this.iR.send(a, a, "GET", null, null, 0, function(e) {
    b.hA.delete(a);
    e = e.target;
    De(b.a, "checkAccess", "GET", e, !1);
    c.resolve(e.$d());
  });
  return c.promise;
};
var xn = function(a) {
  a = rn(a);
  var b;
  if (b = "http:" == a.protocol) {
    a: {
      b: {
        if ((a = a.hostname.match(on)) && 5 == a.length) {
          b = [];
          for (var c = 0;4 > c;c++) {
            if (b[c] = Number.parseInt(a[c + 1], 10), 0 > b[c] || 255 < b[c]) {
              a = null;
              break b;
            }
          }
          a = b;
        } else {
          a = null;
        }
      }
      if (a) {
        for (a = (a[0] << 24 | a[1] << 16 | a[2] << 8 | a[0]) >>> 0, b = 0;3 > b;b++) {
          if ((a & pn[b]) >>> 0 == qn[b]) {
            b = !0;
            break a;
          }
        }
      }
      b = !1;
    }
  }
  return b;
}, un = null, vn = null;
var An = null, Bn = null, Cn = function() {
  An || (An = new Zi(3, "dial.DialOnDeviceListEventListener", "mr.dial.SinkDiscoveryService", chrome.dial.onDeviceList));
  Bn || (Bn = new Zi(4, "dial.DialOnErrorEventListener", "mr.dial.SinkDiscoveryService", chrome.dial.onError));
  return [An, Bn];
};
var Dn = function(a, b) {
  b = void 0 === b ? new wn : b;
  this.fq = a;
  this.iF = b;
  this.a = D("mr.dial.SinkDiscoveryService");
  this.Dc = new Map;
  this.Bt = this.jz = !1;
  this.kf = {Mk:0, Sl:0};
  this.Hr = 0;
};
la(Dn, ph);
d = Dn.prototype;
d.init = function() {
  Rh(this);
  zh("mr.dial.SinkDiscoveryService", this);
};
d.start = function() {
  this.jz || (this.a.info("Starting..."), this.jz = !0, Cn().forEach(function(a) {
    return a.addListener();
  }), this.refresh());
};
d.refresh = function() {
  var a = this;
  this.jz ? chrome.dial.discoverNow(function(b) {
    a.a.info("chrome.dial.discoverNow = " + b);
  }) : this.a.info("Not started. Ignoring discover().");
};
d.y3 = function(a) {
  var b = this;
  this.a.info("onDeviceList returned " + a.length + " devices");
  this.a.w(function() {
    return "....the list is: " + JSON.stringify(a);
  });
  this.Bt = !1;
  var c = 0, e = [], f = new Set;
  a.forEach(function(a) {
    e.push(b.e6(a).then(function(a) {
      f.add(a.getId());
      b.l2(a);
    }, function() {
      c++;
    }));
  });
  xi(e).then(function() {
    b.Bt || b.St(f).then(function() {
      var a = b.Dc.size;
      b.wL(a, a + c);
    });
  });
};
d.wL = function(a, b) {
  this.kf = {Mk:a, Sl:b};
  36E5 > Date.now() - this.Hr || (a = this.kf, bh("MediaRouter.Dial.AvailableDevicesCount", a.Mk), bh("MediaRouter.Dial.KnownDevicesCount", a.Sl), this.Hr = Date.now());
};
d.l2 = function(a) {
  if (!this.Bt) {
    this.a.w("mayAddSink, id = " + a.getId());
    var b = this.Dc.get(a.getId());
    b ? b.update(a) && (this.a.w("Updated sink " + b.getId()), this.fq.Ad(b)) : (this.a.w(function() {
      return "Adding new sink " + a.getId() + ": " + a.BO();
    }), this.Dc.set(a.getId(), a), this.fq.Kj(a));
  }
};
d.St = function(a) {
  var b = this, c = [], e = [];
  this.Dc.forEach(function(f) {
    a.has(f.getId()) || e.push(b.XS(f).then(function(a) {
      a || (b.Dc.delete(f.getId()), c.push(f));
    }));
  });
  return xi(e).then(function() {
    0 < c.length && b.fq.Le(c);
  });
};
d.XS = function(a) {
  return a.lg ? this.iF.Fn(a.lg) : Promise.resolve(!1);
};
d.e6 = function(a) {
  return this.iF.SW(a).then(function(b) {
    var c;
    b.uniqueId ? (c = b.uniqueId, 0 == c.indexOf("uuid:") && (c = c.substr(5)), c = c.replace(/-/g, "").toLowerCase()) : c = "";
    var e = b.uniqueId ? hk.W().pl(c) : a.deviceLabel, f = En.test(b.modelName);
    return (new Nk(b.friendlyName, c)).tu(e).S9(b.ipAddress).r9(b.appUrl).q9(a.deviceDescriptionUrl).n$(b.modelName).UN(!f);
  });
};
d.w4 = function(a) {
  switch(a.code) {
    case "no_valid_network_interfaces":
    case "network_disconnected":
      this.a.l("DIAL error: " + a.code + ". Clear device list now.");
      a = Array.from(this.Dc.values());
      this.Dc.clear();
      this.fq.Le(a);
      this.wL(0, 0);
      this.Bt = !0;
      break;
    case "no_listeners":
    case "socket_error":
    case "cellular_network":
    case "unknown":
      this.a.l("DIAL error: " + a.code + ". Keep device list.");
      break;
    default:
      this.a.l("Unhandled DIAL error: " + a.code);
  }
};
d.Y = function(a) {
  return this.Dc.get(a) || null;
};
d.QZ = function(a) {
  var b = [];
  this.Dc.forEach(function(c) {
    "available" == c.ye(a) && b.push(c.Fh());
  });
  var c = Fn[a];
  return new tm(b, c ? [c] : void 0);
};
d.Xd = function() {
  return Array.from(this.Dc.values());
};
d.d3 = function(a, b) {
  this.fq.Ad(b);
};
d.handleEvent = function(a, b) {
  for (var c = [], e = 1;e < arguments.length;++e) {
    c[e - 1] = arguments[e];
  }
  if (a == chrome.dial.onDeviceList) {
    this.y3.apply(this, [].concat(ma(c)));
  } else {
    if (a == chrome.dial.onError) {
      this.w4.apply(this, [].concat(ma(c)));
    } else {
      throw Error("Unhandled event");
    }
  }
};
d.oa = function() {
  return "dial.DialSinkDiscoveryService";
};
d.getData = function() {
  return [new Gn(Array.from(this.Dc), this.kf), {deviceCountMetricsRecordTime:this.Hr}];
};
d.Xa = function() {
  var a = Oh(this);
  if (a) {
    for (var b = ka(a.sinks), c = b.next();!c.done;c = b.next()) {
      c = c.value, this.Dc.set(c[0], Ok(c[1]));
    }
    this.kf = a.deviceCounts;
  }
  if (a = Ph(this)) {
    this.Hr = a.deviceCountMetricsRecordTime;
  }
};
var Fn = {YouTube:"https://www.youtube.com", Netflix:"https://www.netflix.com", Pandora:"https://www.pandora.com", Radio:"https://www.pandora.com", Hulu:"https://www.hulu.com", Vimeo:"https://www.vimeo.com", Dailymotion:"https://www.dailymotion.com", "com.dailymotion":"https://www.dailymotion.com"}, En = /Eureka Dongle|Chromecast Audio/i, Gn = function(a, b) {
  this.sinks = a;
  this.deviceCounts = b;
};
var Hn = function(a, b) {
  this.a = D("mr.dial.AppDiscoveryService");
  this.zc = new Set;
  this.ea = a;
  this.kd = b;
  this.Yb = new Map;
  this.Gw = new Map;
  this.Te = null;
  this.vm = !1;
};
d = Hn.prototype;
d.init = function() {
  Rh(this);
};
d.start = function() {
  this.a.info("Starting periodic scanning.");
  this.vm || (this.vm = !0, this.sF());
};
d.stop = function() {
  this.a.info("Stopping periodic scanning.");
  this.vm && (this.vm = !1, this.Te && (clearTimeout(this.Te), this.Te = null), this.Yb.clear(), this.Gw.forEach(function(a) {
    a.abort();
  }));
};
d.BA = function(a) {
  if (!this.zc.has(a) || this.LR(a)) {
    this.zc.add(a), 0 != this.ea.Dc.size && (this.vm ? this.ea.Xd().forEach(this.rF.bind(this, a)) : this.start());
  }
};
d.mC = function(a) {
  this.zc.delete(a);
};
d.nZ = function() {
  return Array.from(this.zc);
};
d.sF = function() {
  var a = this;
  this.a.info("Start app status scan.");
  var b = [];
  this.ea.Xd().forEach(function(c) {
    b.push.apply(b, a.Qp(c));
  });
  this.kd.KV().forEach(function(c) {
    b.push(a.f8(c));
  });
  xi(b).then(function() {
    a.vm && !a.Te && (a.a.w("Scan complete; scheduling for next scan."), a.Te = setTimeout(function() {
      a.BU();
    }, 6E4));
  });
};
d.BU = function() {
  this.a.w("Start app status scan (timer-based)");
  this.Te = null;
  this.sF();
};
d.Qp = function(a) {
  if (!a.Rm) {
    return [];
  }
  for (var b = [], c = ka(this.zc), e = c.next();!e.done;e = c.next()) {
    b.push(this.rF(e.value, a));
  }
  return b;
};
d.rF = function(a, b) {
  if ("unknown" != b.ye(a) && 36E5 > Date.now() - b.NV(a) || !b.Rm) {
    return Promise.resolve();
  }
  this.a.w("Querying " + b.getId() + " for " + a + " to update app status");
  return this.dG(b, a).then(this.s2.bind(this, b, a));
};
d.f8 = function(a) {
  var b = this.ea.Y(a.$a.sinkId);
  if (!b) {
    return this.a.l("Activity refers to nonexistent sink: " + a.$a.id), Promise.resolve();
  }
  if (!b.Rm) {
    return Promise.resolve();
  }
  a = a.appName;
  this.a.w("Querying " + b.getId() + " for " + a + " to update activity");
  return this.dG(b, a).then(this.r2.bind(this, b, a));
};
d.VW = function(a) {
  var b = this.Gw.get(a.getId());
  b || (b = new $m(a), this.a.w("Created DIAL client for " + a.getId()), this.Gw.set(a.getId(), b));
  return b;
};
d.dG = function(a, b) {
  var c = this, e = In(a, b), f = this.Yb.get(e);
  if (f) {
    return f;
  }
  f = this.VW(a).yx(b);
  this.Yb.set(e, f);
  a = function() {
    c.Yb.delete(e);
  };
  f.then(a, a);
  return f;
};
d.XV = function(a, b) {
  if (404 == b.GP.Ra()) {
    return "unavailable";
  }
  b = b.Zf;
  if ("Netflix" == a) {
    return this.MV(b);
  }
  switch(b.state) {
    case "running":
    case "stopped":
      return "available";
    default:
      return "unavailable";
  }
};
d.MV = function(a) {
  x("Netflix" == a.name, "Expecting app name to be Netflix");
  return !a.extraData || "websocket" != a.extraData.capabilities || "running" != a.state && "stopped" != a.state ? "unavailable" : "available";
};
var In = function(a, b) {
  return a.getId() + ":" + b;
};
d = Hn.prototype;
d.s2 = function(a, b, c) {
  if (404 == c.GP.Ra() || c.Zf) {
    c = this.XV(b, c);
    this.a.w("Got app status " + c + " from " + a.getId() + " for " + b);
    var e = a.ye(b);
    a.Vp(b, c);
    c != e && this.ea.d3(b, a);
  } else {
    this.a.l("Failed to process app availability; " + a.getId() + " does not support app availability"), a.UN(!1);
  }
};
d.r2 = function(a, b, c) {
  (a = this.kd.mG(a.getId())) && a.appName == b && !c.d8 && this.kd.GL(a.$a.id);
};
d.LR = function(a) {
  return this.ea.Xd().some(function(b) {
    return "unknown" == b.ye(a);
  });
};
d.oa = function() {
  return "dial.AppDiscoveryService";
};
d.getData = function() {
  return [this.nZ()];
};
d.Xa = function() {
  var a = Oh(this);
  this.zc = new Set(a || []);
};
var Jn = function(a, b, c) {
  this.o = a;
  this.Cc = b || new Dn(this);
  this.kd = new jn(this);
  this.nd = c || new Hn(this.Cc, this.kd);
  this.a = D("mr.DialProvider");
};
d = Jn.prototype;
d.getName = function() {
  return "dial";
};
d.mc = function() {
  this.kd.init();
  this.Cc.init();
  this.Cc.start();
  this.nd.init();
  this.np();
};
d.zh = function(a) {
  this.a.w("GetAvailableSinks for " + a);
  return (a = dn(a)) ? this.Cc.QZ(a.appName) : um;
};
d.startObservingMediaSinks = function(a) {
  if (a = dn(a)) {
    this.nd.BA(a.appName), this.np();
  }
};
d.stopObservingMediaSinks = function(a) {
  if (a = dn(a)) {
    this.nd.mC(a.appName), this.pt();
  }
};
d.startObservingMediaRoutes = function() {
  this.np();
};
d.stopObservingMediaRoutes = function() {
  this.pt();
};
d.pt = function() {
  (0 == this.Cc.Dc.size || 0 == this.nd.zc.size && 0 == this.kd.Cd.size) && this.nd.stop();
};
d.np = function() {
  0 < this.Cc.Dc.size && (0 < this.nd.zc.size || 0 < this.kd.Cd.size) && this.nd.start();
};
d.Y = function(a) {
  return (a = this.Cc.Y(a)) ? a.Fh() : null;
};
d.vf = function() {
  return this.kd.vf();
};
d.createRoute = function(a, b, c, e) {
  var f = this, g = this.Cc.Y(b);
  if (!g) {
    return mn(0), Jg(Error("Unkown sink: " + b));
  }
  hk.W().Wj = new gk(g.xc, g.qa);
  var k = dn(a);
  if (!k) {
    return Jg(Error("No app name set."));
  }
  var q = k.appName, r = this.eK(g);
  return Kg(r.yx(q).then(function(a) {
    if (!a.Zf) {
      throw Error("Failed to get app info");
    }
    if ("running" == a.Zf.state) {
      return r.mO(q);
    }
  }).then(function() {
    return r.launchApp(q, k.launchParameter);
  }).then(function() {
    return f.af(b, a, !0, q, c, e);
  }).catch(function(a) {
    mn(3);
    throw a;
  }));
};
d.joinRoute = function() {
  return Jg(Error("Not supported"));
};
d.connectRouteByRouteId = function() {
  return Jg(Error("Not supported"));
};
d.detachRoute = function() {
};
d.af = function(a, b, c, e, f, g) {
  mn(1);
  a = ym(f, this.getName(), a, b, c, e, null);
  a.offTheRecord = g;
  this.kd.add(new hn(a, e));
  return a;
};
d.Kj = function(a) {
  this.o.onSinkAvailabilityUpdated(this, 1);
  this.np();
  this.nd.Qp(a);
  this.o.ee();
  hk.W().Vj = new gk(a.xc, a.qa);
};
d.Le = function(a) {
  var b = this;
  if (0 == this.Cc.Dc.size) {
    this.o.onSinkAvailabilityUpdated(this, 0);
  }
  this.pt();
  a.forEach(function(a) {
    b.kd.d7(a.getId());
  });
  this.o.ee();
};
d.Ad = function() {
  this.o.ee();
};
d.U2 = function(a) {
  this.np();
  this.o.Jj(this, a.$a);
};
d.nK = function(a) {
  a = a.$a;
  if (a.isLocal) {
    this.o.onPresentationConnectionStateChanged(a.id, "terminated");
  }
  this.pt();
  this.o.Ig(this, a);
};
d.terminateRoute = function(a) {
  var b = this.kd.lG(a);
  if (!b) {
    return Promise.reject(new sm(3, "Route in DIAL provider not found for routeId " + a));
  }
  this.kd.GL(a);
  return (a = this.Cc.Y(b.$a.sinkId)) ? this.eK(a).mO(b.appName) : Promise.reject(new sm(3, "Sink in DIAL provider not found for sinkId " + b.$a.sinkId));
};
d.cj = function() {
  return null;
};
d.bj = function() {
  return null;
};
d.sendRouteMessage = function() {
  return Promise.reject(Error("DIAL sending message is not supported"));
};
d.Ok = function(a, b) {
  b = this.Cc.Y(b);
  return !b || kh(a) ? !1 : (a = dn(a)) ? "available" == b.ye(a.appName) : !1;
};
d.Ii = function() {
  return !1;
};
d.searchSinks = function() {
  return null;
};
d.eK = function(a) {
  return new $m(a);
};
var Kn = function(a, b) {
  this.TS = a;
  this.bx = b;
  this.kh = this.TS.ea;
  this.a = D("mr.cast.CastDialSinkDiscoveryCallbacks");
};
d = Kn.prototype;
d.EU = function(a) {
  return this.kh.Fn(a);
};
d.OH = function(a) {
  var b = this.kh.Y(a.getId());
  return b ? b : (a = a.qa) ? this.kh.OZ(a, hk.W().Qk || 8009) : null;
};
d.Kj = function(a) {
  this.OH(a) ? $k(2) : this.NO(a);
  this.bx.Kj(a);
};
d.NO = function(a) {
  var b = this, c = Qk(a);
  c && this.EU(c).then(function(e) {
    e ? b.OH(a) ? $k(2) : (b.kh.sn(c), $k(0)) : $g("MediaRouter.Dial.Sink.Discovered.NonCast");
  }, n);
};
d.Le = function(a) {
  var b = this;
  y(a, function(a) {
    var c = b.kh.Y(a.getId());
    c && c.il && b.kh.Zj(a.getId());
  });
  this.bx.Le(a);
};
d.Ad = function(a) {
  var b = this.kh.Y(a.getId());
  b ? b.il && (b.update(a.ul(), a.qa, b.Wa(), b.pd) && this.a.info("Updated Cast sink with DIAL sink: " + a.getId()), this.kh.Ad(b)) : this.NO(a);
  this.bx.Ad(a);
};
var Ln = function(a, b) {
  this.ea = new Dn(new Kn(b, this));
  this.dk = new I;
  this.o = a;
  this.Up = this.hk = 0;
  this.fp = new Ae;
  this.gb = new Jn(this, this.ea);
};
d = Ln.prototype;
d.oa = function() {
  return "cast.DialProviderWrapper";
};
d.getData = function() {
  return [new Mn(this.dk.b(), this.hk, this.Up, this.fp.H())];
};
d.Xa = function() {
  var a = Oh(this);
  a && (this.dk.addAll(a.V7), this.hk = a.sequenceNumber, this.Up = a.G8, this.fp.addAll(a.O1));
};
d.getName = function() {
  return this.gb.getName();
};
d.mc = function() {
  this.gb.mc();
  Rh(this);
};
d.vf = function() {
  return this.gb.vf();
};
d.CK = function() {
};
d.zh = function(a) {
  return this.gb.zh(a);
};
d.startObservingMediaSinks = function(a) {
  this.gb.startObservingMediaSinks(a);
};
d.stopObservingMediaSinks = function(a) {
  this.gb.stopObservingMediaSinks(a);
};
d.startObservingMediaRoutes = function(a) {
  this.gb.startObservingMediaRoutes(a);
};
d.stopObservingMediaRoutes = function(a) {
  this.gb.stopObservingMediaRoutes(a);
};
d.Y = function(a) {
  return this.gb.Y(a);
};
d.ks = function(a) {
  return new $m(a);
};
d.Hx = function(a) {
  return this.ea.Y(a);
};
d.zU = function(a, b, c, e) {
  var f = this, g = dn(a), k = this.Hx(b);
  if (!k) {
    return Promise.reject(Error("Attempting custom launch with closed route"));
  }
  var q = g.appName;
  if (!q) {
    return Promise.reject(Error("No app name given"));
  }
  var r = Vl(a);
  if (!r) {
    return Promise.reject(Error("No client ID"));
  }
  var A = null;
  return this.ks(k).yx(q).then(function(a) {
    if (!a.Zf) {
      return Promise.reject(Error("Failed to get app info"));
    }
    A = a.Zf;
  }).then(function() {
    return f.gb.af(b, a, !0, q, e, c);
  }).then(function(a) {
    var b = {routeId:a.id, sinkId:k.getId(), appName:q, Zf:A, launchParameter:g.launchParameter, session:null, clientId:null};
    f.dk.set(a.id, b);
    f.OT(b, r);
    return a;
  });
};
d.j1 = function(a) {
  return Nn.test(a);
};
d.createRoute = function(a, b, c, e, f, g, k) {
  return this.j1(a) ? Kg(this.zU(a, b, e, c)) : this.gb.createRoute(a, b, c, e, f, g, k);
};
d.terminateRoute = function(a) {
  var b = this.dk.get(a);
  if (b && b.session && b.clientId) {
    var c = {receiver:this.Pw(b.sinkId), action:chrome.cast.qn.STOP}, c = new Nl("receiver_action", c);
    c.clientId = b.clientId;
    this.o.Ke(this, b.routeId, c);
    this.o.onPresentationConnectionStateChanged(b.routeId, "terminated");
  }
  return this.gb.terminateRoute(a);
};
d.sendRouteMessage = function(a, b, c) {
  var e = JSON.parse(b);
  switch(e.type) {
    case "client_connect":
      return this.t7(a, e.clientId);
    case "custom_dial_launch":
      if (this.fp.contains(e.sequenceNumber)) {
        return this.p3(a, e);
      }
      break;
    case "v2_message":
      if ("STOP" == e.message.type) {
        return this.terminateRoute(a), Promise.resolve();
      }
  }
  return this.gb.sendRouteMessage(a, b, c);
};
d.IY = function() {
  var a = String(this.Up);
  this.Up = (this.Up + 1) % 9007199254740992;
  return a;
};
d.OT = function(a, b) {
  var c = this.Pw(a.sinkId), e = new Nl("receiver_action", {receiver:c, action:chrome.cast.qn.CAST});
  e.clientId = b;
  this.o.Ke(this, a.routeId, e);
  c = new chrome.cast.D(this.IY(), "", a.appName, [], c);
  a.session = c;
  a.clientId = b;
  c = new Nl("new_session", c);
  c.clientId = b;
  this.o.Ke(this, a.routeId, c);
};
d.p3 = function(a, b) {
  this.fp.remove(b.sequenceNumber);
  b = b.message;
  a = this.dk.get(a);
  if (!a) {
    return Promise.reject(Error("Unknown route"));
  }
  if (b && !b.doLaunch) {
    return Promise.resolve();
  }
  var c = this.Hx(a.sinkId);
  if (!c) {
    return Promise.reject(Error("Custom launch response for sink that no longer exists"));
  }
  var c = new $m(c), e = a.launchParameter, e = (b ? b.launchParameter : null) || e;
  return c.launchApp(a.appName, e);
};
d.Pw = function(a) {
  var b = this.Hx(a);
  a = new chrome.cast.Ev(a, b.ul());
  a.ipAddress = b.qa;
  a.receiverType = chrome.cast.Jq.DIAL;
  return a;
};
d.HY = function() {
  var a = this.hk;
  this.hk = (this.hk + 1) % 9007199254740992;
  return a;
};
d.t7 = function(a, b) {
  a = this.dk.get(a);
  if (!a) {
    return Promise.reject(Error("Unknown route"));
  }
  var c = this.Pw(a.sinkId);
  c.receiverType = chrome.cast.Jq.DIAL;
  c = new Nl("custom_dial_launch", new chrome.cast.XC(c, a.Zf.state, a.Zf.extraData));
  c.clientId = b;
  c.sequenceNumber = this.HY();
  this.fp.add(c.sequenceNumber);
  this.o.Ke(this, a.routeId, c);
  return Promise.resolve();
};
d.cj = function(a) {
  return this.gb.cj(a);
};
d.bj = function(a) {
  return this.gb.bj(a);
};
d.Ok = function(a, b) {
  return this.gb.Ok(a, b);
};
d.Ii = function(a, b) {
  return this.gb.Ii(a, b);
};
d.connectRouteByRouteId = function(a, b, c, e, f) {
  return this.gb.connectRouteByRouteId(a, b, c, e, f);
};
d.joinRoute = function(a, b, c, e, f, g) {
  return this.gb.joinRoute(a, b, c, e, f, g);
};
d.detachRoute = function(a) {
  this.dk.remove(a);
  this.gb.detachRoute(a);
};
d.ee = function() {
  this.o.ee();
};
d.onSinkAvailabilityUpdated = function(a, b) {
  this.o.onSinkAvailabilityUpdated(a, b);
};
d.Jj = function(a, b) {
  this.o.Jj(this, b);
};
d.Ig = function(a, b) {
  this.o.Ig(this, b);
};
d.Yh = function(a, b) {
  this.o.Yh(this, b);
};
d.Ke = function(a, b, c) {
  this.o.Ke(this, b, c);
};
d.onPresentationConnectionStateChanged = function(a, b) {
  this.o.onPresentationConnectionStateChanged(a, b);
};
d.onPresentationConnectionClosed = function(a, b, c) {
  this.o.onPresentationConnectionClosed(a, b, c);
};
d.cy = function(a) {
  return this.o.cy(a);
};
d.hy = function() {
  return this.o.hy();
};
d.ug = function() {
  return this.o.ug();
};
d.Et = function(a, b, c) {
  this.o.Et(this, b, c);
};
d.Nz = function(a) {
  this.o.Nz(a);
};
d.Kj = function(a) {
  this.gb.Kj(a);
};
d.Le = function(a) {
  this.gb.Le(a);
};
d.Ad = function(a) {
  this.gb.Ad(a);
};
d.mq = function() {
};
d.cv = function() {
};
d.searchSinks = function(a, b) {
  return this.gb.searchSinks(a, b);
};
d.CA = function(a) {
  this.o.CA(a);
};
d.My = function() {
  return this.o.My();
};
d.Lf = function(a, b) {
  return this.o.Lf(a, b);
};
var Mn = function(a, b, c, e) {
  this.V7 = a;
  this.sequenceNumber = b;
  this.G8 = c;
  this.O1 = e;
}, Nn = /__dialAppName__/;
var On = function(a, b) {
  var c = new XMLHttpRequest;
  c.open(b, a, !1);
  c.send(null);
  return 200 === c.status ? c.responseText : null;
};
var Pn = function(a) {
  this.Mc = a;
  this.rp = null;
  this.start = this.start;
  this.stop = this.stop;
  this.stopMirroring = this.Fba;
  this.mirrorDesktopViaCastStreaming = this.I2;
  this.mirrorTabViaCastStreaming = this.J2;
  this.getSinksForCastUrn = this.RZ;
};
d = Pn.prototype;
d.start = function() {
  var a = this.Mc.Hh("cast");
  a && (a.startObservingMediaSinks("urn:x-org.chromium.media:source:desktop"), a.startObservingMediaSinks("https://google.com/cast#__castAppId__=BE6E4473"));
};
d.stop = function() {
  var a = this.Mc.Hh("cast");
  a && (a.stopObservingMediaSinks("urn:x-org.chromium.media:source:desktop"), a.stopObservingMediaSinks("https://google.com/cast#__castAppId__=BE6E4473"));
};
d.Fba = function() {
  var a = this;
  this.rp && this.Mc.terminateRoute(this.rp).then(function() {
    a.rp = null;
  });
};
d.I2 = function(a) {
  var b = this;
  (a = this.NH(a, "cast")) && this.Mc.createRoute("urn:x-org.chromium.media:source:desktop", a.id, this.VF()).then(function(a) {
    b.rp = a.id;
  });
};
d.J2 = function(a, b, c, e) {
  var f = this, g = this.NH(a, "cast");
  if (g) {
    if (c && e) {
      var k = function(a) {
        var b = a.address, f = a.port, g = new Qj(c + "/start"), k = new Rj;
        k.set("eureka_ip", b);
        k.set("mirroring_port", f);
        k.set("network_profile", e);
        g.Gm(k);
        b = On(g.toString(), "GET").split(":");
        a.address = b[0];
        a.port = Number(b[1]);
      }, q = function(a) {
        a = a.port;
        var b = new Qj(c + "/stop"), e = new Rj;
        e.set("udp_proxy_ports", a);
        b.Gm(e);
        On(b.toString(), "GET");
      };
      this.Mc.vo("cast_streaming").then(function(a) {
        a.Kaa({onAnswer:k, onSessionStop:q});
      });
    }
    chrome.tabs.create({url:b}, function(a) {
      f.Mc.createRoute("urn:x-org.chromium.media:source:tab:" + a.id, g.id, f.VF(), void 0, a.id).then(function(a) {
        f.rp = a.id;
      });
    });
  }
};
d.RZ = function() {
  var a = this.Mc.Hh("cast");
  return a ? a.zh("https://google.com/cast#__castAppId__=BE6E4473").sinks : [];
};
d.NH = function(a, b) {
  return (b = this.Mc.Hh(b)) ? b.zh("urn:x-org.chromium.media:source:desktop").sinks.find(function(b) {
    return b.friendlyName == a;
  }) || null : null;
};
d.VF = function() {
  return "test" + Math.floor(1e6 * Math.random());
};
var Qn = function(a, b) {
  this.routeId = a;
  this.message = b;
}, Rn = function(a) {
  return "string" != typeof a.message;
};
var Sn = function(a) {
  if (0 >= a) {
    throw Error("invalid buffer size");
  }
  this.Yd = [];
  this.Tm = [];
  this.Yl = a;
};
d = Sn.prototype;
d.enqueue = function(a) {
  this.V() >= this.Yl && this.uh();
  this.Tm.push(a);
};
d.uh = function() {
  if (this.Bb()) {
    throw Error("Empty queue");
  }
  0 == this.Yd.length && (this.Yd = this.Tm, this.Yd.reverse(), this.Tm = []);
  return this.Yd.pop();
};
d.mU = function() {
  var a = this.H();
  this.clear();
  return a;
};
d.V = function() {
  return this.Yd.length + this.Tm.length;
};
d.l1 = function() {
  return this.V() == this.Yl;
};
d.Bb = function() {
  return 0 == this.V();
};
d.H = function() {
  var a = this.Yd.slice();
  a.reverse();
  a.push.apply(a, [].concat(ma(this.Tm)));
  return a;
};
d.clear = function() {
  this.Yd = [];
  this.Tm = [];
};
var Tn = function(a) {
  this.yd = a;
  this.Ue = this.$s = null;
};
d = Tn.prototype;
d.lT = function() {
  null != this.Ue && (clearTimeout(this.Ue), this.Ue = null);
};
d.iM = function() {
  if (null == this.Ue) {
    if (null == this.$s || Date.now() - this.$s >= this.yd) {
      this.$b();
    } else {
      var a = Math.max(this.$s + this.yd - Date.now(), 5);
      this.Ue = setTimeout(this.$b.bind(this), a);
    }
  }
};
d.nM = function() {
  this.$b();
};
d.$b = function() {
  this.lT();
  this.tF();
  this.$s = Date.now();
};
d.tF = function() {
};
var Un = function(a, b) {
  Tn.call(this, 20);
  this.Kf = new Map;
  this.Rh = new Set;
  this.aB = null;
  this.dr = this.Zg = 0;
  this.cO = !1;
  this.o = a;
  this.E2 = b;
  this.a = D("mr.RouteMessageSender");
};
la(Un, Tn);
d = Un.prototype;
d.init = function(a) {
  this.aB = a;
  Rh(this);
};
d.R1 = function(a) {
  this.Rh.has(a) || (this.Rh.add(a), this.G0(a) && this.iM());
};
d.stopListeningForRouteMessages = function(a) {
  this.Rh.delete(a);
};
d.send = function(a, b) {
  var c = this.Kf.get(a);
  c || (c = new Sn(50), this.Kf.set(a, c));
  if (c.l1()) {
    this.a.l("Queue is full; dropping oldest message");
    this.a.w("   for route " + a);
    var e = c.uh();
    this.Zg -= Rn(e) ? 0 : e.message.length;
    Rn(e) && this.dr--;
  }
  b = new Qn(a, b);
  c.enqueue(b);
  this.Zg += Rn(b) ? 0 : b.message.length;
  Rn(b) && this.dr++;
  this.uC();
  this.Rh.has(a) && this.iM();
};
d.Ig = function(a) {
  this.Rh.delete(a);
  var b = this.Kf.get(a);
  b && (this.Kf.delete(a), this.BK(b.H()), this.uC());
};
d.BK = function(a) {
  if (0 != a.length) {
    a = ka(a);
    for (var b = a.next();!b.done;b = a.next()) {
      b = b.value, this.Zg -= Rn(b) ? 0 : b.message.length, Rn(b) && this.dr--;
    }
  }
};
d.G0 = function(a) {
  return this.Kf.has(a) && !this.Kf.get(a).Bb();
};
d.uC = function() {
  var a = 0 < this.dr || this.Zg > this.E2;
  a != this.cO && (this.cO = a, this.o.Lf(this.oa(), a));
};
d.tF = function() {
  if (this.aB) {
    for (var a = ka(this.Rh), b = a.next();!b.done;b = a.next()) {
      var b = b.value, c = this.Kf.get(b);
      c && !c.Bb() && (c = c.mU(), this.aB(b, c), this.BK(c));
    }
    this.uC();
  } else {
    this.a.error("sendMessagesCallback not set. Messages not delivered.");
  }
};
d.oa = function() {
  return "mr.RouteMessageSender";
};
d.getData = function() {
  var a = Array.from(this.Kf, function(a) {
    return [a[0], a[1].H()];
  }), b = Array.from(this.Rh);
  return [new Vn(a, b, this.Zg)];
};
d.Xa = function() {
  var a = this, b = Oh(this);
  b && (this.Kf = new Map, b.E6.forEach(function(b) {
    var c = b[0];
    b = b[1];
    var f = new Sn(50);
    a.Kf.set(c, f);
    b.forEach(function(a) {
      f.enqueue(a);
    });
  }), this.Rh = new Set(b.V1), this.Zg = b.dca);
};
var Vn = function(a, b, c) {
  this.E6 = a;
  this.V1 = b;
  this.dca = c;
};
var Wn = function(a, b, c) {
  Rc.call(this);
  this.Cg = null != c ? u(a, c) : a;
  this.yd = b;
  this.Hi = u(this.Uz, this);
  this.Di = [];
};
w(Wn, Rc);
d = Wn.prototype;
d.Re = !1;
d.Me = 0;
d.ab = null;
d.bo = function(a) {
  this.Di = arguments;
  this.ab || this.Me ? this.Re = !0 : this.kl();
};
d.stop = function() {
  this.ab && (je(this.ab), this.ab = null, this.Re = !1, this.Di = []);
};
d.pause = function() {
  this.Me++;
};
d.resume = function() {
  this.Me--;
  this.Me || !this.Re || this.ab || (this.Re = !1, this.kl());
};
d.U = function() {
  Wn.T.U.call(this);
  this.stop();
};
d.Uz = function() {
  this.ab = null;
  this.Re && !this.Me && (this.Re = !1, this.kl());
};
d.kl = function() {
  this.ab = ie(this.Hi, this.yd);
  this.Cg.apply(null, this.Di);
};
var Xn = function(a) {
  this.Mc = a;
  this.a = D("mr.ExternalMessageHandler");
};
Xn.prototype.onMessage = function(a, b, c) {
  this.a.info("Received a message from " + b.id + " type: " + a.type);
  var e = chrome.runtime.id;
  "start" == a.type ? (a = a.message, a = this.Mc.searchSinks("pseudo:cloud", "urn:x-org.chromium.media:source:desktop", new ii(a.meetingName, a.domain)), b = "PresentationId" + b.id + Yn++, this.Mc.createRoute("urn:x-org.chromium.media:source:desktop", a, b).then(function(a) {
    c(new Nf(e, "route", a.id));
  }).catch(function(a) {
    c(new Nf(e, "error", a));
  })) : "stop" == a.type ? this.Mc.terminateRoute(a.message.routeId).then(function() {
    c(new Nf(e, "stopped"));
  }) : (c(new Nf(e, "error", Error("Unhandled message type"))), this.a.error("Unhandled message type " + a.type));
};
var Yn = 0;
var Zn = function() {
  this.bg = new Sn(1000);
  this.ri = Date.now();
};
d = Zn.prototype;
d.init = function() {
  Dc = 1;
  var a = D("browser"), b = window.onerror;
  window.onerror = function(c, f, g, k, q) {
    b && b(c, f, g, k, q);
    a.error("Error: " + c + " (" + f + " @ Line: " + g + ")", q);
  };
  Ec.push(this.S3.bind(this));
  var c = window.localStorage["debug.logs"];
  c && (Dc = Hc(c.toUpperCase(), 0));
  window.localStorage["debug.console"] && Ec.push(this.oz.bind(this));
};
d.S3 = function(a) {
  this.bg.enqueue(this.SF(a, !1));
  a = a.pg;
  a instanceof Error && a.stack && this.bg.enqueue(a.stack);
};
d.oz = function(a) {
  var b = [this.SF(a, !0)];
  a.pg && b.push(a.pg);
  switch(a.level) {
    case 3:
      console.error.apply(console, [].concat(ma(b)));
      break;
    case 2:
      console.warn.apply(console, [].concat(ma(b)));
      break;
    case 1:
      console.log.apply(console, [].concat(ma(b)));
      break;
    default:
      console.debug.apply(console, [].concat(ma(b)));
  }
};
d.SF = function(a, b) {
  var c = ["["];
  if (b) {
    c.push(("       " + ((Date.now() - this.ri) / 1000).toFixed(3)).slice(-7));
  } else {
    var e = new Date(a.time), f = function(a) {
      return 10 > a ? "0" + a : a;
    };
    c.push(e.getFullYear().toString(), "-", f(e.getMonth() + 1), "-", f(e.getDate()), " ", f(e.getHours()), ":", f(e.getMinutes()), ":", f(e.getSeconds()), ".", f(Math.floor(e.getMilliseconds() / 10)));
  }
  c.push("][", Gc[a.level], "][", a.m, "] ", a.message);
  if (!b && null != a.pg) {
    if (c.push("\n"), a.pg instanceof Error) {
      c.push(a.pg.message);
    } else {
      try {
        c.push(JSON.stringify(a.pg));
      } catch (g) {
        c.push(a.pg.toString());
      }
    }
  }
  c.push("\n");
  return c.join("");
};
d.getLogs = function() {
  return 0 == this.bg.V() ? "NA" : this.bg.H().join("");
};
d.R6 = function() {
  Rh(this);
};
d.oa = function() {
  return "LogManager";
};
d.getData = function() {
  return [this.bg.H()];
};
d.Xa = function() {
  var a = this.bg.H();
  this.bg.clear();
  for (var b = ka(Oh(this) || []), c = b.next();!c.done;c = b.next()) {
    this.bg.enqueue(c.value);
  }
  a = ka(a);
  for (c = a.next();!c.done;c = a.next()) {
    this.bg.enqueue(c.value);
  }
};
pa(Zn);
var $n = function(a) {
  this.Mc = a;
  this.a = D("mr.InternalMessageHandler");
};
$n.prototype.onMessage = function(a, b, c) {
  var e = this;
  if ("retrieve_log_data" != a.type) {
    c(new Nf(chrome.runtime.id, "error", Error("Unhandled message type")));
  } else {
    var f = {logs:Zn.W().getLogs(), device:hk.W().gZ()};
    b = [];
    var g = Sf(f.device.ip).then(function(a) {
      a && (f.device.version = a);
    });
    b.push(g);
    var k = this.Mc.bp;
    k && (a = this.a2(k, a.source).then(function(a) {
      a && (f.castStreamingLogs = a);
    }, function() {
      e.a.error("Log upload failed for service: " + k);
    }), b.push(a));
    b.push(this.pD(f, "mr.cast.SinkDiscoveryService", "castDeviceCounts"));
    b.push(this.pD(f, "mr.dial.SinkDiscoveryService", "dialDeviceCounts"));
    xi(b).then(function() {
      c(f);
    });
  }
};
$n.prototype.pD = function(a, b, c) {
  var e = this;
  return uh(b).then(function(b) {
    b = b.kf;
    a[c] = b.Sl + "." + b.Mk;
  }, function() {
    e.a.error("Failed to get device counts for " + c + ".");
  });
};
$n.prototype.a2 = function(a, b) {
  return this.Mc.vo(a).then(function(a) {
    return a.Mf(b);
  });
};
var ao = function() {
  this.wc = null;
  this.a = D("mr.IssueSenderImpl");
};
ao.prototype.init = function(a) {
  this.wc = a;
};
ao.prototype.send = function(a) {
  if (this.wc) {
    if (this.wc.onIssue) {
      this.wc.onIssue(a);
    } else {
      this.a.error("MediaRouterService.onIssue not defined.");
    }
  } else {
    this.a.error("MediaRouterService is not set.");
  }
};
var bo = function(a, b) {
  F.call(this, "internal_message");
  this.routeId = a;
  this.message = b;
};
la(bo, F);
var co = function(a, b, c) {
  this.$L = a;
  this.Nf = b;
  this.C2 = c;
  this.onMessage = function() {
  };
  c.listen("internal_message", this.Gt, !1, this);
};
co.prototype.sendMessage = function(a, b) {
  return this.Nf(this.$L, a, b);
};
co.prototype.Gt = function(a) {
  if (a.routeId == this.$L) {
    this.onMessage(a.message);
  }
};
co.prototype.Qa = function() {
  this.onMessage = function() {
  };
  this.C2.Fc("internal_message", this.Gt, !1, this);
};
var eo = new co("", function() {
  return Promise.resolve();
}, new G), fo = function(a) {
  this.o = a;
};
fo.prototype.qs = function(a) {
  var b = this.o.cy(a);
  return b ? new co(a, b.sendRouteMessage.bind(b), this.o.hy()) : eo;
};
var go = function() {
  this.a = D("mr.ProviderManager");
  this.ge = [];
  this.ke = new Map;
  this.sm = new Map;
  this.Wg = new Set;
  this.ek = new Set;
  this.yt = new Map;
  this.wc = this.bp = null;
  this.Jm = !1;
  this.aM = new G;
  this.bM = new Wn(this.v8, 500, this);
  this.mba = new Wn(this.aV, 500, this);
  this.Fj = new Un(this, 524288);
  this.lA = 0;
  this.gJ = new ao;
  this.Km = new Map;
  this.rt = -1 == window.navigator.userAgent.indexOf("Windows");
  this.qt = [];
  this.Xs = [];
  this.OI = new $n(this);
  this.FF = new Xn(this);
  this.onBeforeInvokeHandler = this.g3;
  this.createRoute = this.createRoute;
  this.joinRoute = this.joinRoute;
  this.connectRouteByRouteId = this.connectRouteByRouteId;
  this.terminateRoute = this.terminateRoute;
  this.startObservingMediaSinks = this.startObservingMediaSinks;
  this.stopObservingMediaSinks = this.stopObservingMediaSinks;
  this.sendRouteMessage = this.sendRouteMessage;
  this.sendRouteBinaryMessage = this.sendRouteBinaryMessage;
  this.startListeningForRouteMessages = this.startListeningForRouteMessages;
  this.stopListeningForRouteMessages = this.stopListeningForRouteMessages;
  this.startObservingMediaRoutes = this.startObservingMediaRoutes;
  this.stopObservingMediaRoutes = this.stopObservingMediaRoutes;
  this.onPresentationSessionDetached = this.detachRoute = this.detachRoute;
  this.enableMdnsDiscovery = this.enableMdnsDiscovery;
  this.searchSinksAndCreateRoute = this.searchSinksAndCreateRoute;
  this.searchSinks = this.searchSinks;
  this.updateMediaSinks = this.updateMediaSinks;
};
la(go, ph);
d = go.prototype;
d.handleEvent = function(a, b) {
  for (var c = [], e = 1;e < arguments.length;++e) {
    c[e - 1] = arguments[e];
  }
  if (a == chrome.runtime.onMessage) {
    this.OI.onMessage.apply(this.OI, [].concat(ma(c)));
  } else {
    if (a == chrome.runtime.onMessageExternal) {
      this.FF.onMessage.apply(this.FF, [].concat(ma(c)));
    } else {
      throw Error("Unhandled event");
    }
  }
};
d.vo = function(a) {
  var b = this;
  a = this.yt.get(a);
  return uh(a).then(function(a) {
    a.mc(b);
    return a;
  });
};
d.Q6 = function(a) {
  a.forEach(this.V6, this);
};
d.mc = function(a, b) {
  this.yt.set("webrtc", "mr.mirror.webrtc.WebRtcService");
  this.yt.set("cast_streaming", "mr.mirror.cast.Service");
  this.yt.set("hangouts", "mr.mirror.hangouts.HangoutsService");
  var c = new fo(this);
  Fg || (Fg = c);
  this.wc = a;
  this.gJ.init(a);
  this.Fj.init(this.wc.onRouteMessagesReceived.bind(this.wc));
  this.Q6(b);
  Rh(this);
  zh("mr.ProviderManager", this);
};
d.V6 = function(a) {
  if (this.Hh(a.getName())) {
    this.a.l("Provider " + a.getName() + " already registered.");
  } else {
    try {
      a.mc(), this.ge.push(a), this.Km.set(a.getName(), 0);
    } catch (b) {
      this.a.l("Provider " + a.getName() + " failed to initialize.", b);
    }
  }
};
d.Oq = function(a, b) {
  var c = this;
  return new Promise(function(e, f) {
    var g = null;
    c.b6();
    var g = window.setTimeout(function() {
      g = null;
      a.cancel(new sm(2, "timeout after " + b + " ms."));
    }, b), k = function() {
      c.HR();
      null != g && window.clearTimeout(g);
    };
    a.promise.then(function(a) {
      k();
      e(a);
    }, function(a) {
      k();
      f(a instanceof sm ? a : a instanceof Error ? new sm(0, a.message, a.stack) : new sm(0));
    });
  });
};
d.tR = function(a, b) {
  return this.Oq(Kg(a), b);
};
d.b6 = function() {
  this.lA++;
  this.rz();
};
d.HR = function() {
  this.lA--;
  this.rz();
};
d.g3 = function() {
  hh(0);
};
d.createRoute = function(a, b, c, e, f, g, k) {
  var q = this, r = this.dZ(a, b);
  if (!r) {
    return Promise.reject(new sm(7, "No provider supports createRoute with source: " + a + " and sink: " + b));
  }
  g = g && 0 < g ? g : 6E4;
  a = r.createRoute(a, b, c, k || !1, g, e, f);
  return this.Oq(a, g).then(function(a) {
    return a;
  }, function(a) {
    q.a.error("Error creating route.", a);
    throw a;
  });
};
d.connectRouteByRouteId = function(a, b, c, e, f, g) {
  var k = this.ke.get(b);
  if (!k) {
    return Promise.reject(new sm(7, "No provider supports join " + b));
  }
  a = k.connectRouteByRouteId(a, b, c, e, f);
  return this.Oq(a, g && 0 < g ? g : 3E4);
};
d.joinRoute = function(a, b, c, e, f, g) {
  var k = this.cZ(a);
  if (!k) {
    return Promise.reject(new sm(7, "No provider supports join " + b));
  }
  f = f && 0 < f ? f : 3E4;
  a = k.joinRoute(a, b, g || !1, f, c, e);
  return this.Oq(a, f);
};
d.terminateRoute = function(a) {
  var b = this.ke.get(a);
  return b ? this.RJ(a).then(function() {
    return b.terminateRoute(a);
  }) : Promise.reject(new sm(3, "Route not found for routeId " + a));
};
d.startObservingMediaSinks = function(a) {
  this.Wg.has(a) || (this.Wg.add(a), this.ge.forEach(function(b) {
    b.startObservingMediaSinks(a);
  }));
  this.wA(a);
};
d.stopObservingMediaSinks = function(a) {
  this.Wg.delete(a) ? this.uF(a) : this.a.info("No existing query " + a);
};
d.uF = function(a) {
  this.ge.forEach(function(b) {
    b.stopObservingMediaSinks(a);
  });
};
d.wA = function(a) {
  var b = this;
  if ("urn:x-org.chromium.media:source:tab:-1" == a) {
    this.a.l("No sinks for sourceUrn: " + a);
  } else {
    var c = new Map, e = [];
    this.ge.forEach(function(f) {
      var g = f.zh(a);
      0 < g.sinks.length && (e = g.origins);
      g.sinks.forEach(function(a) {
        c.has(a.id) ? b.a.l("Detected duplicate sink " + a.id + " from provider: " + f.getName()) : c.set(a.id, a);
      });
    });
    this.w8(a, Array.from(c.values()), e || []);
  }
};
d.w8 = function(a, b, c) {
  this.a.info("Sending " + b.length + " sinks to MR for " + a);
  this.wc.onSinksReceived(a, b, c);
};
d.sendRouteMessage = function(a, b, c) {
  var e = this.ke.get(a);
  return e ? this.tR(e.sendRouteMessage(a, b, c), 3E4) : Promise.reject(Error("Invalid route ID " + a));
};
d.sendRouteBinaryMessage = function(a) {
  return Promise.reject(Error("Route " + a + " does not support sending binary data"));
};
d.startListeningForRouteMessages = function(a) {
  this.Fj.R1(a);
};
d.stopListeningForRouteMessages = function(a) {
  this.Fj.stopListeningForRouteMessages(a);
};
d.detachRoute = function(a) {
  var b = this.ke.get(a);
  b ? b.detachRoute(a) : this.a.info("Route " + a + " does not exist.");
};
d.enableMdnsDiscovery = function() {
  this.rt = !0;
  this.qt.forEach(function(a) {
    a();
  });
  this.qt.length = 0;
};
d.dZ = function(a, b) {
  return this.ge.find(function(c) {
    return c.Ok(a, b);
  }) || null;
};
d.cZ = function(a) {
  return this.ge.find(function(b) {
    return b.Ii(a);
  }) || null;
};
d.aV = function() {
  var a = this;
  this.Wg.forEach(function(b) {
    a.wA(b);
  });
};
d.rz = function() {
  this.wc.setKeepAlive(0 < this.lA || 0 < this.Xs.length);
};
d.startObservingMediaRoutes = function(a) {
  this.ek.has(a) || (this.Jm = !0, this.ek.add(a), this.ge.forEach(function(b) {
    b.startObservingMediaRoutes(a);
  }));
  this.bM.bo();
};
d.stopObservingMediaRoutes = function(a) {
  this.ek.delete(a) ? (0 == this.ek.size && (this.Jm = !1), this.ge.forEach(function(b) {
    b.stopObservingMediaRoutes(a);
  })) : this.a.info("No existing route query " + a);
};
d.v8 = function() {
  var a = this;
  if (this.Jm) {
    var b = [];
    this.ge.forEach(function(a) {
      b = b.concat(a.vf());
    });
    this.ek.forEach(function(c) {
      var e = [];
      a.ge.forEach(function(a) {
        a.vf().forEach(function(b) {
          !b.cl && a.Ii(c, b) && e.push(b.id);
        });
      });
      a.wc.onRoutesUpdated(b, c, e);
    });
  }
};
d.oa = function() {
  return "ProviderManager";
};
d.getData = function() {
  return [new ho(this.ge.map(function(a) {
    return a.getName();
  }), Array.from(this.Wg), Array.from(this.ek), this.Jm, Array.from(this.ke, function(a) {
    var b = ka(a);
    a = b.next().value;
    b = b.next().value;
    return [a, b.getName()];
  }), Array.from(this.Km), this.rt, this.bp)];
};
d.Xa = function() {
  var a = Oh(this);
  if (a) {
    this.Wg = new Set(a.lba);
    this.ek = new Set(a.W7);
    this.Jm = a.iba;
    for (var b = ka(a.U7), c = b.next();!c.done;c = b.next()) {
      var e = ka(c.value), c = e.next().value, e = e.next().value, f = this.Hh(e);
      x(f, "Provider not found: " + e);
      this.ke.set(c, f);
    }
    this.Km = new Map(a.kba);
    this.bp = a.N1 || null;
    a.t2 && this.enableMdnsDiscovery();
  }
};
d.cy = function(a) {
  return this.ke.get(a);
};
d.Jj = function(a, b) {
  this.ke.set(b.id, a);
  this.Yh(a, b);
};
d.Ig = function(a, b) {
  this.RJ(b.id);
  this.ke.delete(b.id);
  this.Fj.Ig(b.id);
  this.Yh(a, b);
};
d.Yh = function() {
  this.Jm && this.bM.bo();
};
d.CK = function(a) {
  var b = this.ke.get(a.id);
  b && this.Yh(b, a);
};
d.Ke = function(a, b, c) {
  this.ke.has(b) ? ("string" != typeof c && (c = JSON.stringify(c)), this.Fj.send(b, c)) : this.a.l("Got route message for closed route " + b);
};
d.onPresentationConnectionStateChanged = function(a, b) {
  "terminated" == b && this.Fj.nM();
  this.wc.onPresentationConnectionStateChanged(a, b);
};
d.onPresentationConnectionClosed = function(a, b, c) {
  this.Fj.nM();
  this.wc.onPresentationConnectionClosed(a, b, c);
};
d.Nz = function(a) {
  this.sm.delete(a);
  var b = this.ke.get(a);
  b && b.terminateRoute(a);
};
d.Et = function(a, b, c) {
  this.aM.dispatchEvent(new bo(b, c));
};
d.ee = function() {
  this.mba.bo();
};
d.onSinkAvailabilityUpdated = function(a, b) {
  var c = this, e = this.Km.get(a.getName());
  x(void 0 !== e, "oldValue != undefined");
  e != b && (e = this.KE(), this.Km.set(a.getName(), b), a = this.KE(), e != a && (this.wc.onSinkAvailabilityUpdated(a), 0 == a && (this.Wg.forEach(function(a) {
    c.uF(a);
  }), this.Wg.clear())));
};
d.KE = function() {
  return Array.from(this.Km.values()).reduce(function(a, b) {
    return Math.max(a, b);
  }, 0);
};
d.hy = function() {
  return this.aM;
};
d.ug = function() {
  return this.gJ;
};
d.RJ = function(a) {
  var b = this;
  return this.sm.has(a) ? this.vo(this.sm.get(a)).then(function(c) {
    b.sm.delete(a);
    return c.nO();
  }) : Promise.resolve(!1);
};
d.mq = function(a, b, c, e) {
  var f = this, g = Za(a.bj(b.sinkId));
  this.a.info("Starting mirroring using service: " + g);
  this.sm.set(b.id, g);
  return Lg(this.vo(g), function(k) {
    f.bp = g;
    return k.mq(b, Za(b.mediaSource), x(a.cj(b.sinkId)), c, e).catch(function(a) {
      if (a instanceof dh && 3 == a.reason) {
        throw new sm(8);
      }
      throw a;
    });
  });
};
d.cv = function(a, b, c, e, f, g) {
  var k = this, q = this.sm.get(b.id);
  return q ? Lg(this.vo(q), function(r) {
    k.bp = q;
    return r.cv(b, c, x(a.cj(b.sinkId)), e, f, g);
  }) : Jg(Error("Route " + b.id + " is not mirroring"));
};
d.CA = function(a) {
  this.rt ? a() : -1 == this.qt.indexOf(a) && this.qt.push(a);
};
d.My = function() {
  return this.rt;
};
d.Lf = function(a, b) {
  var c = this.Xs.indexOf(a), e = 0 <= c;
  b && !e ? this.Xs.push(a) : !b && e && this.Xs.splice(c, 1);
  this.rz();
};
d.Hh = function(a) {
  return this.ge.find(function(b) {
    return b.getName() == a;
  }) || null;
};
d.wH = function(a) {
  return a.startsWith("pseudo:") ? a.substring(7) : null;
};
d.searchSinksAndCreateRoute = function(a, b, c, e, f, g, k, q) {
  var r = this.wH(a), r = r ? this.Hh(r) : null, A = null;
  r && (A = r.searchSinks(b, c));
  if (A) {
    return this.wc.onSearchSinkIdReceived(a, A.id), this.createRoute(b, A.id, e, f, g, k, q);
  }
  this.wc.onSearchSinkIdReceived(a, "");
  return Promise.reject(new sm(0, "No sink found for search input: " + c.input + " and source: " + b));
};
d.searchSinks = function(a, b, c) {
  a = (a = this.wH(a)) ? this.Hh(a) : null;
  var e = null;
  a && (e = a.searchSinks(b, c));
  return e ? e.id : "";
};
d.updateMediaSinks = function(a) {
  this.Wg.has(a) || this.wA(a);
};
var ho = function(a, b, c, e, f, g, k, q) {
  this.lba = b;
  this.W7 = c;
  this.iba = e;
  this.U7 = f;
  this.kba = g;
  this.t2 = k;
  this.N1 = q;
};
var io = function(a, b) {
  this.$a = a;
  this.oba = b;
  this.Kg = new Jc;
  this.I = this.Kg.promise;
  this.Lc = Fg.qs(a.id);
  this.wa = new Jc;
  this.fd = !1;
  this.cq();
  this.MB();
  this.Fb(new Gh("GET_TURN_CREDENTIALS"));
};
d = io.prototype;
d.start = function() {
  var a = this;
  return this.I.then(function(b) {
    if (b.Ss()) {
      return Promise.reject(Error("Presentation already started"));
    }
    b.start();
    return a.wa.promise;
  });
};
d.stop = function() {
  var a = this;
  this.fd = !1;
  return this.I.then(function(b) {
    b.stop();
    a.I = Promise.reject(Error("Peer connection has already been stopped"));
  });
};
d.cq = function() {
  var a = this;
  this.Lc.onMessage = function(b) {
    if (b.type) {
      switch(b.type) {
        case "TURN_CREDENTIALS":
          a.Kg.resolve(new Kh(a.$a.id, b.data.credentials));
          break;
        case "ANSWER":
          a.I.then(function(a) {
            a.setRemoteDescription(b.data);
          });
          break;
        case "STOP":
          a.wa.reject("Stop signal received");
          a.stop();
          break;
        default:
          throw Error("Unknown message type: " + b.type);
      }
    } else {
      a.I.then(function(a) {
        a.n8({type:"PRESENTATION_CONNECTION_MESSAGE", data:b});
      });
    }
  };
};
d.MB = function() {
  var a = this;
  this.I.then(function(b) {
    b.uN(function(b) {
      a.Fb(new Gh("OFFER", new Ih(b, null, null, a.oba)));
    });
    b.tN(function(b) {
      b = Hh(b);
      "STOP" == b.type && a.stop();
      a.Fb(b);
    });
    b.sN(function() {
      a.fd = !0;
      a.Fb(new Gh("SESSION_START_SUCCESS"));
      a.wa.resolve(a);
    });
    b.qN(function() {
      a.Fb(new Gh("SESSION_END"));
    });
    b.rN(function(b) {
      a.fd || a.wa.reject(b);
      a.Fb(new Gh("SESSION_FAILURE"));
    });
  });
};
d.Fb = function(a) {
  this.Lc.sendMessage(a, jo);
};
var jo = {channelType:"cloud"};
var ko = function(a) {
  this.o = a;
  this.xa = new Map;
  this.hu = new Map;
  this.gq = [];
  this.Qe = this.$l = this.xd = this.sg = this.Hl = null;
  this.gm = this.Mi = this.nh = !1;
  this.hq = new Map;
  this.Wm = new Map;
  Rh(this);
};
d = ko.prototype;
d.getName = function() {
  return "cloud";
};
d.mc = function() {
  var a = this;
  this.a.info("Initializing Cloud MRP");
  var b = Dk.W(), c = b.zW(this);
  this.gq.push(c);
  this.Hl = b.FX(this);
  this.gq.push(this.Hl);
  this.sg = b.PG();
  this.xd = b.po();
  this.$l = b.wY(this);
  this.Qe = b.LZ();
  this.Qe.wW().then(function(b) {
    a.nh = b;
    a.a.info("Cloud enabled setting: " + a.nh);
  });
  this.Qe.yW().then(function(b) {
    a.Mi = b;
    a.a.info("Cloud on setting: " + a.Mi);
  });
  this.Qe.B$(function(b) {
    a.nh = b;
    a.a.info("Cloud enabled setting: " + a.nh);
    a.nh && a.KI();
  });
  this.Qe.LY().then(function(b) {
    a.gm = b;
    a.a.info("Privacy notified setting: " + a.gm);
  });
};
d.vf = function() {
  return Array.from(this.xa.values());
};
d.zh = function(a) {
  if (!this.Iy(a)) {
    return um;
  }
  this.a.w("GetAvailableSinks for " + a);
  var b = [];
  if (this.Mi || this.gba()) {
    b = this.KI();
  }
  this.Wm.clear();
  for (var c = {}, e = ka(this.hq.values()), f = e.next();!f.done;c = {tm:c.tm, $r:c.$r}, f = e.next()) {
    c.tm = f.value, c.$r = !1, b.forEach(function(a) {
      return function(b) {
        b.bb.id == a.tm.bb.id && (a.$r = !0, b.bb.friendlyName = a.tm.bb.friendlyName);
      };
    }(c)), c.$r || this.Wm.set(c.tm.bb.id, c.tm);
  }
  b = b.concat.apply(b, [].concat(ma(this.Wm.values())));
  this.a.w(function() {
    return "Available sinks are..." + JSON.stringify(b);
  });
  c = b.map(function(a) {
    return a.bb;
  });
  this.Hl && (c = c.concat(lo));
  return new tm(c, nh(a));
};
d.KI = function() {
  var a = [];
  this.a.info("Checking cloud discovery services");
  hk.W().Zs = v();
  this.gq.forEach(function(b) {
    b = b.Xd();
    a = a.concat(b);
  });
  return a;
};
d.startObservingMediaSinks = function() {
};
d.stopObservingMediaSinks = function() {
};
d.startObservingMediaRoutes = function() {
};
d.stopObservingMediaRoutes = function() {
};
d.Y = function(a) {
  return (a = this.ko(a)) ? a.bb : null;
};
d.createRoute = function(a, b, c, e, f, g, k) {
  var q = this;
  this.a.info("createRoute called");
  this.a.w("urn: " + a + " sinkId:" + b);
  if (f = this.hu.get(b)) {
    return this.o.cv(this, f, a, c, k, function(b) {
      b.mediaSource = a;
      b.Je.tabId = k;
      return Ig(b);
    }).yw(function(a) {
      q.o.Yh(q, a);
      return a;
    });
  }
  f = this.ko(b);
  return this.Ti(a, f, b, c, e, g, k);
};
d.aF = function(a, b, c, e) {
  a instanceof sm && 2 == a.errorCode ? this.wk(b, 6, null) : (this.a.error("Error on start session", a instanceof Error ? a : Error("Expected an Error value, got " + a)), this.wk(b, e, new Gg(rj, "warning", "dismiss")));
  this.Hl && this.Hl.IL(c) && this.Le([c.bb]);
};
d.Ti = function(a, b, c, e, f, g, k) {
  var q = this;
  if (f) {
    return Jg(Error("not supported"));
  }
  f = !1;
  switch(this.by(b)) {
    case "cloud":
      Ti(1);
      break;
    case "mesi":
      f = !0, this.gm || (this.gm = !0, this.Qe.A$(), g = new Gg(uj, "notification", "learn_more"), g.naa(["dismiss"]), g.N9(6320939), this.o.ug().send(g)), Ti(0);
  }
  hk.W().Wj = new gk(b.model, null);
  var r = ym(e, this.getName(), c, a, !0, "", null);
  f && (r.customControllerPath = "cloud_route_details/view.html?routeId=" + r.id);
  this.xa.set(r.id, r);
  this.hu.set(c, r);
  this.hq.set(r.id, b);
  this.o.Jj(this, r);
  this.o.Lf(this.oa(), !0);
  if (lh(a) && !f) {
    return this.a.info("starting presentation on route: " + r.id), this.wba(r, a).catch(function(a) {
      q.aF(a, x(r), b, 7);
      throw a;
    });
  }
  this.a.info("starting mirroring on route: " + r.id);
  r.Je = {tabId:k, sessionId:"", eO:"", fO:b.model};
  lh(a) && (r.isOffscreenPresentation = !0);
  return this.o.mq(this, r, e).catch(function(a) {
    q.aF(a, x(r), b, 5);
    throw a;
  });
};
d.terminateRoute = function(a) {
  var b = this.xa.get(a);
  return b ? this.wk(b, 0, null) : Promise.reject(new sm(3, "Route in cloud provider not found for routeId " + a));
};
d.wk = function(a, b, c) {
  this.a.info("terminating route: " + a.id);
  var e = this.xa.delete(a.id);
  x(e);
  e = this.hu.delete(a.sinkId);
  x(e);
  e = this.hq.get(a.id);
  x(e);
  this.hq.delete(a.id);
  c && this.ug().send(c);
  ah("MediaRouter.Cloud.Session.End", b, Oi);
  switch(b) {
    case 1:
      break;
    default:
      this.pT(e);
  }
  this.o.Ig(this, a);
  0 == this.xa.size && this.o.Lf(this.oa(), !1);
  this.o.onPresentationConnectionStateChanged(a.id, "terminated");
  this.Wm.has(a.sinkId) && (b = this.Wm.get(a.sinkId), this.Le([b.bb]), this.Wm.delete(a.sinkId));
  return Promise.resolve();
};
d.sendRouteMessage = function(a, b, c) {
  if (c && c.channelType) {
    c = c.channelType;
    var e = (a = this.xa.get(a) || void 0) ? x(this.ko(a.sinkId)) : void 0;
    return this.$l.f6(c, b, a, e);
  }
  return p(b) ? (this.Dd(b, a), Promise.resolve()) : Promise.reject(Error("Channel type missing"));
};
d.cj = function(a) {
  var b = new Fh;
  "hangouts" != this.bj(a) && (b.senderSideLetterboxing = !0);
  b.HJ();
  this.a.info("Settings for " + a + ": " + b.Wu());
  return b.shouldCaptureAudio || b.shouldCaptureVideo ? b : null;
};
d.bj = function(a) {
  var b = null;
  a = this.ko(a);
  switch(this.by(a)) {
    case "cloud":
      b = "webrtc";
      break;
    case "mesi":
      b = "hangouts";
  }
  return b;
};
d.Ok = function(a, b) {
  this.a.w("Checking canRoute: " + a + " for sinkId: " + b);
  return this.Iy(a) && !!this.Y(b);
};
d.Ii = function(a) {
  return "chrome://media-router/cloudmrp-mirroring" == a;
};
d.joinRoute = function(a, b) {
  return (a = this.xa.get(b)) ? Ig(a) : Jg(Error("not supported"));
};
d.connectRouteByRouteId = function() {
  return Jg(Error("not supported"));
};
d.detachRoute = function() {
};
d.Sz = function(a) {
  this.a.info(a.length + " sinks added");
  0 < a.length && !this.Mi && (this.Qe.ica(), this.Mi = !0);
  a = this.ko(a[0].id);
  hk.W().Vj = new gk(a.model, null);
  this.o.ee();
  this.o.onSinkAvailabilityUpdated(this, 2);
  this.a.info("sinkAvailability changed to AVAILABLE");
};
d.Le = function(a) {
  this.a.info(a.length + " sinks removed");
  this.gq.some(function(a) {
    return 0 < a.Xd().length;
  }) || (this.o.onSinkAvailabilityUpdated(this, 0), this.a.info("sinkAvailability changed to UNAVAILABLE"));
  this.o.ee();
};
d.ee = function(a) {
  this.a.info(a.length + " sinks updated");
  this.o.ee();
};
d.ug = function() {
  return this.o.ug();
};
d.Dd = function(a, b, c) {
  c ? this.o.Ke(this, b, a) : this.o.Et(this, b, a);
};
d.ko = function(a) {
  var b = this.WW(a);
  b || (b = this.EZ(a));
  return b;
};
d.WW = function(a) {
  var b = null;
  this.gq.some(function(c) {
    b = c.Y(a);
    return !!b;
  });
  return b;
};
d.EZ = function(a) {
  var b = null;
  (a = this.hu.get(a)) && (b = this.hq.get(a.id));
  return b;
};
d.pT = function(a) {
  switch(this.by(a)) {
    case "cloud":
      this.sg.x8(a.deviceId);
  }
};
d.by = function(a) {
  return a.tO("cloud") ? "cloud" : a.tO("mesi") ? "mesi" : null;
};
d.gba = function() {
  var a = hk.W().Zs;
  return 3E5 <= Date.now() - a;
};
d.Iy = function(a) {
  var b = kh(a);
  a = lh(a);
  if (this.xd.Wo && !this.xd.Vg && b) {
    return this.o.onSinkAvailabilityUpdated(this, 2), !0;
  }
  var c = !1;
  this.nh && this.xd.Vg && (c = !0);
  return c && (b || a);
};
d.searchSinks = function(a, b) {
  if (!this.Iy(a)) {
    return null;
  }
  (a = this.Hl.vR(b)) && this.Sz([a]);
  return a;
};
d.oa = function() {
  return "CloudProvider";
};
d.getData = function() {
  return [void 0, {cloudEnabled:this.nh, cloudOn:this.Mi, notifiedHangoutsPrivacy:this.gm}];
};
d.Xa = function() {
  var a = Ph(this);
  a && (a.cloudEnabled && (this.nh = a.cloudEnabled), a.cloudOn && (this.Mi = a.cloudOn), a.notifiedHangoutsPrivacy && (this.gm = a.notifiedHangoutsPrivacy));
};
d.wba = function(a, b) {
  a = new io(a, b);
  return Kg(a.start());
};
d.a = D("mr.CloudProvider");
var lo = new hi("pseudo:cloud", "", "hangout", "Add a hangout", "default");
var mo = function(a) {
  this.o = a;
  this.Pc = [new hi("id1", "test-sink-1"), new hi("id2", "test-sink-2")];
  this.xa = new Map;
  this.Bp = new Map;
};
d = mo.prototype;
d.getName = function() {
  return "test";
};
d.mc = function() {
  setTimeout(u(this.c2, this));
};
d.c2 = function() {
  var a = this, b = this.Ai("initialSinks");
  b && (this.Pc = [], b.forEach(function(b) {
    a.Pc.push(new hi(b.id, b.friendlyName));
  }));
  this.o.onSinkAvailabilityUpdated(this, 0 == this.Pc.length ? 0 : 1);
};
d.vf = function() {
  return Array.from(this.xa.values());
};
d.zh = function(a) {
  var b = this.Ai("getAvailableSinks");
  if (!b) {
    return this.Vo(a) ? new tm(this.Pc) : um;
  }
  a = b[a];
  if (!a) {
    return um;
  }
  var c = [];
  a.forEach(function(a) {
    c.push(new hi(a.id, a.friendlyName));
  });
  return new tm(c);
};
d.startObservingMediaSinks = function() {
};
d.stopObservingMediaSinks = function() {
};
d.startObservingMediaRoutes = function() {
};
d.stopObservingMediaRoutes = function() {
};
d.Y = function(a) {
  return this.Pc.find(function(b) {
    return b.id == a;
  }) || null;
};
d.createRoute = function(a, b, c, e, f, g, k) {
  var q = this;
  if (f = this.Av("createRoute")) {
    return Kg(f);
  }
  var r = this.Ai("createRoute");
  return r && "delayMillis" in r ? new Hg(function(f) {
    setTimeout(function() {
      f(q.Ti(a, b, c, e, g, k));
    }, r.delayMillis);
  }) : Ig(this.Ti(a, b, c, e, g, k));
};
d.Ti = function(a, b, c, e) {
  a = ym(c, this.getName(), b, a, !0, "Test Route", null);
  a.offTheRecord = e;
  this.xa.set(a.id, a);
  this.Bp.set(c, a);
  this.o.Jj(this, a);
  this.o.Lf("mr.TestProvider", !0);
  return a;
};
d.terminateRoute = function(a) {
  var b = this.xa.get(a);
  if (!b) {
    return Promise.reject(new sm(3, "Route in test provider not found for routeId " + a));
  }
  this.xa.delete(a);
  var c = new Map;
  this.Bp.forEach(function(b, f) {
    b.id != a && c.set(f, b);
  });
  this.Bp.clear();
  this.Bp = c;
  this.o.onPresentationConnectionStateChanged(b.id, "terminated");
  this.o.Ig(this, b);
  0 == this.xa.size && this.o.Lf("mr.TestProvider", !1);
  return Promise.resolve();
};
d.sendRouteMessage = function(a, b) {
  if ("true" == this.Ai("closeRouteWithErrorOnSend")) {
    return this.o.onPresentationConnectionClosed(a, "error", "Foo"), (a = this.xa.get(a)) && this.o.Ig(this, a), Promise.reject(Error("Send error. Closing connection."));
  }
  this.o.Ke(this, a, "Pong: " + b);
  return Promise.resolve();
};
d.cj = function() {
  return null;
};
d.bj = function() {
  return null;
};
d.Ok = function(a, b) {
  return this.Vo(a) ? (a = this.Ai("canRoute")) ? "true" == a : !!this.Y(b) : !1;
};
d.Ii = function(a, b) {
  return this.Vo(a) ? (a = this.Ai("canJoin")) ? "true" == a : null != b ? this.xa.has(b.id) : !0 : !1;
};
d.connectRouteByRouteId = function(a, b) {
  return this.Vo(a) ? (a = this.Av("connectRouteByRouteId")) ? Kg(a) : (b = this.xa.get(b)) ? Ig(b) : Jg(Error("Presentation does not exist")) : Jg(Error("Invalid source"));
};
d.joinRoute = function(a, b, c) {
  return this.Vo(a) ? (a = this.Av("joinRoute")) ? Kg(a) : (b = this.Bp.get(b)) ? b.offTheRecord != c ? Jg(Error("Off-the-record mismatch")) : Ig(b) : Jg(Error("Presentation does not exist")) : Jg(Error("Invalid source"));
};
d.detachRoute = function() {
};
d.Vo = function(a) {
  return 0 <= a.indexOf("__testprovider__=true");
};
d.Ai = function(a) {
  if ("testdata" in window.localStorage) {
    var b = JSON.parse(window.localStorage.testdata);
    if (a in b) {
      return this.a.info(a + " : " + JSON.stringify(b[a])), b[a];
    }
  }
  return null;
};
d.Av = function(a) {
  return (a = this.Ai(a)) && "passed" in a && "false" == a.passed && "errorMessage" in a ? Promise.reject(Error(a.errorMessage)) : null;
};
d.searchSinks = function() {
  return null;
};
d.a = D("mr.TestProvider");
var no = function() {
  Zi.call(this, 12, "ExternalMessageListener", "mr.ProviderManager", chrome.runtime.onMessageExternal);
};
la(no, Zi);
no.prototype.jv = function(a, b) {
  return b.id && -1 != oo.indexOf(b.id) ? "start" == a.type || "stop" == a.type : !1;
};
no.prototype.Xw = function() {
  return !0;
};
var qo = function() {
  po || (po = new no);
  return po;
}, po = null, oo = ["idmofbkcelhplfjnmmdolenpigiiiecc", "ggedfkijiiammpnbdadhllnehapomdge", "njjegkblellcjnakomndbaloifhcoccg"];
var ro = function() {
  Zi.call(this, 11, "InternalMessageListener", "mr.ProviderManager", chrome.runtime.onMessage);
};
la(ro, Zi);
ro.prototype.jv = function(a, b) {
  return "retrieve_log_data" == a.type && b.id == chrome.runtime.id && b.url == "chrome-extension://" + b.id + "/feedback.html";
};
ro.prototype.Xw = function() {
  return !0;
};
var to = function() {
  so || (so = new ro);
  return so;
}, so = null;
var uo, vo, wo = D("mr.Init");
Zn.W().init();
uo = new Vg("MediaRouter.Provider.WakeDuration");
vo = new go;
var xo = (new Promise(function(a, b) {
  switch(window.location.host) {
    case "enhhojjnijigcajfphajepfemndkmdlo":
      a();
      break;
    case "pkedcjkdefgpdelpbcmbmeomcjbeemfm":
      chrome.management.get("enhhojjnijigcajfphajepfemndkmdlo", function(c) {
        chrome.runtime.lastError || !c.enabled ? a() : b(Error("Dev extension is enabled"));
      });
      break;
    default:
      b(Error("Unknown extension id"));
  }
})).then(function() {
  return chrome.mojoPrivate && chrome.mojoPrivate.requireAsync ? new Promise(function(a) {
    chrome.mojoPrivate.requireAsync("media_router_bindings").then(function(b) {
      b.start().then(function(c) {
        a({mrService:b, mrInstanceId:c});
      });
    });
  }) : Promise.reject(Error("No mojo service loaded"));
}).then(function(a) {
  if (!a.mrService) {
    throw Error("Failed to get MR service");
  }
  var b = a.mrInstanceId;
  if (!b) {
    throw Error("Failed to get MR instance ID.");
  }
  wo.info("MR instance ID: " + b);
  a = a.mrService;
  if (!vo) {
    throw Error("providerManager not initialized.");
  }
  a.setHandlers(vo);
  Uh(b) && uo.Dm("MediaRouter.Provider.FirstWakeDuration");
  chrome.runtime.onSuspend.addListener(uo.end.bind(uo));
  for (var c = 0, e = ka(Object.keys(n.oO)), f = e.next();!f.done;f = e.next()) {
    var f = f.value, g = f.length + window.localStorage.getItem(f).length;
    f.startsWith("mr.") ? Mh += g : c += g;
  }
  Sh = b;
  (window.localStorage.getItem("version") && window.localStorage.getItem("version") !== chrome.runtime.getManifest().version || Uh(b)) && Yh();
  Th.info("initialize: " + Mh + " bytes used, " + c + " other bytes");
  chrome.runtime.onSuspend.addListener(Xh);
  Zn.W().R6();
  b = new Jm(vo);
  c = new Ln(vo, b);
  b = [b, c];
  b.push(new ko(vo));
  b.push(new mo(vo));
  window.e2eTestService = new Pn(vo);
  vo.mc(a, b);
}).then(void 0, function(a) {
  wo.l(a.message);
  throw a;
});
[].concat([qo(), to()], ma(Cn()), ma([dl(), fl()]), ma([gj()])).forEach(function(a) {
  return a.yR();
});
qo().addListener();
to().addListener();
xo.then(void 0, function() {
  return window.close();
});

