'use strict';var BF = {TAB:0, WC:1, oQ:2}, CF = function(a) {
  ah("MediaRouter.WebRtc.Start.Success", a, BF);
};
var DF = function(a, b) {
  Dh.call(this, b);
  this.Fa = a;
  this.Kg = new Jc;
  this.Lc = Fg.qs(b.id);
  this.wa = new Jc;
  this.fd = !1;
  this.Hd = null;
  this.Ly = !1;
  this.dd = this.Ef = null;
  this.cq();
  this.MB();
  this.Fb(new Gh("GET_TURN_CREDENTIALS"));
};
la(DF, Dh);
d = DF.prototype;
d.start = function(a) {
  var b = this;
  return this.Kg.promise.then(function(c) {
    if (c.Ss()) {
      return Promise.reject(new dh("Mirroring already started"));
    }
    if (b.Hd) {
      return Promise.reject(new dh("Session permanently stopped"));
    }
    b.Ef = new Sg("MediaRouter.WebRtc.Session.Launch");
    c.addStream(a);
    c.start();
    return b.wa.promise;
  });
};
d.stop = function() {
  var a = this;
  this.wa.reject(new dh("Session stop requested."));
  this.dd && (this.dd.end(), this.dd = null);
  if (this.Hd) {
    return this.Hd;
  }
  this.Ly = this.fd = !1;
  this.Ef = null;
  return this.Hd = this.Kg.promise.then(function(a) {
    a.stop();
  }).then(function() {
    return a.Lc.Qa();
  }).catch(function(b) {
    a.Lc.Qa();
    throw b;
  });
};
d.cq = function() {
  var a = this;
  this.Lc.onMessage = function(b) {
    if (!b.type) {
      throw Error("Message has no type.");
    }
    switch(b.type) {
      case "TURN_CREDENTIALS":
        a.Kg.resolve(new Kh(a.$a.id, b.data.credentials));
        break;
      case "ANSWER":
        a.Kg.promise.then(function(a) {
          a.setRemoteDescription(b.data);
        });
        break;
      case "KNOCK_ANSWER":
        a.Ly = !0;
        a.Kg.promise.then(function(a) {
          a.setRemoteDescription(b.data);
        });
        break;
      case "STOP":
        a.wa.reject(new dh("Stop signal received"));
        a.stop();
        break;
      default:
        throw new dh("Unknown message type: " + b.type);
    }
  };
};
d.MB = function() {
  var a = this;
  this.Kg.promise.then(function(b) {
    b.uN(function(b) {
      a.Fb(new Gh("OFFER", new Ih(b, a.Fa, Jh)));
    });
    b.tN(function(b) {
      a.Fb(Hh(b));
    });
    b.sN(function() {
      a.fd = !0;
      a.Fb(new Gh("SESSION_START_SUCCESS"));
      !a.Ly && a.Ef && a.Ef.end();
      a.Ef = null;
      a.dd = new Xg("MediaRouter.WebRtc.Session.Length");
      a.wa.resolve(a);
    });
    b.qN(function() {
      a.Fb(new Gh("SESSION_END"));
    });
    b.rN(function(b) {
      a.fd || a.wa.reject(b);
      a.Fb(new Gh("SESSION_FAILURE"));
    });
  });
};
d.Fb = function(a) {
  this.Lc.sendMessage(a, EF);
};
var EF = {channelType:"cloud"};
var FF = function() {
  Bh.call(this, "webrtc");
};
la(FF, Bh);
d = FF.prototype;
d.yr = function(a, b) {
  return new DF(a, b);
};
d.$t = function() {
  CF(0);
};
d.Wt = function() {
  CF(1);
};
d.zA = function() {
  CF(2);
};
d.Xt = function() {
  $g("MediaRouter.WebRtc.Session.End");
};
d.Yt = function(a) {
  ah("MediaRouter.WebRtc.Start.Failure", a, ch);
};
d.Zt = function() {
  $g("MediaRouter.WebRtc.Stream.End");
};
var GF = new FF;
zh("mr.mirror.webrtc.WebRtcService", GF);

