'use strict';var d, ca = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
  if (c.get || c.set) {
    throw new TypeError("ES3 does not support getters and setters.");
  }
  a != Array.prototype && a != Object.prototype && (a[b] = c.value);
}, da = "undefined" != typeof window && window === this ? this : "undefined" != typeof global && null != global ? global : this, ea = function() {
  ea = function() {
  };
  da.Symbol || (da.Symbol = fa);
}, ga = 0, fa = function(a) {
  return "jscomp_symbol_" + (a || "") + ga++;
}, ia = function() {
  ea();
  var a = da.Symbol.iterator;
  a || (a = da.Symbol.iterator = da.Symbol("iterator"));
  "function" != typeof Array.prototype[a] && ca(Array.prototype, a, {configurable:!0, writable:!0, value:function() {
    return ha(this);
  }});
  ia = function() {
  };
}, ha = function(a) {
  var b = 0;
  return ja(function() {
    return b < a.length ? {done:!1, value:a[b++]} : {done:!0};
  });
}, ja = function(a) {
  ia();
  a = {next:a};
  a[da.Symbol.iterator] = function() {
    return this;
  };
  return a;
}, ka = function(a) {
  ia();
  var b = a[Symbol.iterator];
  return b ? b.call(a) : ha(a);
}, la = function(a, b) {
  function c() {
  }
  c.prototype = b.prototype;
  a.prototype = new c;
  a.prototype.constructor = a;
  for (var e in b) {
    if (Object.defineProperties) {
      var f = Object.getOwnPropertyDescriptor(b, e);
      f && Object.defineProperty(a, e, f);
    } else {
      a[e] = b[e];
    }
  }
}, ma = function(a) {
  if (!(a instanceof Array)) {
    a = ka(a);
    for (var b, c = [];!(b = a.next()).done;) {
      c.push(b.value);
    }
    a = c;
  }
  return a;
}, na = na || {}, h = this, l = function(a) {
  return void 0 !== a;
}, m = function(a, b, c) {
  a = a.split(".");
  c = c || h;
  a[0] in c || !c.execScript || c.execScript("var " + a[0]);
  for (var e;a.length && (e = a.shift());) {
    !a.length && l(b) ? c[e] = b : c = c[e] ? c[e] : c[e] = {};
  }
}, oa = function(a, b) {
  a = a.split(".");
  b = b || h;
  for (var c;c = a.shift();) {
    if (null != b[c]) {
      b = b[c];
    } else {
      return null;
    }
  }
  return b;
}, n = function() {
}, pa = function(a) {
  a.Fy = void 0;
  a.W = function() {
    return a.Fy ? a.Fy : a.Fy = new a;
  };
}, qa = function(a) {
  var b = typeof a;
  if ("object" == b) {
    if (a) {
      if (a instanceof Array) {
        return "array";
      }
      if (a instanceof Object) {
        return b;
      }
      var c = Object.prototype.toString.call(a);
      if ("[object Window]" == c) {
        return "object";
      }
      if ("[object Array]" == c || "number" == typeof a.length && "undefined" != typeof a.splice && "undefined" != typeof a.propertyIsEnumerable && !a.propertyIsEnumerable("splice")) {
        return "array";
      }
      if ("[object Function]" == c || "undefined" != typeof a.call && "undefined" != typeof a.propertyIsEnumerable && !a.propertyIsEnumerable("call")) {
        return "function";
      }
    } else {
      return "null";
    }
  } else {
    if ("function" == b && "undefined" == typeof a.call) {
      return "object";
    }
  }
  return b;
}, ra = function(a) {
  return null === a;
}, sa = function(a) {
  return "array" == qa(a);
}, ta = function(a) {
  var b = qa(a);
  return "array" == b || "object" == b && "number" == typeof a.length;
}, p = function(a) {
  return "string" == typeof a;
}, t = function(a) {
  return "number" == typeof a;
}, ua = function(a) {
  return "function" == qa(a);
}, va = function(a) {
  var b = typeof a;
  return "object" == b && null != a || "function" == b;
}, wa = "closure_uid_" + (1e9 * Math.random() >>> 0), xa = 0, ya = function(a, b, c) {
  return a.call.apply(a.bind, arguments);
}, za = function(a, b, c) {
  if (!a) {
    throw Error();
  }
  if (2 < arguments.length) {
    var e = Array.prototype.slice.call(arguments, 2);
    return function() {
      var c = Array.prototype.slice.call(arguments);
      Array.prototype.unshift.apply(c, e);
      return a.apply(b, c);
    };
  }
  return function() {
    return a.apply(b, arguments);
  };
}, u = function(a, b, c) {
  u = Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? ya : za;
  return u.apply(null, arguments);
}, Aa = function(a, b) {
  var c = Array.prototype.slice.call(arguments, 1);
  return function() {
    var b = c.slice();
    b.push.apply(b, arguments);
    return a.apply(this, b);
  };
}, v = Date.now || function() {
  return +new Date;
}, w = function(a, b) {
  function c() {
  }
  c.prototype = b.prototype;
  a.T = b.prototype;
  a.prototype = new c;
  a.prototype.constructor = a;
  a.Oia = function(a, c, g) {
    for (var e = Array(arguments.length - 2), f = 2;f < arguments.length;f++) {
      e[f - 2] = arguments[f];
    }
    return b.prototype[c].apply(a, e);
  };
};
var chrome = chrome || window.chrome || {};
chrome.cast = chrome.cast || {};
chrome.cast.media = chrome.cast.media || {};
var Ba = function(a) {
  if (Error.captureStackTrace) {
    Error.captureStackTrace(this, Ba);
  } else {
    var b = Error().stack;
    b && (this.stack = b);
  }
  a && (this.message = String(a));
};
w(Ba, Error);
Ba.prototype.name = "CustomError";
var Ca;
var Da = function(a, b) {
  return 0 == a.lastIndexOf(b, 0);
}, Ea = function(a, b) {
  return a.toLowerCase() == b.toLowerCase();
}, Fa = function(a, b) {
  for (var c = a.split("%s"), e = "", f = Array.prototype.slice.call(arguments, 1);f.length && 1 < c.length;) {
    e += c.shift() + f.shift();
  }
  return e + c.join("%s");
}, Ga = function(a) {
  return /^[\s\xa0]*$/.test(a);
}, Ha = String.prototype.trim ? function(a) {
  return a.trim();
} : function(a) {
  return a.replace(/^[\s\xa0]+|[\s\xa0]+$/g, "");
}, Ia = /&/g, Ja = /</g, Ka = />/g, La = /"/g, Ma = /'/g, Na = /\x00/g, Oa = /[\x00&<>"']/, Pa = function(a) {
  return null == a ? "" : String(a);
}, Qa = function(a) {
  return Array.prototype.join.call(arguments, "");
}, Ra = function() {
  return Math.floor(2147483648 * Math.random()).toString(36) + Math.abs(Math.floor(2147483648 * Math.random()) ^ v()).toString(36);
}, Ta = function(a, b) {
  var c = 0;
  a = Ha(String(a)).split(".");
  b = Ha(String(b)).split(".");
  for (var e = Math.max(a.length, b.length), f = 0;0 == c && f < e;f++) {
    var g = a[f] || "", k = b[f] || "";
    do {
      g = /(\d*)(\D*)(.*)/.exec(g) || ["", "", "", ""];
      k = /(\d*)(\D*)(.*)/.exec(k) || ["", "", "", ""];
      if (0 == g[0].length && 0 == k[0].length) {
        break;
      }
      c = Sa(0 == g[1].length ? 0 : parseInt(g[1], 10), 0 == k[1].length ? 0 : parseInt(k[1], 10)) || Sa(0 == g[2].length, 0 == k[2].length) || Sa(g[2], k[2]);
      g = g[3];
      k = k[3];
    } while (0 == c);
  }
  return c;
}, Sa = function(a, b) {
  return a < b ? -1 : a > b ? 1 : 0;
}, Ua = function(a, b, c) {
  a = a.split(b);
  for (var e = [];0 < c && a.length;) {
    e.push(a.shift()), c--;
  }
  a.length && e.push(a.join(b));
  return e;
};
var Va = function(a, b) {
  b.unshift(a);
  Ba.call(this, Fa.apply(null, b));
  b.shift();
};
w(Va, Ba);
Va.prototype.name = "AssertionError";
var Wa = function(a, b, c, e) {
  var f = "Assertion failed";
  if (c) {
    var f = f + (": " + c), g = e;
  } else {
    a && (f += ": " + a, g = b);
  }
  throw new Va("" + f, g || []);
}, x = function(a, b, c) {
  a || Wa("", null, b, Array.prototype.slice.call(arguments, 2));
  return a;
}, Xa = function(a, b) {
  throw new Va("Failure" + (a ? ": " + a : ""), Array.prototype.slice.call(arguments, 1));
}, Ya = function(a, b, c) {
  t(a) || Wa("Expected number but got %s: %s.", [qa(a), a], b, Array.prototype.slice.call(arguments, 2));
  return a;
}, Za = function(a, b, c) {
  p(a) || Wa("Expected string but got %s: %s.", [qa(a), a], b, Array.prototype.slice.call(arguments, 2));
  return a;
}, $a = function(a, b, c) {
  ua(a) || Wa("Expected function but got %s: %s.", [qa(a), a], b, Array.prototype.slice.call(arguments, 2));
  return a;
}, ab = function(a, b, c) {
  va(a) || Wa("Expected object but got %s: %s.", [qa(a), a], b, Array.prototype.slice.call(arguments, 2));
  return a;
}, bb = function(a, b, c) {
  sa(a) || Wa("Expected array but got %s: %s.", [qa(a), a], b, Array.prototype.slice.call(arguments, 2));
  return a;
}, db = function(a, b, c, e) {
  a instanceof b || Wa("Expected instanceof %s but got %s.", [cb(b), cb(a)], c, Array.prototype.slice.call(arguments, 3));
  return a;
}, cb = function(a) {
  return a instanceof Function ? a.displayName || a.name || "unknown type name" : a instanceof Object ? a.constructor.displayName || a.constructor.name || Object.prototype.toString.call(a) : null === a ? "null" : typeof a;
};
var eb = function(a) {
  return a[a.length - 1];
}, fb = Array.prototype.indexOf ? function(a, b, c) {
  x(null != a.length);
  return Array.prototype.indexOf.call(a, b, c);
} : function(a, b, c) {
  c = null == c ? 0 : 0 > c ? Math.max(0, a.length + c) : c;
  if (p(a)) {
    return p(b) && 1 == b.length ? a.indexOf(b, c) : -1;
  }
  for (;c < a.length;c++) {
    if (c in a && a[c] === b) {
      return c;
    }
  }
  return -1;
}, gb = Array.prototype.lastIndexOf ? function(a, b, c) {
  x(null != a.length);
  return Array.prototype.lastIndexOf.call(a, b, null == c ? a.length - 1 : c);
} : function(a, b, c) {
  c = null == c ? a.length - 1 : c;
  0 > c && (c = Math.max(0, a.length + c));
  if (p(a)) {
    return p(b) && 1 == b.length ? a.lastIndexOf(b, c) : -1;
  }
  for (;0 <= c;c--) {
    if (c in a && a[c] === b) {
      return c;
    }
  }
  return -1;
}, y = Array.prototype.forEach ? function(a, b, c) {
  x(null != a.length);
  Array.prototype.forEach.call(a, b, c);
} : function(a, b, c) {
  for (var e = a.length, f = p(a) ? a.split("") : a, g = 0;g < e;g++) {
    g in f && b.call(c, f[g], g, a);
  }
}, hb = function(a, b, c) {
  for (var e = p(a) ? a.split("") : a, f = a.length - 1;0 <= f;--f) {
    f in e && b.call(c, e[f], f, a);
  }
}, ib = Array.prototype.filter ? function(a, b, c) {
  x(null != a.length);
  return Array.prototype.filter.call(a, b, c);
} : function(a, b, c) {
  for (var e = a.length, f = [], g = 0, k = p(a) ? a.split("") : a, q = 0;q < e;q++) {
    if (q in k) {
      var r = k[q];
      b.call(c, r, q, a) && (f[g++] = r);
    }
  }
  return f;
}, z = Array.prototype.map ? function(a, b, c) {
  x(null != a.length);
  return Array.prototype.map.call(a, b, c);
} : function(a, b, c) {
  for (var e = a.length, f = Array(e), g = p(a) ? a.split("") : a, k = 0;k < e;k++) {
    k in g && (f[k] = b.call(c, g[k], k, a));
  }
  return f;
}, jb = Array.prototype.some ? function(a, b, c) {
  x(null != a.length);
  return Array.prototype.some.call(a, b, c);
} : function(a, b, c) {
  for (var e = a.length, f = p(a) ? a.split("") : a, g = 0;g < e;g++) {
    if (g in f && b.call(c, f[g], g, a)) {
      return !0;
    }
  }
  return !1;
}, kb = Array.prototype.every ? function(a, b, c) {
  x(null != a.length);
  return Array.prototype.every.call(a, b, c);
} : function(a, b, c) {
  for (var e = a.length, f = p(a) ? a.split("") : a, g = 0;g < e;g++) {
    if (g in f && !b.call(c, f[g], g, a)) {
      return !1;
    }
  }
  return !0;
}, mb = function(a, b, c) {
  b = lb(a, b, c);
  return 0 > b ? null : p(a) ? a.charAt(b) : a[b];
}, lb = function(a, b, c) {
  for (var e = a.length, f = p(a) ? a.split("") : a, g = 0;g < e;g++) {
    if (g in f && b.call(c, f[g], g, a)) {
      return g;
    }
  }
  return -1;
}, ob = function(a, b, c) {
  a: {
    for (var e = p(a) ? a.split("") : a, f = a.length - 1;0 <= f;f--) {
      if (f in e && b.call(c, e[f], f, a)) {
        b = f;
        break a;
      }
    }
    b = -1;
  }
  return 0 > b ? null : p(a) ? a.charAt(b) : a[b];
}, pb = function(a, b) {
  return 0 <= fb(a, b);
}, qb = function(a) {
  if (!sa(a)) {
    for (var b = a.length - 1;0 <= b;b--) {
      delete a[b];
    }
  }
  a.length = 0;
}, sb = function(a, b, c) {
  var e;
  2 == arguments.length || 0 > (e = fb(a, c)) ? a.push(b) : rb(a, e, 0, b);
}, ub = function(a, b) {
  b = fb(a, b);
  var c;
  (c = 0 <= b) && tb(a, b);
  return c;
}, tb = function(a, b) {
  x(null != a.length);
  return 1 == Array.prototype.splice.call(a, b, 1).length;
}, vb = function(a, b, c) {
  b = lb(a, b, c);
  return 0 <= b ? (tb(a, b), !0) : !1;
}, wb = function(a, b, c) {
  var e = 0;
  hb(a, function(f, g) {
    b.call(c, f, g, a) && tb(a, g) && e++;
  });
  return e;
}, xb = function(a) {
  return Array.prototype.concat.apply(Array.prototype, arguments);
}, B = function(a) {
  var b = a.length;
  if (0 < b) {
    for (var c = Array(b), e = 0;e < b;e++) {
      c[e] = a[e];
    }
    return c;
  }
  return [];
}, yb = function(a, b) {
  for (var c = 1;c < arguments.length;c++) {
    var e = arguments[c];
    if (ta(e)) {
      var f = a.length || 0, g = e.length || 0;
      a.length = f + g;
      for (var k = 0;k < g;k++) {
        a[f + k] = e[k];
      }
    } else {
      a.push(e);
    }
  }
}, rb = function(a, b, c, e) {
  x(null != a.length);
  return Array.prototype.splice.apply(a, zb(arguments, 1));
}, zb = function(a, b, c) {
  x(null != a.length);
  return 2 >= arguments.length ? Array.prototype.slice.call(a, b) : Array.prototype.slice.call(a, b, c);
}, Bb = function(a, b) {
  a.sort(b || Ab);
}, Cb = function(a, b, c) {
  var e = c || Ab;
  Bb(a, function(a, c) {
    return e(b(a), b(c));
  });
}, Db = function(a, b, c) {
  Cb(a, function(a) {
    return a[b];
  }, c);
}, Fb = function(a, b, c) {
  if (!ta(a) || !ta(b) || a.length != b.length) {
    return !1;
  }
  var e = a.length;
  c = c || Eb;
  for (var f = 0;f < e;f++) {
    if (!c(a[f], b[f])) {
      return !1;
    }
  }
  return !0;
}, Ab = function(a, b) {
  return a > b ? 1 : a < b ? -1 : 0;
}, Eb = function(a, b) {
  return a === b;
}, Gb = function(a, b, c) {
  var e = {};
  y(a, function(f, g) {
    e[b.call(c, f, g, a)] = f;
  });
  return e;
};
var Hb = function(a, b, c) {
  for (var e in a) {
    b.call(c, a[e], e, a);
  }
}, Ib = function(a, b, c) {
  for (var e in a) {
    if (b.call(c, a[e], e, a)) {
      return !0;
    }
  }
  return !1;
}, Jb = function(a) {
  var b = [], c = 0, e;
  for (e in a) {
    b[c++] = a[e];
  }
  return b;
}, Kb = function(a) {
  var b = [], c = 0, e;
  for (e in a) {
    b[c++] = e;
  }
  return b;
}, Lb = function(a, b) {
  for (var c in a) {
    if (a[c] == b) {
      return !0;
    }
  }
  return !1;
}, Mb = function(a, b, c) {
  a: {
    for (var e in a) {
      if (b.call(c, a[e], e, a)) {
        b = e;
        break a;
      }
    }
    b = void 0;
  }
  return b && a[b];
}, Nb = function(a) {
  for (var b in a) {
    return !1;
  }
  return !0;
}, Ob = function(a) {
  for (var b in a) {
    delete a[b];
  }
}, Pb = function(a, b, c) {
  return b in a ? a[b] : a[b] = c;
}, Qb = function(a) {
  var b = {}, c;
  for (c in a) {
    b[c] = a[c];
  }
  return b;
}, Rb = function(a) {
  var b = qa(a);
  if ("object" == b || "array" == b) {
    if (ua(a.clone)) {
      return a.clone();
    }
    var b = "array" == b ? [] : {}, c;
    for (c in a) {
      b[c] = Rb(a[c]);
    }
    return b;
  }
  return a;
}, Sb = function(a) {
  var b = {}, c;
  for (c in a) {
    b[a[c]] = c;
  }
  return b;
}, Tb = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" "), Ub = function(a, b) {
  for (var c, e, f = 1;f < arguments.length;f++) {
    e = arguments[f];
    for (c in e) {
      a[c] = e[c];
    }
    for (var g = 0;g < Tb.length;g++) {
      c = Tb[g], Object.prototype.hasOwnProperty.call(e, c) && (a[c] = e[c]);
    }
  }
};
var Vb;
a: {
  var Wb = h.navigator;
  if (Wb) {
    var Xb = Wb.userAgent;
    if (Xb) {
      Vb = Xb;
      break a;
    }
  }
  Vb = "";
}
var C = function(a) {
  return -1 != Vb.indexOf(a);
};
var Yb = function() {
  return (C("Chrome") || C("CriOS")) && !C("Edge");
};
var Zb = function() {
  return C("iPhone") && !C("iPod") && !C("iPad");
};
var $b = function(a) {
  $b[" "](a);
  return a;
};
$b[" "] = n;
var ac = function(a, b) {
  try {
    return $b(a[b]), !0;
  } catch (c) {
  }
  return !1;
}, bc = function(a, b, c, e) {
  e = e ? e(b) : b;
  return Object.prototype.hasOwnProperty.call(a, e) ? a[e] : a[e] = c(b);
};
var cc = C("Opera"), dc = C("Trident") || C("MSIE"), ec = C("Edge"), fc = C("Gecko") && !(-1 != Vb.toLowerCase().indexOf("webkit") && !C("Edge")) && !(C("Trident") || C("MSIE")) && !C("Edge"), gc = -1 != Vb.toLowerCase().indexOf("webkit") && !C("Edge"), hc = gc && C("Mobile"), ic = h.navigator || null, jc = ic && ic.platform || "", kc = C("Macintosh"), lc = C("Windows"), mc = C("Linux") || C("CrOS"), nc = C("Android"), oc = Zb(), pc = C("iPad"), qc = C("iPod"), rc = function() {
  var a = h.document;
  return a ? a.documentMode : void 0;
}, sc;
a: {
  var tc = "", uc = function() {
    var a = Vb;
    if (fc) {
      return /rv\:([^\);]+)(\)|;)/.exec(a);
    }
    if (ec) {
      return /Edge\/([\d\.]+)/.exec(a);
    }
    if (dc) {
      return /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);
    }
    if (gc) {
      return /WebKit\/(\S+)/.exec(a);
    }
    if (cc) {
      return /(?:Version)[ \/]?(\S+)/.exec(a);
    }
  }();
  uc && (tc = uc ? uc[1] : "");
  if (dc) {
    var vc = rc();
    if (null != vc && vc > parseFloat(tc)) {
      sc = String(vc);
      break a;
    }
  }
  sc = tc;
}
var wc = sc, xc = {}, yc = function(a) {
  return bc(xc, a, function() {
    return 0 <= Ta(wc, a);
  });
}, zc;
var Ac = h.document;
zc = Ac && dc ? rc() || ("CSS1Compat" == Ac.compatMode ? parseInt(wc, 10) : 5) : void 0;
var Bc = function(a) {
  this.ua = a;
}, D = function(a) {
  var b = Cc.get(a);
  b || (b = new Bc(a), Cc.set(a, b));
  return b;
}, Fc = function(a) {
  a.level >= Dc && Ec.forEach(function(b) {
    return b(a);
  });
};
d = Bc.prototype;
d.log = function(a, b, c) {
  if (a >= Dc) {
    "function" == typeof b && (b = b());
    var e = {m:this.ua, level:a, time:Date.now(), message:b, pg:c};
    Ec.forEach(function(a) {
      return a(e);
    });
  }
};
d.error = function(a, b) {
  this.log(3, a, b);
};
d.l = function(a, b) {
  this.log(2, a, b);
};
d.info = function(a, b) {
  this.log(1, a, b);
};
d.w = function(a, b) {
  this.log(0, a, b);
};
var Hc = function(a, b) {
  a = Gc.indexOf(a);
  return -1 == a ? b : a;
}, Ic = function(a) {
  return 600 >= a ? 0 : 850 >= a ? 1 : 950 >= a ? 2 : 3;
}, Ec = [], Cc = new Map, Gc = ["FINE", "INFO", "WARNING", "SEVERE"], Dc = 1;
var Jc = function() {
  var a = this;
  this.promise = new Promise(function(b, c) {
    a.G7 = b;
    a.Y6 = c;
  });
};
Jc.prototype.resolve = function(a) {
  this.G7(a);
};
Jc.prototype.reject = function(a) {
  this.Y6(a);
};
var Kc = /^(?:([^:/?#.]+):)?(?:\/\/(?:([^/?#]*)@)?([^/#?]*?)(?::([0-9]+))?(?=[/#?]|$))?([^?#]+)?(?:\?([^#]*))?(?:#([\s\S]*))?$/, Lc = function(a, b) {
  return a ? b ? decodeURI(a) : decodeURIComponent(a) : a;
}, Mc = function(a, b) {
  if (a) {
    a = a.split("&");
    for (var c = 0;c < a.length;c++) {
      var e = a[c].indexOf("="), f, g = null;
      0 <= e ? (f = a[c].substring(0, e), g = a[c].substring(e + 1)) : f = a[c];
      b(f, g ? decodeURIComponent(g.replace(/\+/g, " ")) : "");
    }
  }
}, Nc = function(a, b, c) {
  a = [a, "&", b];
  null != c && a.push("=", encodeURIComponent(String(c)));
  a[1] && (c = a[0], b = c.indexOf("#"), 0 <= b && (a.push(c.substr(b)), a[0] = c = c.substr(0, b)), b = c.indexOf("?"), 0 > b ? a[1] = "?" : b == c.length - 1 && (a[1] = void 0));
  return a.join("");
}, Pc = /#|$/, Qc = function(a, b) {
  var c = a.search(Pc), e;
  a: {
    e = 0;
    for (var f = b.length;0 <= (e = a.indexOf(b, e)) && e < c;) {
      var g = a.charCodeAt(e - 1);
      if (38 == g || 63 == g) {
        if (g = a.charCodeAt(e + f), !g || 61 == g || 38 == g || 35 == g) {
          break a;
        }
      }
      e += f + 1;
    }
    e = -1;
  }
  if (0 > e) {
    return null;
  }
  f = a.indexOf("&", e);
  if (0 > f || f > c) {
    f = c;
  }
  e += b.length + 1;
  return decodeURIComponent(a.substr(e, f - e).replace(/\+/g, " "));
};
var Rc = function() {
  this.jl = this.jl;
  this.Hj = this.Hj;
};
d = Rc.prototype;
d.jl = !1;
d.isDisposed = function() {
  return this.jl;
};
d.Qa = function() {
  this.jl || (this.jl = !0, this.U());
};
d.la = function(a) {
  this.xD(Aa(Sc, a));
};
d.xD = function(a, b) {
  this.jl ? l(b) ? a.call(b) : a() : (this.Hj || (this.Hj = []), this.Hj.push(l(b) ? u(a, b) : a));
};
d.U = function() {
  if (this.Hj) {
    for (;this.Hj.length;) {
      this.Hj.shift()();
    }
  }
};
var Sc = function(a) {
  a && "function" == typeof a.Qa && a.Qa();
};
var F = function(a, b) {
  this.type = a;
  this.currentTarget = this.target = b;
  this.defaultPrevented = this.Rj = !1;
  this.YL = !0;
};
F.prototype.stopPropagation = function() {
  this.Rj = !0;
};
F.prototype.preventDefault = function() {
  this.defaultPrevented = !0;
  this.YL = !1;
};
var Tc = !dc || 9 <= Number(zc), Uc = dc && !yc("9");
!gc || yc("528");
fc && yc("1.9b") || dc && yc("8") || cc && yc("9.5") || gc && yc("528");
fc && !yc("8") || dc && yc("9");
var Vc = function(a) {
  return gc ? "webkit" + a : cc ? "o" + a.toLowerCase() : a.toLowerCase();
}, Wc = Vc("AnimationStart"), Xc = Vc("AnimationEnd"), Yc = Vc("AnimationIteration"), Zc = Vc("TransitionEnd");
var $c = function(a, b) {
  F.call(this, a ? a.type : "");
  this.relatedTarget = this.currentTarget = this.target = null;
  this.charCode = this.keyCode = this.button = this.screenY = this.screenX = this.clientY = this.clientX = this.offsetY = this.offsetX = 0;
  this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = !1;
  this.Wn = this.state = null;
  a && this.init(a, b);
};
w($c, F);
$c.prototype.init = function(a, b) {
  var c = this.type = a.type, e = a.changedTouches ? a.changedTouches[0] : null;
  this.target = a.target || a.srcElement;
  this.currentTarget = b;
  (b = a.relatedTarget) ? fc && (ac(b, "nodeName") || (b = null)) : "mouseover" == c ? b = a.fromElement : "mouseout" == c && (b = a.toElement);
  this.relatedTarget = b;
  null === e ? (this.offsetX = gc || void 0 !== a.offsetX ? a.offsetX : a.layerX, this.offsetY = gc || void 0 !== a.offsetY ? a.offsetY : a.layerY, this.clientX = void 0 !== a.clientX ? a.clientX : a.pageX, this.clientY = void 0 !== a.clientY ? a.clientY : a.pageY, this.screenX = a.screenX || 0, this.screenY = a.screenY || 0) : (this.clientX = void 0 !== e.clientX ? e.clientX : e.pageX, this.clientY = void 0 !== e.clientY ? e.clientY : e.pageY, this.screenX = e.screenX || 0, this.screenY = e.screenY || 
  0);
  this.button = a.button;
  this.keyCode = a.keyCode || 0;
  this.charCode = a.charCode || ("keypress" == c ? a.keyCode : 0);
  this.ctrlKey = a.ctrlKey;
  this.altKey = a.altKey;
  this.shiftKey = a.shiftKey;
  this.metaKey = a.metaKey;
  this.state = a.state;
  this.Wn = a;
  a.defaultPrevented && this.preventDefault();
};
$c.prototype.stopPropagation = function() {
  $c.T.stopPropagation.call(this);
  this.Wn.stopPropagation ? this.Wn.stopPropagation() : this.Wn.cancelBubble = !0;
};
$c.prototype.preventDefault = function() {
  $c.T.preventDefault.call(this);
  var a = this.Wn;
  if (a.preventDefault) {
    a.preventDefault();
  } else {
    if (a.returnValue = !1, Uc) {
      try {
        if (a.ctrlKey || 112 <= a.keyCode && 123 >= a.keyCode) {
          a.keyCode = -1;
        }
      } catch (b) {
      }
    }
  }
};
var ad = "closure_listenable_" + (1e6 * Math.random() | 0), bd = function(a) {
  return !(!a || !a[ad]);
}, cd = 0;
var dd = function(a, b, c, e, f, g) {
  this.listener = a;
  this.proxy = b;
  this.src = c;
  this.type = e;
  this.capture = !!f;
  this.Jc = g;
  this.key = ++cd;
  this.removed = this.fr = !1;
};
dd.prototype.kt = function() {
  this.removed = !0;
  this.Jc = this.src = this.proxy = this.listener = null;
};
var ed = function(a) {
  this.src = a;
  this.bc = {};
  this.yq = 0;
};
d = ed.prototype;
d.add = function(a, b, c, e, f) {
  var g = a.toString();
  a = this.bc[g];
  a || (a = this.bc[g] = [], this.yq++);
  var k = fd(a, b, e, f);
  -1 < k ? (b = a[k], c || (b.fr = !1)) : (b = new dd(b, null, this.src, g, !!e, f), b.fr = c, a.push(b));
  return b;
};
d.remove = function(a, b, c, e) {
  a = a.toString();
  if (!(a in this.bc)) {
    return !1;
  }
  var f = this.bc[a];
  b = fd(f, b, c, e);
  return -1 < b ? (f[b].kt(), tb(f, b), 0 == f.length && (delete this.bc[a], this.yq--), !0) : !1;
};
d.FL = function(a) {
  var b = a.type;
  if (!(b in this.bc)) {
    return !1;
  }
  var c = ub(this.bc[b], a);
  c && (a.kt(), 0 == this.bc[b].length && (delete this.bc[b], this.yq--));
  return c;
};
d.removeAll = function(a) {
  a = a && a.toString();
  var b = 0, c;
  for (c in this.bc) {
    if (!a || c == a) {
      for (var e = this.bc[c], f = 0;f < e.length;f++) {
        ++b, e[f].kt();
      }
      delete this.bc[c];
      this.yq--;
    }
  }
  return b;
};
d.ro = function(a, b, c, e) {
  a = this.bc[a.toString()];
  var f = -1;
  a && (f = fd(a, b, c, e));
  return -1 < f ? a[f] : null;
};
d.hasListener = function(a, b) {
  var c = l(a), e = c ? a.toString() : "", f = l(b);
  return Ib(this.bc, function(a) {
    for (var g = 0;g < a.length;++g) {
      if (!(c && a[g].type != e || f && a[g].capture != b)) {
        return !0;
      }
    }
    return !1;
  });
};
var fd = function(a, b, c, e) {
  for (var f = 0;f < a.length;++f) {
    var g = a[f];
    if (!g.removed && g.listener == b && g.capture == !!c && g.Jc == e) {
      return f;
    }
  }
  return -1;
};
var gd = "closure_lm_" + (1e6 * Math.random() | 0), hd = {}, id = 0, jd = function(a, b, c, e, f) {
  if (sa(b)) {
    for (var g = 0;g < b.length;g++) {
      jd(a, b[g], c, e, f);
    }
    return null;
  }
  c = kd(c);
  return bd(a) ? a.listen(b, c, e, f) : ld(a, b, c, !1, e, f);
}, ld = function(a, b, c, e, f, g) {
  if (!b) {
    throw Error("Invalid event type");
  }
  var k = !!f, q = nd(a);
  q || (a[gd] = q = new ed(a));
  c = q.add(b, c, e, f, g);
  if (c.proxy) {
    return c;
  }
  e = od();
  c.proxy = e;
  e.src = a;
  e.listener = c;
  if (a.addEventListener) {
    a.addEventListener(b.toString(), e, k);
  } else {
    if (a.attachEvent) {
      a.attachEvent(pd(b.toString()), e);
    } else {
      throw Error("addEventListener and attachEvent are unavailable.");
    }
  }
  id++;
  return c;
}, od = function() {
  var a = qd, b = Tc ? function(c) {
    return a.call(b.src, b.listener, c);
  } : function(c) {
    c = a.call(b.src, b.listener, c);
    if (!c) {
      return c;
    }
  };
  return b;
}, rd = function(a, b, c, e, f) {
  if (sa(b)) {
    for (var g = 0;g < b.length;g++) {
      rd(a, b[g], c, e, f);
    }
    return null;
  }
  c = kd(c);
  return bd(a) ? a.hp(b, c, e, f) : ld(a, b, c, !0, e, f);
}, sd = function(a, b, c, e, f) {
  if (sa(b)) {
    for (var g = 0;g < b.length;g++) {
      sd(a, b[g], c, e, f);
    }
    return null;
  }
  c = kd(c);
  if (bd(a)) {
    return a.Fc(b, c, e, f);
  }
  if (!a) {
    return !1;
  }
  if (a = nd(a)) {
    if (b = a.ro(b, c, !!e, f)) {
      return td(b);
    }
  }
  return !1;
}, td = function(a) {
  if (t(a) || !a || a.removed) {
    return !1;
  }
  var b = a.src;
  if (bd(b)) {
    return b.OO(a);
  }
  var c = a.type, e = a.proxy;
  b.removeEventListener ? b.removeEventListener(c, e, a.capture) : b.detachEvent && b.detachEvent(pd(c), e);
  id--;
  (c = nd(b)) ? (c.FL(a), 0 == c.yq && (c.src = null, b[gd] = null)) : a.kt();
  return !0;
}, ud = function(a, b) {
  if (!a) {
    return 0;
  }
  if (bd(a)) {
    return a.EL(b);
  }
  a = nd(a);
  if (!a) {
    return 0;
  }
  var c = 0;
  b = b && b.toString();
  for (var e in a.bc) {
    if (!b || e == b) {
      for (var f = a.bc[e].concat(), g = 0;g < f.length;++g) {
        td(f[g]) && ++c;
      }
    }
  }
  return c;
}, pd = function(a) {
  return a in hd ? hd[a] : hd[a] = "on" + a;
}, wd = function(a, b, c, e) {
  var f = !0;
  if (a = nd(a)) {
    if (b = a.bc[b.toString()]) {
      for (b = b.concat(), a = 0;a < b.length;a++) {
        var g = b[a];
        g && g.capture == c && !g.removed && (g = vd(g, e), f = f && !1 !== g);
      }
    }
  }
  return f;
}, vd = function(a, b) {
  var c = a.listener, e = a.Jc || a.src;
  a.fr && td(a);
  return c.call(e, b);
}, qd = function(a, b) {
  if (a.removed) {
    return !0;
  }
  if (!Tc) {
    var c = b || oa("window.event");
    b = new $c(c, this);
    var e = !0;
    if (!(0 > c.keyCode || void 0 != c.returnValue)) {
      a: {
        var f = !1;
        if (0 == c.keyCode) {
          try {
            c.keyCode = -1;
            break a;
          } catch (k) {
            f = !0;
          }
        }
        if (f || void 0 == c.returnValue) {
          c.returnValue = !0;
        }
      }
      c = [];
      for (f = b.currentTarget;f;f = f.parentNode) {
        c.push(f);
      }
      a = a.type;
      for (f = c.length - 1;!b.Rj && 0 <= f;f--) {
        b.currentTarget = c[f];
        var g = wd(c[f], a, !0, b), e = e && g;
      }
      for (f = 0;!b.Rj && f < c.length;f++) {
        b.currentTarget = c[f], g = wd(c[f], a, !1, b), e = e && g;
      }
    }
    return e;
  }
  return vd(a, new $c(b, this));
}, nd = function(a) {
  a = a[gd];
  return a instanceof ed ? a : null;
}, xd = "__closure_events_fn_" + (1e9 * Math.random() >>> 0), kd = function(a) {
  x(a, "Listener can not be null.");
  if (ua(a)) {
    return a;
  }
  x(a.handleEvent, "An object listener must have handleEvent method.");
  a[xd] || (a[xd] = function(b) {
    return a.handleEvent(b);
  });
  return a[xd];
};
var G = function() {
  Rc.call(this);
  this.lf = new ed(this);
  this.jR = this;
  this.vp = null;
};
w(G, Rc);
G.prototype[ad] = !0;
d = G.prototype;
d.xu = function(a) {
  this.vp = a;
};
d.addEventListener = function(a, b, c, e) {
  jd(this, a, b, c, e);
};
d.removeEventListener = function(a, b, c, e) {
  sd(this, a, b, c, e);
};
d.dispatchEvent = function(a) {
  this.ND();
  var b, c = this.vp;
  if (c) {
    b = [];
    for (var e = 1;c;c = c.vp) {
      b.push(c), x(1000 > ++e, "infinite loop");
    }
  }
  c = this.jR;
  e = a.type || a;
  if (p(a)) {
    a = new F(a, c);
  } else {
    if (a instanceof F) {
      a.target = a.target || c;
    } else {
      var f = a;
      a = new F(e, c);
      Ub(a, f);
    }
  }
  var f = !0, g;
  if (b) {
    for (var k = b.length - 1;!a.Rj && 0 <= k;k--) {
      g = a.currentTarget = b[k], f = g.Xr(e, !0, a) && f;
    }
  }
  a.Rj || (g = a.currentTarget = c, f = g.Xr(e, !0, a) && f, a.Rj || (f = g.Xr(e, !1, a) && f));
  if (b) {
    for (k = 0;!a.Rj && k < b.length;k++) {
      g = a.currentTarget = b[k], f = g.Xr(e, !1, a) && f;
    }
  }
  return f;
};
d.U = function() {
  G.T.U.call(this);
  this.EL();
  this.vp = null;
};
d.listen = function(a, b, c, e) {
  this.ND();
  return this.lf.add(String(a), b, !1, c, e);
};
d.hp = function(a, b, c, e) {
  return this.lf.add(String(a), b, !0, c, e);
};
d.Fc = function(a, b, c, e) {
  return this.lf.remove(String(a), b, c, e);
};
d.OO = function(a) {
  return this.lf.FL(a);
};
d.EL = function(a) {
  return this.lf ? this.lf.removeAll(a) : 0;
};
d.Xr = function(a, b, c) {
  a = this.lf.bc[String(a)];
  if (!a) {
    return !0;
  }
  a = a.concat();
  for (var e = !0, f = 0;f < a.length;++f) {
    var g = a[f];
    if (g && !g.removed && g.capture == b) {
      var k = g.listener, q = g.Jc || g.src;
      g.fr && this.OO(g);
      e = !1 !== k.call(q, c) && e;
    }
  }
  return e && 0 != c.YL;
};
d.ro = function(a, b, c, e) {
  return this.lf.ro(String(a), b, c, e);
};
d.hasListener = function(a, b) {
  return this.lf.hasListener(l(a) ? String(a) : void 0, b);
};
d.ND = function() {
  x(this.lf, "Event target is not initialized. Did you call the superclass (goog.events.EventTarget) constructor?");
};
var yd = function(a, b, c) {
  this.P1 = c;
  this.$T = a;
  this.SA = b;
  this.Dt = 0;
  this.Yd = null;
};
yd.prototype.get = function() {
  var a;
  0 < this.Dt ? (this.Dt--, a = this.Yd, this.Yd = a.next, a.next = null) : a = this.$T();
  return a;
};
yd.prototype.put = function(a) {
  this.SA(a);
  this.Dt < this.P1 && (this.Dt++, a.next = this.Yd, this.Yd = a);
};
var Ad = function(a) {
  return function() {
    return a;
  };
}, Bd = Ad(!0), Cd = function(a) {
  return a;
}, Dd = function(a) {
  return function() {
    return !a.apply(this, arguments);
  };
};
var Ed = function(a) {
  h.setTimeout(function() {
    throw a;
  }, 0);
}, Fd, Gd = function() {
  var a = h.MessageChannel;
  "undefined" === typeof a && "undefined" !== typeof window && window.postMessage && window.addEventListener && !C("Presto") && (a = function() {
    var a = document.createElement("IFRAME");
    a.style.display = "none";
    a.src = "";
    document.documentElement.appendChild(a);
    var b = a.contentWindow, a = b.document;
    a.open();
    a.write("");
    a.close();
    var c = "callImmediate" + Math.random(), e = "file:" == b.location.protocol ? "*" : b.location.protocol + "//" + b.location.host, a = u(function(a) {
      if (("*" == e || a.origin == e) && a.data == c) {
        this.port1.onmessage();
      }
    }, this);
    b.addEventListener("message", a, !1);
    this.port1 = {};
    this.port2 = {postMessage:function() {
      b.postMessage(c, e);
    }};
  });
  if ("undefined" !== typeof a && !C("Trident") && !C("MSIE")) {
    var b = new a, c = {}, e = c;
    b.port1.onmessage = function() {
      if (l(c.next)) {
        c = c.next;
        var a = c.jr;
        c.jr = null;
        a();
      }
    };
    return function(a) {
      e.next = {jr:a};
      e = e.next;
      b.port2.postMessage(0);
    };
  }
  return "undefined" !== typeof document && "onreadystatechange" in document.createElement("SCRIPT") ? function(a) {
    var b = document.createElement("SCRIPT");
    b.onreadystatechange = function() {
      b.onreadystatechange = null;
      b.parentNode.removeChild(b);
      b = null;
      a();
      a = null;
    };
    document.documentElement.appendChild(b);
  } : function(a) {
    h.setTimeout(a, 0);
  };
};
var Hd = function() {
  this.tv = this.Ek = null;
}, Jd = new yd(function() {
  return new Id;
}, function(a) {
  a.reset();
}, 100);
Hd.prototype.add = function(a, b) {
  var c = this.n_();
  c.set(a, b);
  this.tv ? this.tv.next = c : (x(!this.Ek), this.Ek = c);
  this.tv = c;
};
Hd.prototype.remove = function() {
  var a = null;
  this.Ek && (a = this.Ek, this.Ek = this.Ek.next, this.Ek || (this.tv = null), a.next = null);
  return a;
};
Hd.prototype.S7 = function(a) {
  Jd.put(a);
};
Hd.prototype.n_ = function() {
  return Jd.get();
};
var Id = function() {
  this.next = this.scope = this.tx = null;
};
Id.prototype.set = function(a, b) {
  this.tx = a;
  this.scope = b;
  this.next = null;
};
Id.prototype.reset = function() {
  this.next = this.scope = this.tx = null;
};
var Od = function(a, b) {
  Kd || Ld();
  Md || (Kd(), Md = !0);
  Nd.add(a, b);
}, Kd, Ld = function() {
  if (-1 != String(h.Promise).indexOf("[native code]")) {
    var a = h.Promise.resolve(void 0);
    Kd = function() {
      a.then(Pd);
    };
  } else {
    Kd = function() {
      var a = Pd;
      !ua(h.setImmediate) || h.Window && h.Window.prototype && !C("Edge") && h.Window.prototype.setImmediate == h.setImmediate ? (Fd || (Fd = Gd()), Fd(a)) : h.setImmediate(a);
    };
  }
}, Md = !1, Nd = new Hd, Pd = function() {
  for (var a;a = Nd.remove();) {
    try {
      a.tx.call(a.scope);
    } catch (b) {
      Ed(b);
    }
    Nd.S7(a);
  }
  Md = !1;
};
var Qd = function(a) {
  a.prototype.then = a.prototype.then;
  a.prototype.$goog_Thenable = !0;
}, Rd = function(a) {
  if (!a) {
    return !1;
  }
  try {
    return !!a.$goog_Thenable;
  } catch (b) {
    return !1;
  }
};
var Td = function(a, b) {
  this.F = 0;
  this.Qg = void 0;
  this.Nk = this.cg = this.Ob = null;
  this.Hs = this.ox = !1;
  if (a != n) {
    try {
      var c = this;
      a.call(b, function(a) {
        c.$j(2, a);
      }, function(a) {
        if (!(a instanceof Sd)) {
          try {
            if (a instanceof Error) {
              throw a;
            }
            throw Error("Promise rejected.");
          } catch (f) {
          }
        }
        c.$j(3, a);
      });
    } catch (e) {
      this.$j(3, e);
    }
  }
}, Ud = function() {
  this.next = this.context = this.im = this.Ij = this.Ki = null;
  this.xn = !1;
};
Ud.prototype.reset = function() {
  this.context = this.im = this.Ij = this.Ki = null;
  this.xn = !1;
};
var Vd = new yd(function() {
  return new Ud;
}, function(a) {
  a.reset();
}, 100), Wd = function(a, b, c) {
  var e = Vd.get();
  e.Ij = a;
  e.im = b;
  e.context = c;
  return e;
}, Xd = function(a) {
  if (a instanceof Td) {
    return a;
  }
  var b = new Td(n);
  b.$j(2, a);
  return b;
}, Yd = function(a) {
  return new Td(function(b, c) {
    c(a);
  });
}, $d = function(a, b, c) {
  Zd(a, b, c, null) || Od(Aa(b, a));
}, ae = function(a) {
  return new Td(function(b, c) {
    var e = a.length, f = [];
    if (e) {
      for (var g = function(a, c) {
        e--;
        f[a] = c;
        0 == e && b(f);
      }, k = function(a) {
        c(a);
      }, q = 0, r;q < a.length;q++) {
        r = a[q], $d(r, Aa(g, q), k);
      }
    } else {
      b(f);
    }
  });
}, be = function(a) {
  return new Td(function(b) {
    var c = a.length, e = [];
    if (c) {
      for (var f = function(a, f, g) {
        c--;
        e[a] = f ? {as:!0, value:g} : {as:!1, reason:g};
        0 == c && b(e);
      }, g = 0, k;g < a.length;g++) {
        k = a[g], $d(k, Aa(f, g, !0), Aa(f, g, !1));
      }
    } else {
      b(e);
    }
  });
}, H = function() {
  var a, b, c = new Td(function(c, f) {
    a = c;
    b = f;
  });
  return new ce(c, a, b);
};
Td.prototype.then = function(a, b, c) {
  null != a && $a(a, "opt_onFulfilled should be a function.");
  null != b && $a(b, "opt_onRejected should be a function. Did you pass opt_context as the second argument instead of the third?");
  return this.mD(ua(a) ? a : null, ua(b) ? b : null, c);
};
Qd(Td);
d = Td.prototype;
d.Vba = function(a, b, c) {
  null != a && $a(a, "opt_onFulfilled should be a function.");
  null != b && $a(b, "opt_onRejected should be a function. Did you pass opt_context as the second argument instead of the third?");
  this.Mv(Wd(a || n, b || null, c));
};
d.Um = function(a, b) {
  a = Wd(a, a, b);
  a.xn = !0;
  this.Mv(a);
  return this;
};
d.jb = function(a, b) {
  return this.mD(null, a, b);
};
d.cancel = function(a) {
  0 == this.F && Od(function() {
    var b = new Sd(a);
    this.iE(b);
  }, this);
};
d.iE = function(a) {
  0 == this.F && (this.Ob ? (this.Ob.MS(this, a), this.Ob = null) : this.$j(3, a));
};
d.MS = function(a, b) {
  if (this.cg) {
    for (var c = 0, e = null, f = null, g = this.cg;g && (g.xn || (c++, g.Ki == a && (e = g), !(e && 1 < c)));g = g.next) {
      e || (f = g);
    }
    e && (0 == this.F && 1 == c ? this.iE(b) : (f ? this.g7(f) : this.dL(), this.zF(e, 3, b)));
  }
};
d.Mv = function(a) {
  this.E0() || 2 != this.F && 3 != this.F || this.gM();
  this.s6(a);
};
d.mD = function(a, b, c) {
  var e = Wd(null, null, null);
  e.Ki = new Td(function(f, g) {
    e.Ij = a ? function(b) {
      try {
        var e = a.call(c, b);
        f(e);
      } catch (r) {
        g(r);
      }
    } : f;
    e.im = b ? function(a) {
      try {
        var e = b.call(c, a);
        !l(e) && a instanceof Sd ? g(a) : f(e);
      } catch (r) {
        g(r);
      }
    } : g;
  });
  e.Ki.Ob = this;
  this.Mv(e);
  return e.Ki;
};
d.lca = function(a) {
  x(1 == this.F);
  this.F = 0;
  this.$j(2, a);
};
d.mca = function(a) {
  x(1 == this.F);
  this.F = 0;
  this.$j(3, a);
};
d.$j = function(a, b) {
  0 == this.F && (this === b && (a = 3, b = new TypeError("Promise cannot resolve to itself")), this.F = 1, Zd(b, this.lca, this.mca, this) || (this.Qg = b, this.F = a, this.Ob = null, this.gM(), 3 != a || b instanceof Sd || de(this, b)));
};
var Zd = function(a, b, c, e) {
  if (a instanceof Td) {
    return a.Vba(b, c, e), !0;
  }
  if (Rd(a)) {
    return a.then(b, c, e), !0;
  }
  if (va(a)) {
    try {
      var f = a.then;
      if (ua(f)) {
        return ee(a, f, b, c, e), !0;
      }
    } catch (g) {
      return c.call(e, g), !0;
    }
  }
  return !1;
}, ee = function(a, b, c, e, f) {
  var g = !1, k = function(a) {
    g || (g = !0, c.call(f, a));
  }, q = function(a) {
    g || (g = !0, e.call(f, a));
  };
  try {
    b.call(a, k, q);
  } catch (r) {
    q(r);
  }
};
d = Td.prototype;
d.gM = function() {
  this.ox || (this.ox = !0, Od(this.XU, this));
};
d.E0 = function() {
  return !!this.cg;
};
d.s6 = function(a) {
  x(null != a.Ij);
  this.Nk ? this.Nk.next = a : this.cg = a;
  this.Nk = a;
};
d.dL = function() {
  var a = null;
  this.cg && (a = this.cg, this.cg = a.next, a.next = null);
  this.cg || (this.Nk = null);
  null != a && x(null != a.Ij);
  return a;
};
d.g7 = function(a) {
  x(this.cg);
  x(null != a);
  a.next == this.Nk && (this.Nk = a);
  a.next = a.next.next;
};
d.XU = function() {
  for (var a;a = this.dL();) {
    this.zF(a, this.F, this.Qg);
  }
  this.ox = !1;
};
d.zF = function(a, b, c) {
  3 == b && a.im && !a.xn && this.o7();
  if (a.Ki) {
    a.Ki.Ob = null, fe(a, b, c);
  } else {
    try {
      a.xn ? a.Ij.call(a.context) : fe(a, b, c);
    } catch (e) {
      ge.call(null, e);
    }
  }
  Vd.put(a);
};
var fe = function(a, b, c) {
  2 == b ? a.Ij.call(a.context, c) : a.im && a.im.call(a.context, c);
};
Td.prototype.o7 = function() {
  var a;
  for (a = this;a && a.Hs;a = a.Ob) {
    a.Hs = !1;
  }
};
var de = function(a, b) {
  a.Hs = !0;
  Od(function() {
    a.Hs && ge.call(null, b);
  });
}, ge = Ed, Sd = function(a) {
  Ba.call(this, a);
};
w(Sd, Ba);
Sd.prototype.name = "cancel";
var ce = function(a, b, c) {
  this.promise = a;
  this.resolve = b;
  this.reject = c;
};
var he = function(a, b) {
  G.call(this);
  this.yd = a || 1;
  this.Vm = b || h;
  this.kw = u(this.Xba, this);
  this.ez = v();
};
w(he, G);
d = he.prototype;
d.enabled = !1;
d.ab = null;
d.setInterval = function(a) {
  this.yd = a;
  this.ab && this.enabled ? (this.stop(), this.start()) : this.ab && this.stop();
};
d.Xba = function() {
  if (this.enabled) {
    var a = v() - this.ez;
    0 < a && a < 0.8 * this.yd ? this.ab = this.Vm.setTimeout(this.kw, this.yd - a) : (this.ab && (this.Vm.clearTimeout(this.ab), this.ab = null), this.uU(), this.enabled && (this.ab = this.Vm.setTimeout(this.kw, this.yd), this.ez = v()));
  }
};
d.uU = function() {
  this.dispatchEvent("tick");
};
d.start = function() {
  this.enabled = !0;
  this.ab || (this.ab = this.Vm.setTimeout(this.kw, this.yd), this.ez = v());
};
d.stop = function() {
  this.enabled = !1;
  this.ab && (this.Vm.clearTimeout(this.ab), this.ab = null);
};
d.U = function() {
  he.T.U.call(this);
  this.stop();
  delete this.Vm;
};
var ie = function(a, b, c) {
  if (ua(a)) {
    c && (a = u(a, c));
  } else {
    if (a && "function" == typeof a.handleEvent) {
      a = u(a.handleEvent, a);
    } else {
      throw Error("Invalid listener argument");
    }
  }
  return 2147483647 < Number(b) ? -1 : h.setTimeout(a, b || 0);
}, je = function(a) {
  h.clearTimeout(a);
}, ke = function(a, b) {
  var c = null;
  return (new Td(function(e, f) {
    c = ie(function() {
      e(b);
    }, a);
    -1 == c && f(Error("Failed to schedule timer."));
  })).jb(function(a) {
    je(c);
    throw a;
  });
};
var le = "StopIteration" in h ? h.StopIteration : {message:"StopIteration", stack:""}, me = function() {
};
me.prototype.next = function() {
  throw le;
};
me.prototype.$e = function() {
  return this;
};
var ne = function(a) {
  if (a instanceof me) {
    return a;
  }
  if ("function" == typeof a.$e) {
    return a.$e(!1);
  }
  if (ta(a)) {
    var b = 0, c = new me;
    c.next = function() {
      for (;;) {
        if (b >= a.length) {
          throw le;
        }
        if (b in a) {
          return a[b++];
        }
        b++;
      }
    };
    return c;
  }
  throw Error("Not implemented");
}, oe = function(a, b, c) {
  if (ta(a)) {
    try {
      y(a, b, c);
    } catch (e) {
      if (e !== le) {
        throw e;
      }
    }
  } else {
    a = ne(a);
    try {
      for (;;) {
        b.call(c, a.next(), void 0, a);
      }
    } catch (e) {
      if (e !== le) {
        throw e;
      }
    }
  }
}, pe = function(a, b, c) {
  a = ne(a);
  try {
    for (;;) {
      if (b.call(c, a.next(), void 0, a)) {
        return !0;
      }
    }
  } catch (e) {
    if (e !== le) {
      throw e;
    }
  }
  return !1;
}, qe = function(a) {
  if (ta(a)) {
    return B(a);
  }
  a = ne(a);
  var b = [];
  oe(a, function(a) {
    b.push(a);
  });
  return b;
};
var I = function(a, b) {
  this.mb = {};
  this.Da = [];
  this.zk = this.Va = 0;
  var c = arguments.length;
  if (1 < c) {
    if (c % 2) {
      throw Error("Uneven number of arguments");
    }
    for (var e = 0;e < c;e += 2) {
      this.set(arguments[e], arguments[e + 1]);
    }
  } else {
    a && this.addAll(a);
  }
};
d = I.prototype;
d.V = function() {
  return this.Va;
};
d.H = function() {
  this.Sk();
  for (var a = [], b = 0;b < this.Da.length;b++) {
    a.push(this.mb[this.Da[b]]);
  }
  return a;
};
d.ub = function() {
  this.Sk();
  return this.Da.concat();
};
d.Ma = function(a) {
  return re(this.mb, a);
};
d.$k = function(a) {
  for (var b = 0;b < this.Da.length;b++) {
    var c = this.Da[b];
    if (re(this.mb, c) && this.mb[c] == a) {
      return !0;
    }
  }
  return !1;
};
d.equals = function(a, b) {
  if (this === a) {
    return !0;
  }
  if (this.Va != a.V()) {
    return !1;
  }
  b = b || se;
  this.Sk();
  for (var c, e = 0;c = this.Da[e];e++) {
    if (!b(this.get(c), a.get(c))) {
      return !1;
    }
  }
  return !0;
};
var se = function(a, b) {
  return a === b;
};
d = I.prototype;
d.Bb = function() {
  return 0 == this.Va;
};
d.clear = function() {
  this.mb = {};
  this.zk = this.Va = this.Da.length = 0;
};
d.remove = function(a) {
  return re(this.mb, a) ? (delete this.mb[a], this.Va--, this.zk++, this.Da.length > 2 * this.Va && this.Sk(), !0) : !1;
};
d.Sk = function() {
  if (this.Va != this.Da.length) {
    for (var a = 0, b = 0;a < this.Da.length;) {
      var c = this.Da[a];
      re(this.mb, c) && (this.Da[b++] = c);
      a++;
    }
    this.Da.length = b;
  }
  if (this.Va != this.Da.length) {
    for (var e = {}, b = a = 0;a < this.Da.length;) {
      c = this.Da[a], re(e, c) || (this.Da[b++] = c, e[c] = 1), a++;
    }
    this.Da.length = b;
  }
};
d.get = function(a, b) {
  return re(this.mb, a) ? this.mb[a] : b;
};
d.set = function(a, b) {
  re(this.mb, a) || (this.Va++, this.Da.push(a), this.zk++);
  this.mb[a] = b;
};
d.addAll = function(a) {
  var b;
  a instanceof I ? (b = a.ub(), a = a.H()) : (b = Kb(a), a = Jb(a));
  for (var c = 0;c < b.length;c++) {
    this.set(b[c], a[c]);
  }
};
d.forEach = function(a, b) {
  for (var c = this.ub(), e = 0;e < c.length;e++) {
    var f = c[e], g = this.get(f);
    a.call(b, g, f, this);
  }
};
d.clone = function() {
  return new I(this);
};
d.b = function() {
  this.Sk();
  for (var a = {}, b = 0;b < this.Da.length;b++) {
    var c = this.Da[b];
    a[c] = this.mb[c];
  }
  return a;
};
d.$G = function() {
  return this.$e(!0);
};
d.sy = function() {
  return this.$e(!1);
};
d.$e = function(a) {
  this.Sk();
  var b = 0, c = this.zk, e = this, f = new me;
  f.next = function() {
    if (c != e.zk) {
      throw Error("The map has changed since the iterator was created");
    }
    if (b >= e.Da.length) {
      throw le;
    }
    var f = e.Da[b++];
    return a ? f : e.mb[f];
  };
  return f;
};
var re = function(a, b) {
  return Object.prototype.hasOwnProperty.call(a, b);
};
var te = function(a) {
  if (a.V && "function" == typeof a.V) {
    a = a.V();
  } else {
    if (ta(a) || p(a)) {
      a = a.length;
    } else {
      var b = 0, c;
      for (c in a) {
        b++;
      }
      a = b;
    }
  }
  return a;
}, ue = function(a) {
  if (a.H && "function" == typeof a.H) {
    return a.H();
  }
  if (p(a)) {
    return a.split("");
  }
  if (ta(a)) {
    for (var b = [], c = a.length, e = 0;e < c;e++) {
      b.push(a[e]);
    }
    return b;
  }
  return Jb(a);
}, ve = function(a) {
  if (a.ub && "function" == typeof a.ub) {
    return a.ub();
  }
  if (!a.H || "function" != typeof a.H) {
    if (ta(a) || p(a)) {
      var b = [];
      a = a.length;
      for (var c = 0;c < a;c++) {
        b.push(c);
      }
      return b;
    }
    return Kb(a);
  }
}, we = function(a) {
  return a.Bb && "function" == typeof a.Bb ? a.Bb() : ta(a) || p(a) ? 0 == a.length : Nb(a);
}, xe = function(a, b, c) {
  if (a.forEach && "function" == typeof a.forEach) {
    a.forEach(b, c);
  } else {
    if (ta(a) || p(a)) {
      y(a, b, c);
    } else {
      for (var e = ve(a), f = ue(a), g = f.length, k = 0;k < g;k++) {
        b.call(c, f[k], e && e[k], a);
      }
    }
  }
}, ye = function(a, b, c) {
  if ("function" == typeof a.map) {
    return a.map(b, c);
  }
  if (ta(a) || p(a)) {
    return z(a, b, c);
  }
  var e, f = ve(a), g = ue(a), k = g.length;
  if (f) {
    e = {};
    for (var q = 0;q < k;q++) {
      e[f[q]] = b.call(c, g[q], f[q], a);
    }
  } else {
    for (e = [], q = 0;q < k;q++) {
      e[q] = b.call(c, g[q], void 0, a);
    }
  }
  return e;
}, ze = function(a, b, c) {
  if ("function" == typeof a.every) {
    return a.every(b, c);
  }
  if (ta(a) || p(a)) {
    return kb(a, b, c);
  }
  for (var e = ve(a), f = ue(a), g = f.length, k = 0;k < g;k++) {
    if (!b.call(c, f[k], e && e[k], a)) {
      return !1;
    }
  }
  return !0;
};
var Ae = function(a) {
  this.mb = new I;
  a && this.addAll(a);
}, Be = function(a) {
  var b = typeof a;
  return "object" == b && a || "function" == b ? "o" + (a[wa] || (a[wa] = ++xa)) : b.substr(0, 1) + a;
};
d = Ae.prototype;
d.V = function() {
  return this.mb.V();
};
d.add = function(a) {
  this.mb.set(Be(a), a);
};
d.addAll = function(a) {
  a = ue(a);
  for (var b = a.length, c = 0;c < b;c++) {
    this.add(a[c]);
  }
};
d.removeAll = function(a) {
  a = ue(a);
  for (var b = a.length, c = 0;c < b;c++) {
    this.remove(a[c]);
  }
};
d.remove = function(a) {
  return this.mb.remove(Be(a));
};
d.clear = function() {
  this.mb.clear();
};
d.Bb = function() {
  return this.mb.Bb();
};
d.contains = function(a) {
  return this.mb.Ma(Be(a));
};
d.H = function() {
  return this.mb.H();
};
d.clone = function() {
  return new Ae(this);
};
d.equals = function(a) {
  return this.V() == te(a) && this.C1(a);
};
d.C1 = function(a) {
  var b = te(a);
  if (this.V() > b) {
    return !1;
  }
  !(a instanceof Ae) && 5 < b && (a = new Ae(a));
  return ze(this, function(b) {
    var c = a;
    return c.contains && "function" == typeof c.contains ? c.contains(b) : c.$k && "function" == typeof c.$k ? c.$k(b) : ta(c) || p(c) ? pb(c, b) : Lb(c, b);
  });
};
d.$e = function() {
  return this.mb.$e(!1);
};
var Ce = function(a, b, c) {
  this.e3 = a;
  this.WA = 0 < b ? b : 10;
  this.k2 = 0 < c ? c : 1;
  this.MJ = 0;
  this.br = 1;
  this.jK = 0;
  this.WI = !1;
  this.Zb = this.Ue = null;
};
d = Ce.prototype;
d.start = function() {
  if (null != this.Zb) {
    return Promise.reject(Error("Cannot call Retry.start more than once."));
  }
  this.Zb = new Jc;
  this.WL();
  return this.Zb.promise;
};
d.WL = function() {
  var a = this;
  this.Ue = null;
  this.WI || (this.jK++, this.e3().then(function(b) {
    a.mh();
    a.Zb.resolve(b);
  }, function() {
    a.jK >= a.k2 ? (a.mh(), a.Zb.reject(Error("Max attempts reached"))) : (a.Ue = ie(a.WL, a.WA, a), a.Dca());
  }));
};
d.Dca = function() {
  var a = this.WA * this.br;
  0 < this.MJ && (a = Math.min(a, this.MJ));
  this.WA = a;
};
d.pu = function(a) {
  x(1 <= a);
  this.br = a;
  return this;
};
d.abort = function() {
  this.mh();
  this.Zb.reject(Error("abort"));
};
d.mh = function() {
  null != this.Ue && (je(this.Ue), this.Ue = null);
  this.WI = !0;
};
var De = function(a, b, c, e, f) {
  c = "[" + b + "]: " + c + " " + e.rs() + " => " + e.Ra() + " (" + e.WH() + ")";
  e.$d() ? (a.w(c), f && (e = e.Dl()) && 0 < e.length && a.w("[" + b + "]: " + e)) : (c += ", error = " + e.Oh + " (" + e.aH() + ")", a.info(c));
};
var Ee = /<[^>]*>|&[^;]+;/g, Fe = function(a, b) {
  return b ? a.replace(Ee, "") : a;
}, Ge = /[A-Za-z\u00c0-\u00d6\u00d8-\u00f6\u00f8-\u02b8\u0300-\u0590\u0800-\u1fff\u200e\u2c00-\ufb1c\ufe00-\ufe6f\ufefd-\uffff]/, He = /^[^A-Za-z\u00c0-\u00d6\u00d8-\u00f6\u00f8-\u02b8\u0300-\u0590\u0800-\u1fff\u200e\u2c00-\ufb1c\ufe00-\ufe6f\ufefd-\uffff]*[\u0591-\u06ef\u06fa-\u07ff\u200f\ufb1d-\ufdff\ufe70-\ufefc]/, Ie = /^http:\/\/.*/, Je = /\s+/, Ke = /[\d\u06f0-\u06f9]/;
var Me = function() {
  this.bC = "";
  this.OQ = Le;
};
Me.prototype.Ll = !0;
Me.prototype.toString = function() {
  return "Const{" + this.bC + "}";
};
var Le = {}, Ne = function(a) {
  var b = new Me;
  b.bC = a;
  return b;
};
Ne("");
var Pe = function() {
  this.lL = "";
  this.JQ = Oe;
};
Pe.prototype.Ll = !0;
var Oe = {};
Pe.prototype.toString = function() {
  return "SafeScript{" + this.lL + "}";
};
var Qe = function(a) {
  if (a instanceof Pe && a.constructor === Pe && a.JQ === Oe) {
    return a.lL;
  }
  Xa("expected object of type SafeScript, got '" + a + "' of type " + qa(a));
  return "type_error:SafeScript";
};
var Se = function() {
  this.mL = "";
  this.KQ = Re;
};
Se.prototype.Ll = !0;
var Re = {};
Se.prototype.toString = function() {
  return "SafeStyle{" + this.mL + "}";
};
var Te = function(a) {
  if (a instanceof Se && a.constructor === Se && a.KQ === Re) {
    return a.mL;
  }
  Xa("expected object of type SafeStyle, got '" + a + "' of type " + qa(a));
  return "type_error:SafeStyle";
};
var Ve = function() {
  this.Cp = "";
  this.LQ = Ue;
};
Ve.prototype.Ll = !0;
Ve.prototype.jc = function() {
  return 1;
};
Ve.prototype.toString = function() {
  return "SafeUrl{" + this.Cp + "}";
};
var We = function(a) {
  if (a instanceof Ve && a.constructor === Ve && a.LQ === Ue) {
    return a.Cp;
  }
  Xa("expected object of type SafeUrl, got '" + a + "' of type " + qa(a));
  return "type_error:SafeUrl";
}, Ue = {};
var Ye = function() {
  this.rA = "";
  this.TQ = Xe;
};
Ye.prototype.Ll = !0;
Ye.prototype.jc = function() {
  return 1;
};
Ye.prototype.toString = function() {
  return "TrustedResourceUrl{" + this.rA + "}";
};
var Ze = function(a) {
  if (a instanceof Ye && a.constructor === Ye && a.TQ === Xe) {
    return a.rA;
  }
  Xa("expected object of type TrustedResourceUrl, got '" + a + "' of type " + qa(a));
  return "type_error:TrustedResourceUrl";
}, Xe = {};
var af = function() {
  this.Cp = "";
  this.IQ = $e;
  this.Tn = null;
};
af.prototype.jc = function() {
  return this.Tn;
};
af.prototype.Ll = !0;
af.prototype.toString = function() {
  return "SafeHtml{" + this.Cp + "}";
};
var bf = function(a) {
  if (a instanceof af && a.constructor === af && a.IQ === $e) {
    return a.Cp;
  }
  Xa("expected object of type SafeHtml, got '" + a + "' of type " + qa(a));
  return "type_error:SafeHtml";
}, $e = {};
var cf = function(a) {
  switch(a) {
    case 0:
      return "No Error";
    case 1:
      return "Access denied to content document";
    case 2:
      return "File not found";
    case 3:
      return "Firefox silently errored";
    case 4:
      return "Application custom error";
    case 5:
      return "An exception occurred";
    case 6:
      return "Http response at 400 or 500 level";
    case 7:
      return "Request was aborted";
    case 8:
      return "Request timed out";
    case 9:
      return "The resource is not available offline";
    default:
      return "Unrecognized error code";
  }
};
var df = h.JSON.parse, ef = h.JSON.stringify;
var ff = function(a, b) {
  var c = [], e = function(a, g, k) {
    var f = g + "  ";
    k = new Ae(k);
    try {
      if (l(a)) {
        if (null === a) {
          c.push("NULL");
        } else {
          if (p(a)) {
            c.push('"' + a.replace(/\n/g, "\n" + g) + '"');
          } else {
            if (ua(a)) {
              c.push(String(a).replace(/\n/g, "\n" + g));
            } else {
              if (va(a)) {
                if (k.contains(a)) {
                  c.push("*** reference loop detected ***");
                } else {
                  k.add(a);
                  c.push("{");
                  for (var r in a) {
                    if (b || !ua(a[r])) {
                      c.push("\n"), c.push(f), c.push(r + " = "), e(a[r], f, k);
                    }
                  }
                  c.push("\n" + g + "}");
                }
              } else {
                c.push(a);
              }
            }
          }
        }
      } else {
        c.push("undefined");
      }
    } catch (A) {
      c.push("*** " + A + " ***");
    }
  };
  e(a, "", new Ae);
  return c.join("");
}, gf = function(a) {
  var b;
  b = Error();
  if (Error.captureStackTrace) {
    Error.captureStackTrace(b, gf), b = String(b.stack);
  } else {
    try {
      throw b;
    } catch (f) {
      b = f;
    }
    b = (b = b.stack) ? String(b) : null;
  }
  if (b) {
    return b;
  }
  b = [];
  for (var c = arguments.callee.caller, e = 0;c && (!a || e < a);) {
    b.push(hf(c));
    b.push("()\n");
    try {
      c = c.caller;
    } catch (f) {
      b.push("[exception trying to get caller]\n");
      break;
    }
    e++;
    if (50 <= e) {
      b.push("[...long stack...]");
      break;
    }
  }
  a && e >= a ? b.push("[...reached max depth limit...]") : b.push("[end]");
  return b.join("");
}, hf = function(a) {
  if (jf[a]) {
    return jf[a];
  }
  a = String(a);
  if (!jf[a]) {
    var b = /function ([^\(]+)/.exec(a);
    jf[a] = b ? b[1] : "[Anonymous]";
  }
  return jf[a];
}, jf = {};
var kf = function(a, b, c, e, f) {
  this.reset(a, b, c, e, f);
};
kf.prototype.hk = 0;
kf.prototype.nx = null;
var lf = 0;
kf.prototype.reset = function(a, b, c, e, f) {
  this.hk = "number" == typeof f ? f : lf++;
  this.Yba = e || v();
  this.xj = a;
  this.Q2 = b;
  this.h2 = c;
  delete this.nx;
};
kf.prototype.A9 = function(a) {
  this.nx = a;
};
kf.prototype.vu = function(a) {
  this.xj = a;
};
kf.prototype.getMessage = function() {
  return this.Q2;
};
var mf = function(a) {
  this.ua = a;
  this.Lo = this.Cw = this.xj = this.Ob = null;
}, nf = function(a, b) {
  this.name = a;
  this.value = b;
};
nf.prototype.toString = function() {
  return this.name;
};
var of = new nf("SEVERE", 1000), pf = new nf("WARNING", 900), qf = new nf("INFO", 800), rf = new nf("CONFIG", 700), sf = new nf("FINE", 500), tf = new nf("FINER", 400), uf = new nf("ALL", 0);
d = mf.prototype;
d.getName = function() {
  return this.ua;
};
d.sR = function(a) {
  this.Lo || (this.Lo = []);
  this.Lo.push(a);
};
d.getParent = function() {
  return this.Ob;
};
d.getChildren = function() {
  this.Cw || (this.Cw = {});
  return this.Cw;
};
d.vu = function(a) {
  this.xj = a;
};
d.LG = function() {
  if (this.xj) {
    return this.xj;
  }
  if (this.Ob) {
    return this.Ob.LG();
  }
  Xa("Root logger has no level set.");
  return null;
};
d.ZI = function(a) {
  return a.value >= this.LG().value;
};
d.log = function(a, b, c) {
  this.ZI(a) && (ua(b) && (b = b()), this.qF(this.bY(a, b, c)));
};
d.bY = function(a, b, c) {
  a = new kf(a, String(b), this.ua);
  c && a.A9(c);
  return a;
};
d.SB = function(a, b) {
  this.log(of, a, b);
};
d.l = function(a, b) {
  this.log(pf, a, b);
};
d.info = function(a, b) {
  this.log(qf, a, b);
};
d.config = function(a, b) {
  this.log(rf, a, b);
};
d.w = function(a, b) {
  this.log(sf, a, b);
};
d.logRecord = function(a) {
  this.ZI(a.xj) && this.qF(a);
};
d.qF = function(a) {
  var b = "log:" + a.getMessage();
  h.console && (h.console.timeStamp ? h.console.timeStamp(b) : h.console.markTimeline && h.console.markTimeline(b));
  h.msWriteProfilerMark && h.msWriteProfilerMark(b);
  for (b = this;b;) {
    b.FS(a), b = b.getParent();
  }
};
d.FS = function(a) {
  if (this.Lo) {
    for (var b = 0, c;c = this.Lo[b];b++) {
      c(a);
    }
  }
};
d.L$ = function(a) {
  this.Ob = a;
};
d.pR = function(a, b) {
  this.getChildren()[a] = b;
};
var vf = {}, wf = null, xf = function() {
  wf || (wf = new mf(""), vf[""] = wf, wf.vu(rf));
}, yf = function(a) {
  xf();
  var b;
  if (!(b = vf[a])) {
    b = new mf(a);
    var c = a.lastIndexOf("."), e = a.substr(c + 1), c = yf(a.substr(0, c));
    c.pR(e, b);
    b.L$(c);
    vf[a] = b;
  }
  return b;
};
var zf = function(a, b) {
  a = yf(a);
  b && a && a.vu(b);
  return a;
}, Af = function(a, b, c, e) {
  a && a.log(b, c, e);
}, Bf = function(a, b, c) {
  a && a.SB(b, c);
}, J = function(a, b, c) {
  a && a.l(b, c);
}, K = function(a, b, c) {
  a && a.info(b, c);
}, L = function(a, b, c) {
  a && a.w(b, c);
};
var Cf = function() {
};
Cf.prototype.dE = null;
Cf.prototype.Ce = function() {
  return this.dE || (this.dE = this.d1());
};
var Df, Ef = function() {
};
w(Ef, Cf);
Ef.prototype.Jn = function() {
  var a = this.vH();
  return a ? new ActiveXObject(a) : new XMLHttpRequest;
};
Ef.prototype.d1 = function() {
  var a = {};
  this.vH() && (a[0] = !0, a[1] = !0);
  return a;
};
Ef.prototype.vH = function() {
  if (!this.FI && "undefined" == typeof XMLHttpRequest && "undefined" != typeof ActiveXObject) {
    for (var a = ["MSXML2.XMLHTTP.6.0", "MSXML2.XMLHTTP.3.0", "MSXML2.XMLHTTP", "Microsoft.XMLHTTP"], b = 0;b < a.length;b++) {
      var c = a[b];
      try {
        return new ActiveXObject(c), this.FI = c;
      } catch (e) {
      }
    }
    throw Error("Could not create ActiveXObject. ActiveX might be disabled, or MSXML might not be installed");
  }
  return this.FI;
};
Df = new Ef;
var Ff = function(a) {
  G.call(this);
  this.headers = new I;
  this.wv = a || null;
  this.eh = !1;
  this.vv = this.ba = null;
  this.qJ = this.ap = "";
  this.Oh = 0;
  this.Ph = "";
  this.pj = this.Dy = this.Os = this.kx = !1;
  this.Yg = 0;
  this.Te = null;
  this.rm = "";
  this.iv = this.i6 = this.bh = !1;
};
w(Ff, G);
Ff.prototype.a = zf("goog.net.XhrIo");
var Gf = /^https?$/i, Hf = ["POST", "PUT"], If = [], Jf = function(a, b, c, e, f, g, k) {
  var q = new Ff;
  If.push(q);
  b && q.listen("complete", b);
  q.hp("ready", q.gT);
  g && q.Bu(g);
  k && q.RB(k);
  q.send(a, c, e, f);
  return q;
};
d = Ff.prototype;
d.gT = function() {
  this.Qa();
  ub(If, this);
};
d.Bu = function(a) {
  this.Yg = Math.max(0, a);
};
d.KN = function(a) {
  this.rm = a;
};
d.RB = function(a) {
  this.bh = a;
};
d.send = function(a, b, c, e) {
  if (this.ba) {
    throw Error("[goog.net.XhrIo] Object is active with another request=" + this.ap + "; newUri=" + a);
  }
  b = b ? b.toUpperCase() : "GET";
  this.ap = a;
  this.Ph = "";
  this.Oh = 0;
  this.qJ = b;
  this.kx = !1;
  this.eh = !0;
  this.ba = this.ZT();
  this.vv = this.wv ? this.wv.Ce() : Df.Ce();
  this.ba.onreadystatechange = u(this.KK, this);
  this.i6 && "onprogress" in this.ba && (this.ba.onprogress = u(function(a) {
    this.HK(a, !0);
  }, this), this.ba.upload && (this.ba.upload.onprogress = u(this.HK, this)));
  try {
    L(this.a, this.qg("Opening Xhr")), this.Dy = !0, this.ba.open(b, String(a), !0), this.Dy = !1;
  } catch (g) {
    L(this.a, this.qg("Error opening Xhr: " + g.message));
    this.Nr(5, g);
    return;
  }
  a = c || "";
  var f = this.headers.clone();
  e && xe(e, function(a, b) {
    f.set(b, a);
  });
  e = mb(f.ub(), Kf);
  c = h.FormData && a instanceof h.FormData;
  !pb(Hf, b) || e || c || f.set("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
  f.forEach(function(a, b) {
    this.ba.setRequestHeader(b, a);
  }, this);
  this.rm && (this.ba.responseType = this.rm);
  "withCredentials" in this.ba && this.ba.withCredentials !== this.bh && (this.ba.withCredentials = this.bh);
  try {
    this.wE(), 0 < this.Yg && (this.iv = Lf(this.ba), L(this.a, this.qg("Will abort after " + this.Yg + "ms if incomplete, xhr2 " + this.iv)), this.iv ? (this.ba.timeout = this.Yg, this.ba.ontimeout = u(this.AO, this)) : this.Te = ie(this.AO, this.Yg, this)), L(this.a, this.qg("Sending request")), this.Os = !0, this.ba.send(a), this.Os = !1;
  } catch (g) {
    L(this.a, this.qg("Send error: " + g.message)), this.Nr(5, g);
  }
};
var Lf = function(a) {
  return dc && yc(9) && t(a.timeout) && l(a.ontimeout);
}, Kf = function(a) {
  return Ea("Content-Type", a);
};
d = Ff.prototype;
d.ZT = function() {
  return this.wv ? this.wv.Jn() : Df.Jn();
};
d.AO = function() {
  "undefined" != typeof na && this.ba && (this.Ph = "Timed out after " + this.Yg + "ms, aborting", this.Oh = 8, L(this.a, this.qg(this.Ph)), this.dispatchEvent("timeout"), this.abort(8));
};
d.Nr = function(a, b) {
  this.eh = !1;
  this.ba && (this.pj = !0, this.ba.abort(), this.pj = !1);
  this.Ph = b;
  this.Oh = a;
  this.mF();
  this.mr();
};
d.mF = function() {
  this.kx || (this.kx = !0, this.dispatchEvent("complete"), this.dispatchEvent("error"));
};
d.abort = function(a) {
  this.ba && this.eh && (L(this.a, this.qg("Aborting")), this.eh = !1, this.pj = !0, this.ba.abort(), this.pj = !1, this.Oh = a || 7, this.dispatchEvent("complete"), this.dispatchEvent("abort"), this.mr());
};
d.U = function() {
  this.ba && (this.eh && (this.eh = !1, this.pj = !0, this.ba.abort(), this.pj = !1), this.mr(!0));
  Ff.T.U.call(this);
};
d.KK = function() {
  this.isDisposed() || (this.Dy || this.Os || this.pj ? this.JK() : this.j4());
};
d.j4 = function() {
  this.JK();
};
d.JK = function() {
  if (this.eh && "undefined" != typeof na) {
    if (this.vv[1] && 4 == this.Ao() && 2 == this.Ra()) {
      L(this.a, this.qg("Local request error detected and ignored"));
    } else {
      if (this.Os && 4 == this.Ao()) {
        ie(this.KK, 0, this);
      } else {
        if (this.dispatchEvent("readystatechange"), this.Jy()) {
          L(this.a, this.qg("Request complete"));
          this.eh = !1;
          try {
            this.$d() ? (this.dispatchEvent("complete"), this.dispatchEvent("success")) : (this.Oh = 6, this.Ph = this.WH() + " [" + this.Ra() + "]", this.mF());
          } finally {
            this.mr();
          }
        }
      }
    }
  }
};
d.HK = function(a, b) {
  x("progress" === a.type, "goog.net.EventType.PROGRESS is of the same type as raw XHR progress.");
  this.dispatchEvent(Mf(a, "progress"));
  this.dispatchEvent(Mf(a, b ? "downloadprogress" : "uploadprogress"));
};
var Mf = function(a, b) {
  return {type:b, lengthComputable:a.lengthComputable, loaded:a.loaded, total:a.total};
};
d = Ff.prototype;
d.mr = function(a) {
  if (this.ba) {
    this.wE();
    var b = this.ba, c = this.vv[0] ? n : null;
    this.vv = this.ba = null;
    a || this.dispatchEvent("ready");
    try {
      b.onreadystatechange = c;
    } catch (e) {
      Bf(this.a, "Problem encountered resetting onreadystatechange: " + e.message);
    }
  }
};
d.wE = function() {
  this.ba && this.iv && (this.ba.ontimeout = null);
  t(this.Te) && (je(this.Te), this.Te = null);
};
d.Cf = function() {
  return !!this.ba;
};
d.Jy = function() {
  return 4 == this.Ao();
};
d.$d = function() {
  var a = this.Ra(), b;
  a: {
    switch(a) {
      case 200:
      case 201:
      case 202:
      case 204:
      case 206:
      case 304:
      case 1223:
        b = !0;
        break a;
      default:
        b = !1;
    }
  }
  return b || 0 === a && !this.o1();
};
d.o1 = function() {
  var a = String(this.ap).match(Kc)[1] || null;
  !a && h.self && h.self.location && (a = h.self.location.protocol, a = a.substr(0, a.length - 1));
  return Gf.test(a ? a.toLowerCase() : "");
};
d.Ao = function() {
  return this.ba ? this.ba.readyState : 0;
};
d.Ra = function() {
  try {
    return 2 < this.Ao() ? this.ba.status : -1;
  } catch (a) {
    return -1;
  }
};
d.WH = function() {
  try {
    return 2 < this.Ao() ? this.ba.statusText : "";
  } catch (a) {
    return L(this.a, "Can not get status: " + a.message), "";
  }
};
d.rs = function() {
  return String(this.ap);
};
d.Dl = function() {
  try {
    return this.ba ? this.ba.responseText : "";
  } catch (a) {
    return L(this.a, "Can not get responseText: " + a.message), "";
  }
};
d.IH = function() {
  try {
    return this.ba ? this.ba.responseXML : null;
  } catch (a) {
    return L(this.a, "Can not get responseXML: " + a.message), null;
  }
};
d.vZ = function(a) {
  if (this.ba) {
    var b = this.ba.responseText;
    a && 0 == b.indexOf(a) && (b = b.substring(a.length));
    return df(b);
  }
};
d.getResponseHeader = function(a) {
  if (this.ba && this.Jy()) {
    return a = this.ba.getResponseHeader(a), null === a ? void 0 : a;
  }
};
d.getAllResponseHeaders = function() {
  return this.ba && this.Jy() ? this.ba.getAllResponseHeaders() : "";
};
d.aH = function() {
  return p(this.Ph) ? this.Ph : String(this.Ph);
};
d.qg = function(a) {
  return a + " [" + this.qJ + " " + this.ap + " " + this.Ra() + "]";
};
var Nf = function(a, b, c) {
  this.source = a;
  this.type = b;
  this.message = c;
};
var Of = D("mr.DongleUtils"), Pf = function(a) {
  return "https://crash.corp.google.com/samples?stbtiq=" + a;
}, Qf = function(a, b, c) {
  var e = new Ff;
  e.KN("text");
  e.Bu(3E5);
  jd(e, "complete", function(a) {
    a = a.target;
    var e, f;
    a.$d() ? (e = "ok", f = Pf(b)) : (e = "error", f = "Unable to retrieve " + a.rs() + ", error = " + a.aH());
    c(e, f);
    a.Qa();
  });
  e.send("http://" + a + ":8008/setup/send_log_report", "POST", JSON.stringify({uuid:b}), {"Content-Type":"application/json"});
  return Pf(b);
}, Rf = null, Sf = function(a) {
  if (!p(a)) {
    return Promise.resolve();
  }
  if (Rf && Rf.ip == a && Rf.time > Date.now() - 36E5) {
    return Rf.version;
  }
  var b = new Jc;
  Rf = {version:b.promise, ip:a || "", time:Date.now()};
  Jf("http://" + a + ":8008/setup/eureka_info", function(a) {
    a = a.target;
    De(Of, "getBuildVersion", "GET", a, !1);
    if (a.$d()) {
      try {
        var c = JSON.parse(a.Dl());
        b.resolve(c.cast_build_revision || c.build_version);
      } catch (f) {
        b.resolve(void 0);
      }
    } else {
      b.resolve(void 0);
    }
  }, "GET", void 0, void 0, 3E3);
  return b.promise;
};

